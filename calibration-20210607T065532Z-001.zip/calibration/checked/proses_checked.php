<?php
include"../config/koneksi.php";
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysql_query("select *from employee where empname LIKE '%$q%'");
while($r = mysql_fetch_array($sql)) {
	$kode2_barang = $r['empname'];
	
	echo "$kode2_barang\n";
}
?>
