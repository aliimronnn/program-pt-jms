<?php
	session_start();
	session_destroy();
	//echo "<center>Anda telah sukses keluar system <b>[LOGOUT]</b>";
	//header('location:index_login.php');
	header('location:http://svr05:8080/jmsb/index2.php');
?>