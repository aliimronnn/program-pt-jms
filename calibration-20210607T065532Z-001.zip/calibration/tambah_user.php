<html>
<head>
	<title> Tambah User </title>
	
</head>
<body>
<?php 
include "koneksi/koneksi.php";
include "library.php";
include "fungsi_combobox.php";

?>
<h2>Tambah User</h2>
Note : username dan pasword tidak boleh sama dengan data yang sudah ada
<form name="form1" method=post action=index.php?menu=create_user>

<table>
          <tr><td>Username</td>     <td> : <input type=text name='username'></td></tr>
          <tr><td>Password</td>     <td> : <input type=text name='password'></td></tr>
          <tr><td>Nama Lengkap</td> <td> : <input type=text name='nama_lengkap' size=30></td></tr>  
          <tr><td>E-mail</td>       <td> : <input type=text name='email' size=30></td></tr>
          <tr><td>No.Telp/HP</td>   <td> : <input type=text name='no_telp' size=20></td></tr>
          <tr><td colspan=2><input type=submit value=Simpan>
                            <input type=button value=Batal onclick=self.history.back()></td></tr>
          </table>
</form>