<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.dokumen.value.length < mincar){
       alert("Document Type still empty!");
       form.dokumen.focus();
       return (false);
   }
   if (form.keterangan.value.length < mincar){
       alert("Description still empty!");
       form.keterangan.focus();
       return (false);
   }
   
   return (true);
}
</script>

<?php

$aksi="modul/mod_doc_code/aksi_doc_code.php";
switch(@$_GET['act']){

default:
echo "<h2>List Document Code</h2>
<p>&nbsp;</p>
<input type=button value='Add Document Code'  class='large blue super button'
onclick=\"window.location.href='?module=doc_code&act=tambahdoc_code';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Document Type</th><th>Code 1</th><th>Code 2</th><th>Action</th></tr><thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM doc_code ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td>
	<td>$r[keterangan]</td>
      	<td>$r[code1]</td>
      	<td>$r[code2]</td>
      	
        <td><a href='?module=doc_code&act=editdoc_code&id=$r[id]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=doc_code&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

// Form Tambah doc_code
case "tambahdoc_code":
echo "<h2>Add Document Code</h2>
<form method=POST action='$aksi?module=doc_code&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>ID Document</td><td>: <input type='text' name='dokumen' size='20' value='' ></td></tr>                
<tr><td>Code 1</td><td>: <input type='text' name='code1' size='20' value='' ></td></tr>                
<tr><td>Code 2</td><td>: <input type='text' name='code2' size='20' value='' ></td></tr>                
<tr><td>Description</td><td>: <input type='text' name='keterangan' size='80' value='' ></td></tr>                
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit doc_code 
case "editdoc_code":
$edit = mysqli_query($conn, "SELECT * FROM doc_code WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Modify Document Code</h2>
<form method=POST action='$aksi?module=doc_code&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>ID Document</td><td>: <span> $r[dokumen] </span></td></tr>                
<tr><td>Code 1</td><td>: <input type='text' name='code1' size='20' value='$r[code1]' ></td></tr>                
<tr><td>Code 2</td><td>: <input type='text' name='code2' size='20' value='$r[code2]' ></td></tr>                
<tr><td>Description</td><td>: <input type='text' name='keterangan' size='100' value='$r[keterangan]' ></td></tr>    
<tr><td colspan=2><input type=submit value=Update class='large blue super button'>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
?>
