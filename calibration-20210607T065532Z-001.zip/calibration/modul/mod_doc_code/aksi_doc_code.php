<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  $dokumen = htmlentities($_POST['dokumen']);
  $code1 = htmlentities($_POST['code1']);
  $code2 = htmlentities($_POST['code2']);
  $keterangan = htmlentities($_POST['keterangan']);

  // Input doc_code
  if ($module=='doc_code' AND $act=='input'){
  	        mysqli_query($conn, "INSERT INTO doc_code(dokumen,
					code1,
					code2,
					keterangan)
                                VALUES('$dokumen',
					'$code1',
					'$code2',
					'$keterangan')");
     header('location:../../index2.php?module='.$module);         
  }
  // Update doc_code  
  elseif ($module=='doc_code' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE doc_code SET  
					code1 = '$code1',
					code2 = '$code2',
					keterangan = '$keterangan'                                         
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index2.php?module='.$module);
  }
    
  // Delete doc_code  
  elseif ($module=='doc_code' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM doc_code WHERE id = '$_GET[id]'");
      header('location:../../index2.php?module='.$module);
            
  }
  
  }
?>
