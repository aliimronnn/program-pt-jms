<?php
$aksi="modul/mod_identitas/aksi_identitas.php";
$act=$_GET[act];
switch($act) {
	// Tampil identitas
	default:
	echo "<h2>Identitas Header</h2><br/>
		  <input type=button value='Tambah Identitas' onclick=\"window.location.href='?module=identitas&act=tambahidentitas';\" class='large blue super button'> 
		  <p>&nbsp;</p>";

echo "<table id=example class='pretty dataTable'>
<thead>
<tr>
	<th width=5px class=rounded-company>No.</th>
	<th>Judul</th>
	<th>Identitas</th>
	
	
	
	<th class=rounded-q4 align=center width=100px>Aksi</th>
</tr>
</thead>
<tbody>";

$tampil=mysql_query("SELECT * FROM identitas ORDER BY id ASC");
$no=$posisi+1;
while($r=mysql_fetch_array($tampil)){
		$tglhr = tgl_indo($r[tglhr]);
		
		echo "<tr><td>$no</td>
		          
						<td>$r[judul]</td>
				<td>$r[identitas]</td>
				
								
				<td><a href=?module=identitas&act=editidentitas&id=$r[id]><img src='images/edit.png' alt='edit' /></a>
				<a href=$aksi?module=identitas&act=hapus&id=$r[id]><img src='images/hapus.png' alt='hapus' /></a></td>
			</tr>";
	$no++;
}
echo "</tbody></table>";
break;


case "tambahidentitas":
$thn_skrg=date("Y");
echo "<h2>Tambah Jenis Pelayanan</h2><br/>
<form method=POST action='$aksi?module=identitas&act=input' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr>
	<td>Judul</td>
	<td> : </td><td><input type=text name='judul' size=60 maxlength=100></td>
</tr>
<tr>
	<td>Identitas</td>
	<td> : </td><td> <textarea name='identitas' id='loko' style='width: 1000px; height: 350px;'></textarea></td></td>
</tr>


		


<tr>
	<td colspan=3><input type=submit value=Simpan class='large blue super button'>
	<input type=button value=Batal onclick=self.history.back() class='large orange super button'>
	</td>
</tr>
</table>
</form>";
break;

case "editidentitas":
$edit=mysql_query("SELECT * FROM identitas WHERE id='$_GET[id]'");
$r=mysql_fetch_array($edit);

$thn_skrg=date("Y");
echo "<h2>Edit Judul Identitas</h2>
<form method=POST action='$aksi?module=identitas&act=update' enctype='multipart/form-data'>
<input type=hidden name=id value='$r[id]'><p>&nbsp;</p>
<table cellspacing=10 cellpadding=6>
<tr>
	<td>Judul</td>
	<td> : </td><td><input type=text name='judul' value='$r[judul]' size=60 maxlength=100></td>
</tr>
<tr>
	<td>Identitas</td>
	<td> : </td><td> <textarea name='identitas' id='loko' style='width: 1000px; height: 350px;'>$r[identitas]</textarea></td></td>
</tr>


		


<tr>
	<td colspan=3><input type=submit value=Update class='large blue super button'>
	<input type=button value=Batal onclick=self.history.back() class='large orange super button'>
	</td>
</tr>
</table>
</form>";
break;
}
?>