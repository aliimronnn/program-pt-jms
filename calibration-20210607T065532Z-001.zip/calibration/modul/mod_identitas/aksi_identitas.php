<?php
session_start();
include "../../config/koneksi.php";
$module=$_GET[module];
$act=$_GET[act];

// Hapus jenis_pelayanan
if ($module=='identitas' AND $act=='hapus') {
	mysql_query("DELETE FROM identitas WHERE id='$_GET[id]'");
	header('location:../../index2.php?module='.$module);

}

// Input jenis_pelayanan
elseif ($module=='identitas' AND $act=='input') {
	mysql_query("INSERT INTO identitas(judul,identitas) VALUES ('$_POST[judul]','$_POST[identitas]')");
	header('location:../../index2.php?module='.$module);

}

// Update jenis_pelayanan
elseif ($module=='identitas' AND $act=='update') {
	mysql_query("UPDATE identitas SET judul = '$_POST[judul]',
identitas='$_POST[identitas]' WHERE id='$_POST[id]'");
	header('location:../../index2.php?module='.$module);

}
?>