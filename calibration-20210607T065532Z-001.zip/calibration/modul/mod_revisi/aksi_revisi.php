<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  //$code_freq = htmlentities($_POST['code_freq']);
  //$days = htmlentities($_POST['days']);
$update_jmsb =$_POST['thn_jmsb'].'-'.$_POST['bln_jmsb'].'-'.$_POST['tgl_jmsb'];
$update_jmss =$_POST['thn_jmss'].'-'.$_POST['bln_jmss'].'-'.$_POST['tgl_jmss'];
$update_eksternal =$_POST['thn_eksternal'].'-'.$_POST['bln_eksternal'].'-'.$_POST['tgl_eksternal'];
  // Input revisi
  if ($module=='revisi' AND $act=='input'){
  	        mysqli_query($conn, "INSERT INTO revisi(code_freq,revisi,days)
                                VALUES('$_POST[code_freq]','$_POST[revisi]',
					'$_POST[days]')");
     header('location:../../index2.php?module='.$module);
            
  }
  
  // Update revisi  
  elseif ($module=='revisi' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE sectioncode SET  rev_jmsb = '$_POST[rev_jmsb]', 
										rev_jmss = '$_POST[rev_jmss]',				
										rev_eksternal = '$_POST[rev_eksternal]',
										update_jmsb = '$update_jmsb',
										update_jmss = '$update_jmss',
										update_eksternal = '$update_eksternal'
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index2.php?module=revisi');
  }
    
  // Delete revisi  
  elseif ($module=='revisi' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM revisi WHERE id = '$_GET[id]'");
      header('location:../../index2.php?module='.$module);
            
  }
  
  }
?>
