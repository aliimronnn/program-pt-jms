<script>
function confirmdelete(delUrl) {
  if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
    if (form.hari.value =="pilih"){
       alert("Day is Still Empty");            
       return (false);
   }
   
   return (true);
}
</script>

<?php
$aksi="modul/mod_revisi/aksi_revisi.php";
switch(@$_GET['act']){

default:
$qdir=mysqli_query($conn, "select *from sectioncode where id='$_SESSION[section]'");
$rdir=mysqli_fetch_array($qdir);
echo "

<h2 align=center>Setting Revision Date</h2><p>&nbsp;</p>

<form method=POST action='$aksi?module=revisi&act=update'  onsubmit='return validasi(this)'>
<input type='hidden' name='id' value='$rdir[id]'>
<table cellspacing=8 cellpadding=4 border=0 width=900px align=center>

<tr align=center>
<tr ><td height=30 width=200 align=center>
<h2>Last Update Internal JMSB</h2></td><td width=200 align=center>
<h2>Last Update Internal JMSS</h2></td><td width=200 align=center>
<h2>Last Update Eksternal</h2></td></tr>
<tr><td align=center>";
$get_tgl2=substr("$rdir[update_jmsb]",8,2);
combotgl(1,31,'tgl_jmsb',$get_tgl2);
$get_bln2=substr("$rdir[update_jmsb]",5,2);
combobln(1,12,'bln_jmsb',$get_bln2);
$get_thn2=substr("$rdir[update_jmsb]",0,4);
combothn(2010,$thn_sekarang,'thn_jmsb',$get_thn2);
echo "</td>

<td align=center>";
$get_tgl1=substr("$rdir[update_jmss]",8,2);
combotgl(1,31,'tgl_jmss',$get_tgl1);
$get_bln1=substr("$rdir[update_jmss]",5,2);
combobln(1,12,'bln_jmss',$get_bln1);
$get_thn1=substr("$rdir[update_jmss]",0,4);
combothn(2010,$thn_sekarang,'thn_jmss',$get_thn1);
echo "</td>
<td align=center>";
$get_tgl3=substr("$rdir[update_eksternal]",8,2);
combotgl(1,31,'tgl_eksternal',$get_tgl3);
$get_bln3=substr("$rdir[update_eksternal]",5,2);
combobln(1,12,'bln_eksternal',$get_bln3);
$get_thn3=substr("$rdir[update_eksternal]",0,4);
combothn(2010,$thn_sekarang,'thn_eksternal',$get_thn3);
echo "</td></tr>

<tr>
<tr><td>&nbsp;<br><br><br><br></td></tr>
<tr ><td height=30 width=200 align=center>
<h2>Last Revision No Internal JMSB</h2></td><td width=200 align=center>
<h2>Last Revision No Internal JMSS</h2></td><td width=200 align=center>
<h2>Last Revision No Eksternal</h2></td></tr>

<td align=center><input type='text' name='rev_jmsb' value='$rdir[rev_jmsb]' size='20' style='text-align: center'></td>
<td align=center><input type='text' name='rev_jmss' value='$rdir[rev_jmss]' size='20' style='text-align: center'></td>
<td align=center><input type='text' name='rev_eksternal' value='$rdir[rev_eksternal]' size='20' style='text-align: center'></td></tr>

</table>
<div align=center>
<br>
<input type=submit name=submit class='large blue super button' value='Update'>
</div>
</form>

";

break;

// Form Tambah revisi
case "tambahrevisi":
echo "<h2>New revisi Calibration</h2>
<form method=POST action='$aksi?module=revisi&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code revisi</td><td>: <input type='text' name='code_freq' size='30' value='' ></td></tr>                
<tr><td>revisi Name</td><td>: <input type='text' name='revisi' size='30' value='' ></td></tr>    
<tr><td>Total Mounth</td><td>: <input type='text' name='days' size='20' value='' ></td></tr>    
<tr><td colspan=2><input type=submit name=submit value=Save class='large Orange super button' >
<input type=button value=Cancel onclick=self.history.back() class='large Blue super button'></td></tr>
</table>
</form>";
break;

// Form Edit revisi 
case "editrevisi":
$edit = mysqli_query($conn, "SELECT * FROM revisi WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Data revisi</h2>
<form method=POST action='$aksi?module=revisi&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>revisi Code</td><td>: <input type='text' name='code_freq' size='30' value='$r[code_freq]' ></td></tr> 
<tr><td>revisi Name</td><td>: <input type='text' name='revisi' size='30' value='$r[revisi]' ></td></tr>                
<tr><td>Total Mounth</td><td>: <input type='text' name='days' size='30' value='$r[days]' ></td></tr> 
<tr><td colspan=2><input type=submit value=Update class='large Orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;
}
?>
