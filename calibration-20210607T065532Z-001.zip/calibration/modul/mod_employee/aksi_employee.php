<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";
  include "../../config/library.php";
  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  $sectioncode = htmlentities($_POST['sectioncode']);
  
  $empno = htmlentities($_POST['empno']);
  $empname = $_POST['empname'];
 // $datejoin = htmlentities($_POST['datejoin']);
 // $joindate=$_POST['bln_joindate'].'/'.$_POST['tgl_joindate'].'/'.$_POST['thn_joindate'];
  $hrempno = htmlentities($_POST['hrempno']);
  $hrempname = htmlentities($_POST['hrempname']);
  $hrgender = htmlentities($_POST['hrgender']);
  $hrposition = htmlentities($_POST['hrposition']);
  $supervisor = htmlentities($_POST['supervisor_no']);
  

  // Input employee
  if ($module=='employee' AND $act=='input'){
       
  //  $qcek  = mysql_query("select *from employee where empname='$_POST[empname]'");
    // $cek= mysql_fetch_array($qcek);
   //  if (empty($cek)) {
	  mysqli_query($conn, "INSERT INTO employee
                                VALUES('$sectioncode',
				
					'$empno',
					UPPER('$empname'))");
					// } 
					
					//else {
						
				//		die("Maaf, nama karyawan sudah ada dan tidak boleh sama.");
				// 	}
     header('location:../../index2.php?module='.$module);
            
  } else if ($module=='employee' AND $act=='inputuser'){
  	   //    $qcek  = mysql_query("select *from employee where empname='$_POST[empname]'");
  //  $cek= mysql_fetch_array($qcek);
   //  if (empty($cek)) {
  	        mysqli_query($conn, "INSERT INTO employee(sectioncode,
				
					empno,
					empname
					)
                                VALUES('$sectioncode',
				
					'$empno',
					UPPER('$empname'))"); 
					// } 
					//else {
						
					//	die("Maaf, nama karyawan sudah ada dan tidak boleh sama.");
				//	}
     header('location:../../index2.php?module=employee&act=employeeuser');
            
  }
  
  // Update employee  
  else if ($module=='employee' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE employee SET  sectioncode = '$sectioncode',
					
					empno = '$empno',
					empname = upper('$empname')                                       
                          WHERE empno = '$_POST[id]'");
    
    header('location:../../index2.php?module='.$module);
  } else if ($module=='employee' AND $act=='updateuser'){ 
          
    mysqli_query($conn, "UPDATE employee SET  sectioncode = '$sectioncode',
					
					empno = '$empno',
					empname = upper('$empname')                                     
                          WHERE empno = '$_POST[id]'");
    
    header('location:../../index2.php?module=employee&act=employeeuser');
  }
  
    
  // Delete employee  
  elseif ($module=='employee' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM employee WHERE empno = '$_GET[id]'");
      header('location:../../index2.php?module='.$module);
            
  } elseif ($module=='employee' AND $act=='deleteuser'){
            
      mysqli_query($conn, "DELETE FROM employee WHERE empno = '$_GET[id]'");
      header('location:../../index2.php?module=employee&act=employeeuser');
            
  } 
  
  else if ($module=='employee' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE employee";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      
      $empno           = $data->val($i, 1);
      $name           = $data->val($i, 2);
      $empname= mysqli_real_escape_string($conn, $name);
      $section           = $data->val($i, 3);
     // $joindate           = $data->val($i, 3);
      //$supervisor           = $data->val($i, 4);
      
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into employee values('$section','$empno',Upper('$empname'))";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index2.php?module=employee&act=employee');
  }
    else if ($module=='employee' AND $act=='importsql'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE employee";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      
      $empno           = $data->val($i, 2);
     
        $name           = $data->val($i, 3);
      $empname= mysqli_real_escape_string($conn, $name);
      $section           = $data->val($i, 4);
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into employee  values('$section','$empno',upper('$empname'))";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index2.php?module=employee&act=employee');
  }
   else if ($module=='employee' AND $act=='importhrd'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE employee";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      
      $empno           = $data->val($i, 1);
     
        $name           = $data->val($i, 2);
      $empname= mysqli_real_escape_string($conn, $name);
      //$joindate           = $data->val($i, 7);
      //$supervisor           = $data->val($i, 4);
      $section           = $data->val($i, 3);
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into employee values('$section','$empno',upper('$empname'))";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index2.php?module=employee&act=employee');
  }
  
  else if ($module=='employee' AND $act=='importuser'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    //if($_POST['drop']==1){
//             kosongkan tabel pegawai
           //  $truncate ="TRUNCATE TABLE employee2";
         //    mysql_query($truncate);
   // };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      //$section= $_SESSION['section'];
      $empno           = $data->val($i, 1);
      $name           = $data->val($i, 2);
      $empname= mysqli_real_escape_string($conn, $name);
      $section           = $data->val($i, 3);
     // $joindate           = $data->val($i, 3);
     // $supervisor           = $data->val($i, 4);
      
      
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into employee values('$section','$empno',Upper('$empname'))";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index2.php?module=employee&act=employeeuser');
  }
  }
?>
