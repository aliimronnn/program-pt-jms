<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure want to delete this data?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.id.value != ""){
       var x = (form.id.value);
       var status = true;
       var list = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9");
       for (i=0; i<=x.length-1; i++)
       {
           if (x[i] in list) cek = true;
           else cek = false;
           status = status && cek;
       }
       if (status == false)
       {
          alert("Code harus angka!");
          form.id.focus();
          return false;
       }
   }         
   
   return (true);
}
</script>

<?php


$aksi="modul/mod_section/aksi_section.php";
switch(@$_GET['act']){

default:
echo "<h2>List Section</h2>
<p>&nbsp;</p>
<input type=button value='Add Section'  class='large blue super button' 
onclick=\"window.location.href='?module=section&act=tambahsection';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th>
<th>Code</th><th>Section</th><th>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * FROM sectioncode");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td>
	<td>$r[id]</td>
      	<td>$r[section]</td>
        <td><a href='?module=section&act=editsection&id=$r[id]'>Edit</a> | 
        <a href=javascript:confirmdelete('$aksi?module=section&act=delete&id=$r[id]')>Delete</a>
        </td><td></td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

// Form Tambah section
case "tambahsection":
echo "<h2>Add section</h2>
<form method=POST action='$aksi?module=section&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code</td><td>: <input type='text' name='id' size='20' value='' ></td></tr>                
<tr><td>Section</td><td>: <input type='text' name='section' size='20' value='' ></td></tr>                
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit section 
case "editsection":
$edit = mysqli_query($conn, "SELECT * FROM sectioncode WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit section</h2><p>&nbsp;</p>
<form method=POST action='$aksi?module=section&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=idd value='$r[id]'>
<table>
<tr><td>Code</td><td>: <input type='text' name='id' size='20' value='$r[id]' ></td></tr>                
<tr><td>Section</td><td>: <input type='text' name='section' size='20' value='$r[section]' ></td></tr>                <td><p>&nbsp;</p></td></tr>
<tr><td colspan=2><input type=submit value=Update class='large blue super button' >
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}

?>
