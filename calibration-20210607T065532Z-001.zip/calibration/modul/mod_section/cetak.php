<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");



$html = 
'
<html>
				<head><style type="text/css">
				
				body{font-size:12 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20;margin-top: -0.75 cm; }
			
				tr td{ padding-left:3px; font-size:7 pt;}
				tr th{ padding-left:3px;}	
					
}

				</style></head>
<body>

<table width="680" border="0">
 <tr>
    <td ><div align="left" STYLE="font-size:16px"><img src="../../images/logo-kecil.png" alt="" /><strong> PT. JMS BATAM</strong></div></td>
    <td ><div align="center" STYLE="font-size:16px"><strong>OVERTIME FORM</strong></div></td>
    <td width="40" STYLE="font-size:12px" align="right">Date</td><td STYLE="font-size:11px">: </td>
  </tr>
 <tr>
    <td align="left" STYLE="font-size:12px">SECTION :  /  </td>
    <td ><div align="center" STYLE="font-size:11px">SUPERVISOR : </div></td>
    <td STYLE="font-size:11px" align="right">OT Ref No</td><td STYLE="font-size:11px">: </td>
  </tr>
</table>


<table border="1" cellspacing=0; cellpadding=0; style="font-size:9pt;" width="500">
<tr align="center" >
<td rowspan="2" align="center" width="20">No</td><td rowspan="2" align="center" width="40" >Emp No.</td><td rowspan="2" align="center" width="80" >Emp Name</td><td colspan="4" align="center" STYLE="font-size:15px" >Expected Overtime</td>
<td rowspan="2"   >LKD </td><td rowspan="2">HFG </td><td rowspan="2" >IZG </td><td rowspan="2">PCT5 </td><td rowspan="2" width="30">Emp Sign</td><td rowspan="2" align="center" width="150" >Jobs During Overtime</td>
</tr>
<tr ALIGN="center" ><td width="40" height="20" >Start </td><td width="40">Finish </td><td width="30" >Break </td><td width="30" align="center" >OT Hours</td></tr>
 ';
 	$no=1;
	$detail=mysql_query("select *from sectioncode where id = '$_GET[id]'");
	while($d=mysql_fetch_array($detail)){
	$html.='   <tr ><td height="15">'.$no.'.</td>
        <td >'.$d[id].'</td>
        <td>'.$d[section].'</td>
        <td class=ckeditor>'.$d[testing].'</td>
        <td ></td>
        <td ></td>
        <td ></td><td></td><td></td><td></td><td></td><td></td>
         <td ></td>
        </tr>';
        $no++;
	}
	$html.='
	<tr align="center">
	<td colspan=2 width="50">Prepared By:</td><td width="50">Verified By: <br> Supervisor/Controller</td>
	<td colspan=2 width="50">Approved By: <br>Mgr/Plan Dir/Press Dir</td><td colspan=3 width="90">Stamp when received by: <br>Hr&Payroll</td><td colspan=5>Instruction</td>
	</tr>
	<tr valign="bottom" align="center">
	<td  height="50" colspan=2><strong></strong></td>
	<td ><strong></strong></td>
	<td colspan=2 ><strong></strong></td><td colspan=3></td><td colspan=5>
		<table>
		<tr>
			<td valign="top">1.</td><td> Before OT, Supv Submit OT Form to Mgr</td>
		</tr>
		<tr>
			<td valign="top">2.</td><td> Supv / Section Submit OT Form to HR latest Friday 15.00</td>
		</tr>
		<tr>
			<td valign="top">3.</td><td> HRD Submit to Payroll</td>
		</tr>
		<tr>
			<td valign="top">**</td><td> PD to approve for shutdown period.</td>
		</tr>
		<tr><td>&nbsp;</td></tr>
		
		
		</table>
	</td>
	</tr>
	
	
</table><div align="right" STYLE="font-size:10px"> bhrd.inform.06.00</div
</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$dompdf->stream("form.pdf", array("Attachment" => false));
?>