<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET[module];
  $act=$_GET[act];

  $sect_head = htmlentities($_POST['sect_head']);
  $div_head = htmlentities($_POST['div_head']);
  $approval1 = htmlentities($_POST['approval1']);
  $approval2 = htmlentities($_POST['approval2']);
  $approval3 = htmlentities($_POST['approval3']);
  $approval4 = htmlentities($_POST['approval4']);
  $approval5 = htmlentities($_POST['approval5']);
  $jabatan1 = htmlentities($_POST['jabatan1']);
  $jabatan2 = htmlentities($_POST['jabatan2']);
  $jabatan3 = htmlentities($_POST['jabatan3']);
  $jabatan4 = htmlentities($_POST['jabatan4']);
  $jabatan5 = htmlentities($_POST['jabatan5']);
  
 
 

  // Input approval 
  // Update approval  
  if ($module=='approval' AND $act=='update'){ 
          
    mysql_query("UPDATE approval SET  
					
					approval1 = upper('$approval1'),
					approval2 = upper('$approval2'),
					approval3 = upper('$approval3'),
					approval4 = upper('$approval4'),
					approval5 = upper('$approval5'),
					jabatan1  = '$jabatan1',
					jabatan2  = '$jabatan2',
					jabatan3  = '$jabatan3',
					jabatan4  = '$jabatan4',
					jabatan5  = '$jabatan5'
					
				
					");
    
    header('location:../../index.php?module='.$module);
  }
    
  // Delete approval  
  
  }
?>
