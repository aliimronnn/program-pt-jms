<script>
function confirmdelete(delUrl) {
    if (confirm("Are you sure to delete the item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}

 
function validasi(form){
   var mincar = 1;
  
  if (form.scheduled.value==""){
       alert("Scheduled Is still empty!");
       form.scheduled.focus();
       return (false);
   }
   if (form.expenditure.value==""){
       alert("Expenditure Is still empty!");
       form.expenditure.focus();
       return (false);
   }
   if (form.title.value.length < mincar){
       alert("Subject Title Is still empty!");
       form.title.focus();
       return (false);
   }
   if (form.estimated_cost.value.length < mincar){
       alert("ESTIMATED COST Is still empty!");
       form.estimated_cost.focus();
       return (false);
   }
   if (form.commence_date.value.length < mincar){
       alert("Commence Date Is still empty!");
       form.commence_date.focus();
       return (false);
   }
   if (form.completion_date.value.length < mincar){
       alert("Completion Date Is still empty!");
       form.completion_date.focus();
       return (false);
   }
   if (form.reason.value.length < mincar){
       alert("REASON Is still empty!");
       form.reason.focus();
       return (false);
   }         
   if (form.attachment.value.length < mincar){
       alert("ATTACHMENT Is still empty!");
       form.attachment.focus();
       return (false);
   }         
  /* if (form.explanation.value.length < mincar){
       alert("EXPLANATION OF EFFECT Is still empty!");
       form.explanation.focus();
       return (false);
   }         
   */
   if (form.requestor.value.length < mincar){
       alert("requestor Is still empty!");
       form.requestor.focus();
       return (false);
   }
   if (form.sect_head.value.length < mincar){
       alert("Sect head Is still empty!");
       form.sect_head.focus();
       return (false);
   }
   if (form.div_head.value.length < mincar){
       alert("Division Head Is still empty!");
       form.dept_head.focus();
       return (false);
   }
   
   return (true);
}
</script>



<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
   echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Login is required to acces the system!<br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_approval/aksi_approval.php";
switch($_GET[act]){

default:
$qdir=mysql_query("select *from approval");
$rdir=mysql_fetch_array($qdir);
echo "

<h2 align=center>Setting Approval Board</h2>
<p>&nbsp;</p>

<form method=POST action='$aksi?module=approval&act=update'  onsubmit='return validasi(this)'>

<table cellspacing=8 cellpadding=4 border=0 width=800px align=center>

<tr align=center>
<td colspan=2 valign=top style=height:100px><u><input type='text' name='jabatan1' value='$rdir[jabatan1]' size='30' style='text-align: center'></u><br><br><br><input type='text' name='approval1' value='$rdir[approval1]' size='30' style='text-align: center' ></td><td colspan=2 valign=top><u><input type='text' name='jabatan2' value='$rdir[jabatan2]' size='30' style='text-align: center'></u><br><br><br><input type='text' align=center name='approval2' value='$rdir[approval2]' size='30' style='text-align: center'></td></tr>

<tr align=center>
<td colspan=4>&nbsp;</td>
</tr>
<tr align=center>
<td valign=top style=height:100px ><input type='text' name='jabatan3' value='$rdir[jabatan3]' size='30' style='text-align: center'><br><br><br><input type='text' name='approval3' value='$rdir[approval3]' size='30' style='text-align: center'></td>

<td valign=top colspan=2><u><input type='text' name='jabatan4' value='$rdir[jabatan4]' size='30' style='text-align: center'></u><br><br><br><input type='text' name='approval4' value='$rdir[approval4]' size='30' style='text-align: center'></td>
<td valign=top><input type='text' name='jabatan5' value='$rdir[jabatan5]' size='30' style='text-align: center'><br><br><br><input type='text' name='approval5' value='$rdir[approval5]' size='30' style='text-align: center'></td>
</tr>

</table>
<div align=center>
<br>
<input type=submit name=submit class='large blue super button' value='Update'>
</div>
</form>

";

break;

}
}
?>
