<?php
session_start();
 if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index2.php><b>LOGIN</b></a></center>";
}
else{
	include "../../config/koneksi.php";

	$module=$_GET['module'];
	$act=$_GET['act'];

	// Hapus User

	if ($module=='user' AND $act=='hapus') {
		mysqli_query($conn, "DELETE FROM users WHERE id_user='$_GET[id]'");
		header('location:../../index2.php?module='.$module.'&act=');
	}

	// Input User
	elseif ($module=='user' AND $act=='input') {
		
		if ($_POST['jenisuser']==1) {
			$levell='admin';
			} else {
				$levell='user';
			}
		$pass=md5($_POST['password1']);
		mysqli_query($conn, "INSERT INTO users(id_user,password,level,blokir,id_jenisuser,section)
				VALUES
				('$_POST[username]','$pass','$levell','N','$_POST[jenisuser]','$_POST[section]')");
		echo "<script>
					window.location.href='../../index2.php?module=user&act=';
					alert('Account has been created succesfully');
					</script>";;

	}

	// Update User
	elseif ($module=='user' AND $act=='update') {
		if ($_POST['jenisuser']==1) {
			$levell='admin';
			} else {
				$levell='user';
			}
	if (empty($_POST['password1'])) {
		mysqli_query($conn, "UPDATE users SET id_user        = '$_POST[username]',
										level = '$levell',
										blokir       = '$_POST[blokir]',
										id_jenisuser = '$_POST[jenisuser]',
										section = '$_POST[section]'										
										
					WHERE id_user = '$_POST[id]'");
	}
	else {
		$pass = md5($_POST['password1']);
			mysqli_query($conn, "UPDATE users SET id_user        = '$_POST[username]',
					                     password = '$pass',
										level = '$levell',
										blokir       = '$_POST[blokir]',
										id_jenisuser = '$_POST[jenisuser]',
										section = '$_POST[section]'										
										
					WHERE id_user = '$_POST[id]'");
	}

		echo "<script>
					window.location.href='../../index2.php?module=user&act=';
					alert('Account has been changed succesfully');
					</script>";
	}
	
	
elseif ($module=='user' AND $act=='updateuser') {
	
	$newpass = md5($_POST['password1']);
		mysqli_query($conn, "UPDATE users SET password = '$newpass'									
										
					WHERE id_user = '$_POST[id]'");
				 header('location:../../index2.php?module=home');	
	}
	
else if ($module=='user' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
       //  kosongkan tabel pegawai
        $truncate ="delete from users where id_jenisuser=$_POST[jenisuser]";
  		mysqli_query($conn, $truncate);
 		  };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      $id_user           = $data->val($i, 1);
      $passwordd           = $data->val($i, 2);
      $enkrippassword = md5($passwordd);
      //$leveluser           = "user";
      //$blokir 				= "N";
      $idjenisuser			= $_POST['jenisuser'];
      $section           = $data->val($i, 3);
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into users values('$id_user','$enkrippassword','user','N','$idjenisuser','$section')";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index2.php?module=user');
  }
}
?>


	
