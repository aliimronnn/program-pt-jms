<script type="text/javascript">
function validasipassword(form){
   var mincar = 1;
   
   if (form.password1.value==""){
       alert("Password Is still empty!");
       form.password1.focus();
       return (false);
   }
    if (form.password2.value==""){
       alert("Confirm Password Is still empty!");
       form.password2.focus();
       return (false);
   }
  if (form.password1.value!=form.password2.value){
       alert("Confirm password is different, Re-type your password!");
       form.password2.focus();
       return (false);
   }
  
  
  return (true);
}
function validasipsw2(form){
   var mincar = 1;
   if (form.username.value==""){
       alert("Username Is still empty!");
       form.username.focus();
       return (false);
   }
  
  if (form.password1.value!=form.password2.value){
       alert("Confirm password is different, Re-type your password!");
       form.password2.focus();
       return (false);
   }
  
  
  return (true);
}

function validasipsw3(form){
   var mincar = 1;
   if (form.username.value==""){
       alert("Username Is still empty!");
       form.username.focus();
       return (false);
   }
  if (form.password1.value==""){
       alert("Password Is still empty!");
       form.password1.focus();
       return (false);
   }
    if (form.password2.value==""){
       alert("Confirm Password Is still empty!");
       form.password2.focus();
       return (false);
   }
      
  if (form.password1.value!=form.password2.value){
       alert("Confirm password is different, Re-type your password!");
       form.password2.focus();
       return (false);
   }
    if (form.jenisuser.value==""){
       alert("Type of User Is still empty!");
       form.jenisuser.focus();
       return (false);
   }
   if (form.section.value==""){
       alert("Section Is still empty!");
       form.section.focus();
       return (false);
   }

  
  
  return (true);
}
</script>
<?php
//session_start();
 if (empty($_SESSION['namauser']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
	$aksi="modul/mod_user/aksi_user.php";
	$act=$_GET['act'];
	switch($act) {
		// Tampil User
		default:
		echo "<h2>Data User</h2><br/>
		<input type=button value='Add User' onclick=\"window.location.href='?module=user&act=tambahuser';\" class='large blue super button'>
		<input type=button value='Type of User' onclick=\"window.location.href='?module=jenisuser&act=';\" class='large blue super button'>  <input type=button value='Import User' onclick=\"window.location.href='?module=user&act=importuser';\" class='large blue super button'><br/><br/>
<table id=example class='pretty dataTable'>
<thead>
<tr>
	<th>No.</th>
	<th>Username</th>
	<th>Section</th>
	<th>Level</th>
	<th>Jenis User</th>
	
	<th width='90'>Aksi</th>
</tr>
</thead><tbody>";
		$tampil=mysqli_query($conn, "SELECT * FROM users ORDER BY id_user");
		$no=1;
		while($r=mysqli_fetch_array($tampil)) {
		$jenisuser = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM jenis_user WHERE id='$r[id_jenisuser]'"));
		$nm = mysqli_fetch_array(mysqli_query($conn, "SELECT section FROM sectioncode WHERE id ='$r[section]'"));
			echo "<tr><td>$no</td>
					<td>$r[id_user]</td>
					<td>$nm[section]</td>
					<td>$r[level]</td>
					<td>$jenisuser[jenis_user]</td>
					
					<td><a href=?module=user&act=edituser&id=$r[id_user]><img src='images/edit.png' alt='edit' /></a> &nbsp; 
						<a href=$aksi?module=user&act=hapus&id=$r[id_user]><img src='images/hapus.png' alt='hapus' /></a></td>
				</tr>";
			$no++;
		}
		
	echo "</tbody></table>";
	break;

	case "tambahuser":
	echo "<h2>Add User</h2><br/>
		<form method=POST action='$aksi?module=user&act=input' onsubmit='return validasipsw3(this)'>
		<table cellspacing=10 cellpadding=6>
			<tr>
				<td>Username</td>
				<td> : <input type=text name='username' value=''></td>
			</tr>
			<tr>
				<td>Password</td>
				<td> : <input type=password name='password1' value=''></td>
			</tr>
			<tr>
				<td>Confirm Password</td>
				<td> : <input type=password name='password2' value=''></td>
			</tr>
			<tr>
				<td>Type of User</td>
				<td> : <select name=jenisuser>
				<option value=''>- Type User -</option>";
				$jenisuser=mysqli_query($conn, "SELECT * FROM jenis_user");
				while($b=mysqli_fetch_array($jenisuser))
				{
				 echo "<option value='$b[id]'>$b[jenis_user]</option>"; 
				}
				
				echo " </select></td>
			</tr>	
			<tr><td>Section Code</td><td> : ";
$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='section'>
      <option value='' >- Section -</option>";
while ($r_combobox2=mysqli_fetch_array($sql_combobox2)){
 echo "<option value='$r_combobox2[id]'>$r_combobox2[id] $r_combobox2[section]</option>";
}
echo "</select></td></tr>		
			<tr>
				<td colspan=2><input type=submit value=Save class='large blue super button'> 
				<input type=button value=Cancel onclick=self.history.back() class='large orange super button'></td>
			</tr>
		</table>
	</form>";
	break;

	case "edituser":
	$edit=mysqli_query($conn, "SELECT * FROM users WHERE id_user='$_GET[id]'");
	$r=mysqli_fetch_array($edit);

	echo "<h2>Edit User</h2><br/>
	<form method=POST action=$aksi?module=user&act=update onsubmit='return validasipsw2(this)'>
	<input type=hidden name=id value='$r[id_user]'>

	<table cellspacing=10 cellpadding=6>
	<tr>
		<td>Username</td>
		<td> : <input type=text name='username' value='$r[id_user]'></td>
	</tr>
	<tr>
		<td>Password</td>
		<td> : <input type=password   name='password1'> *)</td>
	</tr>
	
	<tr>
		<td>Confirm Password</td>
		<td> : <input type=password   name='password2'> *)</td>
	</tr>
	<tr><td>User Type</td><td>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM jenis_user");
echo "<select name='jenisuser'>
      <option value=''>--Choose--</option>";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
 if ($r['id_jenisuser'] == $r_combobox4['id']){
     echo "<option value='$r_combobox4[id]' selected>$r_combobox4[jenis_user]</option>";
 }
 else {
     echo "<option value='$r_combobox4[id]'>$r_combobox4[jenis_user]</option>";
 }
}
echo "</select></td></tr>
<tr><td>Section Code</td><td>: ";
$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='section'>
      <option value='pilih'>--Pilih--</option>";
while ($r_combobox2=mysqli_fetch_array($sql_combobox2)){
 if ($r['section'] == $r_combobox2['id']){
     echo "<option value='$r_combobox2[id]' selected>$r_combobox2[id] / $r_combobox2[section]</option>";
 }
 else {
     echo "<option value='$r_combobox2[id]'>$r_combobox2[id] / $r_combobox2[section]</option>";
 }
}
echo "</select></td></tr>
";

	if ($r['blokir']=='N') {
		echo "<tr><td>Blokir</td>
				<td> : <input type=radio name='blokir' value='Y'> Y
				<input type=radio name='blokir' value='N' checked> N </td></tr>";
	}
	else {
		echo "<tr><td>Blokir</td>
				<td> : <input type=radio name='blokir' value='Y' checked> Y
				<input type=radio name='blokir' value='N'> N </td></tr>";
	}
	echo "<tr><td colspan=2><small>*) If the password is not changed, just leave it blank.</small></td></tr>
		<tr><td colspan=2><input type=submit value=Update class='large blue super button'>
		<input type=button value=Cancel onclick=self.history.back() class='large orange super button'></td></tr>
		</table></form>";
	break;
	
	case "akunuser":
	$qakun=mysqli_query($conn, "SELECT * FROM sectioncode where id='$_SESSION[section]'");
	$rk=mysqli_fetch_array($qakun);
	echo "
	<table cellspacing=10 cellpadding=6>
	
	<tr><td>Section</td><td>: $_SESSION[section]/$rk[section] </td></tr>
	<tr><td>Level</td><td>: $_SESSION[user] </td></tr>
	</table>
	
	";
	$edit=mysqli_query($conn, "SELECT * FROM users WHERE id_user='$_SESSION[namauser]'");
	$r=mysqli_fetch_array($edit);

	echo "<p>&nbsp;</p><h2>Change Account</h2><br/>
	<form method=POST action=$aksi?module=user&act=updateuser onsubmit='return validasipassword(this)'>
	<input type=hidden name=id value='$r[id_user]'>
	

	<table cellspacing=10 cellpadding=6>
	<tr>
		<td>Username </td>
		<td> : <input type=text name='username' value='$r[id_user]' size='30' readonly></td>
	</tr>
		
	<tr>
		<td>New Password</td>
		<td> : <input type=password   name='password1' size='30' value=''> </td>
	</tr>
	
	<tr>
		<td>Confirm Password</td>
		<td> : <input type=password   name='password2' size='30' value=''> </td>
	</tr>
	<tr><td colspan=2><small>*) Only the password can be modified!</small></td></tr>
		<tr><td colspan=2><input type=submit value=Update class='large blue super button'>
		<input type=button value=Cancel onclick=self.history.back() class='large orange super button'></td></tr>
		</table></form>";
	
	break;
	
	case "importuser":

echo "<h2>Import User</h2>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=user&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr>
				<td>Level</td>
				<td> : <select name=jenisuser>";
				$jenisuser=mysqli_query($conn, "SELECT * FROM jenis_user where id!=1 order by id desc");
				while($b=mysqli_fetch_array($jenisuser))
				{
				 echo "<option value='$b[id]'>$b[jenis_user]</option>"; 
				}
				
				echo " </select></td>
			</tr>
<tr><td>Excel File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /> </td>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003!<i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the old User data?</u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2><img src='images/user_xample.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

case "developer":
echo "

<table width=500 border=0 align=center >
<tr><td colspan=2 align=center><h2>MIS Team 2015</h2></td></tr>
<tr><td align=center ><img src='images/pak_rudi.png' alt='cetak' width=300 height=300/><i><br>Mr. Rudy Prasatyo <br>
	IT Administrator <br>
	<a href='https://www.facebook.com/rudy.prasatio' target=_blank>See More </a></i>
</td><td align=center><img src='images/pak_aidil.png' alt='cetak' width=300 height=300/><i><br>Mr. Aidil Asrap <br>
	IT Administrator <br>
	<a href='https://www.facebook.com/abu.raihan.aidil' target=_blank>See More </a></i>
</td></tr>
<tr><td colspan=2 align=center><img src='images/ali.png' alt='cetak' width=300 height=300/><i><br>Mr. Ali Imron <br>
	IT Programmer <br>
	<a href='https://www.facebook.com/ipong30' target=_blank>See More </a></i>
</td></tr>
</table>
";
break;
	
	}
}
?>