<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");

//$year=$_POST['thn_tgl3'];
//$section=$_POST['section'];

$qkode= mysql_query("select * from doc_code where dokumen= 'eksternal'");
$rkode=mysql_fetch_array($qkode);

$html = 
'
<html>
					<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:0.6; margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:11 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:0.4 CM; margin-top: 0.75 cm; margin-bottom: 0.5 cm;margin-right:-10; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:10 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>
<table width="1000" border="0" align="center">
  	<tr><td align=left colspan=2><strong><h2>EQUIPMENT CALIBRATION MASTERLIST - EXTERNAL </h2></strong></td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
	<tr><td width=100>Section</td><td>: All Section</td></tr>
	<tr><td width=100>Status</td><td>: '.$_POST[status].'</td></tr>
	<tr><td>Revision Number</td><td>: '.$p[rev_eksternal].'</td></tr>
	<tr><td>Update On</td><td>: '.$p[update_eksternal].'</td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
</table>

<table style="border-collapse: collapse;" cellspacing="6" cellpadding="10" border="0" align=left width="1100">

<thead>
<tr style="font-variant:small-caps;font-style:italic;color:black;font-size:14px;">
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=10>No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  >Apparatus/ Measuring<br>Equipment Name</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=70>Inclusion<br>Date</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=110>Apparatus/ Measuring<br>Equipment Location</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=100>Unique<br>Identification</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=90>Serial No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=90>Model No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;"  width=100>Manufacturer</th >

<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;"  width=70>Calibration<br>Frequency</th>

</tr></thead><tbody>
';


$tampil=mysql_query("SELECT c.create_date,
c.equip_name, c.equip_location, c.equip_identify,c.serial_no,c.model_no,c.manufacturer,
c.type_calibration, c.status
FROM calibration c
WHERE c.status='$_POST[status]' and c.calibrated_by='eksternal' order by c.equip_name,c.cal_date ");


$no=1;
while ($r=mysql_fetch_array($tampil)){
  $html.='<tr >
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$no.'.</td>
	   	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[equip_name].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[create_date].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[equip_location].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[equip_identify].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[serial_no].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[model_no].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r[manufacturer].'</td>     
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;"  valign=top>'.$r[type_calibration].'</td>
		
        </tr>';
  $no++;
}
 $html.=' <tr><td style="border-top:1px solid #000000;" colspan=9><br><br><br><br><br></td></tr>
<tr style=font-style:italic>
	<td colspan=2 align=center >Calibration Designated<br>_______________________</td>
	<td colspan=3 align=center >Section Head<br> _______________________</td>
	<td colspan=4 align=center >Department Head<br>_______________________</td>
</tr> 
<tr style=font-style:italic>
	<td colspan=2  align=center valign=top>PREPARED BY : N/D/S/D</td>
	<td colspan=3  align=center >CHECKED BY : N/D/S/D</td>
	<td colspan=4 align=center >APPROVED BY : N/D/S/D</td>
</tr> 
 <tr style=font-style:italic><td colspan=9><br><br><i>(N/D/S/D : Name/Designation/Signature/Date)</i></td></tr>


 </table> 
 

 
</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A3", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$font = Font_Metrics::get_font("helvetica");
$font2 = Font_Metrics::get_font("helvetica", "bold");
$canvas->page_text(111, 22, "PT. JMS BATAM", $font2, 10, array(0,0,0));
$canvas->page_text(111, 26, "___________________________________________________________________________________________________________________________________________________", $font, 8, array (0,0,0));
$canvas->page_text(111, 37, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia (Telepon): (62) 770-611807 Faksimili: 770-611806", $font, 10, array (0,0,0));

$canvas->page_text(480,800, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 10, array(0,0,0));
$canvas->page_text(16, 800, "Doc. Code : $rkode[code1]", $font, 9, array(0,0,0));
$canvas->page_text(900, 800, "$rkode[code2]", $font, 9, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>