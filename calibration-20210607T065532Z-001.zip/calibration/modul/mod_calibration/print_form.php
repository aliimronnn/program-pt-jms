<?php
error_reporting(E_ALL);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);

//$year=$_POST['thn_tgl3'];
//$section=$_POST['section'];
//$status=$_POST['status'];
$q_tampil= mysqli_query($conn, "select *, date_format(create_date ,'%d %b %y')as inclusion_date,date_format(propose_deletiondate ,'%d %b %y') as propose_date, date_format(cal_date ,'%d %b %y') as calibration_date from calibration  where id='$_GET[id]'");
$e=mysqli_fetch_array($q_tampil);

$qkode= mysqli_query($conn, "select * from doc_code where dokumen= 'form_inclusion'");
$rkode=mysqli_fetch_array($qkode);

$html = 
'
<html>
					<head><style type="text/css">
				
				#header { position: fixed; left:0; margin-left:1.3; margin-top: -0.5 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:11 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left: 1.3; margin-top: 1.3 cm; margin-bottom: 0.5 cm;margin-right:1; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:10 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>
<table align=left width="520" border="0" cellpadding=4 cellspacing=0>
  	<tr><td align=center colspan=5><strong>INCLUSION / DELETION OF EQUIPMENT FOR CALIBRATION</strong></td></tr>
	
 
 ';
if ($e['status']=='NotApproved') {
$html.='<tr><td align=center width=140>&nbsp;</td><td align=center width=60><input type=checkbox style="width:15px;height:18px;" checked> Inclusion </td><td></td>
			<td align=center width=60><input type=checkbox style="width:15px;height:18px;"> Deletion </td><td align=center width=140>&nbsp;</td></tr>
			<tr><td colspan=5>Date : '.$e['inclusion_date'].'</td></tr>';
} else {
	$html.='<tr><td align=center width=140>&nbsp;</td><td align=center width=60><input type=checkbox style="width:15px;height:18px;" > Inclusion </td><td></td>
			<td align=center width=60><input type=checkbox style="width:15px;height:18px;" checked> Deletion </td><td align=center width=140>&nbsp;</td></tr>
			<tr><td colspan=5>Date : '.$e['propose_date'].'</td></tr>';
}

$html.='

 </table> 

 <table align=left width="520" border="0" cellpadding=4 cellspacing=0>
 <tr><td colspan=3><br><br><br><br><br><strong>EQUIPMENT DATA :</strong></td></tr>
 <tr><td width=15 height=20>1)</td><td width=170> Equipment Name </td><td>: '.$e['equip_name'].'</td></tr>
 <tr><td height=20>2)</td><td> Unique Equipment Identification </td><td>: '.$e['equip_identify'].'</td></tr>
 <tr><td height=20>3)</td><td> Manufacturer </td><td>: '.$e['manufacturer'].'</td></tr>
 <tr><td height=20>4)</td><td> Model No. </td><td>: '.$e['model_no'].'</td></tr>
 <tr><td height=20>5)</td><td> Serial No. </td><td>: '.$e['serial_no'].'</td></tr>
 <tr><td height=20>6)</td><td> Equipmenent Measurement Range </td><td>: '.$e['measure_range'].'</td></tr>
 <tr><td height=20>7)</td><td> Usage Range </td><td>: '.$e['usage_range'].'</td></tr>
 <tr><td height=20>8)</td><td> Calibration Range </td><td>: '.$e['calibration_range'].'</td></tr>
 <!-- <tr><td height=20>9)</td><td> UsageTolerance </td><td>: '.$e['usage_tolerance'].'</td></tr> -->
 <tr><td height=20>9)</td><td> Location of Equipment </td><td>: '.$e['equip_location'].'</td></tr>
 <tr><td height=20>10)</td><td> Record Retention Location </td><td>: '.$e['retention'].'</td></tr>
 <tr><td height=20>11)</td><td> Equipment Tolerance </td><td>: '.$e['equip_tolerance'].'</td></tr>
 
 
  <tr><td colspan=3><br><strong>CALIBRATION INFORMATION :</strong></td></tr>
  <tr><td width=15 height=20>1)</td><td width=170>Calibrated By :</td><td> </td></tr>
  <tr><td width=15 height=15></td><td width=170>*a) &nbsp; Internally</td><td>: ';
  if ($e['internal']=='JMSB') {
	  $html.='
	  <input type=checkbox style="width:15px;height:18px;" checked> JMS(B) &nbsp;&nbsp; <input type=checkbox style="width:15px;height:18px;"> JMS(S)';
  } else if ($e['internal']=='JMSS') {
	  $html.='
	  <input type=checkbox style="width:15px;height:18px;" > JMS(B) &nbsp;&nbsp; <input type=checkbox style="width:15px;height:18px;" checked> JMS(S)';
  } else {
	  $html.='
	  <input type=checkbox style="width:15px;height:18px;" > JMS(B) &nbsp;&nbsp; <input type=checkbox style="width:15px;height:18px;" > JMS(S)';
  }
  $html.='</td></tr>

  
  <tr><td width=15 height=15></td><td width=170>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Apparatus / Identification</td><td>: '.$e['apparatus'].' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/ &nbsp;&nbsp;'.$e['identification'].'</td></tr> 
   <tr><td width=15 height=15></td><td width=170>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Apparatus Location</td><td>: '.$e['app_location'].'</td></tr> 
  <tr><td width=15 height=20></td><td width=170>&nbsp;b) &nbsp; Externally</td><td>: '.$e['eksternal'].'</td></tr> 
  <tr><td height=20>2)</td><td> Calibration Frequency </td><td>: '.$e['type_calibration'].' </td></tr>
  <tr><td height=20>3)</td><td> Calibration Date </td><td>: '.$e['calibration_date'].'</td></tr>
  <tr><td height=20>4)</td><td> Calibration Tolerance </td><td>: '.$e['cal_tolerance'].'</td></tr>
  <tr><td height=20 colspan=2> Reason For *Inclusion / Deletion </td><td>: '.$e['reason'].'</td></tr>
  
 </table>
 <table align=left width="520" border="0" cellpadding=4 cellspacing=0>
 <tr><td><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br></td></tr>
 <tr><td>Initiated By : </td><td><u>'.$e['initiaded'].'</u><br>Calibration Designate</td>
 <td ></td>
 <td>Approved By : </td><td><u>'.$e['approved'].'</u><br>Department Head</td>
 </tr>
</body></html>';
	
$dompdf->load_html($html);
$dompdf->set_paper("A4", "Portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();

$canvas->page_text(115, 22, "PT. JMS BATAM", "helvetica-bold", 10, array(0,0,0));
$canvas->page_text(115, 34, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia", "helvetica", 9, array (0,0,0));
$canvas->page_text(115, 45, "(Telepon): (62) 770-611807 Faksimili: 770-611806", "helvetica", 8, array (0,0,0));
$canvas->page_text(35, 53, "_____________________________________________________________________________________________________________________", "helvetica-bold", 8, array (0,0,0));
$canvas->page_text(290, 805, "Page: {PAGE_NUM} of {PAGE_COUNT}", "helvetica", 9, array(0,0,0));
$canvas->page_text(35, 810, "Doc. Code : $rkode[code1]", "helvetica", 9, array(0,0,0));
$canvas->page_text(480, 800, "$rkode[code2]", "helvetica", 9, array(0,0,0));
$canvas->page_text(700,570, "Page: {PAGE_NUM} of {PAGE_COUNT}", "helvetica", 10, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>