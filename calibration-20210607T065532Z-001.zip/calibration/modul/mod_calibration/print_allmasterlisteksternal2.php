<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");

//$year=$_POST['thn_tgl3'];
//$section=$_POST['section'];
//$sql= mysql_query("select section from sectioncode  where id='$_POST[section]'");
//$p=mysql_fetch_array($sql);
$qkode= mysql_query("select *from doc_code where dokumen= 'eksternal'");
$rkode=mysql_fetch_array($qkode);

$html = 
'
<html>
					<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:0.6; margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:11 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:0.4 CM; margin-top: 0.75 cm; margin-bottom: 0.5 cm;margin-right:-10; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:10 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>
<table width="1100" border="0" align="center">
  	<tr><td align=left colspan=2><strong><h2>EQUIPMENT CALIBRATION MASTERLIST - EKSTERNAL </h2></strong></td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
	<tr><td width=100>Section</td><td>: All Section</td></tr>
	<tr><td width=100>Status</td><td>: '.$_POST[status].'</td></tr>
	<tr><td>Revision Number</td><td>: </td></tr>
	<tr><td>Update On</td><td>: </td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
</table>

<table style="border-collapse: collapse;" cellspacing="6" cellpadding="10" border=1 align=left width="1100">

<tr style="font-variant:small-caps;font-style:italic;color:black;font-size:14px;">
<th width=10>No.</th>
<th width=140>Apparatus/ Measuring<br>Equipment Name</th><th width=40>Section</th><th width=50>Inclusion<br>Date</th><th width=100>Apparatus/ Measuring<br>Equipment Location</th>
<th width=60>Unique<br>Identification</th><th width=60>Serial No.</th><th width=60>Model No.</th><th width=70>Manufacturer</th ><th width=70>Measurement<br>Range</th><th width=70>Usage<br>Range</th><th width=70>Calibration<br>Range</th><th width=60>Calibration<br>Frequency</th>

</tr>
';


$tampil=mysql_query("SELECT *, date_format(create_date,'%d %b %y')as inclusion_date  FROM calibration WHERE status='$_POST[status]' and calibrated_by='eksternal' order by section");


$no=1;
while ($r=mysql_fetch_array($tampil)){
  $html.='<tr >
		<td valign=top>'.$no.'.</td>
	   	<td valign=top>'.$r[equip_name].'</td>
		<td valign=top>'.$r[section].'</td>
      	<td valign=top>'.$r[inclusion_date].'</td>
		<td valign=top>'.$r[equip_location].'</td>
		<td valign=top>'.$r[equip_identify].'</td>
      	<td valign=top>'.$r[serial_no].'</td>
      	<td valign=top>'.$r[model_no].'</td>
      	<td valign=top>'.$r[manufacturer].'</td>
      	<td valign=top>'.$r[measure_range].'</td>
		<td valign=top>'.$r[usage_range].'</td>
		<td valign=top>'.$r[calibration_range].'</td>
		<td valign=top>'.$r[type_calibration].'</td>
		
		    
      
        </tr>';
  $no++;
}
 $html.='
<tr><td colspan=13><br><br><br><br>
<table border=0 align=center cellpadding=4 cellspacing=0 width=1100 style=font-style:italic>
 <tr><td width=100 align=center>Calibration Designated<br>_______________________</td><td  align=center width=100>Section Head<br> _______________________</td><td  align=center width=100>Department Head<br>_______________________</td></tr> 
<tr><td width=100 align=center valign=top>PREPARED BY : N/D/S/D</td><td  align=center width=100>CHECKED BY : N/D/S/D</td><td  align=center width=100>APPROVED BY : N/D/S/D</td></tr> 
 <tr><td colspan=3><br><br><br><br><i>(N/D/S/D : Name/Designation/Signature/Date)</i></td></tr>
 </table>
 </td></tr>
 

 </table> 
 

 
</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A3", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$font = Font_Metrics::get_font("helvetica");
$font2 = Font_Metrics::get_font("helvetica", "bold");
$canvas->page_text(111, 22, "PT. JMS BATAM", $font2, 10, array(0,0,0));
$canvas->page_text(111, 26, "___________________________________________________________________________________________________________________________________________________", $font, 8, array (0,0,0));
$canvas->page_text(111, 37, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia (Telepon): (62) 770-611807 Faksimili: 770-611806", $font, 10, array (0,0,0));

$canvas->page_text(480,800, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 10, array(0,0,0));
$canvas->page_text(16, 800, "Doc. Code : $rkode[code1]", $font, 9, array(0,0,0));
$canvas->page_text(900, 800, "$rkode[code2]", $font, 9, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>