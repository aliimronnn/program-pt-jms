<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
   include "../../config/koneksi.php";
   include "../../config/library.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];
	
	$cal_date=@$_POST['thn_cal'].'-'.@$_POST['bln_cal'].'-'.@$_POST['tgl_cal'];
	$create_date=@$_POST['thn_date'].'-'.@$_POST['bln_date'].'-'.@$_POST['tgl_date'];
    $equip_name = htmlentities(@$_POST['equip_name']);
	$equip_identify = htmlentities(@$_POST['equip_identify']);
	$manufacturer = htmlentities(@$_POST['manufacturer']);
	$model_no = htmlentities(@$_POST['model_no']);
	$serial_no = htmlentities(@$_POST['serial_no']);
	$measure_range = htmlentities(@$_POST['measure_range']);
	$usage_range = htmlentities(@$_POST['usage_range']);
	$calibration_range = htmlentities(@$_POST['calibration_range']);
	$equip_location = htmlentities(@$_POST['equip_location']);
	$retention = htmlentities(@$_POST['retention']);
	$equip_tolerance = htmlentities(@$_POST['equip_tolerance']);
	$calibrated_by = htmlentities(@$_POST['calibrated_by']);
	$internal = htmlentities(@$_POST['internal']);
	$eksternal = htmlentities(@$_POST['eksternal']);
	$apparatus = htmlentities(@$_POST['apparatus']);
	$identification = htmlentities(@$_POST['identification']);
	$app_location = htmlentities(@$_POST['app_location']);
	$cal_frequency = htmlentities(@$_POST['cal_frequency']);
	$other_frequency = htmlentities(@$_POST['other_frequency']);
	
	$cal_tolerance = htmlentities(@$_POST['cal_tolerance']);
	$usage_tolerance = htmlentities(@$_POST['usage_tolerance']); // Refer to CRF/007/BQAC5/17 and CRF/009/BQAC5/17
	$reason = str_replace("\n", '<BR />',htmlentities(@$_POST['reason']));
	//$reason = mysql_real_escape_string(htmlentities($_POST['reason']));
	$initiaded = htmlentities(@$_POST['initiaded']);
	$approved = htmlentities(@$_POST['approved']);
	
	$remarks = htmlentities(@$_POST['remarks']);

	$section = htmlentities(@$_POST['section']);
  // Input calibration
  if ($module=='calibration' AND $act=='input'){
	  
/**	  $qurutan=mysql_query("SELECT RIGHT( CONCAT('000', CONVERT( IFNULL(MAX(d.counter)+1,1), 
	  CHAR( 4 ) ) ) ,3 ) AS no_surat , DATE_FORMAT(curdate(),'%y') as th_surat
FROM calibration d, sectioncode sc WHERE d.section=sc.id and sc.id='$_SESSION[section]' and 
YEAR(d.create_date)=year(NOW())");
$rurutan=mysql_fetch_array($qurutan);

$qkodesurat=mysql_query("SELECT CONCAT('CAL/','$rurutan[no_surat]/','$_SESSION[section]/','$rurutan[th_surat]') as kode_surat");
$rkodesurat=mysql_fetch_array($qkodesurat);

$urutan = $rurutan['no_surat'];
**/
	$q_freq=mysqli_query($conn, "SELECT frequency from frequency where code_freq='$_POST[cal_frequency]'");
	$r_freq=mysqli_fetch_array($q_freq);
  	        mysqli_query($conn, "INSERT INTO calibration (`section`, `create_date`, `equip_name`, `equip_identify`, `manufacturer`, `model_no`, `serial_no`, `measure_range`, `usage_range`, `calibration_range`, `equip_location`, `retention`, `equip_tolerance`, `usage_tolerance`, `calibrated_by`, `internal`, `eksternal`, `apparatus`, `identification`, `app_location`, `cal_frequency`, `type_calibration`, `other_frequency`, `cal_date`, `cal_tolerance`, `reason`, `initiaded`, `approved`,`status`)
                                VALUES('$_SESSION[section]','$create_date',
								'$equip_name','$equip_identify','$manufacturer','$model_no',
								'$serial_no','$measure_range','$usage_range','$calibration_range','$equip_location',
								'$retention','$equip_tolerance','$usage_tolerance','$calibrated_by','$internal','$eksternal','$apparatus',
								'$identification','$app_location','$cal_frequency','$r_freq[frequency]','$other_frequency','$cal_date','$cal_tolerance',
								'$reason',upper('$initiaded'),upper('$approved'),'NotApproved')");
     header('location:../../index2.php?module=calibration&act=');
            
  }
  
  // Update calibration  
  elseif ($module=='calibration' AND $act=='update'){ 
    
	$q_freq=mysqli_query($conn, "SELECT frequency from frequency where code_freq='$_POST[cal_frequency]'");
	$r_freq=mysqli_fetch_array($q_freq);
	
    mysqli_query($conn, "UPDATE calibration SET  
								create_date = '$create_date',
								equip_name='$equip_name',equip_identify='$equip_identify',manufacturer='$manufacturer',model_no='$model_no',
								serial_no='$serial_no',measure_range='$measure_range',usage_range='$usage_range',
								calibration_range='$calibration_range',equip_location='$equip_location',
								retention='$retention',equip_tolerance='$equip_tolerance',usage_tolerance='$usage_tolerance',
								calibrated_by='$calibrated_by',internal='$internal',eksternal='$eksternal',apparatus='$apparatus',
								identification='$identification',app_location='$app_location',cal_frequency='$cal_frequency',
								type_calibration='$r_freq[frequency]',
								other_frequency='$other_frequency',cal_date='$cal_date',usage_tolerance='$usage_tolerance',cal_tolerance='$cal_tolerance',
								reason='$reason',initiaded=upper('$initiaded'),approved=upper('$approved')
								 WHERE id = $_POST[id]
								");	
                
    
    header('location:../../index2.php?module='.$module.'&act=');
  }

  // Transfer calibration  
  elseif ($module=='calibration' AND $act=='transfer'){ 
    
    mysqli_query($conn,"UPDATE calibration SET  
								section='$section'
						WHERE equip_identify='$equip_identify' ");	
    header('location:../../index2.php?module='.$module.'&act=');
  }
  elseif ($module=='calibration' AND $act=='deletion'){ 
          
    mysqli_query($conn, "UPDATE calibration SET  

								status='Deletion',
								deletion_date='$cal_date'
								 WHERE id = $_POST[id]
								");	
                
    
    header('location:../../index2.php?module='.$module.'&act=view_ekscalibration');
  }
  
    elseif ($module=='calibration' AND $act=='approve'){ 
          
    mysqli_query($conn, "UPDATE calibration SET  

								status='Active',
								approve_date='$cal_date'
								 WHERE id = $_POST[id]
								");	
                
    
    header('location:../../index2.php?module='.$module.'&act=v_activecal');
  }
  
    elseif ($module=='calibration' AND $act=='return'){ 
          
    mysqli_query($conn, "UPDATE calibration SET  

								status='NotApproved',
								approve_date=NULL
								 WHERE id = $_POST[id]
								");	
                
    
    header('location:../../index2.php?module='.$module.'&act=');
  }
  
  elseif ($module=='calibration' AND $act=='propose'){ 
          
    mysqli_query($conn, "UPDATE calibration SET  

								propose_deletiondate='$create_date'
								 WHERE id = $_POST[id]
								");	
                
    //include"print_form.php";
    header('location:../../index2.php?module='.$module.'&act=v_activecal');
  }
    elseif ($module=='calibration' AND $act=='undel'){ 
          
    mysqli_query($conn, "UPDATE calibration SET  

								status='Active',
								deletion_date=NULL
								 WHERE id = $_POST[id]
								");	
                
    
    header('location:../../index2.php?module='.$module.'&act=v_activecal');
  }
  // Delete calibration  
  elseif ($module=='calibration' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM calibration WHERE id = '$_GET[id]'");
      header('location:../../index2.php?module='.$module.'&act=');
            
  }
  elseif ($module=='calibration' AND $act=='del_process'){
            
      mysqli_query($conn, "DELETE FROM process_calibration WHERE id = '$_GET[id]'");
      header('location:../../index2.php?module='.$module.'&act=v_process');
            
  }
  elseif ($module=='calibration' AND $act=='process'){
            
     $cek= mysqli_query($conn, "SELECT id,cal_frequency from calibration where equip_identify='$_POST[equip_identify]'");
	 $r=mysqli_fetch_array($cek);
	$bulan = $r['cal_frequency']; 
	
	if ($bulan=='daily' ) {
		mysqli_query($conn, "UPDATE calibration SET  
								last_caldate='$cal_date', due_caldate=DATE_ADD('$cal_date', INTERVAL $bulan DAY)
							
								 WHERE id = '$r[id]'
								");	
	} elseif ($bulan=='weekly' ) {
		mysqli_query($conn, "UPDATE calibration SET  
								last_caldate='$cal_date', due_caldate=DATE_ADD('$cal_date', INTERVAL $bulan DAY)
								 WHERE id = '$r[id]'
								");	
	} elseif ($bulan=='others' ) {
		mysqli_query($conn, "UPDATE calibration SET  
								last_caldate='$cal_date' 
								
								 WHERE id = '$r[id]'
								");	
	} else {
		mysqli_query($conn, "UPDATE calibration SET  
								last_caldate='$cal_date', due_caldate=DATE_ADD('$cal_date', INTERVAL $bulan MONTH)
								 WHERE id = '$r[id]'
								");	
	} 
	
	mysqli_query($conn, "INSERT INTO process_calibration (`equip_identify`, `date`) VALUES ('$equip_identify', '$cal_date')");	
	 
									
    header('location:../../index2.php?module=calibration&act=v_process');
            
  }
  else if ($module=='calibration' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE calibration";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      
	
    $equip_nam = $data->val($i, 2);
	$inclusion_dat=$data->val($i, 3);
	$equip_locatio = $data->val($i, 4);
	$serial_n = $data->val($i, 5);
	$equip_identif = $data->val($i, 6);
	$manufacture = $data->val($i, 7);
	$model_n = $data->val($i, 8);
	$measure_rang = $data->val($i, 9);
	$usage_rang = $data->val($i, 10);
	$calibration_rang = $data->val($i, 11);
	$cal_frequenc = $data->val($i, 12);
	$cal_toleranc = $data->val($i, 13);
//	$usage_tolerance = $data->val($i, 14);
	$apparatu = $data->val($i, 14);
	$identificatio = $data->val($i, 15);
	$sectio = $data->val($i, 16);
	$calibrated_b = $data->val($i, 17);
	$interna = $data->val($i, 18);
	$eksterna = $data->val($i, 19);
	$statu = $data->val($i, 20);
	
	$equip_name = htmlentities($equip_nam);
	$inclusion_date= htmlentities($inclusion_dat);
	$equip_location = htmlentities($equip_locatio);
	$serial_no = htmlentities($serial_n);
	$equip_identify = htmlentities($equip_identif);
	$manufacturer = htmlentities($manufacture);
	$model_no = htmlentities($model_n);
	$measure_range = htmlentities($measure_rang);
	$usage_range = htmlentities($usage_rang);
	$calibration_range = htmlentities($calibration_rang);
	$cal_frequency = htmlentities($cal_frequenc);
	$cal_tolerance = htmlentities($cal_toleranc);
//	$usage_tolerance = mysql_real_escape_string(htmlentities($usage_tolerance));
	$apparatus = htmlentities($apparatu);
	$identification = htmlentities($identificatio);
	$section = htmlentities($sectio);
	$calibrated_by = htmlentities($calibrated_b);
	$internal = htmlentities($interna);
	$eksternal = htmlentities($eksterna);
	$status = htmlentities($statu);
	

	
	
     // $joindate           = $data->val($i, 3);
      //$supervisor           = $data->val($i, 4);
      
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into calibration (`section`, `create_date`, `equip_name`, `equip_identify`, `manufacturer`, `model_no`, `serial_no`, `measure_range`, `usage_range`, `calibration_range`,`equip_location`, `calibrated_by`, `internal`, `eksternal`, `apparatus`, `identification`, `cal_frequency`, `cal_tolerance`,`status`)
                                VALUES('$section','$inclusion_date',
								'$equip_name','$equip_identify','$manufacturer','$model_no',
								'$serial_no','$measure_range','$usage_range','$calibration_range','$equip_location',
								'$calibrated_by','$internal','$eksternal','$apparatus',
								'$identification','$cal_frequency','$cal_tolerance','Active')";
      $hasil = mysqli_query($conn, $query);
	  
	 $q_updatefreq = "update calibration cal set cal.type_calibration= (select f.frequency  from frequency f where f.code_freq=cal.cal_frequency)";
     $r_updatefreq = mysqli_query($conn, $q_updatefreq);
	  
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index2.php?module=calibration&act=v_activecal');
  }
    else if ($module=='calibration' AND $act=='cetak_statuslog') {
 	if ($_POST['section']=='all'){
		include"print_allstatuslog.php";
	} else {
		include"print_statuslog.php";
	}   	
} else if ($module=='calibration' AND $act=='cetak_masterlist') {
 	if ($_POST['section']=='all' && $_POST['format']=='PDF'){
		if ($_POST['calibrated_by']=='eksternal'){
					include"print_allmasterlisteksternal.php";
			} else {
					include"print_allmasterlistinternal.php";
			}  
	} else if ($_POST['section']=='all' && $_POST['format']=='Xls') {
		if ($_POST['calibrated_by']=='eksternal'){
					include"xls_allmasterlisteksternal.php";
			} else {
					include"xls_allmasterlistinternal.php";
			}  
	} else {		
		if ($_POST['calibrated_by'] == 'eksternal'){
					include"print_masterlisteksternal.php";
			} else {
					include"print_masterlistinternal.php";
			} 	
		}
	}

else if ($module=='calibration' AND $act=='cetak_form') {
 		include"print_form.php";
						
	}

  }
?>
