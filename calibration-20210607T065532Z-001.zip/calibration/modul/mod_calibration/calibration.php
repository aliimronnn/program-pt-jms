<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>

<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.equip_identify.value.length < mincar){
       alert("Unique identify is still empty!");
       form.equip_identify.focus();
       return (false);
   }         
  
   if (form.equip_name.value.length < mincar){
       alert("Equipment Name Is still empty!");
       form.equip_name.focus();
       return (false);
   }
 
  if (form.manufacturer.value.length < mincar){
       alert("Manufacturer Is still empty!");
       form.manufacturer.focus();
       return (false);
   }
   if (form.model_no.value.length < mincar){
       alert("Model No Is still empty!");
       form.model_no.focus();
       return (false);
   }
   if (form.serial_no.value.length < mincar){
       alert("Serial No Is still empty!");
       form.serial_no.focus();
       return (false);
   }
   
   if (form.measure_range.value.length < mincar){
       alert("measure range Is still empty!");
       form.measure_range.focus();
       return (false);
   }
   
    if (form.usage_range.value.length < mincar){
       alert("usage range Is still empty!");
       form.usage_range.focus();
       return (false);
   }
   if (form.calibration_range.value.length < mincar){
       alert("calibration range Is still empty!");
       form.calibration_range.focus();
       return (false);
   }
   if (form.equip_location.value.length < mincar){
       alert("Equipment location Is still empty!");
       form.equip_location.focus();
       return (false);
   }
 
   if (form.retention.value.length < mincar){
       alert("retention Periode Is still empty!");
       form.retention.focus();
       return (false);
   }
  
    if (form.equip_tolerance.value.length < mincar){
       alert("Equipment Tolerance Is still empty!");
       form.equip_tolerance.focus();
       return (false);
   }  
   var radio_val15 = check_radio(form.calibrated_by);
   if (radio_val15 === false){
       alert("Type Calibration Must not be Empty!");
       return false;
   }
   
   if (form.cal_frequency.value.length < mincar){
       alert("Frequency Is still empty!");
       form.cal_frequency.focus();
       return (false);
   }  
   
   if (form.cal_tolerance.value.length < mincar){
       alert("calibration tolerance Number Is still empty!");
       form.cal_tolerance.focus();
       return (false);
   }  
   
   if (form.reason.value.length < mincar){
       alert("Reason Is still empty!");
       form.reason.focus();
       return (false);
   }  
  
   if (form.initiaded.value.length < mincar){
       alert("Initiaded Is still empty!");
       form.initiaded.focus();
       return (false);
   }
   
   if (form.approved.value.length < mincar){
       alert("Approved Is still empty!");
       form.approved.focus();
       return (false);
   }    
   
   return (true);
}
</script>
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateImport()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }
 
        if(!hasExtension('filepegawaiall', ['.xls'])){
            alert("Sorry..Only Excel 97-2003 could be imported.");
            return false;
        }
    }
</script>
<?php
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Login is required to access this system.<br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_calibration/aksi_calibration.php";
switch(@$_GET['act']){

default:
echo "
<input type=button value='Add New Master Calibration'  class='large blue super button' 
onclick=\"window.location.href='?module=calibration&act=tambahcalibration';\"> 
<input type=button value='View Active Calibration'  class='large orange super button' 
onclick=\"window.location.href='?module=calibration&act=v_activecal';\">
<input type=button value='View Deletion Calibration'  class='large orange super button' 
onclick=\"window.location.href='?module=calibration&act=view_ekscalibration';\">
<!--<input type=button value='Transfer Calibration'  class='large blue super button' 
onclick=\"window.location.href='?module=calibration&act=transfer_calibration';\">-->
<p>&nbsp;</p>
<h2>The Masterlist Not Approved Calibration</h2>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th><th>Unique Code</th><th>Equipment Name</th><th>Inclusion Date</th><th>Frequency</th><th>Type</th><th>Location</th><th>Initiated By</th><th>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * FROM calibration c where c.section='$_SESSION[section]' and c.status='NotApproved' order by c.id desc");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td><td>$r[equip_identify]</td>
	<td>$r[equip_name]</td><td>$r[create_date]</td><td>$r[type_calibration]</td><td>$r[calibrated_by]</td><td>$r[equip_location]</td>	<td>$r[initiaded]</td>	
        <td width=150><a href=$aksi?module=calibration&act=cetak_form&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a><a href='?module=calibration&act=editcalibration&id=$r[id]'><image src=images/edit.png></a>|<a href='?module=calibration&act=approve_cal&id=$r[id]'><image src=images/approve.png></a> 
        <a href=javascript:confirmdelete('$aksi?module=calibration&act=delete&id=$r[id]')><image src=images/hapus.png></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "v_process":
echo "
<input type=button value='Calibrate Equipment'  class='large blue super button' 
onclick=\"window.location.href='?module=calibration&act=process_calibrate';\"> 

<p>&nbsp;</p>
<h2>The Lastest 300 Process Calibration</h2>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th><th>Unique Code</th><th>Equipment Name</th><th>Calibration Date</th><th>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT c.*,cal.equip_name FROM process_calibration c, calibration cal where c.equip_identify=cal.equip_identify and cal.section='$_SESSION[section]' order by c.id desc limit 300");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td><td>$r[equip_identify]</td>
	<td>$r[equip_name]</td>	<td>$r[date]</td>	
        <td width=150><a href=javascript:confirmdelete('$aksi?module=calibration&act=del_process&id=$r[id]')><image src=images/hapus.png></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "v_activecal":
echo "
<input type=button value='View Not Approved Calibration'  class='large orange super button' 
onclick=\"window.location.href='?module=calibration&act=';\">

<input type=button value='View Deletion Calibration'  class='large blue super button' 
onclick=\"window.location.href='?module=calibration&act=view_ekscalibration';\">
<p>&nbsp;</p>
<h2>The Masterlist Active Calibration</h2>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th><th>Unique Code</th><th>Equipment Name</th><th>Last Calibration</th><th>Frequency</th><th>Due Calibration</th><th>Location</th><th>Type</th><th>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * FROM calibration c where c.section='$_SESSION[section]' and c.status='Active' order by c.equip_identify");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td><td>$r[equip_identify]</td>
	<td>$r[equip_name]</td><td>$r[last_caldate]</td><td>$r[type_calibration]</td><td>$r[due_caldate]</td><td>$r[equip_location]</td>	<td>$r[calibrated_by]</td>	
        <td width=170>
		<a href='?module=calibration&act=propose_del&id=$r[id]'><image src=images/edit.png></a>
		<a href=$aksi?module=calibration&act=cetak_form&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
		<a href='?module=calibration&act=deletion_cal&id=$r[id]'><image src=images/checked.png>|
		<a href='?module=calibration&act=return&id=$r[id]'><image src=images/return.png></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "report_cal":
echo "
<table border=0 width=1000>

<tr><td><h2>Equipment Calibration Status Log</h2></td><td><h2>Equipment Calibration Master List</h2></td></tr>
"; 
//Log Draf Period
echo"
<tr><td valign=top>

<form method=POST action='$aksi?module=calibration&act=cetak_statuslog' target='_blank' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>

<tr><td>Section</td><td>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='section'>
      <option value='all'>- All Section -</option>
     ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
if ($_SESSION['section'] == $r_combobox4['id']){
     echo "<option value='$r_combobox4[id]' selected>$r_combobox4[id] $r_combobox4[section]</option>";
 }
 else {
     echo "<option value='$r_combobox4[id]' >$r_combobox4[id] $r_combobox4[section]</option>";
 }
}
echo "</select></td></tr>

<tr><td>Year</td><td>: ";
combothn(2000,$thn_sekarang,'thn_tgl3',$thn_sekarang); 
echo"</td></tr>

<tr><td>Status</td><td>: 
<select name='status'>
      <option value='Active'> Active </option>
      <option value='Deletion'> Deletion </option>
      
     
</select></td></tr>
<tr><td><input type=submit name=submit class='large blue super button' value='View Data'></td></tr>
</table>
</form>
</td>

<td valign=top>
<form method=POST action='$aksi?module=calibration&act=cetak_masterlist' target='_blank' enctype='multipart/form-data'>
<table  cellspacing=10 cellpadding=6>
<tr><td>Section</td><td>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='section'>
      <option value='all'>- All Section -</option>
     ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
if ($_SESSION['section'] == $r_combobox4['id']){
     echo "<option value='$r_combobox4[id]' selected>$r_combobox4[id] $r_combobox4[section]</option>";
 }
 else {
     echo "<option value='$r_combobox4[id]' >$r_combobox4[id] $r_combobox4[section]</option>";
 }
}
echo "</select></td></tr>

<tr><td>Type of Calibration</td><td>: 
<select name='calibrated_by'>
     
    <option value='internaljmsb'> Internal (JMSB)</option>
	  <option value='internaljmss'> Internal (JMSS)</option>
    <option value='eksternal'> Eksternal </option>
   
</select></td></tr>

<tr><td>Status Log</td><td>: 
<select name='status'>
     
      <option value='Active'> Active </option>
      <option value='Deletion'> Deletion </option>
   
</select></td></tr>
<tr><td>Format Report</td><td>: 
<select name='format'>
     
      <option value='PDF'> PDF </option>
      <option value='Xls'> Xls </option>
   
</select></td></tr>
<tr><td><input type=submit name=submit class='large blue super button' value='View Data'></td></tr>
</table>
</form>
</td>

</tr> </table>
"; 
break;


case "report_calsection":
echo "
<table border=0 width=1000>

<tr><td><h2>Equip Calibration Status Log</h2></td><td><h2>Equip Calibration Master List</h2></td></tr>
"; 
//Log Draf Period
echo"
<tr><td valign=top>

<form method=POST action='$aksi?module=calibration&act=cetak_statuslog' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
<input type=hidden name=section value='$_SESSION[section]'>


<tr><td>Year</td><td>: ";
combothn(2000,$thn_sekarang,'thn_tgl3',$thn_sekarang); 
echo"</td></tr>

<tr><td>Status</td><td>: 
<select name='status'>
      <option value='Active'> Active </option>
      <option value='Deletion'> Deletion </option>
      
     
</select></td></tr>
<tr><td><input type=submit name=submit class='large blue super button' value='View Data'></td></tr>
</table>
</form>
</td>

<td valign=top>
<form method=POST action='$aksi?module=calibration&act=cetak_masterlist' enctype='multipart/form-data'>
<table  cellspacing=10 cellpadding=6>
<input type=hidden name=section value='$_SESSION[section]'>
<tr><td>Type of Calibration</td><td>: 
<select name='calibrated_by'>
     
      <option value='internaljmsb'> Internal (JMSB)</option>
	  <option value='internaljmss'> Internal (JMSS)</option>
      <option value='eksternal'> Eksternal </option>
   
</select></td></tr>

<tr><td>Status Log</td><td>: 
<select name='status'>
     
      <option value='Active'> Active </option>
      <option value='Deletion'> Deletion </option>
   
</select></td></tr>
<tr><td><input type=submit name=submit class='large blue super button' value='View Data'></td></tr>
</table>
</form>
</td>

</tr> </table>
"; 
break;



case "view_ekscalibration":
echo "
<input type=button value='View Not Approved Calibration'  class='large orange super button' 
onclick=\"window.location.href='?module=calibration&act=';\">
<input type=button value='View Active Calibration'  class='large blue super button' 
onclick=\"window.location.href='?module=calibration&act=v_activecal';\">
<p>&nbsp;</p>
<h2>The Masterlist Deletion Calibration</h2>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th><th>Unique Code</th><th>Equipment Name</th><th>Inclusion Date</th><th>Frequency</th><th>Date Deletion</th><th>Location</th><th>Type</th><th>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * FROM calibration c where c.section='$_SESSION[section]' and c.status='Deletion' order by c.deletion_date desc");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td><td>$r[equip_identify]</td>
	<td>$r[equip_name]</td><td>$r[create_date]</td><td>$r[type_calibration]</td><td>$r[deletion_date]</td><td>$r[equip_location]</td>	<td>$r[calibrated_by]</td>	
        <td width=130><a href='?module=calibration&act=undel&id=$r[id]'><image src=images/undo2.png></a>|
		<a href='?module=calibration&act=viewcalibration&id=$r[id]'><image src=images/detail.png></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;
/*
<tr><td align=right>Equipment Name</td><td colspan=2>: <input type='text' name='equip_name' size='50' value='' ></td></tr>                
<tr><td align=right>Unique Equipment Identification</td><td colspan=2>: <input type='text' name='equip_identify' size='50' value='' ></td></tr>      
<tr><td align=right>Manufacturer</td><td colspan=2>: <input type='text' name='manufacturer' size='50' value='' ></td></tr>
<tr><td align=right>Model No</td><td colspan=2>: <input type='text' name='model_no' size='50' value='' ></td></tr>          
<tr><td align=right>Serial No</td><td colspan=2>: <input type='text' name='serial_no' size='50' value='' ></td></tr>   
<tr><td align=right>Equipment Measurement Range No</td><td colspan=2>: <input type='text' name='measure_range' size='50' value='' ></td></tr>   
<tr><td align=right>Usage Range</td><td colspan=2>: <input type='text' name='usage_range' size='50' value='' ></td></tr>   
<tr><td align=right>Calibration Range</td><td colspan=2>: <input type='text' name='calibration_range' size='50' value='' ></td></tr>   
<tr><td align=right>Location of Equipment</td><td colspan=2>: <input type='text' name='equip_location' size='50' value='' ></td></tr>   
<tr><td align=right>Record Retention Location</td><td colspan=2>: <input type='text' name='retention' size='50' value='' ></td></tr>   
<tr><td align=right>Equipment Tolerance</td><td colspan=2>: <input type='text' name='equip_tolerance' size='50' value='' ></td></tr>  

*/
// Form Tambah calibration
case "tambahcalibration":
echo "
<form method=POST action='$aksi?module=calibration&act=input'  onSubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6 border=0>

<tr><td align=right>Date</td><td colspan=2>: ";
combotgl(1,31,'tgl_date',$tgl_skrg);
combobln(1,12,'bln_date',$bln_sekarang);
combothn(1990,$thn_sekarang,'thn_date',$thn_sekarang); 
echo"</td></tr>

<tr><td colspan=3><h2>Equipment Data</h2></td></tr>";
include "equipment.php";
echo "
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <input type='text'  name='manufacturer' size='50'  ></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <input type='text'  name='model_no' size='50'  ></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <input type='text'  name='serial_no' size='50'  ></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <input type='text'  name='measure_range' size='50'  ></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <input type='text' name='usage_range' size='50' ></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <input type='text'  name='calibration_range' size='50'  ></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <input type='text'  name='equip_location' size='50'  ></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <input type='text'  name='retention' size='50'  ></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'>: <input type='text'  name='equip_tolerance' maxlength='80' size='50' ></td></tr>
<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <input type='text'  name='usage_tolerance' size='50' ></td></tr> -->


<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr> 
<tr><td align=right>Calibrated By</td><td colspan=2><input type=radio value='internal' name=calibrated_by><strong> Internal : </strong></td></tr>      
<tr><td></td><td colspan=2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox name='internal' value='JMSB'> JMS(B) &nbsp; <input type=checkbox name='internal' value='JMSS'> JMS(S)</td></tr>
<tr><td></td><td align=right width=200>Apparatus</td><td>: <input type='text' name='apparatus' size='50' value='' ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <input type='text' name='identification' size='50' value='' ></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <input type='text' name='app_location' size='50' value='' ></td></tr>    

<tr><td></td><td><input type=radio value='eksternal' name=calibrated_by><strong> Eksternal : </strong></td><td>: <input type='text' name='eksternal' size='50' value='' ></td></tr>      
<tr><td>&nbsp;</td></tr>
<tr><td align=right >Calibration Frequency</td><td colspan=2>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM frequency ");
echo "<select name='cal_frequency'>
<option value=''> --Choose Frequency-- </option>
      ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
 echo "<option value='$r_combobox4[code_freq]'> $r_combobox4[frequency]</option>";
}
//<small>Other </small><input type='text'  name='other_frequency' size='30'  >
echo "</select> </td></tr>  

<tr><td align=right>Calibration Date</td><td colspan=2>: ";
combotgl(1,31,'tgl_cal',$tgl_skrg);
combobln(1,12,'bln_cal',$bln_sekarang);
combothn(1990,$thn_sekarang,'thn_cal',$thn_sekarang); 
echo"</td></tr>

<tr><td align=right>Calibration Tolerance</td><td colspan=2>: <input type='text' name='cal_tolerance' size='50' value='' ></td></tr> 

<tr><td align=right>Reason For *Inclusion /Deletion</td><td colspan=2> &nbsp; <textarea name='reason' style='width: 400px; height: 120px;' ></textarea></td></tr> 



<tr><td align=right>Initiated By</td><td colspan=2>: "; include "initiaded.php"; echo "</td></tr>   
<tr><td align=right>Approved By</td><td colspan=2>: "; include "approved.php"; echo "</td></tr>  


 
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "transfer_calibration":
echo "
<form method=POST action='$aksi?module=calibration&act=transfer'  onSubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6 border=0>

<tr><td colspan=3><h2>Transfer Equipment Data</h2></td></tr>";
include "equipment.php";
echo "
<tr><td align='right'>Section Code</td><td> : ";
$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='section'>
      <option value='' selected>--Select--</option>";
while ($r_combobox2=mysqli_fetch_array($sql_combobox2)){
 echo "<option value='$r_combobox2[id]'>$r_combobox2[id] $r_combobox2[section]</option>";
}
echo "</select></td></tr>

<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;


case "process_calibrate":
echo "
<form method=POST action='$aksi?module=calibration&act=process'  onsubmit=''>
<table cellspacing=10 cellpadding=6 border=0>
<tr><td colspan=3><h2>Equipment Data</h2></td></tr>";
include "equipment2.php";
echo "

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr> 

<tr><td align=right>Calibration Date</td><td colspan=2>: ";
combotgl(1,31,'tgl_cal',$tgl_skrg);
combobln(1,12,'bln_cal',$bln_sekarang);
combothn(1990,$thn_sekarang,'thn_cal',$thn_sekarang); 
echo"</td></tr>



 
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;
//<tr><td align=right>Calibration Remarks</td><td colspan=2>: <input type='text' name='remarks' size='50' value='' ></td></tr> 

case "editcalibration":
$edit = mysqli_query($conn, "SELECT * FROM calibration WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
$reas =  str_replace("<BR />",'', $r['reason']);
$reas2 =  str_replace("<BR />",'', $r['cal_tolerance']);
$reas3 =  str_replace("<BR />",'', $r['equip_tolerance']);
echo "
<form method=POST action='$aksi?module=calibration&act=update'  onSubmit='return validasi(this)'>
<input type='hidden'  name='id' size='50' value='$r[id]' >
<table cellspacing=10 cellpadding=6 border=0>


<tr><td align=right>Date</td><td colspan=2>: ";
$get_tgl2=substr("$r[create_date]",8,2);
combotgl(1,31,'tgl_date',$get_tgl2);
$get_bln2=substr("$r[create_date]",5,2);
combobln(1,12,'bln_date',$get_bln2);
$get_thn2=substr("$r[create_date]",0,4);
combothn(1990,$thn_sekarang,'thn_date',$get_thn2);
echo "</td></tr>

<tr><td colspan=3><h2>Equipment Data</h2></td></tr>";
include "equipmentedit.php";
echo "
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <input type='text'  name='manufacturer' size='50' value='$r[manufacturer]'  ></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <input type='text'  name='model_no' size='50' value='$r[model_no]'   ></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <input type='text'  name='serial_no' size='50' value='$r[serial_no]' ></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <input type='text'  name='measure_range' size='50' value='$r[measure_range]' ></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <input type='text' name='usage_range' size='50' value='$r[usage_range]'></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <input type='text'  name='calibration_range' size='50'  value='$r[calibration_range]'></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <input type='text'  name='equip_location' size='50'  value='";
echo htmlentities(htmlspecialchars_decode($r['equip_location']), ENT_QUOTES);
echo "'></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <input type='text'  name='retention' size='50'  value='$r[retention]'></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'> &nbsp; 
<textarea name='equip_tolerance' style='width: 400px; height: 130px;' >$reas3</textarea></td></tr>

<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <input type='text'  name='usage_tolerance' size='50' value='$r[usage_tolerance]'></td></tr> -->
 

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr>
<tr><td align=right>Calibrated By</td><td colspan=2>"; 
if ($r['calibrated_by']=='internal') {
	echo "<input type=radio value='internal' name=calibrated_by checked> ";
} else {
	echo "<input type=radio value='internal' name=calibrated_by > ";
}
echo "
<strong> Internal : </strong></td></tr>      
<tr><td></td><td colspan=2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ";
if ($r['internal'] =='JMSB') {
	echo "<input type=checkbox name='internal' value='JMSB' checked> JMS(B)&nbsp; <input type=checkbox name='internal' value='JMSS'> JMS(S)"; 
} elseif ($r['internal'] =='jmss') {
	echo "<input type=checkbox name='internal' value='JMSB' > JMS(B)&nbsp; <input type=checkbox name='internal' value='JMSS' checked> JMS(S)"; 
} else {
	echo "<input type=checkbox name='internal' value='JMSB' > JMS(B)&nbsp; <input type=checkbox name='internal' value='JMSS' > JMS(S)"; 
}
echo "</td></tr>
<tr><td></td><td align=right width=200>Apparatus</td><td>: <input type='text' name='apparatus' size='50' value='$r[apparatus]' ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <input type='text' name='identification' size='50' value='$r[identification]' ></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <input type='text' name='app_location' size='50' value='$r[app_location]' ></td></tr>    

<tr><td></td><td>";
if ($r['calibrated_by']=='eksternal') {
	echo "<input type='radio' value='eksternal' name='calibrated_by' checked> ";
} else {
	echo "<input type='radio' value='eksternal' name='calibrated_by' > ";
}
echo "
<strong> Eksternal : </strong></td><td>: <input type='text' name='eksternal' size='50' value='";
echo htmlentities(htmlspecialchars_decode($r['eksternal']), ENT_QUOTES);
echo "' ></td></tr>      
<tr><td>&nbsp;</td></tr>


<tr><td align=right >Calibration Frequency</td><td colspan=2>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM frequency ");
echo "<select name='cal_frequency'>
<option value=''> --Choose Frequency-- </option>
      ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
	
  if ($r['cal_frequency'] == $r_combobox4['code_freq']){
     echo "<option value='$r_combobox4[code_freq]' selected>$r_combobox4[frequency]</option>";
 }
 else {
     echo "<option value='$r_combobox4[code_freq]'>$r_combobox4[frequency]</option>";
 }
}
//<small>Other </small><input type='text'  name='other_frequency' size='30' value='"; echo htmlentities(htmlspecialchars_decode($r[other_frequency]), ENT_QUOTES); echo "' >
echo "</select> </td></tr>  

<tr><td align=right>Calibration Date</td><td colspan=2>: ";
$get_tgl2=substr("$r[cal_date]",8,2);
combotgl(1,31,'tgl_cal',$get_tgl2);
$get_bln2=substr("$r[cal_date]",5,2);
combobln(1,12,'bln_cal',$get_bln2);
$get_thn2=substr("$r[cal_date]",0,4);
combothn(1990,$thn_sekarang,'thn_cal',$get_thn2);
echo "</td></tr>

<tr><td align=right>Calibration Tolerance</td><td colspan=2> &nbsp; 
<textarea name='cal_tolerance' style='width: 400px; height: 130px;' >$reas2</textarea></td></tr>
<tr><td align=right>Reason For *Inclusion /Deletion</td><td colspan=2> &nbsp; <textarea name='reason' style='width: 400px; height: 130px;' >$reas</textarea></td></tr> 

<tr><td align=right>Initiated By</td><td colspan=2>: "; include "initiadededit.php"; echo "</td></tr>   
<tr><td align=right>Approved By</td><td colspan=2>: "; include "approvededit.php"; echo "</td></tr>  


 
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;


case "deletion_cal":
$edit = mysqli_query($conn, "SELECT * FROM calibration WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "
<form method=POST action='$aksi?module=calibration&act=deletion'  onsubmit=''>
<input type='hidden'  name='id' size='50' value='$r[id]' >
<table cellspacing=10 cellpadding=6 border=0>
<tr><td colspan=3><h2>Equipment Data</h2></td></tr>
<tr><td align='right'>Unique Identify</td><td colspan='2'>: <span>$r[equip_identify] </span></td></tr>
<tr><td align='right'>Equipment Name</td><td colspan='2'>: <span>$r[equip_name]</span></td></tr>  
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <span>$r[manufacturer] </span></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <span>$r[model_no]</span></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <span>$r[serial_no]</span></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <span>$r[measure_range]</span></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <span>$r[usage_range]</span></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <span>$r[calibration_range]</span></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <span>$r[equip_location]</span></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <span>$r[retention]</span></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'>: <span>$r[equip_tolerance]</span></td></tr>
<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <span>$r[usage_tolerance]</span></td></tr> -->
 

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr>
<tr><td align=right>Calibrated By</td><td colspan=2>: "; 
if ($r['calibrated_by']=='internal') {
	echo "Internal : $r[internal]</td></tr>  
	<tr><td></td><td align=right width=200>Apparatus</td><td>: <span >$r[apparatus]</span ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <span>$r[identification]</span></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <span>$r[app_location]</span ></td></tr> 
	";
	
} else if ($r['calibrated_by']=='eksternal') {
	echo "Eksternal : $r[eksternal]</td></tr>";
} 
echo "
  
<tr><td align=right>Deletion Date</td><td colspan=2>: ";
combotgl(1,31,'tgl_cal',$tgl_skrg);
combobln(1,12,'bln_cal',$bln_sekarang);
combothn(1990,$thn_sekarang,'thn_cal',$thn_sekarang); 
echo"</td></tr>


<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "approve_cal":
$edit = mysqli_query($conn, "SELECT * FROM calibration WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "
<form method=POST action='$aksi?module=calibration&act=approve'  onsubmit=''>
<input type='hidden'  name='id' size='50' value='$r[id]' >
<table cellspacing=10 cellpadding=6 border=0>
<tr><td colspan=3><h2>Equipment Data</h2></td></tr>
<tr><td align='right'>Unique Identification</td><td colspan='2'>: <span>$r[equip_identify] </span></td></tr>
<tr><td align='right'>Equip Name</td><td colspan='2'>: <span>$r[equip_name] </span></td></tr>
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <span>$r[manufacturer] </span></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <span>$r[model_no]</span></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <span>$r[serial_no]</span></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <span>$r[measure_range]</span></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <span>$r[usage_range]</span></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <span>$r[calibration_range]</span></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <span>$r[equip_location]</span></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <span>$r[retention]</span></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'>: <span>$r[equip_tolerance]</span></td></tr>
<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <span>$r[usage_tolerance]</span></td></tr> -->
 

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr>
<tr><td align=right>Calibrated By</td><td colspan=2>: "; 
if ($r['calibrated_by']=='internal') {
	echo "Internal : $r[internal]</td></tr>  
	<tr><td></td><td align=right width=200>Apparatus</td><td>: <span >$r[apparatus]</span ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <span>$r[identification]</span></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <span>$r[app_location]</span ></td></tr> 
	";
	
} else if ($r['calibrated_by']=='eksternal') {
	echo "Eksternal : $r[eksternal]</td></tr>";
} 
echo "
  
<tr><td align=right>Approve Date</td><td colspan=2>: ";
combotgl(1,31,'tgl_cal',$tgl_skrg);
combobln(1,12,'bln_cal',$bln_sekarang);
combothn(1990,$thn_sekarang,'thn_cal',$thn_sekarang); 
echo"</td></tr>


<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "return":
$edit = mysqli_query($conn, "SELECT * FROM calibration WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "
<form method=POST action='$aksi?module=calibration&act=return'  onsubmit=''>
<input type='hidden'  name='id' size='50' value='$r[id]' >
<table cellspacing=10 cellpadding=6 border=0>
<tr><td colspan=3><h2>Equipment Data</h2></td></tr>
<tr><td align='right'>Unique Identify</td><td colspan='2'>: <span>$r[equip_identify] </span></td></tr>
<tr><td align='right'>Equipment Name</td><td colspan='2'>: <span>$r[equip_name]</span></td></tr>  
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <span>$r[manufacturer] </span></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <span>$r[model_no]</span></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <span>$r[serial_no]</span></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <span>$r[measure_range]</span></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <span>$r[usage_range]</span></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <span>$r[calibration_range]</span></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <span>$r[equip_location]</span></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <span>$r[retention]</span></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'>: <span>$r[equip_tolerance]</span></td></tr>
<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <span>$r[usage_tolerance]</span></td></tr> -->
 

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr>
<tr><td align=right>Calibrated By</td><td colspan=2>: "; 
if ($r['calibrated_by']=='internal') {
	echo "Internal : $r[internal]</td></tr>  
	<tr><td></td><td align=right width=200>Apparatus</td><td>: <span >$r[apparatus]</span ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <span>$r[identification]</span></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <span>$r[app_location]</span ></td></tr> 
	";
	
} else if ($r['calibrated_by']=='eksternal') {
	echo "Eksternal : $r[eksternal]</td></tr>";
} 
echo "
<tr><td align=right>Status</td><td colspan=2>: $r[status]</td></tr>
<tr><td align=right>Approve Date</td><td colspan=2>: $r[approve_date]</td></tr>


<tr><td colspan=2><input type=submit name=submit value=Return (Dis-Approve) class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "propose_del":
$edit = mysqli_query($conn, "SELECT * FROM calibration WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "
<form method=POST action='$aksi?module=calibration&act=propose'  onsubmit=''>
<input type='hidden'  name='id' size='50' value='$r[id]' >
<table cellspacing=10 cellpadding=6 border=0>

<tr><td align=right>Date</td><td colspan=2>: ";
combotgl(1,31,'tgl_date',$tgl_skrg);
combobln(1,12,'bln_date',$bln_sekarang);
combothn(1990,$thn_sekarang,'thn_date',$thn_sekarang); 
echo"</td></tr>

<tr><td colspan=3><h2>Equipment Data</h2></td></tr>
<tr><td align='right'>Unique Identify</td><td colspan='2'>: <span>$r[equip_identify] </span></td></tr>
<tr><td align='right'>Equipment Name</td><td colspan='2'>: <span>$r[equip_name]</span></td></tr>  
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <span>$r[manufacturer] </span></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <span>$r[model_no]</span></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <span>$r[serial_no]</span></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <span>$r[measure_range]</span></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <span>$r[usage_range]</span></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <span>$r[calibration_range]</span></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <span>$r[equip_location]</span></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <span>$r[retention]</span></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'>: <span>$r[equip_tolerance]</span></td></tr>
<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <span>$r[usage_tolerance]</span></td></tr> -->
 

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr>
<tr><td align=right>Calibrated By</td><td colspan=2>: "; 
if ($r['calibrated_by']=='internal') {
	echo "Internal : $r[internal]</td></tr>  
	<tr><td></td><td align=right width=200>Apparatus</td><td>: <span >$r[apparatus]</span ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <span>$r[identification]</span></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <span>$r[app_location]</span ></td></tr> 
	";
	
} else if ($r['calibrated_by']=='eksternal') {
	echo "Eksternal : $r[eksternal]</td></tr>";
} 
echo "
<tr><td align=right>Status</td><td colspan=2>: $r[status]</td></tr>
<tr><td align=right>Approve Date</td><td colspan=2>: $r[approve_date]</td></tr>


<tr><td colspan=2><input type=submit name=submit value='Propose Deletion' class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;


case "undel":
$edit = mysqli_query($conn, "SELECT * FROM calibration WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "
<form method=POST action='$aksi?module=calibration&act=undel'  onsubmit=''>
<input type='hidden'  name='id' size='50' value='$r[id]' >
<table cellspacing=10 cellpadding=6 border=0>
<tr><td colspan=3><h2>Equipment Data</h2></td></tr>
<tr><td align='right'>Unique Identify</td><td colspan='2'>: <span>$r[equip_identify] </span></td></tr>
<tr><td align='right'>Equipment Name</td><td colspan='2'>: <span>$r[equip_name]</span></td></tr>  
<tr><td align='right'>Manufacturer</td><td colspan='2'>: <span>$r[manufacturer] </span></td></tr>
<tr><td align='right'>Model No</td><td colspan='2'>: <span>$r[model_no]</span></td></tr>          
<tr><td align='right'>Serial No</td><td colspan='2'>: <span>$r[serial_no]</span></td></tr>  
<tr><td align='right'>Equipment Measurement Range No</td><td colspan='2'>: <span>$r[measure_range]</span></td></tr>   
<tr><td align='right'>Usage Range</td><td colspan='2'>: <span>$r[usage_range]</span></td></tr>   
<tr><td align='right'>Calibration Range</td><td colspan='2'>: <span>$r[calibration_range]</span></td></tr>   
<tr><td align='right'>Location of Equipment</td><td colspan='2'>: <span>$r[equip_location]</span></td></tr>   
<tr><td align='right'>Record Retention Location</td><td colspan='2'>: <span>$r[retention]</span></td></tr>   
<tr><td align='right'>Equipment Tolerance</td><td colspan='2'>: <span>$r[equip_tolerance]</span></td></tr>
<!-- <tr><td align='right'>Usage Tolerance</td><td colspan='2'>: <span>$r[usage_tolerance]</span></td></tr> -->
 

<tr><td colspan=3 ><br><h2>Calibration Information</h2></td></tr>
<tr><td align=right>Calibrated By</td><td colspan=2>: "; 
if ($r['calibrated_by']=='internal') {
	echo "Internal : $r[internal]</td></tr>  
	<tr><td></td><td align=right width=200>Apparatus</td><td>: <span >$r[apparatus]</span ></td></tr>          
<tr><td></td><td align=right>Identification</td><td>: <span>$r[identification]</span></td></tr> 
<tr><td></td><td align=right>Apparatus Location</td><td>: <span>$r[app_location]</span ></td></tr> 
	";
	
} else if ($r['calibrated_by']=='eksternal') {
	echo "Eksternal : $r[eksternal]</td></tr>";
} 
echo "
<tr><td align=right>Status</td><td colspan=2>: $r[status]</td></tr>
<tr><td align=right>Deletion Date</td><td colspan=2>: $r[deletion_date]</td></tr>


<tr><td colspan=2><input type=submit name=submit value=UnDeletion (Back to Active) class='large blue super button' >
<input type=button value=Cancel class='large orange super button'  onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit calibration 
//<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old Masterlist Data? </u> </label>   </td></tr>
case "import":
//<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old Employee Data? </u> </label>   </td></tr>
echo "<h2>Import Master Pilot No</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateImport()' action='$aksi?module=calibration&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>

<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Column B Row Two (2) : B2,B3,B4... </br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Format Data Excel Must not be changed!</small></i></strong></td></tr>
<tr><td colspan=2><img src='images/calibration.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;


case "rep_statuslog":
$section= $_POST['section'];
$status = $_POST['status'];
$thn3=$_POST['thn_tgl3']; 
echo "
<input type=button value='Add New Master Calibration'  class='large blue super button' 
onclick=\"window.location.href='?module=calibration&act=tambahcalibration';\"> <input type=button value='View Deletion Calibration'  class='large orange super button' 
onclick=\"window.location.href='?module=calibration&act=view_ekscalibration';\">
<p>&nbsp;</p>
<h2>Masterlist Active Calibration</h2>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th><th>Unique Code</th><th>Equipment Name</th><th>Date Calibration</th><th>Frequency</th><th>Due Calibration</th><th>Location</th><th>Type</th><th>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT c.*, f.frequency FROM calibration c inner join frequency f on c.cal_frequency=f.code_freq and c.section='$_SESSION[section]' and c.status='Active' order by c.id desc limit 300");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td><td>$r[equip_identify]</td>
	<td>$r[equip_name]</td><td>$r[cal_date]</td><td>$r[frequency]</td><td>$r[due_caldate]</td><td>$r[equip_location]</td>	<td>$r[calibrated_by]</td>	
        <td width=130><a href='?module=calibration&act=editcalibration&id=$r[id]'><image src=images/edit.png></a>|<a href='?module=calibration&act=deletion_cal&id=$r[id]'><image src=images/approve.png></a> 
        <a href=javascript:confirmdelete('$aksi?module=calibration&act=delete&id=$r[id]')><image src=images/hapus.png></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;


}
}
?>
