<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");

$year=$_POST['thn_tgl3'];
$section=$_POST['section'];
$status=$_POST['status'];

$sql= mysql_query("select date_format(now(),'%d %b %y')as sekarang, section from sectioncode  where id='$_POST[section]'");
$p=mysql_fetch_array($sql);


$html = 
'
<html>
					<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:11 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20; margin-top: 0.75 cm; margin-bottom: 0.5 cm;margin-right:-10; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:10 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>

<table width="800" border="0">
  	<tr><td align=center colspan=2><strong>EQUIPMENT CALIBRATION STATUS LOG</strong></td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
  <tr><td align=left colspan=2> <strong><i>Section : All Section</strong></i><strong><i>&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; Status : '.$_POST[status].'  &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; Year : '.$_POST[year].' &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; Printout Date : '.$p[sekarang].'</i></strong></td></tr>
</table>

<table style="border-collapse: collapse;" cellspacing="6" cellpadding="10" border=1 width="800">
<thead>
<tr style="font-variant:small-caps;font-style:italic;color:black;font-size:14px;">
<th width=10 rowspan=2>SN</th><th rowspan=2 width=60>Equip <br>Identify</th><th rowspan=2 width=80>Equip <br>Name</th>
<th  rowspan=2 width=40>Frequency</th><th width=20 rowspan=2>Type</th><th colspan=12>Calibration Date</th><th width=50 rowspan=2>Due Date<br>Cal</th>
</tr>
<tr><th width=20>Jan</th><th width=20>Feb</th ><th width=20>Mar</th><th width=20>Apr</th><th width=20>May</th><th width=20>Jun</th><th width=20>Jul</th><th width=20>Aug</th>
<th width=20>Sept</th><th width=20>Okt</th><th width=20>Nov</th><th width=20>Dec</th></tr>

</thead><tbody>';


$tampil=mysql_query("SELECT c.equip_identify, c.equip_name, c.type_calibration,upper(left(c.calibrated_by,3)) as type,
datediff(current_date(),c.due_caldate) as selisih,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=1 and year(t.date)=$_POST[year]) as jan,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=2 and year(t.date)=$_POST[year]) as  feb,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=3 and year(t.date)=$_POST[year]) as  mar,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=4 and year(t.date)=$_POST[year])  as apr,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=5 and year(t.date)=$_POST[year]) as  may,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=6 and year(t.date)=$_POST[year])  as jun,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=7 and year(t.date)=$_POST[year])  as jul,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=8 and year(t.date)=$_POST[year])  as aug,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=9 and year(t.date)=$_POST[year])  as sep,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=10 and year(t.date)=$_POST[year])  as okt,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=11 and year(t.date)=$_POST[year])  as nov,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=12 and year(t.date)=$_POST[year])  as des,

date_format((c.due_caldate),'%d %b %y')as due_caldate

 FROM calibration c left join process_calibration t on t.equip_identify=c.equip_identify where c.status='Active' group by c.equip_identify order by c.section");


$no=1;
while ($r=mysql_fetch_array($tampil)){
	
  $html.='<tr >
		<td valign=top>'.$no.'.</td>
	   	<td valign=top>'.$r[equip_identify].'</td>
      	<td valign=top>'.$r[equip_name].'</td>
		<td valign=top>'.$r[type_calibration].'</td>
		<td valign=top>'.$r[type].'</td>
      	<td valign=top>'.$r[jan].'</td>
      	<td valign=top>'.$r[feb].'</td>
      	<td valign=top>'.$r[mar].'</td>
      	<td valign=top>'.$r[apr].'</td>
		<td valign=top>'.$r[may].'</td>
		<td valign=top>'.$r[jun].'</td>
		<td valign=top>'.$r[jul].'</td>
		<td valign=top>'.$r[aug].'</td>
		<td valign=top>'.$r[sep].'</td>
		<td valign=top>'.$r[okt].'</td>
		<td valign=top>'.$r[nov].'</td>
		<td valign=top>'.$r[des].'</td>
      	<td valign=top>'.$r[due_caldate].'</td>
	
      
      
        </tr>';
  $no++;
}
 $html.='</table> 
 <p>&nbsp;<br><br></p>
 <table border=1 align=right cellpadding=4 cellspacing=0>
 <tr><td width=100 align=center>Prepared By </td><td  align=center width=100>Approved By </td></tr> 
 <tr><td><br><br><br> </td><td> </td></tr>
 <tr><td align=center>Calibration Designate</td><td align=center>Section Head</td></tr>
 </table>
</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A4", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$font = Font_Metrics::get_font("helvetica");
$font2 = Font_Metrics::get_font("helvetica", "bold");

$canvas->page_text(94, 22, "PT. JMS BATAM", $font2, 10, array(0,0,0));
$canvas->page_text(94, 26, "_________________________________________________________________________________________________________________", $font, 8, array (0,0,0));
$canvas->page_text(94, 37, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia (Telepon): (62) 770-611807 Faksimili: 770-611806", $font, 8, array (0,0,0));

$canvas->page_text(700,570, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 10, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>