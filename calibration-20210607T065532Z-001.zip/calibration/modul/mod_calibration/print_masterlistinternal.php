<?php
error_reporting(E_ALL);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);


//$year=$_POST['thn_tgl3'];
//$section=$_POST['section'];
if ($_POST['calibrated_by']=='internaljmsb') {
	$internal='JMSB';
}
 else if ($_POST['calibrated_by']=='internaljmss') {
	 $internal='JMSS';
 }

$sql= mysqli_query($conn, "SELECT * FROM sectioncode  where id='$_POST[section]'");
$p=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * FROM doc_code where dokumen= 'internal'");
$rkode=mysqli_fetch_array($qkode);


$html = 
'
<html>
					<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:10 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20; margin-top: 0.75 cm; margin-bottom: 0.5 cm;margin-right:-10; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:10 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>
<table width="1000" border="0" align="center">
  	<tr><td align=left colspan=2><strong><h2>EQUIPMENT CALIBRATION MASTERLIST - INTERNAL ('.$internal.')</h2></strong></td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
	<tr><td width=100>Section</td><td>: '.$_POST['section'].' / '.$p['section'].'</td></tr>
	<tr><td width=100>Status</td><td>: '.$_POST['status'].'</td></tr>
	';
		if ($_POST['calibrated_by']=='internaljmsb') {
	$html.='<tr><td>Revision Number</td><td>: '.$p['rev_jmsb'].'</td></tr>
	<tr><td>Update On</td><td>: '.$p['update_jmsb'].'</td></tr>';
}
 else if ($_POST['calibrated_by']=='internaljmss') {
	 $html.='<tr><td>Revision Number</td><td>: '.$p['rev_jmss'].'</td></tr>
	<tr><td>Update On</td><td>: '.$p['update_jmss'].'</td></tr>';
 } else {
	 $html.='<tr><td>Revision Number</td><td>: </td></tr>
	<tr><td>Update On</td><td>: </td></tr>';
 } 

	$html.='
	<tr><td align=center colspan=2>&nbsp;</td></tr>
</table>

<table style="border-collapse: collapse;" cellspacing="5" cellpadding="8" border="0" align=left width="1000">

<thead>
<tr style="font-variant:small-caps;font-style:italic;color:black;font-size:12px;">
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=10>No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=50>Equipment<br>Name</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=50>Inclusion<br>Date</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=60>Equipment<br>Location</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=70>Unique<br>Identification</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=30>Serial No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=30>Model No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=40>Manufacturer</th >
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=40>Measurement<br>Range</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=30>Usage<br>Range</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=50>Calibration<br>Range</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=30>Calibration<br>Frequency</th>
<!-- <th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=30>Usage<br>Tolerance</th> -->
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=40>Calibration<br>Tolerance</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=40>Calibration<br>Apparatus</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;" width=70>Apparatus<br>Identification<br>and Location</th>
</tr></thead><tbody>
';

$tampil=mysqli_query($conn, "SELECT DATE_FORMAT(c.create_date,'%d %b %y')AS inclusion_date,
c.equip_name, c.equip_location, c.equip_identify,c.serial_no,c.model_no,c.manufacturer,
c.measure_range, c.usage_range, c.calibration_range, c.type_calibration, c.cal_tolerance, 
c.apparatus,c.identification, c.app_location, c.usage_tolerance
FROM calibration c  WHERE c.status='$_POST[status]' and c.calibrated_by='internal' and c.internal='$internal' and c.section='$_POST[section]' 
order by c.equip_name, c.cal_date, c.equip_identify");


$no=1;
while ($r=mysqli_fetch_array($tampil)){
  $html.='<tr >
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$no.'.</td>
	   	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['equip_name'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['inclusion_date'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['equip_location'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['equip_identify'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['serial_no'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['model_no'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['manufacturer'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['measure_range'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['usage_range'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['calibration_range'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['type_calibration'].'</td>
		<!-- <td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['usage_tolerance'].'</td> -->
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['cal_tolerance'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;" valign=top>'.$r['apparatus'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;" valign=top>'.$r['identification'].'<br>'.$r['app_location'].'</td>    
        </tr>';
  $no++;
}
 $html.='
<tr><td colspan=15 style="border-top:1px solid #000000;"><br><br><br><br><br></td></tr>

<tr style="font-style:italic">
	<td colspan=5 align=center>Calibration Designated<br>_______________________</td>
	<td colspan=5 align=center>Section Head<br> _______________________</td>
	<td colspan=5 align=center>Department Head<br>_______________________</td>
</tr> 
<tr style="font-style:italic">
	<td colspan=5 align=center valign=top>PREPARED BY : N/D/S/D</td>
	<td colspan=5 align=center >CHECKED BY : N/D/S/D</td>
	<td colspan=5 align=center >APPROVED BY : N/D/S/D</td>
</tr> 
<tr style="font-style:italic">
	<td colspan=14><br><i>(N/D/S/D : Name/Designation/Signature/Date)</i></td>
</tr>

 </table> 
 

 
</body></html>';
	
$dompdf->load_html($html);
$dompdf->set_paper("A3", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();

$canvas->page_text(94, 22, "PT. JMS BATAM", "helvetica-bold", 9, array(0,0,0));
$canvas->page_text(94, 26, "___________________________________________________________________________________________________________________________________________________", "helvetica", 8, array (0,0,0));
$canvas->page_text(94, 37, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia (Telepon): (62) 770-611807 Faksimili: 770-611806", "helvetica", 10, array (0,0,0));

$canvas->page_text(480,800, "Page: {PAGE_NUM} of {PAGE_COUNT}", "helvetica", 9, array(0,0,0));
$canvas->page_text(16, 800, "Doc. Code : $rkode[code1]", "helvetica", 9, array(0,0,0));
$canvas->page_text(1000, 800, "$rkode[code2]", "helvetica", 9, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>