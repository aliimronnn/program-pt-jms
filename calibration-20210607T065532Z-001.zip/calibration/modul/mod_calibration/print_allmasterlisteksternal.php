<?php
error_reporting(E_ALL);
set_time_limit(0);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);



//$year=$_POST['thn_tgl3'];
//$section=$_POST['section'];
$sql= mysqli_query($conn, "SELECT * FROM sectioncode ");
$p=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * FROM doc_code WHERE dokumen= 'eksternal'");
$rkode=mysqli_fetch_array($qkode);

$html = 
'
<html>
					<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:0.1; margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:10 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:0.1 cm; margin-top: 0.75 cm; margin-bottom: 0.5 cm;margin-right:-10; }
			
				tr td{ word-break:break-all; padding-left:1px;padding-top:1px; font-size:10 pt;}
				tr th{ padding-left:1px;}	
			
					
}

				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>
<table width="1000" border="0" align="center">
  	<tr><td align=left colspan=2><strong><h2>EQUIPMENT CALIBRATION MASTERLIST - EXTERNAL </h2></strong></td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
	<tr><td width=100>Section</td><td>: All Section</td></tr>
	<tr><td width=100>Status</td><td>: '.$_POST['status'].'</td></tr>
	<tr><td>Revision Number</td><td>: '.$p['rev_eksternal'].'</td></tr>
	<tr><td>Update On</td><td>: '.$p['update_eksternal'].'</td></tr>
	<tr><td align=center colspan=2>&nbsp;</td></tr>
</table>

<table style="border-collapse: collapse;" cellspacing="6" cellpadding="10" border="0" align=left width="1000">

<thead>
<tr style="font-variant:small-caps;font-style:italic;color:black;font-size:12px;">
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=10>No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=40>Apparatus/ Measuring<br>Equipment Name</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=40>Inclusion<br>Date</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=60>Apparatus/ Measuring<br>Equipment Location</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=70>Unique<br>Identification</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=30>Serial No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=30>Model No.</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=50>Manufacturer</th >
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=70>Measurement<br>Range</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=70>Usage<br>Range</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=70>Calibration<br>Range</th>
<!-- <th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=40>Usage<br>Tolerance</th> -->
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=70>Calibration<br>Tolerance</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=60>Equipment<br>Tolerance</th>
<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;" width=50>Calibration<br>Frequency</th>

</tr></thead><tbody>
';

//Request to revert to BQA/CAL/012-02/03 by Bu Norita & Bu Nining
/* $tampil=mysql_query("SELECT DATE_FORMAT(c.create_date,'%d %b %y')AS inclusion_date,

$tampil=mysql_query("SELECT c.create_date,
c.equip_name, c.equip_location, c.equip_identify,c.serial_no,c.model_no,c.manufacturer,
c.type_calibration, c.status
FROM calibration c
WHERE c.status='$_POST[status]' and c.calibrated_by='eksternal' order by c.equip_name,c.cal_date ");
*/

$tampil=mysqli_query($conn, "SELECT DATE_FORMAT(c.create_date,'%d %b %y')AS inclusion_date,
c.equip_name, c.equip_location, c.equip_identify,c.serial_no,c.model_no,c.manufacturer,
c.measure_range, c.usage_range, c.calibration_range, cal_tolerance, equip_tolerance, c.type_calibration, c.usage_tolerance
FROM calibration c
WHERE c.status='$_POST[status]' and c.calibrated_by='eksternal' order by c.equip_name, c.cal_date");


$no=1;
while ($r=mysqli_fetch_array($tampil)){
  $html.='<tr >
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"	 valign=top>'.$no.'.</td>
	   	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['equip_name'].'</td>	
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['inclusion_date'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['equip_location'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['equip_identify'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['serial_no'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000; word-break:break-all;"  valign=top>'.$r['model_no'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['manufacturer'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['measure_range'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['usage_range'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['calibration_range'].'</td>
		<!-- <td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['usage_tolerance'].'</td> -->
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['cal_tolerance'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"  valign=top>'.$r['equip_tolerance'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;"  valign=top>'.$r['type_calibration'].'</td>
		
        </tr>';
  $no++;
}
 $html.=' <tr><td style="border-top:1px solid #000000;" colspan=9><br><br><br><br><br></td></tr>
<tr style=font-style:italic>
	<td colspan=2 align=center >Calibration Designated<br>_______________________</td>
	<td colspan=3 align=center >Section Head<br> _______________________</td>
	<td colspan=4 align=center >Department Head<br>_______________________</td>
</tr> 
<tr style=font-style:italic>
	<td colspan=2  align=center valign=top>PREPARED BY : N/D/S/D</td>
	<td colspan=3  align=center >CHECKED BY : N/D/S/D</td>
	<td colspan=4 align=center >APPROVED BY : N/D/S/D</td>
</tr> 
 <tr style=font-style:italic><td colspan=9><br><br><i>(N/D/S/D : Name/Designation/Signature/Date)</i></td></tr>
 </table> 
</body></html>';
	

$dompdf->load_html($html);
$dompdf->set_paper("A3", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();

$canvas->page_text(111, 22, "PT. JMS BATAM", "helvetica-bold", 10, array(0,0,0));
$canvas->page_text(111, 26, "___________________________________________________________________________________________________________________________________________________", "helvetica", 8, array (0,0,0));
$canvas->page_text(111, 37, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia (Telepon): (62) 770-611807 Faksimili: 770-611806", "helvetica", 10, array (0,0,0));

$canvas->page_text(550,800, "Page: {PAGE_NUM} of {PAGE_COUNT}", "helvetica", 10, array(0,0,0));
$canvas->page_text(40, 800, "Doc. Code : $rkode[code1]", "helvetica", 9, array(0,0,0));
$canvas->page_text(900, 800, "$rkode[code2]", "helvetica", 9, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>