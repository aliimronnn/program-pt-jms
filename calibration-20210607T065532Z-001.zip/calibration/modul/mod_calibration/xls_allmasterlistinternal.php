<?php
require_once("../../config/koneksi.php");
if ($_POST['calibrated_by']=='internaljmsb') {
  $internal='JMSB';
}
 else if ($_POST['calibrated_by']=='internaljmss') {
   $internal='JMSS';
 }
header("Content-Disposition: attachment; filename=ExcelReportMasterList_Internal(".$internal.").xls");
header("Content-Type: application/vnd.ms-excel");

$sql= mysqli_query($conn, "SELECT * FROM sectioncode  where id='$_POST[section]'");
$p=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * FROM doc_code where dokumen= 'internal'");
$rkode=mysqli_fetch_array($qkode);


?>
<table border="1">
  <h2>EQUIPMENT CALIBRATION MASTERLIST - INTERNAL (<?php echo $internal; ?>)</h2>
  <h4>Section : All Section</h2>
  <h4>Status : <?php echo $_POST['status']; ?></h2>
  <h4>Revision Number : - </h2>
  <h4>Update On : - </h2>
<tr>
<th>No.</th>
<th>Equipment<br>Name</th>
<th>Inclusion<br>Date</th>
<th>Equipment<br>Location</th>
<th>Unique<br>Identification</th>
<th>Serial No.</th>
<th>Model No.</th>
<th>Manufacturer</th>
<th>Measurement<br>Range</th>
<th>Usage<br>Range</th>
<th>Calibration<br>Range</th>
<th>Calibration<br>Frequency</th>
<th>Usage<br>Tolerance</th>
<th>Calibration<br>Tolerance</th>
<th>Calibration<br>Apparatus</th>
<th>Apparatus<br>Identification<br>and Location</th>
</tr>
<?php  
$tampil=mysqli_query($conn, "SELECT DATE_FORMAT(c.create_date,'%d %b %y')AS inclusion_date, c.create_date,
c.equip_name, c.equip_location, c.equip_identify,c.serial_no,c.model_no,c.manufacturer, c.measure_range, c.usage_range, c.calibration_range, c.type_calibration, c.cal_tolerance, c.apparatus, c.identification, c.app_location, c.usage_tolerance
FROM calibration c  WHERE c.status='$_POST[status]' and c.calibrated_by='internal' and c.internal='$internal' order by c.equip_name, c.cal_date");
  $no=1;
  while ($r=mysqli_fetch_array($tampil)){
    ?>
<tr>
  <td><?php echo $no++; ?></td>
  <td><?php echo $r['equip_name']; ?></td>  
  <td><?php echo $r['inclusion_date']; ?></td>
  <td><?php echo $r['equip_location']; ?></td>
  <td><?php echo $r['equip_identify']; ?></td>
  <td><?php echo $r['serial_no']; ?></td>
  <td><?php echo $r['model_no']; ?></td>
  <td><?php echo $r['manufacturer']; ?></td>
  <td><?php echo $r['measure_range']; ?></td>
  <td><?php echo $r['usage_range']; ?></td>
  <td><?php echo $r['calibration_range']; ?></td>
  <td><?php echo $r['type_calibration']; ?></td>
  <td><?php echo $r['usage_tolerance']; ?></td>
  <td><?php echo $r['cal_tolerance']; ?></td>
  <td><?php echo $r['apparatus']; ?></td>
  <td><?php echo $r['identification']; ?><br><?php echo $r['app_location']; ?></td>     
  </tr>
  <?php
    }
?>
</table>