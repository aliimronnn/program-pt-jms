<?php
require_once("../../config/koneksi.php");

header("Content-Disposition: attachment; filename=ExcelReportMasterList_External.xls");
header("Content-Type: application/vnd.ms-excel");

$sql= mysqli_query($conn, "SELECT * FROM sectioncode ");
$p=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * FROM doc_code where dokumen= 'eksternal'");
$rkode=mysqli_fetch_array($qkode);


?>
<table border="1">
  <h2>EQUIPMENT CALIBRATION MASTERLIST - EXTERNAL</h2>
  <h4>Section : All Section</h2>
  <h4>Status : <?php echo $_POST['status']; ?></h2>
  <h4>Revision Number : <?php echo $p['rev_eksternal']; ?></h2>
  <h4>Update On : <?php echo $p['update_eksternal']; ?></h2>
<tr>
<th>No.</th>
<th>Apparatus/ Measuring<br>Equipment Name</th>
<th>Inclusion<br>Date</th>
<th>Apparatus/ Measuring<br>Equipment Location</th>
<th>Unique<br>Identification</th>
<th>Serial No.</th>
<th>Model No.</th>
<th>Manufacturer</th>
<th>Measurement<br>Range</th>
<th>Usage<br>Range</th>
<th>Calibration<br>Range</th>
<th>Usage<br>Tolerance</th>
<th>Calibration<br>Tolerance</th>
<th>Equipment<br>Tolerance</th>
<th>Calibration<br>Frequency</th>
</tr>
<?php  
$tampil=mysqli_query($conn, "SELECT DATE_FORMAT(c.create_date,'%d %b %y')AS inclusion_date,
c.equip_name, c.equip_location, c.equip_identify,c.serial_no,c.model_no,c.manufacturer,
c.measure_range, c.usage_range, c.calibration_range, cal_tolerance, equip_tolerance, c.type_calibration, c.usage_tolerance
FROM calibration c
WHERE c.status='$_POST[status]' and c.calibrated_by='eksternal' order by c.equip_name, c.cal_date");
  $no=1;
  while ($r=mysqli_fetch_array($tampil)){
    ?>
<tr>
  <td><?php echo $no++; ?></td>
  <td><?php echo $r['equip_name']; ?></td>  
  <td><?php echo $r['inclusion_date']; ?></td>
  <td><?php echo $r['equip_location']; ?></td>
  <td><?php echo $r['equip_identify']; ?></td>
  <td><?php echo $r['serial_no']; ?></td>
  <td><?php echo $r['model_no']; ?></td>
  <td><?php echo $r['manufacturer']; ?></td>
  <td><?php echo $r['measure_range']; ?></td>
  <td><?php echo $r['usage_range']; ?></td>
  <td><?php echo $r['calibration_range']; ?></td>
  <td><?php echo $r['usage_tolerance']; ?></td>
  <td><?php echo $r['cal_tolerance']; ?></td>
  <td><?php echo $r['equip_tolerance']; ?></td>
  <td><?php echo $r['type_calibration']; ?></td>   
  </tr>
  <?php
    }
?>
</table>