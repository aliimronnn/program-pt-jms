<?php
error_reporting(E_ALL);
ini_set('memory_limit', '2048M');
set_time_limit(0);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);

$year=$_POST['thn_tgl3'];
$section=$_POST['section'];
$status=$_POST['status'];

$sql= mysqli_query($conn, "SELECT date_format(now(),'%d %b %y')as sekarang, section from sectioncode  where id='$_POST[section]'");
$p=mysqli_fetch_array($sql);


$html = 
'
<html>
	<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:10 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20; margin-top: 0.75 cm; margin-bottom: 0.5 cm;margin-right:-10; }
				
				tr td{ padding-left:5px;padding-top:1px; font-size:9 pt;}
				tr th{ padding-left:5px;}						
			}
				</style></head>
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>

<table style="border-collapse: collapse;" cellspacing="6" cellpadding="10" border="0" width="800">
  	<tr><td colspan="19" align=center valign="top" height="20" ><strong>EQUIPMENT CALIBRATION STATUS LOG</strong></td></tr>
	
	<tr>
		<td colspan="4" align=left><strong><i>Section : '.$_POST['section'].' / '.$p['section'].'</strong></i></td>
		<td colspan="4" align=left><strong><i>Status : '.$_POST['status'].'</strong></i></td>
		<td colspan="4" align=left><strong><i>Year : '.$_POST['thn_tgl3'].' </strong></i></td>
		<td colspan="7" align=left><strong><i>Printout Date : '.$p['sekarang'].'</strong></i></td>
	</tr>

<tr>
	<td colspan="19" height="10"></td>
</tr>

<tr>
	<td colspan="12"></td>
	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" colspan="4" align=center >Prepared By </td>
	<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;" colspan="3" align=center >Approved By </td>
</tr> 
<tr>
	<td colspan="12"></td>
	<td height="40" style="border-left:1px solid #000000;border-top:1px solid #000000;" colspan="4" align=center ></td>
	<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;" colspan="3" align=center ></td>
</tr> 
<tr>
	<td colspan="12"></td>
	<td style="border-left:1px solid #000000;border-top:1px solid #000000;" colspan="4" align=center>Calibration Designate</td>
	<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;" colspan="3" align=center>Section Head</td>
</tr>
<tr>
	<td colspan="12"></td>
	<td height="10" style="border-top:1px solid #000000;" colspan="4" align=center></td>
	<td style="border-top:1px solid #000000;" colspan="3" align=center></td>
</tr>
<thead>
<tr style="font-variant:small-caps;font-style:italic;color:black;font-size:12px;">
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=10 rowspan=2>SN</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" rowspan=2 width=60>Equip <br>Identify</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" rowspan=2 width=80>Equip <br>Name</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" rowspan=2 width=40>Frequency</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=20 rowspan=2>Type</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;" colspan=12>Calibration Date</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=50 rowspan=2>Due Date<br>Cal</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;" rowspan=2 width=50>Remarks</th>
</tr>
<tr style="font-size:12px;">
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Jan</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Feb</th >
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" width=20>Mar</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Apr</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>May</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Jun</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Jul</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Aug</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Sept</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Okt</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Nov</th>
	<th style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;"  width=20>Dec</th>
</tr></thead><tbody>
';


$tampil=mysqli_query($conn, "SELECT c.equip_identify, c.equip_name, c.type_calibration,
case c.calibrated_by when 'internal' then 'INT' else 'EXT' end as type,
datediff(current_date(),c.due_caldate) as selisih,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=1 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify) as jan,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=2 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify) as  feb,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=3 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify) as  mar,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=4 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as apr,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=5 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify) as  may,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=6 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as jun,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=7 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as jul,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=8 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as aug,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=9 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as sep,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=10 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as okt,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=11 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as nov,
(select day(t.date) from process_calibration t where t.equip_identify=c.equip_identify and month(t.date)=12 and year(t.date)=$_POST[thn_tgl3] GROUP BY c.equip_identify)  as des,

date_format((c.due_caldate),'%d %b %y')as due_caldate,c.remarks

 FROM calibration c left join process_calibration t on t.equip_identify=c.equip_identify where c.section='$_POST[section]' and 
 c.status='$_POST[status]' group by c.equip_identify order by c.equip_identify");


$no=1;
while ($r=mysqli_fetch_array($tampil)){
	if ($r['selisih'] > 0 ){
	$label='Expired';
} else if ($r['selisih'] <= 0 && $r['selisih'] >= -31){
	$label='Alarm';
} else if ($r['selisih'] < -31 ){
	$label='Valid';
} else {
	$label='Valid';
}
  $html.='<tr>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$no.'.</td>
	   	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['equip_identify'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['equip_name'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['type_calibration'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['type'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['jan'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['feb'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['mar'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['apr'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['may'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['jun'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['jul'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['aug'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['sep'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['okt'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['nov'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['des'].'</td>
      	<td style="border-left:1px solid #000000;border-top:1px solid #000000;"   valign=top>'.$r['due_caldate'].'</td>
		<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-right:1px solid #000000;"   valign=top>'.$label.'</td>
      
      
        </tr>';
  $no++;
}
 $html.='
 <tr><td height="30" style="border-top:1px solid #000000;" colspan="19"></td></tr>
 
 <tr>
	<td style="border-left:1px solid #000000;border-top:1px solid #000000;border-bottom:1px solid #000000;" colspan="10">
	Note : <br>
	Valid : Calibration status of equipment more than one month from due date calibration<br>
	Alarm : Calibration status of equipment equals / less than one month from due date calibration<br>
	Expired : Calibration status Over due date calibration</td>
	<td style="border-left:1px solid #000000;"></td>
 </tr>
 </table> 

</body></html>';
	
$dompdf->load_html($html);
$dompdf->set_paper("A4", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();

$canvas->page_text(94, 22, "PT. JMS BATAM", "helvetica-bold", 10, array(0,0,0));
$canvas->page_text(94, 26, "_________________________________________________________________________________________________________________", "helvetica", 8, array (0,0,0));
$canvas->page_text(94, 37, "Jalan Beringin Lot 211, Kawasan Industri Batamindo, Muka Kuning Batam 29433 Indonesia (Telepon): (62) 770-611807 Faksimili: 770-611806", "helvetica", 8, array (0,0,0));

$canvas->page_text(700,570, "Page: {PAGE_NUM} of {PAGE_COUNT}", "helvetica", 10, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>