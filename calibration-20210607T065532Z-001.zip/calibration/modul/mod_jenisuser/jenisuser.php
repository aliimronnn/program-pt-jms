<?php
$aksi="modul/mod_jenisuser/aksi_jenisuser.php";
$act=$_GET['act'];
switch($act) {
	// Tampil jenisuser
	default:
	echo "<h2>Data Type of User </h2><br/>
		  <input type=button value='Add Type of User' onclick=\"window.location.href='?module=jenisuser&act=tambahjenisuser';\" class='large blue super button'> 
		  <br><br>";

echo "<table id='example' class='pretty dataTable'>
<thead>
<tr>
	<th width=5px class=rounded-company>No.</th>
	<th>Type of User</th>
	<th>Menu</th>

	
		
	<th class=rounded-q4 align=center width=100px>Aksi</th>
</tr>
</thead>
<tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM jenis_user where jenis_user!= 'administrator' ORDER BY id ASC");
$no=1;
while($r=mysqli_fetch_array($tampil)){
		//$tglhr = tgl_indo($r['tglhr']);
			echo "<tr><td>$no</td>
		   			<td>$r[jenis_user]</td>
						<td>";
echo'<table><tr><td  valign="top">';
	$bid = mysqli_query($conn, "SELECT * FROM menu WHERE id_jenisuser='$r[id]' order by id_modul");
	//$row = mysql_num_rows($bid);
	
	while($bidang=mysqli_fetch_array($bid))
	{   
	$mod =mysqli_fetch_array( mysqli_query($conn, "SELECT * FROM modul where id_modul='$bidang[id_modul]' order by id_modul"));
	
      	 
	 echo ' &nbsp;'.$mod['nama_modul'].' &nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;';
	 
	
	
	}
	
	
	echo"</td> </tr></table>
						
						</td>
	<td><a href=?module=jenisuser&act=editjenisuser&id=$r[id]><img src='images/edit.png' alt='edit' /></a>";
				
				echo"<a href=$aksi?module=jenisuser&act=hapus&id=$r[id]><img src='images/hapus.png' alt='hapus' /></a></td></tr>";
	$no++;
}
echo "</tbody></table>";
break;


case "tambahjenisuser":
$thn_skrg=date("Y");
echo "<h2>Add Type User</h2><br/>
<form method=POST action='$aksi?module=jenisuser&act=input' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr>
	<td>Type of User</td>
	<td> : </td><td><input type=text name='jenisuser' size=100 maxlength=100></td>
</tr>
<tr><td valign=top>Select the Allowed Menu</td><td valign=top>:</td>";
    echo'<td height="47" colspan="4"><div align="center"><fieldset>
    <legend>Please Check the Allowed Menu:</legend><table border=1 cellpadding=7 cellspacing=5><tr bgcolor="#64950"><td>Name Modul</td></tr>';
	$bid = mysqli_query($conn, "SELECT * FROM modul where status='user' order by nama_modul");
	//$row = mysql_num_rows($bid);
	
	while($bidang=mysqli_fetch_array($bid))
	{   
	
   
    echo '<tr><td><input type=checkbox name="menu[]" value="'.$bidang['id_modul'].'">  &nbsp;'.$bidang['nama_modul'].' </td> </tr>';
	/*
	<td >
	<select name=edit[]><option value=Y>Y</option><option value=N>N</option></select> Edit |
	<select name=hapus[]><option value=Y>Y</option><option value=N>N</option></select> Hapus | 
	<select name=tambah[]><option value=Y>Y</option><option value=N>N</option></select> Tambah
	</td>
	*/
	}
	
	
	echo"</fieldset></table></div></td>
  </tr>
<tr>
	<td colspan=2><input type=submit value=Save class='large blue super button'>
	<input type=button value=Cancel onclick=self.history.back() class='large orange super button'>
	</td>
</tr>
</table>
</form>";
break;

case "editjenisuser":
$edit=mysqli_query($conn, "SELECT * FROM jenis_user WHERE id='$_GET[id]'");
$r=mysqli_fetch_array($edit);

$thn_skrg=date("Y");
echo "<h2>Edit Type of User</h2>
<form method=POST action='$aksi?module=jenisuser&act=update' enctype='multipart/form-data'>
<input type=hidden name=id value='$r[id]'><p>&nbsp;</p>
<table cellspacing=10 cellpadding=6>
<tr>
	<td>Type of User</td>
	<td> : </td><td><input type=text name='jenisuser' value='$r[jenis_user]' size=100 maxlength=100></td>
</tr>
<tr><td valign=top>Select the Allowed Menu</td><td valign=top>:</td>";
    echo'<td height="47" colspan="4"><div align="center"><fieldset>
    <legend>Please Check the Allowed Menu:</legend><table border=1 cellpadding=7 cellspacing=5><tr bgcolor="#64950"><td>Name Modul</td></tr>';
	$bid = mysqli_query($conn, "SELECT * FROM modul where status='user' order by nama_modul");
	//$row = mysql_num_rows($bid);
	$kolom = 2;
	$po=0;
	
	while($bidang=mysqli_fetch_array($bid))
	{  

   $cek = mysqli_fetch_array(mysqli_query($conn, "SELECT menu.id_modul,modul.nama_modul FROM modul,menu WHERE menu.id_modul=modul.id_modul AND menu.id_jenisuser='$r[id]' AND menu.id_modul='$bidang[id_modul]' order by menu.id_modul"));	
	
	 if ($bidang['id_modul'] == $cek['id_modul']) {
       $chek = "checked=checked";
	   } 
	   else { 
	   $chek= "";
	   }
	
	 echo '<tr><td><input type=checkbox name="menu[]" value="'.$bidang['id_modul'].'" '.$chek.'>  &nbsp;'.$bidang['nama_modul'].' </td> </tr>';
	 /**
	 <td >
	<select name=edit[]>'; 
	if ($cek[edit]=='Y') { 
	echo'<option value=Y selected>Y</option>
		 <option value=N>N</option>'; } else {
	echo'<option value=Y >Y</option><option value=N selected>N</option>';	
	}
	echo'</select> Edit |
	
	
	<select name=hapus[]>'; if ($cek[hapus]=='Y') { 
	echo'<option value=Y selected>Y</option><option value=N>N</option>'; } else {
	echo'<option value=Y >Y</option><option value=N selected>N</option>';	
	}
	echo'</select> Hapus | 
	
	
	<select name=tambah[]>'; if ($cek[tambah]=='Y') { 
	echo'<option value=Y selected>Y</option><option value=N>N</option>'; } else {
	echo'<option value=Y >Y</option><option value=N selected>N</option>';	
	}
	echo'</select> Tambah
	</td>
	 */
	}
	
	
	echo"</table></fieldset></div></td>
  </tr>

<tr>
	<td colspan=2><input type=submit value=Update class='large blue super button'>
	<input type=button value=Cancel onclick=self.history.back() class='large orange super button'>
	</td>
</tr>
</table>
</form>";
break;
}
?>