<?php
session_start();
include "../../config/koneksi.php";
$module=$_GET[module];
$act=$_GET[act];

// Hapus jenisuser
if ($module=='jenisuser' AND $act=='hapus') {
	mysql_query("DELETE FROM jenis_user WHERE id='$_GET[id]'");
	header('location:../../index2.php?module='.$module);

}

// Input jenisuser
elseif ($module=='jenisuser' AND $act=='input') {
	mysql_query("INSERT INTO jenis_user(jenis_user) VALUES ('$_POST[jenisuser]')");
	
	$menu = $_POST[menu];
	$hitung = count($menu);
	$user = mysql_fetch_array(mysql_query("SELECT * FROM jenis_user WHERE jenis_user='$_POST[jenisuser]'"));
	for($i=0; $i<$hitung; $i++){
	$tambah = $_POST[tambah] ;
	$edit = $_POST[edit];
	$hapus = $_POST[hapus];
	
	mysql_query("INSERT INTO menu(id_jenisuser,id_modul) VALUES ('$user[id]','$menu[$i]')");
    }	
	header('location:../../index2.php?module='.$module);

}

// Update jenisuser
elseif ($module=='jenisuser' AND $act=='update') {
    mysql_query("DELETE FROM menu WHERE id_jenisuser='$_POST[id]'");
	
	$menu = $_POST[menu];
	$hitung = count($menu);
	$user = mysql_fetch_array(mysql_query("SELECT * FROM jenis_user WHERE id='$_POST[id]'"));
	for($i=0; $i<$hitung; $i++){
	
	mysql_query("INSERT INTO menu(id_jenisuser,id_modul) VALUES ('$user[id]','$menu[$i]')");
	mysql_query("update jenis_user set jenis_user= '$_POST[jenisuser]' where id='$_POST[id]'");
    }	
	header('location:../../index2.php?module='.$module);

}
?>