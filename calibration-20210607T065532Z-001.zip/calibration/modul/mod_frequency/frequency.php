<script>
function confirmdelete(delUrl) {
  if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
    if (form.hari.value =="pilih"){
       alert("Day is Still Empty");            
       return (false);
   }
   
   return (true);
}
</script>

<?php

$aksi="modul/mod_frequency/aksi_frequency.php";
switch(@$_GET['act']){

default:
echo "<h2>Frequency Data </h2><p>&nbsp;</p>
<input type=button value='Add New Frequency'  class='large Orange super button'
onclick=\"window.location.href='?module=frequency&act=tambahfrequency';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th>
<th>Code Frequency</th><th>Frequency Name</th><th>Total Mount</th><th>Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM frequency order by id ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<td>$no.</td>
	<td>$r[code_freq]</td>
      	<td>$r[frequency]</td>
		<td>$r[days]</td>
        <td><a href='?module=frequency&act=editfrequency&id=$r[id]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=frequency&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

// Form Tambah frequency
case "tambahfrequency":
echo "<h2>New Frequency Calibration</h2>
<form method=POST action='$aksi?module=frequency&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code Frequency</td><td>: <input type='text' name='code_freq' size='30' value='' ></td></tr>                
<tr><td>Frequency Name</td><td>: <input type='text' name='frequency' size='30' value='' ></td></tr>    
<tr><td>Total Mounth</td><td>: <input type='text' name='days' size='20' value='' ></td></tr>    
<tr><td colspan=2><input type=submit name=submit value=Save class='large Orange super button' >
<input type=button value=Cancel onclick=self.history.back() class='large Blue super button'></td></tr>
</table>
</form>";
break;

// Form Edit frequency 
case "editfrequency":
$edit = mysqli_query($conn, "SELECT * FROM frequency WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Data Frequency</h2>
<form method=POST action='$aksi?module=frequency&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Frequency Code</td><td>: <input type='text' name='code_freq' size='30' value='$r[code_freq]' ></td></tr> 
<tr><td>Frequency Name</td><td>: <input type='text' name='frequency' size='30' value='$r[frequency]' ></td></tr>                
<tr><td>Total Mounth</td><td>: <input type='text' name='days' size='30' value='$r[days]' ></td></tr> 
<tr><td colspan=2><input type=submit value=Update class='large Orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;

}
?>
