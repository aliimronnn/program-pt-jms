<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  //$code_freq = htmlentities($_POST['code_freq']);
  //$days = htmlentities($_POST['days']);

  // Input frequency
  if ($module=='frequency' AND $act=='input'){
  	        mysqli_query($conn, "INSERT INTO frequency(code_freq,frequency,days)
                                VALUES('$_POST[code_freq]','$_POST[frequency]',
					'$_POST[days]')");
     header('location:../../index2.php?module='.$module);
            
  }
  
  // Update frequency  
  elseif ($module=='frequency' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE frequency SET  code_freq = '$_POST[code_freq]', 
					frequency = '$_POST[frequency]',
					days = '$_POST[days]'                                         
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index2.php?module='.$module);
  }
    
  // Delete frequency  
  elseif ($module=='frequency' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM frequency WHERE id = '$_GET[id]'");
      header('location:../../index2.php?module='.$module);
            
  }
  
  }
?>
