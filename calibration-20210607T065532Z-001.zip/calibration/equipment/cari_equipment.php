<?php
include"../config/koneksi.php";

$sql 	= mysqli_query($conn, "SELECT * from calibration where equip_identify = '$_POST[kode_uniq]'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['id'] = $r['id'];
	$data['equip_name'] = $r['equip_name'];
	$data['serial_no'] = $r['serial_no'];
	$data['manufacturer'] = $r['manufacturer'];
	$data['model_no'] = $r['model_no'];
	$data['measure_range'] = $r['measure_range'];
	$data['usage_range'] = $r['usage_range'];
	$data['calibration_range'] = $r['calibration_range'];
	$data['equip_location'] = $r['equip_location'];
	$data['retention'] = $r['retention'];
	$data['equip_tolerance'] = $r['equip_tolerance'];
		
		
	echo json_encode($data);
}else{
	$data['id'] = '';
	$data['equip_name'] = '';
	$data['serial_no'] = '';
	$data['manufacturer'] = '';
	$data['model_no'] = '';
	$data['measure_range'] = '';
	$data['usage_range'] = '';
	$data['calibration_range'] = '';
	$data['equip_location'] = '';
	$data['retention'] = '';
	$data['equip_tolerance'] = '';
	
	echo json_encode($data);
}
?>
