<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "select * from calibration where equip_identify LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$ser_no = $r['equip_identify'];
	
	echo "$ser_no\n";
}
?>
