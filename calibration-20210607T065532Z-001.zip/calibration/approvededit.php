<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#pelanggan").autocomplete("approved/proses_approved.php", {
		width: 300
	});
	
	$("#pelanggan").result(function(event, data, formatted) {
		var kode2	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode2="+kode2,
			url 	: "approved/cari_approved.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
				
				$("#kode2").val(data.kode2);
				
			}
		});
	});
	$("#pelanggan").keyup(function() {
		var kode2	= $('#pelanggan').val();
		$.ajax({
			type	: "POST",
			data	: "kode2="+kode2,
			url 	: "approved/cari_approved.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
					$("#kode2").val(data.kode2);
					
			}
		});
	});
	
});
</script>
</head>
<body>
  <?php
  //$sql=mysql_query("select *from employee where empno='$r[approvedby]'");
  //$k=mysql_fetch_array($sql);
  //<input type='hidden' id='kode2' name='approvedby' value='$r[approved]'>
  echo"
  
<input type='text' id='pelanggan' name='approved' size='50' value='";
echo htmlentities(htmlspecialchars_decode($r['approved']), ENT_QUOTES);
echo "'>
 ";
  ?>

</body>
</html>
