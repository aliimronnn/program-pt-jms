<?php
include"../config/koneksi.php";

$kode4	= $_POST['kode4'];

$sql 	= mysql_query("SELECT *from employee where empname='$kode4'");
$row	= mysql_num_rows($sql);
if($row>0){
	$r = mysql_fetch_array($sql);
		$data['kode4'] = $r['empno'];
		$data['nama'] = $r['empname'];
			
	echo json_encode($data);
}else{
		$data['kode4'] = '';
		$data['nama'] = '';
				
	echo json_encode($data);
}
?>
