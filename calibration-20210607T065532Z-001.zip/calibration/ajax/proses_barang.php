<?php
include "../config/koneksi.php";
$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = mysql_query("select jenis from jenis_pelayanan where jenis LIKE '%$q%'");
while($r = mysql_fetch_array($sql)) {
	$jenis = $r['jenis'];
	echo "$jenis \n";
}
?>
