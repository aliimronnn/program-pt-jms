<?php
           date_default_timezone_set("Asia/Jakarta");
           $jam = date("H:i:s");
           echo "$jam WIB";
?>