<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#barang").autocomplete("surat\/proses_kode.php", {
		width: 300
	});
	
	$("#barang").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "surat/cari_kode.php",
			dataType: "json",
			success: function(data){
				$("#namabarang").html(data.nama_surat);
				
				$("#kode").val(data.kode);
			}
		});
	});
	$("#barang").keyup(function() {
		var kode	= $('#barang').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "surat/cari_kode.php",
			dataType: "json",
			success: function(data){
				$("#namabarang").val(data.nama_kapal);
					$("#kode").val(data.kode);
						$("#bendera").html(data.bendera);
			}
		});
	});
	
});
</script>
</head>
<body>
  
 <table cellspacing="20" cellpadding="6"> 
 <tr><td>Kode Surat &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> <td> : </td> <td><input type="text"name="kode_surat" id="barang" size="50"></td></tr>
  <input type="hidden" id="kode" name="nama_kapal">
  <tr><td>Nama Surat</td><td> : </td> <td>  <span id="namabarang"></span></td></tr>
 
  </table>
 
</body>
</html>
