<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#uniq").autocomplete("equipment/proses_equipment.php", {
		width: 300
	});
	
	$("#uniq").result(function(event, data, formatted) {
		var kode_uniq	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_uniq="+kode_uniq,
			url 	: "equipment/cari_equipment.php",
			dataType: "json",
			success: function(data){
			
				$("#id").val(data.id);
				$("#equip_name").val(data.equip_name);
				$("#serial_no").val(data.serial_no);
				$("#manufacturer").val(data.manufacturer);
				$("#model_no").val(data.model_no);
				$("#measure_range").val(data.measure_range);
				$("#usage_range").val(data.usage_range);
				$("#calibration_range").val(data.calibration_range);
				$("#equip_location").val(data.equip_location);
				$("#retention").val(data.retention);
				$("#equip_tolerance").val(data.equip_tolerance);
				
			
			
			}
		});
	});
	$("#uniq").keyup(function() {
		var kode_uniq	= $('#uniq').val();
		$.ajax({
			type	: "POST",
			data	: "kode_uniq="+kode_uniq,
			url 	: "equipment/cari_equipment.php",
			dataType: "json",
			success: function(data){
				
				$("#id").val(data.id);
				$("#equip_name").val(data.equip_name);
				$("#serial_no").val(data.serial_no);
				$("#manufacturer").val(data.manufacturer);
				$("#model_no").val(data.model_no);
				$("#measure_range").val(data.measure_range);
				$("#usage_range").val(data.usage_range);
				$("#calibration_range").val(data.calibration_range);
				$("#equip_location").val(data.equip_location);
				$("#retention").val(data.retention);
				$("#equip_tolerance").val(data.equip_tolerance);
				
			}
		});
	});
	
});
//<tr><td>Title</td><td valign="center">: <input type="text" id="title" name="title" readonly size="100"></td></tr>
</script>
</head>
<body>
   
  
<input type="hidden" id="id" name="id_equipment">

<tr><td align="right">Unique Equipment Identification</td><td colspan="2">: <input type="text" id="uniq" name="equip_identify" size="50" autofocus></td></tr>   
<tr><td align="right">Equipment Name</td><td colspan="2">: <input type="text" id="equip_name" name="equip_name" size="50"  ></td></tr>       
 
   
</body>
</html>
