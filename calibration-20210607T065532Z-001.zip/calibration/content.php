<script>
function confirmlogout(delUrl) {
   if (confirm("Are you sure to Logout from system?")) {
      document.location = delUrl;
   }
}
</script>
<?php
include "config/koneksi.php";
include "config/library.php";
include "config/fungsi_indotgl.php";
include "config/fungsi_tanggal.php";
include "config/fungsi_combobox.php";
include "config/class_paging.php";
include "config/fungsi_thumb.php";

// Bagian Home
if ($_SESSION['leveluser']=='admin' OR $_SESSION['leveluser']=='user'  ) {
if ($_GET['module']=='home') {
	echo "<div align=center><h2>Login as : $_SESSION[namauser] </h2>
			<p>Welcome at Calibration System PT. JMS Batam.<br>
			 </p>
			 <p><small>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
   date_default_timezone_set("Asia/Jakarta");
  echo date("H:i:s");
  echo " WIB</small></p>";
 //echo $_SESSION[jenisuser] ;
  if ($_SESSION['leveluser']=='admin'){
  
 echo"	<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
	
		
		<tr>
		 <td width=120 align=center><a href=index2.php?module=calibration&act=>
		  <div class=menu_thumb><img src=images/new-icon/calibration.png border=none>
		  <br/><b>Master Calibration</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index2.php?module=calibration&act=v_process>
		  <div class=menu_thumb><img src=images/new-icon/proses-calibration.png border=none>
		  <br/><b>Process Calibration</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index2.php?module=calibration&act=report_cal>
		  <div class=menu_thumb><img src=images/new-icon/report-calibration.png border=none>
		  <br/><b>Report Calibration</b></div></a></a></td> 		 
    	</tr>
    	
		<tr>
		
			
		  <td width=120 align=center><a href=index2.php?module=section&act=>
		  <div class=menu_thumb><img src=images/new-icon/section.png border=none>
		  <br/><b>Section Data</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index2.php?module=doc_code&act=>
		  <div class=menu_thumb><img src=images/new-icon/doc-code.png border=none>
		  <br/><b>Document Code</b></div></a></a></td>
		 	  
		  <td width=120 align=center><a href=index2.php?module=user&act=>
		  <div class=menu_thumb><img src=images/new-icon/management-user.png border=none>
		  <br/><b>Management User</b></div></a></a></td>	

		 
		</tr>	
		
		<tr>
		
		 <td width=120 align=center><a href=index2.php?module=calibration&act=import>
		  <div class=menu_thumb><img src=images/new-icon/excel.png border=none>
		  <br/><b>Import Calibration Masterlist</b></div></a></a></td>
		  
		
		
		 <td width=120 align=center><a href=index2.php?module=employee>
		  <div class=menu_thumb><img src=images/new-icon/emp-data.png border=none>
		  <br/><b>Employee Data</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index2.php?module=frequency>
		  <div class=menu_thumb><img src=images/new-icon/frequency.png border=none>
		  <br/><b>Frequency Calibration</b></div></a></a></td>
		 
		</tr>	
		
			<tr>
		<td width=120 align=center><a href=index2.php?module=revisi&act=>
		  <div class=menu_thumb><img src=images/new-icon/revisi-no.png border=none>
		  <br/><b>Revision Number</b></div></a></a></td>
			
		  <td width=120 align=center><a href=index2.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/new-icon/account-info.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
		  <td width=120 align=center><a href='#' target=_blank>
		  <div class=menu_thumb><img src=images/new-icon/user-guide.png border=none>
		  <br/><b>User Guide</b></div></a></td>
		  
		 
		</tr>	
		
    </table>
		
	
	
	";

  } else 
   if ($_SESSION['leveluser']=='user'){
   	
   	if ($_SESSION['jenisuser']==2){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		
		<tr>
		 <td width=120 align=center><a href=index2.php?module=calibration&act=>
		  <div class=menu_thumb><img src=images/new-icon/calibration.png border=none>
		  <br/><b>Master Calibration</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index2.php?module=calibration&act=v_process>
		  <div class=menu_thumb><img src=images/new-icon/proses-calibration.png border=none>
		  <br/><b>Process Calibration</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index2.php?module=calibration&act=report_cal>
		  <div class=menu_thumb><img src=images/new-icon/report-calibration.png border=none>
		  <br/><b>Report Calibration</b></div></a></a></td> 		 
    	</tr>    	
		<tr>			
		  <td width=120 align=center><a href=index2.php?module=section&act=>
		  <div class=menu_thumb><img src=images/new-icon/section.png border=none>
		  <br/><b>Section Data</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index2.php?module=doc_code&act=>
		  <div class=menu_thumb><img src=images/new-icon/doc-code.png border=none>
		  <br/><b>Document Code</b></div></a></a></td>
		 	  
		  <td width=120 align=center><a href=index2.php?module=user&act=>
		  <div class=menu_thumb><img src=images/new-icon/management-user.png border=none>
		  <br/><b>Management User</b></div></a></a></td>	

		 
		</tr>	
		
		<tr>
		
		 <td width=120 align=center><a href=index2.php?module=calibration&act=import>
		  <div class=menu_thumb><img src=images/new-icon/excel.png border=none>
		  <br/><b>Import Calibration Masterlist</b></div></a></a></td>
		  
		<td width=120 align=center><a href=index2.php?module=frequency>
		  <div class=menu_thumb><img src=images/new-icon/frequency.png border=none>
		  <br/><b>Frequency Calibration</b></div></a></a></td>
		
		 <td width=120 align=center><a href=index2.php?module=employee>
		  <div class=menu_thumb><img src=images/new-icon/emp-data.png border=none>
		  <br/><b>Employee Data</b></div></a></a></td>
		  
		 
		</tr>	
		
			<tr>
		 <td width=120 align=center><a href=index2.php?module=revisi&act=>
		  <div class=menu_thumb><img src=images/new-icon/revisi-no.png border=none>
		  <br/><b>Revision Number</b></div></a></a></td>
			
		  <td width=120 align=center><a href=index2.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/new-icon/account-info.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
		  <td width=120 align=center><a href='#' target=_blank>
		  <div class=menu_thumb><img src=images/new-icon/user-guider.png border=none>
		  <br/><b>User Guide</b></div></a></td>
		  
		 
		</tr>	
    </table>
	
	";
/*
		   <td width=120 align=center><a href=index2.php?module=deviation&act=valldraf_qms>
		  <div class=menu_thumb><img src=images/v_deviation.png border=none>
		  <br/><b>View All DRAF</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index2.php?module=irp&act=vallcrf_qms>
		  <div class=menu_thumb><img src=images/v_irp.png border=none>
		  <br/><b>View All CRF</b></div></a></a></td>*/
  } else 
  	if ($_SESSION['jenisuser']==3){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		
		<tr>
		 <td width=120 align=center><a href=index2.php?module=calibration&act=>
		  <div class=menu_thumb><img src=images/new-icon/calibration.png border=none>
		  <br/><b>Master Calibration</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index2.php?module=calibration&act=v_process>
		  <div class=menu_thumb><img src=images/new-icon/proses-calibration.png border=none>
		  <br/><b>Process Calibration</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index2.php?module=calibration&act=report_cal>
		  <div class=menu_thumb><img src=images/new-icon/report-calibration.png border=none>
		  <br/><b>Report Calibration</b></div></a></a></td> 

		  
		 
    	</tr>
    	
				
		<tr>
		
		<td width=120 align=center><a href=index2.php?module=revisi&act=>
		  <div class=menu_thumb><img src=images/new-icon/revisi-no.png border=none>
		  <br/><b>Revision Number</b></div></a></a></td>
			
		  <td width=120 align=center><a href=index2.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/new-icon/account-info.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		
		  
		 <td width=120 align=center><a href='#' target=_blank>
		  <div class=menu_thumb><img src=images/new-icon/user-guide.png border=none>
		  <br/><b>User Guide</b></div></a></td>
		</tr>	
		
			<tr>
		 
		</tr>	
				
    </table>
	
	";

  }
 }
}

// Bagian User
 /*elseif ($_GET[module]=='user') {
	include "modul/mod_user/user.php";
	
	 <td width=120 align=center>
		   <a href=javascript:confirmdelete('logout.php')><div class=menu_thumb>
		   <img src=images/big_logout.png border=none>
		  <br/><b>Logout</b></div></a>
		 </td>
}
}*/
// Bagian Modul
elseif ($_GET['module']=='calibration') {
	include "modul/mod_calibration/calibration.php";
}
elseif ($_GET['module']=='frequency') {
	include "modul/mod_frequency/frequency.php";
}
elseif ($_GET['module']=='revisi') {
	include "modul/mod_revisi/revisi.php";
}

elseif ($_GET['module']=='employee') {
	include "modul/mod_employee/employee.php";
} 
elseif ($_GET['module']=='section') {
	include "modul/mod_section/section.php";
} 

elseif ($_GET['module']=='doc_code') {
	include "modul/mod_doc_code/doc_code.php";
}


elseif ($_GET['module']=='jenisuser') {
	include "modul/mod_jenisuser/jenisuser.php";
}
elseif ($_GET['module']=='identitas') {
	include "modul/mod_identitas/identitas.php";
}


// Bagian Modul
elseif ($_GET['module']=='phpmyadmin') {
	include "modul/mod_phpmyadmin/phpmyadmin.php";
}

elseif ($_GET['module']=='autocomplete') {
	include "modul/mod_autocomplete/barang.php";
}



else if ($_GET['module'] == 'logout') {
	include "logout.php";
}

else if ($_GET['module'] == 'identitas') {
	include "identitas.php";
}
else if ($_GET['module'] == 'rdatabase') {
	include "rdatabase.php";
}
else if ($_GET['module'] == 'konfigurasi') {
	include "setting.php";
}
// Bagian provinsi

// Bagian User
else	if ($_GET['module']=='user') {
		include "modul/mod_user/user.php";
}
// Bagian Modul
	elseif ($_GET['module']=='modul') {
		include "modul/mod_modul/modul.php";
}
// Bagian Modul
	elseif ($_GET['module']=='backup') {
		include "modul/mod_backup/backup.php";
}


}

?>