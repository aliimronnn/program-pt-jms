<?php
include"../config/koneksi.php";

$kode	= $_POST[kode];

$sql 	= mysql_query("SELECT dk.*, sp.nama AS sumber
FROM datakendaraan dk, supplier sp WHERE dk.sumber=sp.id AND dk.nama='$kode'");
$row	= mysql_num_rows($sql);
if($row>0){
	$r = mysql_fetch_array($sql);
	$data['nama'] = $r[nama];
		$data['kode'] = $r[nopolisi];
		$data['warna'] = $r[warna];
		$data['tahun'] = $r[tahun];
		$data['sumber'] = $r[sumber];
		$data['atasnama'] = $r[atasnama];
		$data['norangka'] = $r[norangka];
		$data['nomesin'] = $r[nomesin];
		$data['nobpkb'] = $r[nobpkb];
		
	echo json_encode($data);
}else{
	$data['nama'] = '';
		$data['kode'] = '';
		$data['warna'] = '';
		$data['tahun'] ='';
		$data['sumber'] ='';
		$data['atasnama'] = '';
		$data['norangka'] = '';
		$data['nomesin'] ='';
		$data['nobpkb'] ='';
	echo json_encode($data);
}
?>
