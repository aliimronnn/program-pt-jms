<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#uniq").autocomplete("equipment/proses_equipment2.php", {
		width: 300
	});
	
	$("#uniq").result(function(event, data, formatted) {
		var kode_uniq	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_uniq="+kode_uniq,
			url 	: "equipment/cari_equipment2.php",
			dataType: "json",
			success: function(data){
			
				$("#id").val(data.id);
				$("#equip_name").html(data.equip_name);
				$("#serial_no").html(data.serial_no);
				$("#manufacturer").html(data.manufacturer);
				$("#model_no").html(data.model_no);
				$("#measure_range").html(data.measure_range);
				$("#usage_range").html(data.usage_range);
				$("#calibration_range").html(data.calibration_range);
				$("#equip_location").html(data.equip_location);
				$("#retention").html(data.retention);
				//$("#usage_tolerance").html(data.usage_tolerance);
				$("#equip_tolerance").html(data.equip_tolerance);
				$("#type_calibration").html(data.type_calibration);
				$("#cal_date").html(data.cal_date);
				$("#last_caldate").html(data.last_caldate);
				$("#due_caldate").html(data.due_caldate);
				
				
			
			
			}
		});
	});
	$("#uniq").keyup(function() {
		var kode_uniq	= $('#uniq').val();
		$.ajax({
			type	: "POST",
			data	: "kode_uniq="+kode_uniq,
			url 	: "equipment/cari_equipment2.php",
			dataType: "json",
			success: function(data){
				
				$("#id").val(data.id);
				$("#equip_name").html(data.equip_name);
				$("#serial_no").html(data.serial_no);
				$("#manufacturer").html(data.manufacturer);
				$("#model_no").html(data.model_no);
				$("#measure_range").html(data.measure_range);
				$("#usage_range").html(data.usage_range);
				$("#calibration_range").html(data.calibration_range);
				$("#equip_location").html(data.equip_location);
				$("#retention").html(data.retention);
				//$("#usage_tolerance").html(data.usage_tolerance);
				$("#equip_tolerance").html(data.equip_tolerance);
				$("#type_calibration").html(data.type_calibration);
				$("#cal_date").html(data.cal_date);
				$("#last_caldate").html(data.last_caldate);
				$("#due_caldate").html(data.due_caldate);
				
			}
		});
	});
	
});
//<tr><td>Title</td><td valign="center">: <input type="text" id="title" name="title" readonly size="100"></td></tr>
</script>
</head>
<body>
   
  
<input type="hidden" id="id" name="id_equipment">
<tr><td align="right">Unique Equipment Identification</td><td colspan="2">: <input type="text" id="uniq" name="equip_identify" size="25" autofocus> </td></tr> 
<tr><td align="right">Equipment Name</td><td colspan="2">: <span id="equip_name"> </span></td></tr>          
<tr><td align="right">Manufacturer</td><td colspan="2">: <span id="manufacturer"> </span></td></tr>          
<tr><td align="right">Model No</td><td colspan="2">: <span id="model_no"> </span></td></tr>          
<tr><td align="right">Serial No</td><td colspan="2">: <span id="serial_no" > </span></td></tr>  
<tr><td align="right">Equipment Measurement Range No</td><td colspan="2">: <span id="measure_range" ></span></td></tr>   
<tr><td align="right">Usage Range</td><td colspan="2">: <span id="usage_range" ></span></td></tr>
<tr><td align="right">Calibration Range</td><td colspan="2">: <span id="calibration_range" ></span></td></tr>   
<tr><td align="right">Location of Equipment</td><td colspan="2">: <span id="equip_location" ></span></td></tr>   
<tr><td align="right">Record Retention Location</td><td colspan="2">: <span id="retention" ></span></td></tr>   
<!-- <tr><td align="right">Usage Tolerance</td><td colspan="2">: <span id="usage_tolerance" ></span></td></tr> -->
<tr><td align="right">Equipment Tolerance</td><td colspan="2">: <span id="equip_tolerance" ></span></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td align="right">Calibration Date</td><td colspan="2">: <span id="cal_date" ></span></td></tr>   
<tr><td align="right">Last Calibration Date</td><td colspan="2">: <span id="last_caldate" ></span></td></tr> 
<tr><td align="right">Frequency</td><td colspan="2">: <span id="type_calibration" ></span></td></tr>   
<tr><td align="right">Due Calibration Date</td><td colspan="2">: <span id="due_caldate" ></span></td></tr>
 
   
</body>
</html>
