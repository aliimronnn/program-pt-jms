<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#pelanggan3").autocomplete("divhead/proses_divhead.php", {
		width: 300
	});
	
	$("#pelanggan3").result(function(event, data, formatted) {
		var kode4	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "divhead/cari_divhead.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
			
				$("#kode4").val(data.kode4);
				
			}
		});
	});
	$("#pelanggan3").keyup(function() {
		var kode4	= $('#pelanggan3').val();
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "divhead/cari_divhead.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
					$("#kode4").val(data.kode4);
					
			}
		});
	});
	
});
</script>
</head>
<body>
  
  
  <input type="hidden" id="kode4" name="id_divhead">
<input type="text" id="pelanggan3" name="div_head" size="30">
</body>
</html>
