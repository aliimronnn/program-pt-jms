<?php
 
  header('location:paneladmin/index_login.php'); 
  
?>