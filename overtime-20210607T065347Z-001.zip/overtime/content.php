<?php  
       
include "paneladmin/config/koneksi.php";
 
      
if($_GET['module']=='quickcount'){
//Menghitung total 
$sum = mysql_query("select sum(sms_vote_calon.jml_suara) as tot from calon, sms_vote_calon WHERE sms_vote_calon.kode_calon=calon.kode order by calon.kode");
$total = mysql_fetch_array($sum);
/* Menghitung jumlah data kemudian tambah 1 untuk pengisian colspan, maksudnya untuk membuat baris judul grafik pada baris pertama dan menampilkan total jumlah penjualan keseluruhan pada baris terakhir tabel */
$query = mysql_query("select * from calon order by kode");
	echo '<h4 class="header"><strong>Quick Count</strong></h4>
	<div class="row-fluid">
		<div class="span4">
		  <h4 class="header">Jumlah Perolehan Suara</h4>
          <ul class="stat-list">';
while($suara=mysql_fetch_array($query))
{
	$jumlahsuara = mysql_fetch_array(mysql_query("SELECT sum(jml_suara) as jumlahsuara FROM sms_vote_calon WHERE kode_calon='$suara[kode]'"));
	echo '<li>
		  <label class="label-warning">';
		  if ($suara[foto] != ''){
		  echo ' <img src="paneladmin/foto_calon/'.$suara[foto].'" width="62" height="62">';
		  } else {
		  echo' <img src="paneladmin/foto_calon/noprofile-pic.jpg" width="62" height="62">';
		  }
		  echo'</label>
		  <h4 class="sub">'.$suara['nama'].'</h4>';
		  if ($jumlahsuara[jumlahsuara] >= "1"){
		  echo '<h4>('.$jumlahsuara[jumlahsuara].') <small>suara</small></h4>';
		  } else {
		  echo '<h4>(0) <small>suara</small></h4>';
		  }
		echo'</li>';
}
echo '</ul>
        </div>
        <div class="span8">
		  
		  <h4 class="header">Presentase Perolahan Suara</h4>
          <div class="widget">
            <table style="width:100%">';
$query2 = mysql_query("select * from calon order by kode");
$no=1;
while($data=mysql_fetch_array($query2))
{
$jumlahsuara = mysql_fetch_array(mysql_query("SELECT sum(jml_suara) as jumlahsuara FROM sms_vote_calon WHERE kode_calon='$data[kode]'"));
$panjang = @(round($jumlahsuara[jumlahsuara]/$total[tot]*100, 2));

echo '<tr>
		<td class="bar-label">'.$data['nama'].'</td>
		<td class="bar-number">'.$panjang.' %</td>
		<td>
		  <div class="progress">
			<div style="width:'.$panjang.'%" class="bar color'.$no.'"></div>
		  </div>
		</td>
	  </tr>';
	  $no++;
}
echo '</table>
          </div>
        </div>        
      </div>';	

}elseif($_GET['module']=='polling'){
//Menghitung total 
$sum = mysql_query("select sum(rating) as tot from poling where status='Jawaban'");
$total = mysql_fetch_array($sum);
/* Menghitung jumlah data kemudian tambah 1 untuk pengisian colspan, maksudnya untuk membuat baris judul grafik pada baris pertama dan menampilkan total jumlah penjualan keseluruhan pada baris terakhir tabel */
$query = mysql_query("select * from poling where status='Jawaban'");
	echo '<h4 class="header">SMS Polling</h4>
	<div class="row-fluid">
	<div class="span12">
          <div class="widget">
            <table style="width:100%">';
			$no=1;
while($data=mysql_fetch_array($query))
{
$panjang = round($data[rating]/$total[tot]*100, 2);

echo '<tr>
		<td class="bar-label">'.$data['pilihan'].'</td>
		<td class="bar-number">'.$panjang.' %</td>
		<td>
		  <div class="progress">
			<div style="width:'.$panjang.'%" class="bar color'.$no.'"></div>
		  </div>
		</td>
	  </tr>';
	  $no++;
}
echo '</table></div>
          </div>
        </div>';	
}elseif($_GET['module']=='datadpt'){
	
	echo "<h4 class=header>Daftar Pemilih Tetap (DPT)</h4>
	<table id=example class='pretty dataTable'>
<thead>
<tr>
	<th>NIK </th>
	<th>Nama</th>
	<th>Tempat Lahir</th>
	<th>Tanggal Lahir</th>
	
	<th>Umur</th>
	<th>Status</th>
	<th>Jentina</th>
	<th>Alamat</th>
	<th>RW</th>
	<th>RT</th>
	
	<th>TPS</th>
	<th>Wilayah</th>
	<th>Kecamatan</th>
	<th>Kelurahan</th>
</tr>
</thead><tbody>";

$tampil=mysql_query("SELECT * FROM dpt ORDER BY wilayah");
while($r=mysql_fetch_array($tampil)){
		echo "<tr>
				<td>$r[nik]</td>
				<td>$r[nama]</td>				
				<td>$r[tmp_lahir]</td>
				<td>$r[tgl_lahir]</td>				
				<td>$r[umur]</td>
				<td>$r[status_perkawinan]</td>
				<td>$r[jns_klmn]</td>
				<td>$r[alamat]</td>
				<td>$r[rw]</td>
				<td>$r[rt]</td>
				
				<td>$r[tps]</td>
				<td>$r[wilayah]</td>
				<td>$r[kecamatan]</td>
				<td>$r[kelurahan]</td>
			</tr>";
}
echo "</tbody></table>";

}elseif($_GET['module']=='datatps'){
	echo "<h4 class=header>Data Tempat Pemungutan Suara (TPS)</h4>
	<table id=example class='pretty dataTable'>
<thead>
<tr>
				<th> Kode </th>
				<th> TPS</th>
				<th> Kelurahan </th>
				<th> Kecamatan</th>
				<th> Wilayah</th>
				<th> Provinsi</th>
				<th> Jumlah DPT</th>
			</tr>
</thead><tbody>";

$tampil=mysql_query("select tps.*, kelurahan.kelurahan, kecamatan.kecamatan, wilayah.wilayah, provinsi.provinsi from kelurahan, kecamatan, wilayah, provinsi, tps 
WHERE tps.kode_kec=kecamatan.id AND tps.kode_kel=kelurahan.id AND tps.kode_wil=wilayah.id AND tps.kode_prov=provinsi.id");
$no=$posisi+1;
while($r=mysql_fetch_array($tampil)){
		
		echo "<tr>
			<td> $r[kode] </td>
			<td> $r[tps] </td>
			<td> $r[kelurahan] </td>
			<td> $r[kecamatan] </td>
			<td> $r[wilayah] </td>
			<td> $r[provinsi] </td>
			<td> $r[jml_dpt] </td>
			</tr>";
	$no++;
}
echo "</tbody></table>";
}elseif($_GET['module']=='datacalon'){
	
echo "<h4 class=header>Data Calon</h4>
<table id=example-no class='pretty dataTable'>
<thead>
<tr>
	<th>No.</th>
	<th>Foto</th>
	<th>Kode</th>
	<th>Nama</th>
	<th>Alamat</th>
	<th>No. Telpon</th>
	<th>Keterangan</th>
	<th>Jumlah Suara</th>
</tr>
</thead>
<tbody>";

$tampil=mysql_query("SELECT * FROM calon ORDER BY kode");
$no=$posisi+1;
while($r=mysql_fetch_array($tampil)){
		echo "<tr><td>$no</td>
		          <td>";
			  if ($r[foto] != ''){
				echo "<div id=side_content align=center><img src='paneladmin/foto_calon/$r[foto]' width='100'>";
			}else{
				echo "<div id=side_content align=center><img src='paneladmin/foto_calon/noprofile-pic.jpg' >";
			}		
			echo"	</td>
				<td>$r[kode]</td>
				<td>$r[nama]</td>
				<td>$r[alamat]</td>
				<td>$r[hp]</td>
				<td>$r[keterangan]</td>
				<td align=center>$r[jml_suara]</td>
			</tr>";
	$no++;
}
echo "</tbody></table>";

}elseif($_GET['module']=='datasaksi'){

echo "<h4 class=header>Data Saksi</h4>
<table id=example class='pretty dataTable'>
<thead>
<tr>
	<th>Foto</th>
	<th>Kode</th>
	<th>Nama</th>
	<th>Alamat</th>
	<th>Provinsi</th>
	<th>Wilayah</th>
	<th>Kecamatan</th>
	<th>Kelurahan</th>
	<th>TPS</th>
	<th>No. Telpon</th>
	<th>Jenis Kelamin</th>
	<th>Agama</th>
</tr>
</thead>
<tbody>";

$tampil=mysql_query("SELECT saksi.*,provinsi.provinsi,kecamatan.kecamatan,kelurahan.kelurahan,tps.tps, wilayah.wilayah FROM saksi,provinsi,kecamatan,kelurahan,tps, wilayah WHERE saksi.kode_tps=tps.id AND saksi.kode_kel=kelurahan.id AND saksi.kode_kec=kecamatan.id AND saksi.kode_wil=wilayah.id AND saksi.kode_prov=provinsi.id ORDER BY kode");
$no=$posisi+1;
while($r=mysql_fetch_array($tampil)){
		echo "<tr>
		          <td>";
			  if ($r[foto] != ''){
				echo "<div id=side_content align=center><img src='paneladmin/foto_saksi/$r[foto]' width='80'>";
			}else{
				echo "<div id=side_content align=center><img src='paneladmin/foto_saksi/noprofile-pic.jpg' >";
			}		
			echo"	</td>
				<td>$r[kode]</td>
				<td>$r[nama]</td>
				<td>$r[alamat]</td>
				<td>$r[provinsi]</td>
				<td>$r[wilayah]</td>
				<td>$r[kecamatan]</td>
				<td>$r[kelurahan]</td>
				<td>$r[kode_tps]</td>
				<td>$r[notelp]</td>
				<td>$r[jekel]</td>
				<td align=center>$r[agama]</td>
			</tr>";
	$no++;
}
echo "</tbody></table>";
}else{

}



?>