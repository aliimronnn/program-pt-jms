<?php
include"../config/koneksi.php";

$kode_prepared	= $_POST[kode_prepared];

$sql 	= mysqli_query($conn, "SELECT * FROM employee WHERE empname='$kode_prepared'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
		$data['kode_prepared'] = $r[empno];
		$data['nama'] = $r[empname];
			
	echo json_encode($data);
}else{
		$data['kode_prepared'] = '';
		$data['nama'] = '';
				
	echo json_encode($data);
}
?>
