<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#pelangga").autocomplete("prepared/proses_prepared.php", {
		width: 300
	});
	
	$("#pelangga").result(function(event, data, formatted) {
		var kode_prepared	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_prepared="+kode_prepared,
			url 	: "prepared/cari_prepared.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
			
				$("#kode_prepared").val(data.kode_prepared);
				
			}
		});
	});
	$("#pelangga").keyup(function() {
		var kode_prepared	= $('#pelangga').val();
		$.ajax({
			type	: "POST",
			data	: "kode_prepared="+kode_prepared,
			url 	: "prepared/cari_prepared.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
					$("#kode_prepared").val(data.kode_prepared);
					
			}
		});
	});
	
});
</script>
</head>
<body>
  
  <tr><td colspan="2"> <strong> </strong></td></tr>
  <input type="hidden" id="kode_prepared" name="preparedby_no">
 <tr><td>Prepared by </td><td>: <input type="text" id="pelangga" name="preparedby" size="50"> <small>*) Fill employee name</small></td></tr>
  
</body>
</html>
