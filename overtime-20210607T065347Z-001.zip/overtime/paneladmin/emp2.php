<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#empno2").autocomplete("employee/proses_emp2.php", {
		width: 300
	});
	
	$("#empno2").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_emp2="+kode_emp2,
			url 	: "employee/cari_emp2.php",
			dataType: "json",
			success: function(data){
				$("#kode_emp2").val(data.kode_emp2);
				$("#empname2").val(data.empname);
				
			
			}
		});
	});
	$("#empno2").keyup(function() {
		var kode_emp2	= $('#empno2').val();
		$.ajax({
			type	: "POST",
			data	: "kode_emp2="+kode_emp2,
			url 	: "employee/cari_emp2.php",
			dataType: "json",
			success: function(data){
				
					$("#kode_emp2").val(data.kode_emp2);
					$("#empname2").val(data.empname);
					
					
			}
		});
	});
	
});
</script>
</head>
<body>
  
  <tr><td colspan="2"> <strong> </strong></td></tr>
 <tr><td>Emp No 1</td><td>: <input type="text" id="empno2" name="emp2" size="50"> <small>*) Fill employee No</small></td></tr>
 <tr><td>Emp Name</td><td>: <input type="text" id="empname2" size="50" name="empname2" readonly=""></td></tr>
 
   
</body>
</html>
