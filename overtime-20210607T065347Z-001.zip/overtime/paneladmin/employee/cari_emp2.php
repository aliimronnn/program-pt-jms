<?php
include"../config/koneksi.php";

$kode_emp2	= $_POST['kode_emp2'];

$sql 	= mysqli_query($conn, "SELECT * from employee where empno='$kode_emp2'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['empname'] = $r['empname'];
		
		
	echo json_encode($data);
}else{
	$data['empname'] = '';

	
	echo json_encode($data);
}
?>
