<?php
include"../config/koneksi.php";

$kode2	= $_POST[kode2];

$sql 	= mysql_query("SELECT *from employee where empno='$kode2'");
$row	= mysql_num_rows($sql);
if($row>0){
	$r = mysql_fetch_array($sql);
	$data['empname'] = $r[empname];
	
	echo json_encode($data);
}else{
	$data['empname'] = '';
	
	
	echo json_encode($data);
}
?>
