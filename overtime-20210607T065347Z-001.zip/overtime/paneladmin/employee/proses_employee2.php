<?php
include"../config/koneksi.php";
$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = mysql_query("select *from employee where empno LIKE '%$q%'");
while($r = mysql_fetch_array($sql)) {
	$empno = $r['empno'];
	
	echo "$empno\n";
}
?>
