<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to Logout the system?")) {
      document.location = delUrl;
   }
}
</script>
<?php
include "config/koneksi.php";
include "config/library.php";
include "config/fungsi_indotgl.php";
include "config/fungsi_tanggal.php";
include "config/fungsi_combobox.php";
include "config/class_paging.php";
include "config/fungsi_thumb.php";

// Bagian Home
if ($_SESSION['leveluser']=='admin' OR $_SESSION['leveluser']=='user'  ) {
if ($_GET['module']=='home') {
	$sc=mysqli_fetch_array(mysqli_query($conn, "SELECT section FROM sectioncode WHERE id ='$_SESSION[section]'"));
	echo "<div align=center>
	<h2>Welcome </h2>
			<h4>$sc[section] / $_SESSION[section]</br>Overtime System PT. JMS Batam.<br>
			 </h4>
			 <p><small>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
   date_default_timezone_set("Asia/Jakarta");
  echo date("H:i:s");
  echo " WIB</small></p>";
 //echo $_SESSION[jenisuser] ;
  if ($_SESSION['leveluser']=='admin'){
  
 echo"	<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		
		<tr>
		
		 <td width=120 align=center><a href=index.php?module=oti>
		  <div class=menu_thumb><img src=images/inp_oti.png border=none>
		  <br/><b>Input Overtime</b></div></a></a></td> 
		  
		  	 
		 	<td width=120 align=center><a href=index.php?module=oti&act=approve >
		  <div class=menu_thumb><img src=images/big_approve.png border=none>
		  <br/><b>Approve Overtime</b></div></a></a></td> 
		  
		   <td width=120 align=center><a href=index.php?module=oti&act=ordermeals>
		  <div class=menu_thumb><img src=images/verifikasi.png border=none>
		  <br/><b>Order Meals Daily</b></div></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=laporan&act=return>
		  <div class=menu_thumb><img src=images/big_return.png border=none>
		  <br/><b>View and Return</b></div></a></a></td>
		  
		</tr>
		
		<tr>
		
		 <td width=120 align=center><a href=index.php?module=laporan&act=carimeallokasi>
		  <div class=menu_thumb><img src=images/big_meals.png border=none>
		  <br/><b>View Total Meals Order</b></div></a></a></td>  
		 
		 <td width=120 align=center><a href=index.php?module=oti&act=ordermeals2>
		  <div class=menu_thumb><img src=images/big_order.png border=none>
		  <br/><b>View Order Daily</b></div></a></td>
		 
		 <td width=120 align=center><a href=index.php?module=laporan&act=findfasting>
		  <div class=menu_thumb><img src=images/fasting.png border=none>
		  <br/><b>View Paid Meals</b></div></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=laporan&act=carimeal>
		  <div class=menu_thumb><img src=images/big_detail.png border=none>
		  <br/><b>View Order Detail OT</b></div></a></a></td>
		  
		</tr>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=employee>
		  <div class=menu_thumb><img src=images/dosen.png border=none>
		  <br/><b>Employee Data</b></div></a></a></td>
		  		 
		  	
		   <td width=120 align=center><a href=index.php?module=section>
		  <div class=menu_thumb><img src=images/spj.png border=none>
		  <br/><b>Section Data</b></div></a></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=lokasi>
		  <div class=menu_thumb><img src=images/lokasi.png border=none>
		  <br/><b>Location Data </b></div></a></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=meals>
		  <div class=menu_thumb><img src=images/big_mealscode.png border=none>
		  <br/><b>Meals Code</b></div></a></td>
		</tr>
		<tr>
		 
		 <td width=120 align=center><a href=index.php?module=katring>
		  <div class=menu_thumb><img src=images/big_catering.png border=none>
		  <br/><b>Data Catering</b></div></a></td>
		
		  <td width=120 align=center><a href=index.php?module=user>
		  <div class=menu_thumb><img src=images/user.png border=none>
		  <br/><b>User Management</b></div></a></a></td>
		 
		  <td width=120 align=center><a href=index.php?module=modul>
		  <div class=menu_thumb><img src=images/modul.png border=none>
		  <br/><b>Modul Management</b></div></a></a></td>
		 	
		 	<td width=120 align=center><a href=index.php?module=ekstra&act=>
		  <div class=menu_thumb><img src=images/ekstra.png border=none>
		  <br/><b>Ekstra Meals</b></div></a></td>
		  
		</tr>	
		<tr>
		
			  
		  <td width=120 align=center><a href=index.php?module=oti&act=daftarotisection>
		  <div class=menu_thumb><img src=images/oti.png border=none>
		  <br/><b>View Overtime All Section</b></div></a></a></td>
		   
		  <td width=120 align=center><a href=index.php?module=oti&act=report_oti>
		  <div class=menu_thumb><img src=images/header2.png border=none>
		  <br/><b>Report Overtime</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=locker>
		  <div class=menu_thumb><img src=images/locker.png border=none>
		  <br/><b>Data Locker</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=locker&act=importadmin>
		  <div class=menu_thumb><img src=images/import.png border=none>
		  <br/><b>Import Data Locker</b></div></a></td>
		  
		    
		</tr>	
		<tr>
		  
		  <td width=120 align=center><a href=index.php?module=backup target='_blank'>
		  <div class=menu_thumb><img src=images/dbbackup.png border=none>
		  <br/><b>Backup Database</b></div></a></a></td> 
		  
		   <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/user.png border=none>
		  <br/><b>Account Info</b></div></a></td>
    	</tr>
    	
				
		
    </table>
	
	";

  } else 
   if ($_SESSION['leveluser']=='user'){
   	
   	if ($_SESSION['jenisuser']==2){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		  <td width=120 align=center><a href=index.php?module=oti>
		  <div class=menu_thumb><img src=images/inp_oti.png border=none>
		  <br/><b>Input Overtime</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=oti&act=approve >
		  <div class=menu_thumb><img src=images/big_approve.png border=none>
		  <br/><b>Approve Overtime</b></div></a></a></td> 
		  
		  <td width=120 align=center><a href=index.php?module=laporan&act=return>
		  <div class=menu_thumb><img src=images/big_return.png border=none>
		  <br/><b>View and Return</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=oti&act=ordermeals>
		  <div class=menu_thumb><img src=images/verifikasi.png border=none>
		  <br/><b>Order Meals Daily</b></div></a></td>
		   
		 	  
    	</tr>
			<tr>
		
		   <td width=120 align=center><a href=index.php?module=laporan&act=carimeallokasi>
		  <div class=menu_thumb><img src=images/big_meals.png border=none>
		  <br/><b>View Total Meals Order</b></div></a></a></td>
		   
		  <td width=120 align=center><a href=index.php?module=oti&act=ordermeals2>
		  <div class=menu_thumb><img src=images/big_order.png border=none>
		  <br/><b>View Order Daily</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=laporan&act=findfasting>
		  <div class=menu_thumb><img src=images/fasting.png border=none>
		  <br/><b>View Paid Meals</b></div></a></td>  
		  
		  <td width=120 align=center><a href=index.php?module=laporan&act=carimeal>
		  <div class=menu_thumb><img src=images/big_detail.png border=none>
		  <br/><b>View Order Detail OT</b></div></a></a></td>
		  
		     	
		</tr>
    	<tr>
    	  <td width=120 align=center><a href=index.php?module=oti&act=daftarotisection>
		  <div class=menu_thumb><img src=images/oti.png border=none>
		  <br/><b>View Overtime All Section</b></div></a></a></td>
		 
		  <td width=120 align=center><a href=index.php?module=oti&act=report_oti>
		  <div class=menu_thumb><img src=images/header2.png border=none>
		  <br/><b>Report Overtime</b></div></a></a></td>  
		  
		  <td width=120 align=center><a href=index.php?module=katring>
		  <div class=menu_thumb><img src=images/big_catering.png border=none>
		  <br/><b>Catering Data</b></div></a></td>
    	
    	<td width=120 align=center><a href=index.php?module=employee>
		  <div class=menu_thumb><img src=images/dosen.png border=none>
		  <br/><b>Employee Data</b></div></a></a></td>	
		
    	</tr>
    	
    	<tr>
    	
    	<td width=120 align=center><a href=index.php?module=ekstra&act=>
		  <div class=menu_thumb><img src=images/ekstra.png border=none>
		  <br/><b>Ekstra Meals</b></div></a></td>
    	
		 <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/user.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=lokasi>
		  <div class=menu_thumb><img src=images/lokasi.png border=none>
		  <br/><b>Location Data </b></div></a></a></td>
		  
    	</tr>
		
		
		
    </table>
	
	";

  } else 
  	if ($_SESSION['jenisuser']==3){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		  <td width=120 align=center><a href=index.php?module=oti>
		  <div class=menu_thumb><img src=images/inp_oti.png border=none>
		  <br/><b>Input Overtime</b></div></a></td>
		  
		     
		  <td width=120 align=center><a href=index.php?module=oti&act=ordermeals>
		  <div class=menu_thumb><img src=images/big_order.png border=none>
		  <br/><b>Order Meals Daily</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=oti&act=daftaroti>
		  <div class=menu_thumb><img src=images/oti.png border=none>
		  <br/><b>View Overtime</b></div></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=employee&act=employeeuser>
		  <div class=menu_thumb><img src=images/dosen.png border=none>
		  <br/><b>Employee Data</b></div></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/user.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		</tr>
		
			 
		
    </table>
	
	";

  } else 
  	if ($_SESSION['jenisuser']==4){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		  <td width=120 align=center><a href=index.php?module=oti>
		  <div class=menu_thumb><img src=images/inp_oti.png border=none>
		  <br/><b>Input Overtime</b></div></a></td>
		  
		     
		  <td width=120 align=center><a href=index.php?module=oti&act=ordermeals>
		  <div class=menu_thumb><img src=images/big_order.png border=none>
		  <br/><b>Order Meals Daily</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=oti&act=daftaroti>
		  <div class=menu_thumb><img src=images/oti.png border=none>
		  <br/><b>View Overtime</b></div></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=employee&act=employeeuser>
		  <div class=menu_thumb><img src=images/dosen.png border=none>
		  <br/><b>Employee Data</b></div></a></td>
		  
		   
		</tr>
		
		<tr>
		  <td width=120 align=center><a href=index.php?module=locker&act=view_lockeruser>
		  <div class=menu_thumb><img src=images/locker.png border=none>
		  <br/><b>Data Locker</b></div></a></td>
		  
		  	  
		  <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/user.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
	
		  
		</tr>
		
	
		 
		 
		
    </table>
	
	";

  }
  
  else 
  	if ($_SESSION['jenisuser']==5){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		  <td width=120 align=center><a href=index.php?module=oti>
		  <div class=menu_thumb><img src=images/inp_oti.png border=none>
		  <br/><b>Input Overtime</b></div></a></td>
		  
		     
		  <td width=120 align=center><a href=index.php?module=oti&act=ordermeals>
		  <div class=menu_thumb><img src=images/big_order.png border=none>
		  <br/><b>Order Meals Daily</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=oti&act=daftaroti>
		  <div class=menu_thumb><img src=images/oti.png border=none>
		  <br/><b>View Overtime</b></div></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=employee&act=employeeuser>
		  <div class=menu_thumb><img src=images/dosen.png border=none>
		  <br/><b>Employee Data</b></div></a></td>
		  
		   
		</tr>
		
		<tr>
		  <td width=120 align=center><a href=index.php?module=locker>
		  <div class=menu_thumb><img src=images/locker.png border=none>
		  <br/><b>Data Locker</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=locker&act=view_create>
		  <div class=menu_thumb><img src=images/import.png border=none>
		  <br/><b>Add New Locker</b></div></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/user.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
	
		  
		</tr>
		
	
		 
		 
		
    </table>
	
	";

  }
 }
}

// Bagian User
 /*elseif ($_GET[module]=='user') {
	include "modul/mod_user/user.php";
	
	 <td width=120 align=center>
		   <a href=javascript:confirmdelete('logout.php')><div class=menu_thumb>
		   <img src=images/big_logout.png border=none>
		  <br/><b>Logout</b></div></a>
		 </td>
}
}*/
// Bagian Modul

elseif ($_GET['module']=='ekstra') {
	include "modul/mod_ekstra/ekstra.php";
}
elseif ($_GET['module']=='employee') {
	include "modul/mod_employee/employee.php";
} 
elseif ($_GET['module']=='katring') {
	include "modul/mod_katring/katring.php";
}
elseif ($_GET['module']=='meals') {
	include "modul/mod_meals/meals.php";
}
elseif ($_GET['module']=='section') {
	include "modul/mod_section/section.php";
} 
elseif ($_GET['module']=='lokasi') {
	include "modul/mod_lokasi/lokasi.php";
}
elseif ($_GET['module']=='oti') {
	include "modul/mod_oti/oti.php";
} 



elseif ($_GET['module']=='lapservice') {
	include "modul/mod_lapservice/lapservice.php";
}

elseif ($_GET['module']=='laporan') {
	include "modul/mod_laporan/laporan.php";
}

elseif ($_GET['module']=='jenisuser') {
	include "modul/mod_jenisuser/jenisuser.php";
}
elseif ($_GET['module']=='identitas') {
	include "modul/mod_identitas/identitas.php";
}

elseif ($_GET['module']=='bidang') {
	include "modul/mod_bidang/bidang.php";
}

// Bagian Modul
elseif ($_GET['module']=='phpmyadmin') {
	include "modul/mod_phpmyadmin/phpmyadmin.php";
}

elseif ($_GET['module']=='autocomplete') {
	include "modul/mod_autocomplete/barang.php";
}

// Bagian Data SMS Saksi
elseif ($_GET['module']=='dpt') {
	include "modul/mod_dpt/dpt.php";
}

else if ($_GET['module'] == 'logout') {
	include "logout.php";
}

else if ($_GET['module'] == 'identitas') {
	include "identitas.php";
}
else if ($_GET['module'] == 'rdatabase') {
	include "rdatabase.php";
}
else if ($_GET['module'] == 'konfigurasi') {
	include "setting.php";
}
// Bagian provinsi

// Bagian User
else	if ($_GET['module']=='user') {
		include "modul/mod_user/user.php";
}
// Bagian Modul
	elseif ($_GET['module']=='modul') {
		include "modul/mod_modul/modul.php";
}
// Bagian Modul
	elseif ($_GET['module']=='backup') {
		include "modul/mod_backup/backup.php";
}
elseif ($_GET['module']=='locker') {
		include "modul/mod_locker/locker.php";
}


}

?>