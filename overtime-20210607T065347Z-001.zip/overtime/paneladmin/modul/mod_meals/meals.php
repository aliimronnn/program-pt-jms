<script>
function confirmdelete(delUrl) {
  if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   
   return (true);
}
</script>

<?php
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>To Acces the program, you need to login first! <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_meals/aksi_meals.php";
switch(@$_GET['act']){

default:
echo "<h2>List Meals Type</h2>
<p>&nbsp;</p>
<input type=button value='Tambah Jenis Meals'  class='large blue super button'
onclick=\"window.location.href='?module=meals&act=tambahmeals';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th></th>
<th>Code</th><th>Meals Type</th><th colspan=2>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * FROM mealscode ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td></td>
	<td>$r[id]</td>
  <td>$r[jenis]</td>
  <td align='right'><a href='?module=meals&act=editmeals&id=$r[id]'><img src='images/edit.png' alt='edit' /></a></td>
  <td><a href=javascript:confirmdelete('$aksi?module=meals&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a></td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

// Form Tambah meals
case "tambahmeals":
echo "<h2>Add New Meals Type</h2>
<form method=POST action='$aksi?module=meals&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code</td><td>: <input type='text' name='id' size='20' value='' ></td></tr>                
<tr><td>Meals Type</td><td>: <input type='text' name='meals' size='20' value='' ></td></tr>                
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit meals 
case "editmeals":
$edit = mysqli_query($conn, "SELECT * FROM mealscode WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Modify Meals Type</h2>
<form method=POST action='$aksi?module=meals&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code</td><td>: <input type='text' name='id' size='20' value='$r[id]' ></td></tr>                
<tr><td>Meals Type</td><td>: <input type='text' name='meals' size='20' value='$r[jenis]' ></td></tr>                
<tr><td colspan=2><input type=submit value=Update class='large blue super button'>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
}
?>
