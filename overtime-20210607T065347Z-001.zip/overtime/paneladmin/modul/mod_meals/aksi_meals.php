<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
    include "../../config/koneksi.php";
  include "../../config/library.php";
  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  
  $id = htmlentities($_POST['id']);
  $meals = htmlentities($_POST['meals']);

  // Input meals
  if ($module=='meals' AND $act=='input'){
  	        mysqli_query($conn, "INSERT INTO mealscode(id,
					jenis)
                                VALUES('$id',
					'$meals')");
     header('location:../../index.php?module='.$module);
            
  }
  
  // Update meals  
  elseif ($module=='meals' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE mealscode SET  id = '$id',
					jenis = '$meals'                                         
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);
  }
    
  // Delete meals  
  elseif ($module=='meals' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM mealscode WHERE id = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  }
  
  }
?>
