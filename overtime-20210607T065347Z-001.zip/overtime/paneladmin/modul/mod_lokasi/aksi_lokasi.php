<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
    include "../../config/koneksi.php";
  include "../../config/library.php";
  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  
  $codelocations = htmlentities($_POST['codelocations']);
  $locations = htmlentities($_POST['locations']);

  // Input lokasi
  if ($module=='lokasi' AND $act=='input'){
  	        mysqli_query($conn, "INSERT INTO locations(codelocations,
					locations)
                                VALUES('$codelocations',
					'$locations')");
     header('location:../../index.php?module='.$module);
            
  }
  
  // Update lokasi  
  elseif ($module=='lokasi' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE locations SET  codelocations = '$codelocations',
					locations = '$locations'                                         
                          WHERE codelocations = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);
  }
    
  // Delete lokasi  
  elseif ($module=='lokasi' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM locations WHERE codelocations = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  }
  
  }
?>
