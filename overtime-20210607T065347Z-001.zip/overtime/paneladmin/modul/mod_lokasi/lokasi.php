<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   
   return (true);
}
</script>

<?php
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>To Acces the program, you need to login first!  <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_lokasi/aksi_lokasi.php";
switch(@$_GET['act']){

default:
echo "<h2>List Location</h2>
<p>&nbsp;</p>
<input type=button value='Add New Location'  class='large blue super button'
onclick=\"window.location.href='?module=lokasi&act=tambahlokasi';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Code</th><th>Location</th><th colspan=2>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * FROM locations ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
  echo "<tr><td>$no.</td>
	<td>$r[codelocations]</td>
      	<td>$r[locations]</td>
        <td><a href='?module=lokasi&act=editlokasi&id=$r[codelocations]'>Edit</a> | 
        <a href=javascript:confirmdelete('$aksi?module=lokasi&act=delete&id=$r[codelocations]')>Hapus</a>
        </td><td></td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

// Form Tambah lokasi
case "tambahlokasi":
echo "<h2>Add Locations</h2>
<form method=POST action='$aksi?module=lokasi&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code</td><td>: <input type='text' name='codelocations' size='20' value='' ></td></tr>                
<tr><td>Location</td><td>: <input type='text' name='locations' size='20' value='' ></td></tr>                
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit lokasi 
case "editlokasi":
$edit = mysqli_query($conn, "SELECT * FROM locations WHERE codelocations='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Modify Location</h2>
<form method=POST action='$aksi?module=lokasi&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[codelocations]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Code</td><td>: <input type='text' name='codelocations' size='20' value='$r[codelocations]' ></td></tr>                
<tr><td>Location</td><td>: <input type='text' name='locations' size='20' value='$r[locations]' ></td></tr>                
<tr><td colspan=2><input type=submit value=Update class='large blue super button'>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
}
?>
