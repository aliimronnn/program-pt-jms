<?php
session_start();
include "../../config/koneksi.php";
$module=$_GET[module];
$act=$_GET[act];

// Hapus ruangan
if ($module=='ruangan' AND $act=='hapus') {
	mysql_query("DELETE FROM ruangan WHERE id='$_GET[id]'");
	header('location:../../index.php?module='.$module);

}

// Input ruangan
elseif ($module=='ruangan' AND $act=='input') {
	mysql_query("INSERT INTO ruangan(nomor,ruangan) VALUES ('$_POST[nomor]','$_POST[ruangan]')");
	header('location:../../index.php?module='.$module);

}

// Update ruangan
elseif ($module=='ruangan' AND $act=='update') {
	mysql_query("UPDATE ruangan SET nomor = '$_POST[nomor]',
ruangan='$_POST[ruangan]'	WHERE id='$_POST[id]'");
	header('location:../../index.php?module='.$module);

}
?>