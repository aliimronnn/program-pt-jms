<?php
$aksi="modul/mod_ruangan/aksi_ruangan.php";
$act=$_GET[act];
switch($act) {
	// Tampil ruangan
	default:
	echo "<h2>Halaman PHPMYADMIN</h2><br/>
		 ";
echo '<iframe align="center" frameborder="0" src="http://localhost/phpmyadmin/index.php?db=dbksoplok&token=e70816fea601dea949e98e024c2f0765" width="1250" height="700" scrolling="auto"></iframe>'; 

break;


case "tambahruangan":
$thn_skrg=date("Y");
echo "<h2>Tambah Ruangan</h2><br/>
<form method=POST action='$aksi?module=ruangan&act=input' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr>
	<td>Nomor Ruangan</td>
	<td> : </td><td><input type=text name='nomor' size=20 maxlength=100></td>
</tr>
<tr>
	<td>Nama Ruangan</td>
	<td> : </td><td><input type=text name='ruangan' size=90 maxlength=100></td>
</tr>


<tr>
	<td colspan=2><input type=submit value=Simpan class='large blue super button'>
	<input type=button value=Batal onclick=self.history.back() class='large orange super button'>
	</td>
</tr>
</table>
</form>";
break;

case "editruangan":
$edit=mysql_query("SELECT * FROM ruangan WHERE id='$_GET[id]'");
$r=mysql_fetch_array($edit);

$thn_skrg=date("Y");
echo "<h2>Edit Ruangan</h2>
<form method=POST action='$aksi?module=ruangan&act=update' enctype='multipart/form-data'>
<input type=hidden name=id value='$r[id]'><p>&nbsp;</p>
<table cellspacing=10 cellpadding=6>
<tr>
	<td>Nomor</td>
	<td> : </td><td><input type=text name='nomor' value='$r[nomor]' size=20 maxlength=100></td>
</tr>

<tr>
	<td>Ruangan</td>
	<td> : </td><td><input type=text name='ruangan' value='$r[ruangan]' size=90 maxlength=50 ></td>
</tr>

<tr>
	<td colspan=2><input type=submit value=Update class='large blue super button'>
	<input type=button value=Batal onclick=self.history.back() class='large orange super button'>
	</td>
</tr>
</table>
</form>";
break;
}
?>