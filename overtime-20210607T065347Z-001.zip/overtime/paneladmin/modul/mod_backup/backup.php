<?php

$aksi="modul/mod_backup/aksi_backup.php";
//include "../../../config/koneksi.php";
$act=@$_GET['act'];
switch($act) {
	// Tampil backup
	default:
	echo "<h2>Restore Data MySQL</h2>";

echo "DB Name: ".$database;

// form upload file dumo
echo "<form enctype='multipart/form-data' method='post' action='".$_SERVER['PHP_SELF']."?op=restore'>";
echo "<input type='hidden' name='MAX_FILE_SIZE' value='20000000'>
      <input name='datafile' type='file'>
      <input name='submit' type='submit' value='Restore'>";
echo "</form>";
// proses restore data
error_reporting(E_ALL);
if ($_GET['op'] == "restore")
{
  // baca nama file
  $fileName = $_FILES['datafile']['name'];

  // proses upload file
  move_uploaded_file($_FILES['datafile']['tmp_name'], $fileName);

  // membentuk string command untuk restore
  // di sini diasumsikan letak file mysql.exe terletak di direktori C:\AppServ\MySQL\bin
  $string = "F:\xampp\mysql\bin\mysqldump -u".$username." -p".$password." ".$database." < ".$fileName;

  // menjalankan command restore di shell via PHP
  exec($string);

  // hapus file dump yang diupload
  unlink($fileName);
}



//////////////////////////////////////	
	echo "<h2>Backup Database</h2>";
  $query = "SHOW TABLES";
  $hasil = mysqli_query($conn, $query);
  echo "<form method=POST action='$aksi?module=backup&act=proses'>";
echo "<table>";
while ($data = mysqli_fetch_row($hasil))
{
   echo "<tr><td><input type='checkbox' name='tabel[]' value='".$data[0]."'></td><td>".$data[0]."</td></tr>";
}
echo "</table><br>";
echo "<input type='submit' name='submit' value='Backup Data'>";
echo "</form>";

  
break;
}
?>