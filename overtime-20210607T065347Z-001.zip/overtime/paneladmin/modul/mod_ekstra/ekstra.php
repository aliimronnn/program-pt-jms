<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   
   return (true);
}
</script>

<?php
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>To Acces the program, you need to login first!  <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_ekstra/aksi_ekstra.php";
switch(@$_GET['act']){

default:

$edit = mysqli_query($conn, "SELECT * FROM ekstra_meals");
$r    = mysqli_fetch_array($edit);

echo "<h2>Management Ekstra Meals</h2>
<form method=POST action='$aksi?module=ekstra&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Range 1 - 5 </td><td>: <input type='text' name='a' size='20' value='$r[a]' ></td></tr>                
<tr><td>Range 6 - 30 </td><td>: <input type='text' name='b' size='20' value='$r[b]' ></td></tr>  
<tr><td>Range 31 - 60 </td><td>: <input type='text' name='c' size='20' value='$r[c]' ></td></tr> 
<tr><td>Range 61 - 100 </td><td>: <input type='text' name='d' size='20' value='$r[d]' ></td></tr> 
<tr><td>Range 101 - Up </td><td>: <input type='text' name='e' size='20' value='$r[e]' ></td></tr>             
<tr><td colspan=2><input type=submit value=Update class='large blue super button'>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
}
?>
