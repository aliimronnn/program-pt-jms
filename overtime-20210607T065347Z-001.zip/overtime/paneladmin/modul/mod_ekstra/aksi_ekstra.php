<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
    include "../../config/koneksi.php";
  include "../../config/library.php";
  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  
 $a = htmlentities($_POST['a']);
  $b = htmlentities($_POST['b']);
   $c = htmlentities($_POST['c']);
    $d = htmlentities($_POST['d']);
     $e= htmlentities($_POST['e']);
   

  // Input lokasi
  if ($module=='ekstra' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE ekstra_meals SET  a = '$a',
					b = '$b',   c = '$c',  d = '$d',  e = '$e'                                        
                  ");
    
    header('location:../../index.php?module='.$module);
  }
    
  
  }
?>
