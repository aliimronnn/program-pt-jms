<?php
session_start();
 if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
$aksi="modul/mod_agenda/aksi_agenda.php";
switch($_GET[act]){
  // Tampil Agenda
  default:
  ?>
<script type="text/javascript">
$().ready(function() {	
	$("#barang").autocomplete("proses_barang.php", {
		width: 150
  });

	$("#barang").result(function(event, data, formatted) {
				$('#pilihan').html("<p>Anda memilih Barang: " + formatted + "</p>"); 
	});
	
});
</script>

  <div class="demo" style="width: 250px;">
  <div><p>Nama Barang : <input type="text" id="barang"></p></div>
  </div> 
  <div id="pilihan"></div>
<?php
}
}
?>