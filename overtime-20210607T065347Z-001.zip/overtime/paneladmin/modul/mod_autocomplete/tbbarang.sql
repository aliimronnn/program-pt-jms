/*
Navicat MySQL Data Transfer

Source Server         : lokal
Source Server Version : 50141
Source Host           : localhost:3306
Source Database       : tutorial_jquery

Target Server Type    : MYSQL
Target Server Version : 50141
File Encoding         : 65001

Date: 2012-09-12 19:04:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tbbarang`
-- ----------------------------
DROP TABLE IF EXISTS `tbbarang`;
CREATE TABLE `tbbarang` (
  `kodebarang` char(25) NOT NULL,
  `namabarang` varchar(100) DEFAULT NULL,
  `hargabeli` int(11) DEFAULT NULL,
  `hargajual` int(11) DEFAULT NULL,
  `stokawal` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`kodebarang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- ----------------------------
-- Records of tbbarang
-- ----------------------------
INSERT INTO `tbbarang` VALUES ('.8888166606432', 'TOGO COKLAT', '399', '459', '0');
INSERT INTO `tbbarang` VALUES ('0001', 'FLASH DISK NEXUS 1 GB', '57000', '62700', '0');
INSERT INTO `tbbarang` VALUES ('0002', 'FLASH DISK NEXUS 2 GB', '70000', '77000', '0');
INSERT INTO `tbbarang` VALUES ('0003', 'PENGGARIS PLASTIK 30 CM', '900', '990', '0');
INSERT INTO `tbbarang` VALUES ('0004', 'PENGGARIS BESI 30 CM', '3000', '3300', '0');
INSERT INTO `tbbarang` VALUES ('0005', 'BATREI ABC BESAR', '3000', '3300', '0');
INSERT INTO `tbbarang` VALUES ('0006', 'BATREI ABC SEDANG', '2100', '2310', '0');
INSERT INTO `tbbarang` VALUES ('0007', 'BATREI ABC KECIL', '1200', '1320', '0');
INSERT INTO `tbbarang` VALUES ('0008', 'PENSIL STANDARD 2B', '2000', '2200', '0');
INSERT INTO `tbbarang` VALUES ('0009', 'PEN PILOT BPT-P', '1600', '1760', '0');
INSERT INTO `tbbarang` VALUES ('001', 'TOP  Kopi', '950', '1000', '1000');
INSERT INTO `tbbarang` VALUES ('0010', 'PEN BOXY UNI BALL', '4900', '5390', '0');
INSERT INTO `tbbarang` VALUES ('0011', 'AMPLOP COKLAT CABINET PAK', '8500', '9350', '0');
INSERT INTO `tbbarang` VALUES ('0012', 'PEN PILOT BALINER', '9000', '9900', '0');
INSERT INTO `tbbarang` VALUES ('0013', 'CLIP KAITO NO.3', '10000', '9350', '0');
INSERT INTO `tbbarang` VALUES ('0014', 'PEN STANDARD AE7', '800', '880', '0');
INSERT INTO `tbbarang` VALUES ('0015', 'BUKU 1/2 EKSPEDISI', '2000', '2200', '0');
INSERT INTO `tbbarang` VALUES ('0016', 'BAK STEMPLE HERO NO.1', '3300', '3630', '0');
INSERT INTO `tbbarang` VALUES ('0017', 'GUNTING JOY ART', '3000', '3300', '0');
INSERT INTO `tbbarang` VALUES ('0018', 'KERTAS KARBON DAITO FOLIO', '300', '330', '0');
INSERT INTO `tbbarang` VALUES ('0019', 'MAP DIAMOND', '1100', '1210', '0');
INSERT INTO `tbbarang` VALUES ('002', 'Pulpy Orange', '4500', '5000', '10');
INSERT INTO `tbbarang` VALUES ('0020', 'AMPLOP COKLAT POLIO PAK', '23000', '25300', '0');
INSERT INTO `tbbarang` VALUES ('0021', 'AMPLOP COKLAT QUARTO PAK', '18000', '19800', '0');
INSERT INTO `tbbarang` VALUES ('0022', 'AMPLOP COKLAT BHG 310 PAK', '30000', '33000', '0');
INSERT INTO `tbbarang` VALUES ('0023', 'ODNER VICO 1402/1401 DUS', '100000', '110000', '0');
INSERT INTO `tbbarang` VALUES ('0023942431336', 'CD-RW VERBATIM COLOR @ 5', '50000', '55000', '0');
INSERT INTO `tbbarang` VALUES ('0023942433088', 'CD-R AZO VERBATIM @ 10', '30000', '33000', '0');
INSERT INTO `tbbarang` VALUES ('0024', 'ODNER GUNGYU 401/402 DUS', '108000', '118800', '0');
INSERT INTO `tbbarang` VALUES ('0025', 'ODNER VICO 1402/1401', '8400', '9240', '0');
INSERT INTO `tbbarang` VALUES ('0026', 'ODNER GUNGYU 401/402', '9000', '9900', '0');
INSERT INTO `tbbarang` VALUES ('0027', 'AMPLOP COKLAT CABINET', '100', '110', '0');
INSERT INTO `tbbarang` VALUES ('0028', 'AMPLOP COKLAT QUARTO', '200', '220', '0');
INSERT INTO `tbbarang` VALUES ('0029', 'AMPLOP COKLAT FOLIO', '400', '440', '0');
INSERT INTO `tbbarang` VALUES ('003', null, null, null, null);
INSERT INTO `tbbarang` VALUES ('0030', 'LEM DIAKOL BESAR', '3000', '3300', '0');
INSERT INTO `tbbarang` VALUES ('0031', 'LEM DIAKOL SEDANG', '1300', '1430', '0');
INSERT INTO `tbbarang` VALUES ('0032', 'LEM DIAKOL KECIL', '500', '550', '0');
INSERT INTO `tbbarang` VALUES ('0033', 'LEM POWER GLUE', '2100', '2310', '0');
INSERT INTO `tbbarang` VALUES ('0034', 'LAKBAN C/B 2 \"', '4500', '4950', '0');
INSERT INTO `tbbarang` VALUES ('0035', 'LAKBAN HITAM 2 \"', '6500', '7150', '0');
INSERT INTO `tbbarang` VALUES ('0036', 'LAKBAN HITAM 1\"', '5000', '5500', '0');
INSERT INTO `tbbarang` VALUES ('0037', 'PEN FASTER', '1500', '1650', '0');
INSERT INTO `tbbarang` VALUES ('0038', 'PEN FASTER BOX', '20000', '18700', '0');
INSERT INTO `tbbarang` VALUES ('0039', 'MAP BIASA PAK', '11000', '12100', '0');
INSERT INTO `tbbarang` VALUES ('0040', 'MAP BIASA', '300', '330', '0');
INSERT INTO `tbbarang` VALUES ('0041', 'MAP SNELLHECTER PAK', '18000', '19800', '0');
INSERT INTO `tbbarang` VALUES ('0042', 'MAP SNELLHECTER', '400', '440', '0');
INSERT INTO `tbbarang` VALUES ('0043', 'BUKU MIRAGE FOLIO 100', '8500', '9350', '0');
INSERT INTO `tbbarang` VALUES ('0044', 'CD-RW VERBATIM', '10000', '11000', '0');
INSERT INTO `tbbarang` VALUES ('0045', 'CDR VERBATIM', '3000', '3300', '0');
INSERT INTO `tbbarang` VALUES ('0046', 'SPIDOL KECIL', '750', '880', '0');
INSERT INTO `tbbarang` VALUES ('0047', 'DOUBLE TIPE 1\"', '4000', '4400', '0');
INSERT INTO `tbbarang` VALUES ('0048', 'VEGETA JERUK', '750', '862', '0');
INSERT INTO `tbbarang` VALUES ('0049', 'ADEM SARI', '750', '862', '0');
INSERT INTO `tbbarang` VALUES ('0050', 'VEGETA HERBAL', '500', '575', '0');
INSERT INTO `tbbarang` VALUES ('0051', 'SANDAL SWALLOW', '6800', '7820', '0');
INSERT INTO `tbbarang` VALUES ('0052', 'COTTON BUDS BESAR', '1700', '1955', '0');
INSERT INTO `tbbarang` VALUES ('0053', 'COTTON BUDS KECIL', '1250', '1438', '0');
INSERT INTO `tbbarang` VALUES ('0054', 'TISU TESSA KECIL', '850', '978', '0');
INSERT INTO `tbbarang` VALUES ('0055', 'TEH BOTOL SOSRO', '1187', '1365', '0');
INSERT INTO `tbbarang` VALUES ('0056', 'FRUIT TEA BOTOL', '1187', '1365', '0');
INSERT INTO `tbbarang` VALUES ('0057', 'TEBS BOTOL', '1291', '1485', '0');
INSERT INTO `tbbarang` VALUES ('0058', 'JOYTEA BOTOL', '1125', '1294', '0');
INSERT INTO `tbbarang` VALUES ('0059', 'KACANG METE KECIL', '5000', '5750', '0');
INSERT INTO `tbbarang` VALUES ('0060', 'MAP DIAMOND 5002', '53000', '58300', '0');
INSERT INTO `tbbarang` VALUES ('0061', 'PEN BALL LINER PACK', '108000', '118800', '0');
INSERT INTO `tbbarang` VALUES ('0062', 'PEN JOYKO GEL PACK', '15000', '16500', '0');
INSERT INTO `tbbarang` VALUES ('0063', 'PEN PILOT BPT-P PACK', '18500', '20350', '0');
INSERT INTO `tbbarang` VALUES ('0064', 'SNACK AGUNG SARI', '4500', '5175', '0');
INSERT INTO `tbbarang` VALUES ('0068', 'TAS PAPER XL', '4500', '4950', '0');
INSERT INTO `tbbarang` VALUES ('0069', 'TAS PAPER BUKU', '2700', '2970', '0');
INSERT INTO `tbbarang` VALUES ('0070', 'TAS PAPER FOLIO', '3600', '3960', '0');
INSERT INTO `tbbarang` VALUES ('0071', 'TAS SERUT MINI', '7083', '7791', '0');
INSERT INTO `tbbarang` VALUES ('0072', 'TAS SERUT POLOS', '6250', '6875', '0');
INSERT INTO `tbbarang` VALUES ('0073', 'TAS RANSEL', '6250', '6875', '0');
INSERT INTO `tbbarang` VALUES ('749921005953', 'NUTRI SARI', '6350', '7302', '0');
INSERT INTO `tbbarang` VALUES ('749921006523', 'NUTRI SARI HI-C', '7860', '9039', '0');
INSERT INTO `tbbarang` VALUES ('76164217', 'Marlboro', '8000', '8000', '0');
INSERT INTO `tbbarang` VALUES ('8992772233064', 'Vegeta', '3500', '4025', '0');
INSERT INTO `tbbarang` VALUES ('8992775204023', 'GARUDA KACANG ATOM', '400', '460', '0');
INSERT INTO `tbbarang` VALUES ('8992775316108', 'Gery Bismart', '430', '494', '0');
INSERT INTO `tbbarang` VALUES ('8992780227611', '2Tang', '420', '483', '0');
INSERT INTO `tbbarang` VALUES ('8993175531863', 'NABATI WAFER KRIM KEJU', '360', '414', '0');
INSERT INTO `tbbarang` VALUES ('8993989311699', 'CLAS MILD 16', '6500', '7475', '0');
INSERT INTO `tbbarang` VALUES ('8995077601361', 'PILUS TICTAC', '400', '460', '0');
INSERT INTO `tbbarang` VALUES ('8997035111110', 'Pocari Sweat', '3900', '4485', '0');
INSERT INTO `tbbarang` VALUES ('8998009010590', 'ULTRA MILK', '920', '1058', '0');
INSERT INTO `tbbarang` VALUES ('8998685057308', 'FROZZ RASA BLUEBERRY MINT', '3580', '4117', '0');
INSERT INTO `tbbarang` VALUES ('8998899004105', 'Autan', '600', '494', '0');
INSERT INTO `tbbarang` VALUES ('8999909028234', 'Dji Sam Soe 12', '8200', '9430', '0');
INSERT INTO `tbbarang` VALUES ('8999909096004', 'Sampoerna Mild 16', '8900', '9890', '0');
INSERT INTO `tbbarang` VALUES ('8999999701383', 'Rexona MEN', '6800', '7820', '0');
