<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
    include "../../config/koneksi.php";
  include "../../config/library.php";
  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  
  
  $locker_no = htmlentities($_POST['locker_no']);

  // Input lokasi
  if ($module=='locker' AND $act=='input'){
  	        mysqli_query($conn, "INSERT INTO locker
                                VALUES('','$locker_no',
					'$_POST[locker_loc]','$_POST[emp1]','$_POST[emp2]','$_POST[status]')");
     header('location:../../index.php?module=locker&act=view_create');
            
  }
  
  // Update lokasi  
  elseif ($module=='locker' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE locker SET  locker_no = '$locker_no',
					locker_loc = '$_POST[locker_loc]',   
					emp1 = '$_POST[emp1]', emp2 = '$_POST[emp2]', 
					status = '$_POST[status]'   					
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=locker&act=view_detaillocker&id='.$_POST['id']);
  }
  elseif ($module=='locker' AND $act=='update2'){ 
          
    mysqli_query($conn, "UPDATE locker SET  locker_no = '$locker_no',
					locker_loc = '$_POST[locker_loc]',   
					emp1 = '$_POST[emp1]', emp2 = '$_POST[emp2]', 
					status = '$_POST[status]'   					
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=locker&act=view_create');
  }
  
    
  // Delete lokasi  
  elseif ($module=='locker' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM locker WHERE id = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  } 
  elseif ($module=='locker' AND $act=='delete2'){
            
      mysqli_query($conn, "DELETE FROM locker WHERE id = '$_GET[id]'");
     header('location:../../index.php?module=locker&act=view_create');
            
  } 
  else if ($module=='locker' AND $act=='inputstatus'){
  	        mysqli_query($conn, "INSERT INTO status
                                VALUES('$_POST[status]',
					'$_POST[remarks]')");
     header('location:../../index.php?module=locker&act=datastatus');
            
  }
   else if ($module=='locker' AND $act=='inputlocation'){
  	        mysqli_query($conn, "INSERT INTO locker_loc
                                VALUES('$_POST[locker_loc]',
					'$_POST[remarks]')");
     header('location:../../index.php?module=locker&act=datalocation');
            
  }
  elseif ($module=='locker' AND $act=='updatestatus'){ 
          
    mysqli_query($conn, "UPDATE status SET  status = '$_POST[status]',
					remarks = '$_POST[remarks]'   
									
                          WHERE status = '$_POST[id]'");
    
    header('location:../../index.php?module=locker&act=datastatus');
  } 
  elseif ($module=='locker' AND $act=='updatelocation'){ 
          
    mysqli_query($conn, "UPDATE locker_loc SET  locker_loc = '$_POST[locker_loc]',
					remarks = '$_POST[remarks]'   
									
                          WHERE locker_loc = '$_POST[id]'");
    
    header('location:../../index.php?module=locker&act=datalocation');
  } 
   elseif ($module=='locker' AND $act=='deletestatus'){
            
      mysqli_query($conn, "DELETE FROM status WHERE status = '$_GET[id]'");
    header('location:../../index.php?module=locker&act=datastatus');
            
  } 
  elseif ($module=='locker' AND $act=='deletelocation'){
            
      mysqli_query($conn, "DELETE FROM locker_loc WHERE locker_loc = '$_GET[id]'");
    header('location:../../index.php?module=locker&act=datalocation');
            
  }
  else if ($module=='locker' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE locker";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      
		$emp1           = $data->val($i, 2);
        $loc_no           = $data->val($i, 3);
		$emp2           = $data->val($i, 4);
		$status           = $data->val($i, 5);
		$loc           = $data->val($i, 6);
		//$empname= mysql_real_escape_string($name);
     // $joindate           = $data->val($i, 3);
      //$supervisor           = $data->val($i, 4);
      
     
//      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into locker values('','$loc_no','$loc','$emp1','$emp2','$status')";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=locker&act=view_create');
  }
  
  }
?>
