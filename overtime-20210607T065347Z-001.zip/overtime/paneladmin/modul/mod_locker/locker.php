<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
  
  	 
    if (form.locker_no.value ==""){
       alert("Locker No is Still Empty"); 
        form.locker_no.focus();               
       return (false);
   }
    if (form.locker_loc.value ==""){
       alert("Locker Loc is Still Empty");   
        form.locker_loc.focus();             
       return (false);
   }
    if (form.status.value ==""){
       alert("Status is Still Empty");   
        form.status.focus();             
       return (false);
   }
   
   return (true);
}
</script>

<?php
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>To Acces the program, you need to login first!  <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_locker/aksi_locker.php";
switch(@$_GET['act']){

default:
echo "
<h2>Find / Check Locker : </h2> 
<p>&nbsp;</p>
<form method=POST action='?module=locker&act=find_lock' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>Locker No</td><td>: <input type='text' id='' name='locker_no' size='30'></td> <td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Employee 1</th><th>Locker No</th><th>Employee 2</th>
<th>Status</th><th>Location</th><th >Action</th></tr></thead><tbody>";
//paging
$tampil=mysqli_query($conn, "SELECT * from locker order by locker_no limit 200");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
$em1=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp1]'");	
$r1=mysqli_fetch_array($em1);
$em2=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp2]'");	
$r2=mysqli_fetch_array($em2);
  echo "<tr><td>$no.</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp1]' target=_blank>$r[emp1] $r1[empname]</a></td>
      
		<td><a href='?module=locker&act=editlocker&id=$r[id]' target=_blank>$r[locker_no]</a></td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp2]' target=_blank>$r[emp2] $r2[empname]</a></td>
      
		<td><a href='?module=locker&act=datastatus' target=_blank>$r[status]</a></td>
		<td><a href='?module=locker&act=datalocation' target=_blank>$r[locker_loc]</a></td>
        <td><a href='?module=locker&act=editlocker&id=$r[id]' target=_blank>Edit</a> | <a href=javascript:confirmdelete('$aksi?module=locker&act=delete&id=$r[id]')>Delete</a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;



case "find_lock":
echo "

<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Employee 1</th><th>Locker No</th><th>Employee 2</th>
<th>Status</th><th>Location</th><th >Action</th></tr></thead><tbody>";
//paging
$tampil=mysqli_query($conn, "SELECT * from locker where locker_no='$_POST[locker_no]'");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
$em1=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp1]'");	
$r1=mysqli_fetch_array($em1);
$em2=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp2]'");	
$r2=mysqli_fetch_array($em2);
  echo "<tr><td>$no.</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp1]' target=_blank>$r[emp1] $r1[empname]</a></td>
      
		<td><a href='?module=locker&act=editlocker&id=$r[id]' target=_blank>$r[locker_no]</a></td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp2]' target=_blank>$r[emp2] $r2[empname]</a></td>
      
		<td><a href='?module=locker&act=datastatus' target=_blank>$r[status]</a></td>
		<td><a href='?module=locker&act=datalocation' target=_blank>$r[locker_loc]</a></td>
        <td><a href='?module=locker&act=editlocker&id=$r[id]' target=_blank>Edit</a> | <a href=javascript:confirmdelete('$aksi?module=locker&act=delete&id=$r[id]')>Delete</a>
        </td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "view_create":
echo "<input type=button value='Add New Locker One by One' class='large blue super button' 
onclick=\"window.location.href='?module=locker&act=tambahlocker';\"> 
<input type=button value='Import Data Locker from Excel' class='large orange super button' 
onclick=\"window.location.href='?module=locker&act=import';\"><p>&nbsp;</p>
<h2>The Lastest 100 Locker Data </h2> <p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Employee 1</th><th>Locker No</th><th>Employee 2</th>
<th>Status</th><th>Location</th><th >Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * from locker order by id desc limit 100 ");
$no=$posisi+1;
while ($r=mysqli_fetch_array($tampil)){
$em1=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp1]'");	
$r1=mysqli_fetch_array($em1);
$em2=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp2]'");	
$r2=mysqli_fetch_array($em2);
  echo "<tr><td>$no.</td>
		<td>$r[emp1] $r1[empname]</td>
      
		<td><a href='?module=locker&act=editlocker2&id=$r[id]'>$r[locker_no]</a></td>
		<td>$r[emp2] $r2[empname]</td>
      
		<td>$r[status]</td>
		<td>$r[locker_loc]</td>
		 <td><a href=javascript:confirmdelete('$aksi?module=locker&act=delete2&id=$r[id]')>Delete</a>
        </td>
       </tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "view_lockeruser":
echo "
<h2>Find / Check Locker : </h2> 
<p>&nbsp;</p>
<form method=POST action='?module=locker&act=find_lock2' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>Locker No</td><td>: <input type='text' id='' name='locker_no' size='30'></td> <td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Employee 1</th><th>Locker No</th><th>Employee 2</th>
<th>Status</th><th>Location</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * from locker order by locker_no limit 200");
$no=$posisi+1;
while ($r=mysqli_fetch_array($tampil)){
$em1=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp1]'");	
$r1=mysqli_fetch_array($em1);
$em2=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp2]'");	
$r2=mysqli_fetch_array($em2);
  echo "<tr><td>$no.</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp1]'>$r[emp1] $r1[empname]</a></td>
      
		<td>$r[locker_no]</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp2]'>$r[emp2] $r2[empname]</a></td>
      
		<td>$r[status]</td>
		<td>$r[locker_loc]</td>
      </tr>";
  $no++;
}
echo "</tbody></table>";

break;



case "find_lock2":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Employee 1</th><th>Locker No</th><th>Employee 2</th>
<th>Status</th><th>Location</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * from locker where locker_no ='$_POST[locker_no]'");
$no=$posisi+1;
while ($r=mysqli_fetch_array($tampil)){
$em1=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp1]'");	
$r1=mysqli_fetch_array($em1);
$em2=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp2]'");	
$r2=mysqli_fetch_array($em2);
  echo "<tr><td>$no.</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp1]'>$r[emp1] $r1[empname]</a></td>
      
		<td>$r[locker_no]</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp2]'>$r[emp2] $r2[empname]</a></td>
      
		<td>$r[status]</td>
		<td>$r[locker_loc]</td>
      </tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "view_detaillocker":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Employee 1</th><th>Locker No</th><th>Employee 2</th>
<th>Status</th><th>Location</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT * from locker where id=$_GET[id] ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
$em1=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp1]'");	
$r1=mysqli_fetch_array($em1);
$em2=mysqli_query($conn, "SELECT empname  from employee where empno= '$r[emp2]'");	
$r2=mysqli_fetch_array($em2);
  echo "<tr><td>$no.</td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp1]'>$r[emp1] $r1[empname]</a></td>
      
		<td><a href='?module=locker&act=editlocker&id=$r[id]'>$r[locker_no]</a></td>
		<td><a href='?module=locker&act=detailemp&id=$r[emp2]'>$r[emp2] $r2[empname]</a></td>
      
		<td>$r[status]</td>
		<td>$r[locker_loc]</td>
      </tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "datastatus":
echo "<h2>Status Locker</h2>
<p>&nbsp;</p>
<input type=button value='Add New Status' class='large blue super button' 
onclick=\"window.location.href='?module=locker&act=tambahstatus';\"><p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Status</th><th>Remarks</th><th colspan=2>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT *from status order by status");
$no=$posisi+1;
while ($r=mysqli_fetch_array($tampil)){

  echo "<tr><td>$no.</td>
	
		<td>$r[status]</td>
		<td>$r[remarks]</td>
        <td><a href='?module=locker&act=editstatus&id=$r[status]'>Edit</a> |
		<a href=javascript:confirmdelete('$aksi?module=locker&act=deletestatus&id=$r[status]')>Delete</a>
        </td><td></td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "datalocation":
echo "<h2>Location</h2>
<p>&nbsp;</p>
<input type=button value='Add New Location' class='large blue super button' 
onclick=\"window.location.href='?module=locker&act=tambahlocation';\"><p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Location</th><th>Remarks</th><th colspan=2>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT *from locker_loc order by locker_loc");
$no=$posisi+1;
while ($r=mysqli_fetch_array($tampil)){

  echo "<tr><td>$no.</td>
	
		<td>$r[locker_loc]</td>
		<td>$r[remarks]</td>
        <td><a href='?module=locker&act=editlocation&id=$r[locker_loc]'>Edit</a> |
		<a href=javascript:confirmdelete('$aksi?module=locker&act=deletelocation&id=$r[locker_loc]')>Delete</a>
        </td><td></td></tr>";
  $no++;
}
echo "</tbody></table>";

break;

case "tambahstatus":
echo "<h2>Add New Status</h2>
<form method=POST action='$aksi?module=locker&act=inputstatus'  onsubmit='return validasistatus(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Status ID</td><td>: <input type='text' name='status' size='20' value='' ></td></tr>                
<tr><td>Remarks</td><td>: <input type='text' name='remarks' size='60' value='' ></td></tr>         
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;
case "tambahlocation":
echo "<h2>Add New Location</h2>
<form method=POST action='$aksi?module=locker&act=inputlocation'  onsubmit='return validasilocation(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Location ID</td><td>: <input type='text' name='locker_loc' size='20' value='' ></td></tr>                
<tr><td>Remarks</td><td>: <input type='text' name='remarks' size='60' value='' ></td></tr>         
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "editstatus":
$edit = mysqli_query($conn, "SELECT * FROM status WHERE status='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Edit Status</h2>
<form method=POST action='$aksi?module=locker&act=updatestatus'  onsubmit='return validasistatus(this)'>
<input type='hidden' name='id' size='20' value='$_GET[id]' >
<table cellspacing=10 cellpadding=6>
<tr><td>Status ID</td><td>: <input type='text' name='status' size='20' value='$r[status]' ></td></tr>                
<tr><td>Remarks</td><td>: <input type='text' name='remarks' size='60' value='$r[remarks]' ></td></tr>         
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "editlocation":
$edit = mysqli_query($conn, "SELECT * FROM locker_loc WHERE locker_loc='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Edit Location</h2>
<form method=POST action='$aksi?module=locker&act=updatelocation'  onsubmit='return validasilocation(this)'>
<input type='hidden' name='id' size='20' value='$_GET[id]' >
<table cellspacing=10 cellpadding=6>
<tr><td>Location ID</td><td>: <input type='text' name='locker_loc' size='20' value='$r[locker_loc]' ></td></tr>                
<tr><td>Remarks</td><td>: <input type='text' name='remarks' size='60' value='$r[remarks]' ></td></tr>         
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;
// Form Tambah locker
case "tambahlocker":
echo "<h2>Add New Locker</h2>
<form method=POST action='$aksi?module=locker&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Locker No</td><td>: <input type='text' name='locker_no' size='20' value='' ></td></tr>                
<tr><td>Location</td><td>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM locker_loc ");
echo "<select name='locker_loc'>
<option value='' selected>--Choose Location--</option>
      ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
 echo "<option value='$r_combobox4[locker_loc]'> $r_combobox4[remarks]</option>";
}
echo "</select></td></tr>   
<tr><td>Status</td><td>: ";
$sql_combobox5 = mysqli_query($conn, "SELECT * FROM status ");
echo "<select name='status'>
 <option value='' selected>--Choose Status--</option>
      ";
while ($r_combobox5=mysqli_fetch_array($sql_combobox5)){
 echo "<option value='$r_combobox5[status]'> $r_combobox5[remarks]</option>";
}
echo "</select> </td></tr>          
";
include "emp1.php";
include "emp2.php";
echo "

<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit locker 
case "editlocker":
$edit = mysqli_query($conn, "SELECT * FROM locker WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Locker</h2>
<form method=POST action='$aksi?module=locker&act=update'  onsubmit='return validasi(this)'>
<input type='hidden' name='id' size='20' value='$_GET[id]' >
<table cellspacing=10 cellpadding=6>
<tr><td>Locker No</td><td>: <input type='text' name='locker_no' size='20' value='$r[locker_no]' ></td></tr>                
<tr><td>Location</td><td>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM locker_loc");
echo "<select name='locker_loc'>
<option value=''>--Choose Location--</option>
      ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
 if ($r['locker_loc'] == $r_combobox4['locker_loc']){
     echo "<option value='$r_combobox4[locker_loc]' selected>$r_combobox4[remarks]</option>";
 }
 else {
     echo "<option value='$r_combobox4[locker_loc]'>$r_combobox4[remarks]</option>";
 }
}
echo "</select></td></tr> 
<tr><td>Status</td><td>: ";
$sql_combobox5 = mysqli_query($conn, "SELECT * FROM status");
echo "<select name='status'>
<option value='' >--Choose Status--</option>
      ";
while ($r_combobox5=mysqli_fetch_array($sql_combobox5)){
 if ($r['status'] == $r_combobox5['status']){
     echo "<option value='$r_combobox5[status]' selected>$r_combobox5[remarks]</option>";
 }
 else {
     echo "<option value='$r_combobox5[status]'>$r_combobox5[remarks]</option>";
 }
}
echo "</select></td></tr> ";
include "emp1edit.php";
include "emp2edit.php";
echo "

<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "editlocker2":
$edit = mysqli_query($conn, "SELECT * FROM locker WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Locker</h2>
<form method=POST action='$aksi?module=locker&act=update2'  onsubmit='return validasi(this)'>
<input type='hidden' name='id' size='20' value='$_GET[id]' >
<table cellspacing=10 cellpadding=6>
<tr><td>Locker No</td><td>: <input type='text' name='locker_no' size='20' value='$r[locker_no]' ></td></tr>                
<tr><td>Location</td><td>: ";
$sql_combobox4 = mysqli_query($conn, "SELECT * FROM locker_loc");
echo "<select name='locker_loc'>
<option value=''>--Choose Location--</option>
      ";
while ($r_combobox4=mysqli_fetch_array($sql_combobox4)){
 if ($r['locker_loc'] == $r_combobox4['locker_loc']){
     echo "<option value='$r_combobox4[locker_loc]' selected>$r_combobox4[remarks]</option>";
 }
 else {
     echo "<option value='$r_combobox4[locker_loc]'>$r_combobox4[remarks]</option>";
 }
}
echo "</select></td></tr> 
<tr><td>Status</td><td>: ";
$sql_combobox5 = mysqli_query($conn, "SELECT * FROM status");
echo "<select name='status'>
<option value='' >--Choose Status--</option>
      ";
while ($r_combobox5=mysqli_fetch_array($sql_combobox5)){
 if ($r['status'] == $r_combobox5['status']){
     echo "<option value='$r_combobox5[status]' selected>$r_combobox5[remarks]</option>";
 }
 else {
     echo "<option value='$r_combobox5[status]'>$r_combobox5[remarks]</option>";
 }
}
echo "</select></td></tr> ";
include "emp1edit.php";
include "emp2edit.php";
echo "

<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel  class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;


case "import":
echo "
<h2>Import Data Locker</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=locker&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>

<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2..
  </small></i></strong></td></tr>
<tr><td colspan=2><img src='images/ex_locker.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

case "importadmin":
echo "
<h2>Import Data Locker</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=locker&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all Old Locker Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2..
  </small></i></strong></td></tr>
<tr><td colspan=2><img src='images/ex_locker.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>

<p>&nbsp;</p><input type=button value='Add New Locker One By One' class='large blue super button' 
onclick=\"window.location.href='?module=locker&act=tambahlocker';\"><p>&nbsp;</p>";

break;

case "detailemp":
$edit = mysqli_query($conn, "SELECT e.empno, e.empname, sc.section  FROM employee e, sectioncode sc WHERE e.sectioncode=sc.id and e.empno='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Detail Employee</h2>
<table cellspacing=10 cellpadding=6 >
                                                  
<tr><td>Emp No</td><td>: <input type='text' name='empno' size='20' value='$r[empno]' ></td></tr>                
<tr><td>Emp Name</td><td>: <input type='text' name='empname' size='60' value='$r[empname]'></td></tr>  
<tr><td>Section Code</td><td>: <input type='text' name='section' size='100' value='$r[section]'></td></tr>  
<tr><td><input type=button value=Back class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
}
?>
