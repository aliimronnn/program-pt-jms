<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";
  include "../../config/library.php";
  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  $sectioncode = htmlentities(@$_POST['sectioncode']);
  
  $empno = htmlentities(@$_POST['empno']);
  $empname = htmlentities(@$_POST['empname']);
 // $datejoin = htmlentities($_POST['datejoin']);
 // $joindate=$_POST['bln_joindate'].'/'.$_POST['tgl_joindate'].'/'.$_POST['thn_joindate'];
  $hrempno = htmlentities(@$_POST['hrempno']);
  $hrempname = htmlentities(@$_POST['hrempname']);
  $hrgender = htmlentities(@$_POST['hrgender']);
  $hrposition = htmlentities(@$_POST['hrposition']);
  $supervisor = htmlentities(@$_POST['supervisor_no']);
  

  // Input employee
  if ($module=='employee' AND $act=='input'){
       
  $qcek  = mysqli_query($conn, "select * from employee where empno='$_POST[empno]'");
  $cek= mysqli_fetch_array($qcek);
  if (empty($cek)) {
	  mysqli_query($conn, "INSERT INTO employee(sectioncode, empno, empname) VALUES('$sectioncode', '$empno', UPPER('$empname'))");
		 } 				
	else {
    echo "<a href=../../index.php?module=employee><b>Back</b></a></center>";
      die ("<center>FAILED! <br>
        Sorry, employee data already exists and cannot be the same.!<br>");   				
	}
     header('location:../../index.php?module='.$module);
            
  } else if ($module=='employee' AND $act=='inputuser'){
  	   //    $qcek  = mysql_query("select *from employee where empname='$_POST[empname]'");
  //  $cek= mysql_fetch_array($qcek);
   //  if (empty($cek)) {
  	        mysqli_query($conn, "INSERT INTO employee(sectioncode,				
					empno,
					empname)VALUES('$sectioncode',
					'$empno',
					UPPER('$empname'))"); 
					// } 
					//else {
						
					//	die("Maaf, nama karyawan sudah ada dan tidak boleh sama.");
				//	}
     header('location:../../index.php?module=employee&act=employeeuser');
            
  }
  
  // Update employee  
  else if ($module=='employee' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE employee SET  sectioncode = '$sectioncode',	
					empno = '$empno',
					empname = upper('$empname')                                       
    WHERE empno = '$_POST[id]'"); 
    header('location:../../index.php?module='.$module);
  } else if ($module=='employee' AND $act=='updateuser'){         
    mysqli_query($conn, "UPDATE employee SET  sectioncode = '$sectioncode',				
					empno = '$empno',
					empname = upper('$empname')                                     
    WHERE empno = '$_POST[id]'");
    header('location:../../index.php?module=employee&act=employeeuser');
  }
    
  // Delete employee  
  elseif ($module=='employee' AND $act=='delete'){            
      mysqli_query($conn, "DELETE FROM employee WHERE empno = '$_GET[id]'");
      header('location:../../index.php?module='.$module);

  } elseif ($module=='employee' AND $act=='deleteuser'){            
      mysqli_query($conn, "DELETE FROM employee WHERE empno = '$_GET[id]'");
      header('location:../../index.php?module=employee&act=employeeuser');            
  }  
else if ($module=='employee' AND $act=='import'){         
  require "../../excel_reader.php";

    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
    $baris = $data->rowcount($sheet_index=0);
    
    if($_POST['drop']==1){
      $truncate ="TRUNCATE TABLE employee";
      mysqli_query($truncate);
    };
    
    for ($i=2; $i<=$baris; $i++)
    {
      
      $empno      = $data->val($i, 1);
      $name       = $data->val($i, 2);
      $section    = $data->val($i, 3);
      
      $query = "INSERT into employee values('$section','$empno',Upper('$name'))";
      $hasil = mysqli_query($conn, $query);
    }

    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=employee&act=employee');
  }
else if ($module=='employee' AND $act=='importsql'){       
    require "../../excel_reader.php";

    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
    $baris = $data->rowcount($sheet_index=0);

    if($_POST['drop']==1){
        $truncate ="TRUNCATE TABLE employee";
        mysqli_query($truncate);
    };

    for ($i=2; $i<=$baris; $i++)
    {
      
      $empno     = $data->val($i, 2);
      $name      = $data->val($i, 3);
      $section   = $data->val($i, 4);
     
      $query = "INSERT into employee  values('$section','$empno',upper('$name'))";
      $hasil = mysqli_query($conn, $query);
    }
    
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=employee&act=employee');
  }

else if ($module=='employee' AND $act=='importhrd'){           
  require "../../excel_reader.php";

    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
    $baris = $data->rowcount($sheet_index=0);
    
    if($_POST['drop']==1){
             $truncate ="TRUNCATE TABLE employee";
             mysqli_query($truncate);
    };
    
    for ($i=2; $i<=$baris; $i++)
    {     
      $empno      = $data->val($i, 1);
      $name       = $data->val($i, 2);
      $empname    = mysqli_real_escape_string($name);
      $section    = $data->val($i, 3);
     
      $query = "INSERT into employee values('$section','$empno',upper('$empname'))";
      $hasil = mysqli_query($conn, $query);
    }
    
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=employee&act=employee');
  }
  
else if ($module=='employee' AND $act=='importuser'){         
  require "../../excel_reader.php";

    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
    $baris = $data->rowcount($sheet_index=0);
    
    for ($i=2; $i<=$baris; $i++)
    {
      $empno       = $data->val($i, 1);
      $name        = $data->val($i, 2);
      $section     = $data->val($i, 3);

      $query = "INSERT into employee values('$section','$empno',Upper('$name'))";
      $hasil = mysqli_query($conn, $query);
    }
    
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=employee&act=employeeuser');
  }
  }
?>
