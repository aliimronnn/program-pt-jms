<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
//    validasi form (hanya file .xls yang diijinkan)
    function validateForm()
    {
        function hasExtension(inputID, exts) {
            var fileName = document.getElementById(inputID).value;
            return (new RegExp('(' + exts.join('|').replace(/\./g, '\\.') + ')$')).test(fileName);
        }
 
        if(!hasExtension('filepegawaiall', ['.xls'])){
            alert("Sorry..File Excel 97-2003 Only can be imported.");
            return false;
        }
    }
</script>

<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.hrempno.value.length < mincar){
       alert("hrempno Still Empty!");
       form.hrempno.focus();
       return (false);
   }
   if (form.hrempname.value.length < mincar){
       alert("hrempname Still Empty!");
       form.hrempname.focus();
       return (false);
   }
   if (form.hrgender.value.length < mincar){
       alert("hrgender Still Empty!");
       form.hrgender.focus();
       return (false);
   }
   if (form.hrposition.value.length < mincar){
       alert("hrposition Still Empty!");
       form.hrposition.focus();
       return (false);
   }
   if (form.hrstatus.value.length < mincar){
       alert("hrstatus Still Empty!");
       form.hrstatus.focus();
       return (false);
   }
   if (form.status.value.length < mincar){
       alert("status Still Empty!");
       form.status.focus();
       return (false);
   }
   
   return (true);
}
</script>

<?php
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>To Acces the program, you need to login first! <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{

$aksi="modul/mod_employee/aksi_employee.php";
switch(@$_GET['act']){

default:
echo "<h2>Find Employee</h2>

<form action='?module=employee&act=view_emp' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
";
include "employee1.php";

echo "<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=View Employee></td></tr></table>
<p>&nbsp;</p>
<input type=button value='Add New Employee' class='large blue super button' 
onclick=\"window.location.href='?module=employee&act=tambahemployee';\">
<input type=button value='Import Employee Data' class='large orange super button' 
onclick=\"window.location.href='?module=employee&act=importemployee';\">
<input type=button value='Import Employee From SQL Excel' class='large orange super button' 
onclick=\"window.location.href='?module=employee&act=importemployeesql';\">

<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th>
<th>Emp No.</th><th>Emp Name</th><th>Section</th><th width=100>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT e.*, sc.section FROM employee e, sectioncode sc where e.sectioncode=sc.id order by e.sectioncode limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	//$sect=mysql_query("SELECT section from sectioncode  where id='$r[sectioncode]' ");
	//$s=mysql_fetch_array($sect);
	//$sup=mysql_query("SELECT empname from employee  where empno='$r[supervisor]' ");
	//$sp=mysql_fetch_array($sup);
  echo "<tr><td>$no.</td>
	<td>$r[empno]</td>
      	<td>$r[empname]</td>
      	<td>$r[sectioncode]/$r[section]</td>
      
       <td><a href='?module=employee&act=editemployee&id=$r[empno]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=employee&act=delete&id=$r[empno]')><img src='images/hapus.png' alt='hapus' /></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table >";

break;
case "view_emp":
echo "<h2>List Employee</h2>

<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th>
<th>Emp No.</th><th>Emp Name</th><th>Section</th><th width=100>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT e.*, sc.section FROM employee e, sectioncode sc where e.sectioncode=sc.id and e.empno='$_POST[empno]'");
$r=mysqli_fetch_array($tampil);
	
  echo "<tr><td>1.</td>
	<td>$r[empno]</td>
      	<td>$r[empname]</td>
      	<td>$r[sectioncode]/$r[section]</td>
      
       <td><a href='?module=employee&act=editemployee&id=$r[empno]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=employee&act=delete&id=$r[empno]')><img src='images/hapus.png' alt='hapus' /></a>
        </td></tr></tbody></table >";

break;
//modul/mod_employee/import.php
//
case "importemployee2":

echo "<h2>Import Employee Data</h2><p>&nbsp;</p
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=employee&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>Excel File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old Employee Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2><img src='images/empuser.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;
case "importemployee":

echo "<h2>Import Employee Data</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=employee&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old Employee Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2..
  </small></i></strong></td></tr>
<tr><td colspan=2><img src='images/empuser.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

case "importemployeesql":

echo "<h2>Import Employee From Data Excel SQL</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=employee&act=importsql' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old Employee Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2,D2... </br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Format Data Excel Must not be changed!</small></i></strong></td></tr>
<tr><td colspan=2><img src='images/empuser3.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

case "importemployeehrd":

echo "<h2>Import Employee From Data HRD</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=employee&act=importhrd' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old Employee Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2,D2... </br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Format Data Excel Must not be changed!</small></i></strong></td></tr>
<tr><td colspan=2><img src='images/empuser4.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

case "importemployeeuser":

echo "<h2>Import Employee Data On Section</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=employee&act=importuser' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>Excel File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003!  <i></small></strong></td></tr>
<tr><td colspan=2></br>Sample of Excel Format File:  </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2.. </br>
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Section Code will be automatic based on User Login</small></i></strong></td></tr>
<tr><td colspan=2><img src='images/empuser.png' alt='edit' /></td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

case "view_empuser":
echo "<h2>List Employee</h2>

<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th>
<th>Emp No.</th><th>Emp Name</th><th>Section</th><th width=100>Action</th></tr></thead><tbody>";

//paging

$tampil=mysqli_query($conn, "SELECT e.*, sc.section FROM employee e, sectioncode sc where e.sectioncode=sc.id and e.empno='$_POST[empno]'");
$r=mysqli_fetch_array($tampil);
	
  echo "<tr><td>1.</td>
	<td>$r[empno]</td>
      	<td>$r[empname]</td>
      	<td>$r[sectioncode]/$r[section]</td>
      
       <td><a href='?module=employee&act=editempuser&id=$r[empno]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=employee&act=delete&id=$r[empno]')><img src='images/hapus.png' alt='hapus' /></a>
        </td></tr></tbody></table >";

break;
case "employeeuser":
echo "<h2>Find Employee</h2>
<form action='?module=employee&act=view_empuser' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
";
include "employee1.php";

echo "<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=View Employee></td></tr></table>
<p>&nbsp;</p>
<input type=button value='Add New Employee' class='large blue super button' 
onclick=\"window.location.href='?module=employee&act=tambahemployeeuser';\">
<input type=button value='Import Employee Data' class='large blue super button' 
onclick=\"window.location.href='?module=employee&act=importemployeeuser';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'><thead>
<tr><th>No</th>
<th>Emp No.</th><th>Emp Name</th><th>Section</th><th width=100>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT e.*, s.section FROM employee e, sectioncode s where e.sectioncode=s.id and s.id='$_SESSION[section]' ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	//$sup=mysql_query("SELECT empname from employee  where empno='$r[supervisor]' ");
	//$sp=mysql_fetch_array($sup);
  echo "<tr><td>$no.</td>
	<td>$r[empno]</td>
      	<td>$r[empname]</td>
      	<td>$r[sectioncode]/$r[section]</td>
      	  
      	
           	
        <td><a href='?module=employee&act=editemployeeuser&id=$r[empno]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=employee&act=deleteuser&id=$r[empno]')><img src='images/hapus.png' alt='hapus' /></a>
        </td></tr>";
  $no++;
}
echo "</tbody></table >";

break;

// Form Tambah employee
case "tambahemployee":
echo "<h2>Add New Employee</h2>
<form method=POST action='$aksi?module=employee&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<tr><td>Section Code</td><td> : ";
$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='sectioncode'>
      <option value='pilih' selected>--Pilih--</option>";
while ($r_combobox2=mysqli_fetch_array($sql_combobox2)){
 echo "<option value='$r_combobox2[id]'>$r_combobox2[id] $r_combobox2[section]</option>";
}
echo "</select></td></tr>

<tr><td>Emp No</td><td>: <input type='text' name='empno' size='20' value='' ></td></tr>                
<tr><td>Emp Name</td><td>: <input type='text' name='empname' size='60' value='' ></td></tr>                

<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Save>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;
/**
* 
* @var 
* <tr><td>Join Date</td><td>: ";
combotgl(1,31,'tgl_joindate',$tgl_skrg);
combobln(1,12,'bln_joindate',$bln_sekarang);
combothn(1900,$thn_sekarang,'thn_joindate',$thn_sekarang); 
echo"</td></tr>";

include "supervisor.php";
echo "               
* 
*/

case "tambahemployeeuser":
echo "<h2>Add New Employee</h2>
<p>&nbsp;</p>
<form method=POST action='$aksi?module=employee&act=inputuser'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
<input type='hidden' name='sectioncode' size='20' value='$_SESSION[section]' >";

$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode where id='$_SESSION[section]'");
$r_combobox2=mysqli_fetch_array($sql_combobox2);
echo "
<tr><td>Section </td><td>: <input type='text' name='namasection' size='20' value='$r_combobox2[section]' readonly ></td></tr> 
<tr><td>Emp No</td><td>: <input type='text' name='empno' size='20' value='' ></td></tr>                
<tr><td>Emp Name</td><td>: <input type='text' name='empname' size='60' value='' > </td></tr>                

<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Save>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;
// Form Edit employee 
case "editemployee":
$edit = mysqli_query($conn, "SELECT * FROM employee WHERE empno='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Employee</h2>
<form method=POST action='$aksi?module=employee&act=update'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6 >
<tr><td>Section Code</td><td>: ";
$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='sectioncode'>
      <option value='pilih'>--Pilih--</option>";
while ($r_combobox2=mysqli_fetch_array($sql_combobox2)){
 if ($r['sectioncode'] == $r_combobox2['id']){
     echo "<option value='$r_combobox2[id]' selected>$r_combobox2[id] / $r_combobox2[section]</option>";
 }
 else {
     echo "<option value='$r_combobox2[id]'>$r_combobox2[id] / $r_combobox2[section]</option>";
 }
}
echo "</select></td></tr>

<input type='hidden' name='id' size='20' value='$r[empno]' >                                                     
<tr><td>Emp No</td><td>: <input type='text' name='empno' size='20' value='$r[empno]' ></td></tr>                
<tr><td>Emp Name</td><td>: <input type='text' name='empname' size='60' value='$r[empname]'></td></tr>  

<tr><td colspan=2><input type=submit class='large blue super button' value=Update>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "editempuser":
$edit = mysqli_query($conn, "SELECT * FROM employee WHERE empno='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Employee</h2>
<form method=POST action='$aksi?module=employee&act=updateuser'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6 >
<tr><td>Section Code</td><td>: ";
$sql_combobox2 = mysqli_query($conn, "SELECT * FROM sectioncode");
echo "<select name='sectioncode'>
      <option value='pilih'>--Choose--</option>";
while ($r_combobox2=mysqli_fetch_array($sql_combobox2)){
 if ($r['sectioncode'] == $r_combobox2['id']){
     echo "<option value='$r_combobox2[id]' selected>$r_combobox2[id] / $r_combobox2[section]</option>";
 }
 else {
     echo "<option value='$r_combobox2[id]'>$r_combobox2[id] / $r_combobox2[section]</option>";
 }
}
echo "</select></td></tr>

<input type='hidden' name='id' size='20' value='$r[empno]' >                                                     
<tr><td>Emp No</td><td>: <input type='text' name='empno' size='20' value='$r[empno]' ></td></tr>                
<tr><td>Emp Name</td><td>: <input type='text' name='empname' size='60' value='$r[empname]'></td></tr>  

<tr><td colspan=2><input type=submit class='large blue super button' value=Update>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;

case "editemployeeuser":
$edit = mysqli_query($conn, "SELECT e.*, sc.section FROM employee e, sectioncode sc WHERE e.sectioncode=sc.id and empno='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Edit Employee</h2>
<form method=POST action='$aksi?module=employee&act=updateuser'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6 >

<input type='hidden' name='sectioncode' size='20' value='$r[sectioncode]' > 
<input type='hidden' name='id' size='20' value='$r[empno]' >                                                   <tr><td>Section</td><td>: <input type='text' name='namasection' size='30' value='$r[section]' readonly ></td></tr>  
 
<tr><td>Emp No</td><td>: <input type='text' name='empno' size='20' value='$r[empno]' ></td></tr>                
<tr><td>Emp Name</td><td>: <input type='text' name='empname' size='60' value='$r[empname]' ></td></tr>   

<tr><td colspan=2><input type=submit class='large blue super button' value=Update>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>
</table>
</form>";
break;


}
}
?>
