<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#pelanggan2").autocomplete("supervisor/proses_supervisor.php", {
		width: 300
	});
	
	$("#pelanggan2").result(function(event, data, formatted) {
		var kode3	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode3="+kode3,
			url 	: "supervisor/cari_supervisor.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
				
				$("#kode3").val(data.kode3);
				
			}
		});
	});
	$("#pelanggan2").keyup(function() {
		var kode3	= $('#pelanggan2').val();
		$.ajax({
			type	: "POST",
			data	: "kode3="+kode3,
			url 	: "supervisor/cari_supervisor.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
					$("#kode3").val(data.kode3);
					
			}
		});
	});
	
});
</script>
</head>
<body>
  <?php
  $sql=mysql_query("select *from employee where empno='$r[supervisor]'");
  $k=mysql_fetch_array($sql);
  echo"
  <tr><td colspan='2'> <strong></strong></td></tr>
  <input type='hidden' id='kode3' name='supervisor_no' value='$r[supervisor]'>
 <tr><td>Verified By</td><td>: <input type='text' id='pelanggan2' name='supervisor' size='50' value='$k[empname]'> <small>*) Fill employee Name</small></td></tr>
 ";
  ?>

</body>
</html>
