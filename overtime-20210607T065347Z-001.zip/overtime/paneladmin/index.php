<?php
include "config/koneksi.php";
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])) {
	echo "<link href='config/adminstyle.css' rel='stylesheet' type='text/css'>
	<center>Untuk mengakses aplikasi, Anda harus login <br>";
	echo "<a href=index_login.php><b>LOGIN</b></a></center>";
}
else
{
?>




<html>
<head>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<!-- Aauto Complete -->
<script type="text/javascript" src="js1/jquery-1.4.js"></script>
<script type='text/javascript' src='js1/jquery.autocomplete.js'></script>
<!--[if IE]>
   
<![endif]-->
 <link rel="stylesheet" type="text/css" href="js1/jquery.autocomplete.css" />
	<link rel="stylesheet" href="js1/main.css" type="text/css" />

<!-- End Auto Complete -->

<!-- -->
<script src="lib/jquery.min.js"></script>
<script src="lib/zebra_datepicker.js"></script>
<link rel="stylesheet" href="lib/css/default.css" />
<script>
    $(document).ready(function(){
        $('#tanggal').Zebra_DatePicker({
            format: 'd-F-Y',
            months : ['01','02','03','04','05','06','07','08','09','10','11','12'],
            days : ['Sunday','Monday','Tuesday','Wednesday','Thursday','Saturday','Friday'],
            days_abbr :  ['Sunday','Monday','Tuesday','Wednesday','Thursday','Saturday','Friday']
        });
    });
</script>

<title>JMSB Overtime System</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href="css/reset-min.css" rel="stylesheet" type="text/css" />
<link href="css/adminstyle.css" rel="stylesheet" type="text/css" />


<script language="javascript" type="text/javascript" src="js/jquery.js"></script>
<script language="javascript" type="text/javascript" src="js/jquery.dataTables.js"></script> 
 <script src="tinymcpuk/jscripts/tiny_mce/tiny_mce.js" type="text/javascript"></script>
  <script src="tinymcpuk/jscripts/tiny_mce/tiny_lokomedia.js" type="text/javascript"></script>
<!-- Uji prntabel

<script type="text/javascript" language="javascript" src="js/ZeroClipboard.js"></script>
<script type="text/javascript" language="javascript" src="js/TableTools.js"></script>
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
$('#datatable').dataTable({ 
"sPaginationType": "full_numbers",
"sDom": 'T<"clear">lfrtip',
"oTableTools": {
"sSwfPath": "swf/copy_csv_xls_pdf.swf"
}
});
} );
</script>

 -->
 
 	
<!-- ////////////////////////////////////// -->
	<script src="JQuery-UI-1.8.17.custom/development-bundle/ui/jquery.ui.core.js"></script>
<script src="JQuery-UI-1.8.17.custom/development-bundle/ui/jquery.ui.widget.js"></script>
<script src="JQuery-UI-1.8.17.custom/development-bundle/ui/jquery.ui.datepicker.js"></script>
<script src="JQuery-UI-1.8.17.custom/development-bundle/ui/i18n/jquery.ui.datepicker-id.js"></script>
<script src="JQuery-UI-1.8.17.custom/validationEngine/js/jquery.validationEngine-id.js" type="text/javascript" charset="utf-8"></script>
<script src="JQuery-UI-1.8.17.custom/validationEngine/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.autocomplete.js" type='text/javascript' ></script>
	<script>
function confirmlogout(delUrl) {
   if (confirm("Are you sure to Logout from the system?")) {
      document.location = delUrl;
   }
}
</script>
    <script>
	$(document).ready(function() {
	   $("#kodesurat").focus();
		//FUNGSI AUTO SEARCH
		$("#kodesurat").autocomplete("modul/kodesurat.php", {
			width: 260,
			//matchContains: true,
			//selectFirst: false
			
			
		});
		$(function() {
			$( "#datepicker" ).datepicker( { changeMonth: true,
			changeYear: true,
			dateFormat:'yy-mm-dd'}
			);
		});
		$(function() {
			$( "#datepicker2" ).datepicker( { changeMonth: true,
			changeYear: true,
			dateFormat:'yy-mm-dd'}
			);
		});
		$(function() {
			$( "#datepicker1" ).datepicker({ changeMonth: true,
			changeYear: true,
			dateFormat:'yy-mm-dd'});
		});
		
		
</script>

<!-- //////////////////////////////////////// -->
	
<script type="text/javascript">
$(document).ready(function() {
	/* Formatted numbers sorting */
			$.fn.dataTableExt.oSort['formatted-num-asc'] = function(x,y){
	 			x = parseInt( x.replace(/[^\d\-\.\/]/g,'') );
	 			y = parseInt( y.replace(/[^\d\-\.\/]/g,'') );
				return x - y;
			}
			$.fn.dataTableExt.oSort['formatted-num-desc'] = function(x,y){
	 			x = parseInt( x.replace(/[^\d\-\.\/]/g,'') );
	 			y = parseInt( y.replace(/[^\d\-\.\/]/g,'') );
				return y - x;
			}
	$('#example').dataTable( {
		"sPaginationType": "full_numbers",
		"aoColumnDefs": [ {
			"sType": "formatted-num",
			"aTargets": [1,2,3,4],
		} ],
		"iDisplayLength": 25,
		"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]]
	} );
	$('#example-no').dataTable( {
        "bPaginate": false,
        "bLengthChange": false,
        "bFilter": true,
        "bSort": false,
        "bInfo": false,
        "bAutoWidth": false
    } );
} );
</script>
<script>
$(document).ready(function() {
    $('#pelayanan').change(function() { // Jika Select Box id provinsi dipilih
        var persyaratan = $(this).val(); // Ciptakan variabel provinsi
        $.ajax({
            type: 'POST', // Metode pengiriman data menggunakan POST
            url: 'pelayanan.php', // File yang akan memproses data
            data: 'persyaratan=' + persyaratan, // Data yang akan dikirim ke file pemroses
            success: function(response) { // Jika berhasil
                $('#persyaratan').html(response); // Berikan hasil ke id kota
            }
        });
    });
</script>


<!--
<script language="javascript" type="text/javascript"
src="tinymcpuk/tiny_mce_src.js"></script>
<script type="text/javascript">
tinyMCE.init({
		mode : "textareas",
		theme : "advanced",
		plugins : "table,youtube,advhr,advimage,advlink,emotions,flash,searchreplace,paste,directionality,noneditable,contextmenu",
		theme_advanced_buttons1_add : "fontselect,fontsizeselect",
		theme_advanced_buttons2_add : "separator,preview,zoom,separator,forecolor,backcolor,liststyle",
		theme_advanced_buttons2_add_before: "cut,copy,paste,separator,search,replace,separator",
		theme_advanced_buttons3_add_before : "tablecontrols,separator,youtube,separator",
		theme_advanced_buttons3_add : "emotions,flash",
		theme_advanced_toolbar_location : "top",
		theme_advanced_toolbar_align : "left",
		theme_advanced_statusbar_location : "bottom",
		extended_valid_elements : "hr[class|width|size|noshade]",
		file_browser_callback : "fileBrowserCallBack",
		paste_use_dialog : false,
		theme_advanced_resizing : true,
		theme_advanced_resize_horizontal : false,
		theme_advanced_link_targets : "_something=My somthing;_something2=My somthing2;_something3=My somthing3;",
		apply_source_formatting : true
});

	function fileBrowserCallBack(field_name, url, type, win) {
		var connector = "../../filemanager11111/browser.html?Connector=connectors/php/connector.php";
		var enableAutoTypeSelection = true;
		
		var cType;
		tinymcpuk_field = field_name;
		tinymcpuk = win;
		
		switch (type) {
			case "image":
				cType = "Image";
				break;
			case "flash":
				cType = "Flash";
				break;
			case "file":
				cType = "File";
				break;
		}
		
		if (enableAutoTypeSelection && cType) {
			connector += "&Type=" + cType;
		}
		
		window.open(connector, "tinymcpuk", "modal,width=600,height=400");
	}
</script>
-->

</head>
<body>
<div id="header">
	<!-- <div id="logo">
		<div class="JudulBesar">PT. JMS BATAM<br>
</div>
		<div class="JudulKecil">Kawasan Industri Batamindo Blok 211
Jalan Beringin, Muka Kuning Batam 29433 |
TEL 62-770-611-805 | FAX 62-770-611-806</div>  

	</div> -->
	
	<!-- <div id="logout">
		<strong>Selamat Datang : </strong><br>
		<b><?php echo "$_SESSION[namalengkap]"; ?></b> <br>
		<b><?php echo "as $_SESSION[user]"; ?></b> <br>
		<a href="logout.php"><img align="left" src="images/logout.png" /><strong>Keluar</strong></a><br>
		</div>
	-->
  
  
  <!--	<div id="nav">
      		<?php include "menu.php"; ?>
  	</div> -->
  	&nbsp;	
  	<div id="logo">
		<div class="JudulBesar"><a href="?module=home"><img align="left" src="images/big_home.png" /></a>
		</div>
	</div>
  	
  	<div id="logout">
		<a href="javascript:confirmlogout('logout.php')"><img align="left" src="images/big_logout.png" /></a><br>
		</div>
  	
  	<div id="content"> 
    	<?php include "content.php"; ?>
  	</div>
    
</div>

<div id="footer"> 
    	<marquee onmouseover="stop()" onmouseout="start()">Copyright &copy; 2020 by MIS PT. JMS BATAM . All rights reserved.      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <a href="?module=laporan&act=developer" style="color:#ecf1f2; font-size: !important;" target=_blank>About Developer</a></marquee>
  	</div>
</body>
</html>
<?php
}
?>