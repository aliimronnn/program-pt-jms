<?php

//$server = "localhost";
//$username = "dbadmin";
//$password = "misbbo11";
//$database = "db_overtime";


// Koneksi dan memilih database di server


$server = "svr04";
$username = "jmsbadmin";
$password = "MISbbo11";
$database = "db_overtime_v2";


$conn = mysqli_connect($server,$username,$password,$database) or die("Connection Failed!");

?>
