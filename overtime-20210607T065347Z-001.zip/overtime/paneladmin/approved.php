<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#pelanggan").autocomplete("approved/proses_approved.php", {
		width: 300
	});
	
	$("#pelanggan").result(function(event, data, formatted) {
		var kode2	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode2="+kode2,
			url 	: "approved/cari_approved.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
			
				$("#kode2").val(data.kode2);
				
			}
		});
	});
	$("#pelanggan").keyup(function() {
		var kode2	= $('#pelanggan').val();
		$.ajax({
			type	: "POST",
			data	: "kode2="+kode2,
			url 	: "approved/cari_approved.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
					$("#kode2").val(data.kode2);
					
			}
		});
	});
	
});
</script>
</head>
<body>
  
  <tr><td colspan="2"> <strong> </strong></td></tr>
  <input type="hidden" id="kode2" name="approvedby_no">
 <tr><td>Approved by </td><td>: <input type="text" id="pelanggan" name="approvedby" size="50"> <small>*) Fill employee name</small></td></tr>
  
</body>
</html>
