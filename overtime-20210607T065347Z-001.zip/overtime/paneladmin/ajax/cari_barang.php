<?php
include "../config/koneksi.php";
mysql_select_db("siksop");

$kode	= $_POST[kode];

$sql 	= mysql_query("select * from jenis_pelayanan where jenis='$kode'");
$row	= mysql_num_rows($sql);
if($row>0){
	$r = mysql_fetch_array($sql);
	$data['namabarang'] = $r[persyaratan];
	$data['kode'] = $r[id];
	
	echo json_encode($data);
}else{
	$data['namabarang'] = '';
	$data['kode'] = '';
	echo json_encode($data);
}
?>
