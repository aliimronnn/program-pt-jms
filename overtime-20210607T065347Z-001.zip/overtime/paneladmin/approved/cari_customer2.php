<?php
include"../config/koneksi.php";

$kode2	= $_POST[kode2];

$sql 	= mysql_query("SELECT *from customer where nama='$kode2'");
$row	= mysql_num_rows($sql);
if($row>0){
	$r = mysql_fetch_array($sql);
		$data['kode2'] = $r[id];
		$data['nama'] = $r[nama];
		$data['alamat'] = $r[alamat];
		$data['noidentitas'] = $r[noidentitas];
		
		
	echo json_encode($data);
}else{
		$data['kode2'] = '';
		$data['nama'] = '';
		$data['alamat'] = '';
		$data['noidentitas'] = '';
		
	echo json_encode($data);
}
?>
