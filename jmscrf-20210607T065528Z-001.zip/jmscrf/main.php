<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
    <meta name="description" content="description of your site" />
    <meta name="author" content="author of the site" />
	<meta content='10' http-equiv='refresh'/> 
    <title>SMS Quick Count</title>
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap-responsive.css" />
    <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700,900,100italic,300italic,400italic,700italic,900italic" />
    <link rel="stylesheet" href="css/styles.css" />
    <link rel="stylesheet" href="css/toastr.css" />
    <link rel="stylesheet" href="css/fullcalendar.css" />
	<script language="javascript" type="text/javascript" src="paneladmin/js/jquery.js"></script>
    <script language="javascript" type="text/javascript" src="paneladmin/js/jquery.dataTables.js"></script>
    <script type="text/javascript">
	$(document).ready(function() {
		$(function() {
			var urlnya = window.location.search;
			$("ul#menu").find("a[href='"+urlnya+"']").addClass('active');
		});
		/* Formatted numbers sorting */
				$.fn.dataTableExt.oSort['formatted-num-asc'] = function(x,y){
					x = parseInt( x.replace(/[^\d\-\.\/]/g,'') );
					y = parseInt( y.replace(/[^\d\-\.\/]/g,'') );
					return x - y;
				}
				$.fn.dataTableExt.oSort['formatted-num-desc'] = function(x,y){
					x = parseInt( x.replace(/[^\d\-\.\/]/g,'') );
					y = parseInt( y.replace(/[^\d\-\.\/]/g,'') );
					return y - x;
				}
		$('#example').dataTable( {
			"sPaginationType": "full_numbers",
			"aoColumnDefs": [ {
				"sType": "formatted-num",
				"aTargets": [1,2,3,4],
			} ],
			"iDisplayLength": 25,
			"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]]
		} );
		$('#example-no').dataTable( {
			"bPaginate": false,
			"bLengthChange": false,
			"bFilter": true,
			"bSort": false,
			"bInfo": false,
			"bAutoWidth": false
		} );
	} );
	</script>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
  <body>
    <div id="in-nav">
      <div class="container">
        <div class="row">
          <div class="span12">
          	<ul class="pull-right">
              <li><a href="paneladmin/index_login.php">Login</a></li>
            </ul>
            <a id="logo" href="?module=quickcount">
              <h4><img src="quick.png" width="350px" height="60px"></h4>
           	</a>
          </div>
        </div>
      </div>
    </div>
    <div id="in-sub-nav">
      <div class="container">
        <div class="row">
          <div class="span12">
            <ul id="menu">
              <li><a href="?module=quickcount"><i class="batch plane"></i><br />Quick Count</a></li>
              <li><a href="?module=polling"><i class="batch poll"></i><br />Polling</a></li>
              <li><a href="?module=datadpt"><i class="batch book"></i><br />Data DPT</a></li>
              <li><a href="?module=datatps"><i class="batch forms"></i><br />Data TPS</a></li>
              <li><a href="?module=datacalon"><i class="batch users"></i><br />Data Calon</a></li>
              <li><a href="?module=datasaksi"><i class="batch eye"></i><br />Data Saksi</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="page">
      <div class="page-container">
<div class="container">
  <div class="row">
    <div class="span12">
    	<?php include "content.php"; ?>
    </div>
  </div>
</div>
      </div>
    </div>
    <footer>
      <div class="container">
        <div class="row">
          <div class="span12">
            <p>&copy; Copyright 2013 Creative Gama Studio</p>
          </div>
        </div>
      </div>
    </footer>
  </body>
</html>