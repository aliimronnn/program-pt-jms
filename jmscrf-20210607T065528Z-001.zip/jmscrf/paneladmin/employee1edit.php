<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#empno").autocomplete("employee/proses_employee1.php", {
		width: 300
	});
	
	$("#empno").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "employee/cari_employee1.php",
			dataType: "json",
			success: function(data){
				$("#kode").val(data.kode);
				$("#empname").val(data.empname);
				$("#sectioncode").html(data.sectioncode);
				$("#section").html(data.section);
			
			}
		});
	});
	$("#empno").keyup(function() {
		var kode	= $('#empno').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "employee/cari_employee1.php",
			dataType: "json",
			success: function(data){
				
					$("#kode").val(data.kode);
					$("#empname").val(data.empname);
					$("#section").val(data.section);
					$("#sectioncode").val(data.sectioncode);
					
			}
		});
	});
	
});
</script>
</head>
<body>
    <?php
  $sql=mysql_query("SELECT *from employee where empno='$r[empno]'");
  $k=mysql_fetch_array($sql);
  echo "
  <tr><td colspan='2'> <strong>Employee : </strong></td></tr>
 <tr><td>Emp No</td><td>: <input type='text' id='empno' name='empno' size='50' value='$k[empno]'></td></tr>
 <tr><td>Emp Name</td><td>: <input type='text' id='empname' size='50' value='$k[empname]'></td></tr>";
 ?>
 
   
</body>
</html>
