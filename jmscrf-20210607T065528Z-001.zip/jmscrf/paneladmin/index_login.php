<?php
include "config/koneksi.php";
include "config/fungsi_indotgl.php";
$login = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM identitas WHERE judul='login'"));
?>
<html>
<head>
<title>LOGIN FORM</title>
<link href="css/adminstyle.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function validasi(form){
  if (form.username.value == ""){
    alert("Username doesn't filled yet!");
    form.username.focus();
    return (false);
  }
     
  if (form.password.value == ""){
  alert("Password doesn't filled yet!");
    form.password.focus();
    return (false);
  }
  return (true);
}
</script>

<script type="text/javascript">	
	//fungsi displayTime yang dipanggil di bodyOnLoad dieksekusi tiap 1000ms = 1detik
	function displayTime(){
		//buat object date berdasarkan waktu saat ini
		var time = new Date();
		//ambil nilai jam, 
		//tambahan script + "" supaya variable sh bertipe string sehingga bisa dihitung panjangnya : sh.length
		var sh = time.getHours() + ""; 
		//ambil nilai menit
		var sm = time.getMinutes() + "";
		//ambil nilai detik
		var ss = time.getSeconds() + "";
		//tampilkan jam:menit:detik dengan menambahkan angka 0 jika angkanya cuma satu digit (0-9)
		document.getElementById("clock").innerHTML = (sh.length==1?"0"+sh:sh) + ":" + (sm.length==1?"0"+sm:sm) + ":" + (ss.length==1?"0"+ss:ss);
	}
</script>
<script type="text/javascript">
function goBack()
  {
  window.history.back()
  }
</script>

</head>
<body OnLoad="document.login.username.focus();" >
	<div id="logincontent">
        <div id="loginForm">
            <form name="login" action="cek_login.php" method="POST" onSubmit="return validasi(this)">
                 <table border="0"><tr ><td valign='top' colspan=3 align=center>			   
			     <div align=center>
				 <?php
				 echo $login['identitas'];
				 ?><br> 
                  <span style='font-size: medium; color: #5F9EAD;'>
				 <?php 
				  //echo "<span style='font-size: medium; color: #5F9EAD;'>". tgl_indo(date("Y m d"))."</span>"; 
				include "head.php";
				                  
               
				 ?> </div></span>
				</td></tr>
				 <tr ><td>&nbsp;&nbsp;
              </td><td> <span style='font-size: medium; color: #008B8B;'><strong>Username</strong></span></td><td>
                <input type="text" name="id_user" autofocus/><td>
                </tr>
				 <tr ><td>&nbsp;&nbsp; </td><td><span style='font-size: medium; color:#008B8B;'><strong>Password</strong></span></td><td>
                <input type="password" name="password" />
                </td></tr><tr><td colspan=3 align=center><br>
                <input type="submit" value="Login" class="large blue super button"/>&nbsp;&nbsp;&nbsp;
                <input type="button" value="Batal" onclick="goBack()" class="large orange super button"/></td></tr></table>
                
            </form>
        </div>
	</div>
	<div id="footer"><marquee onmouseover="stop()" onmouseout="start()"> &copy; 2015 by MIS PT. JMS BATAM . All rights reserved.      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <a href="https://www.facebook.com/ipong30" style="color:#ecf1f2;" target=_blank>About Developer</a></marquee></div>
</body>
</html>
