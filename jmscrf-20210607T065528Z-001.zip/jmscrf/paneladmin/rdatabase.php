<?
 include "identitas.php";
include "function.php";
echo "<h2>Perbaiki Tabel Database</h2>";
	echo "<p>&nbsp;</p>";
	echo "<p>Fitur ini digunakan apabila Anda menjumpai error sewaktu menjalankan service. Error tersebut terjadi karena rusaknya tabel database. Kerusakan ini seringkali disebabkan karena gangguan listrik (komputer tiba-tiba mati).</p>";
	echo "<hr><br>";
	$query = "SHOW TABLES";
	$hasil = mysql_query($query);
	while ($data = mysql_fetch_row($hasil))
	{
		$query2 = "REPAIR TABLE `".$data[0]."`";
		$hasil2 = mysql_query($query2);
		$data2  = mysql_fetch_array($hasil2);
		echo $query2."<br>".$data2[3]."<br><br>";
	}
?>