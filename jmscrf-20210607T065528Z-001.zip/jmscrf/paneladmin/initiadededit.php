<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#pelanggan3").autocomplete("initiaded/proses_initiaded.php", {
		width: 300
	});
	
	$("#pelanggan3").result(function(event, data, formatted) {
		var kode4	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "initiaded/cari_initiaded.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
				
				$("#kode4").val(data.kode4);
				
			}
		});
	});
	$("#pelanggan3").keyup(function() {
		var kode4	= $('#pelanggan3').val();
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "initiaded/cari_initiaded.php",
			dataType: "json",
			success: function(data){
				$("#namanama").val(data.nama_kapal);
					$("#kode4").val(data.kode4);
					
			}
		});
	});
	
});
</script>
</head>
<body>
  <?php
  //$sql=mysql_query("select *from employee where empno='$r[initiadedby]'");
  //$k=mysql_fetch_array($sql);
  //<input type='hidden' id='kode4' name='initiadedby' value='$r[initiaded]'>
  echo"
  
<td><input type='text' id='pelanggan3' name='initiaded' size='50' value='$r[initiaded]'></td>
 ";
  ?>

</body>
</html>
