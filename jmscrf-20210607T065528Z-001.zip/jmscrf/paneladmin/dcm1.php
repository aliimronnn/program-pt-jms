<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#dcm_no").autocomplete("dcm/proses_dcm1.php", {
		width: 300
	});
	
	$("#dcm_no").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "draf/cari_dcm1.php",
			dataType: "json",
			success: function(data){
				$("#kode").val(data.kode);
				$("#id").val(data.id);
				$("#title").val(data.title);
				//$("#issue_date").html(data.issue_date);
				$("#section").val(data.section);
				$("#hobi").val(data.hobi);
				
			
			}
		});
	});
	$("#dcm_no").keyup(function() {
		var kode	= $('#dcm_no').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "dcm/cari_dcm1.php",
			dataType: "json",
			success: function(data){
				
					$("#kode").val(data.kode);
					$("#title").val(data.title);
					$("#id").val(data.id);
					
					$("#hobi").val(data.hobi);
					$("#section").val(data.section);
									
			}
		});
	});
	
});
//<tr><td>Title</td><td valign="center">: <input type="text" id="title" name="title" readonly size="100"></td></tr>
</script>
</head>
<body>
  <input type="hidden" id="hobi" name="hobi">
  <input type="hidden" id="section" name="section">
  <input type="hidden" id="id" name="id_draf">
  
<input type="text" id="dcm_no" name="dcm_no" size="50"> *) <strong><small><i><u>Fill DCM No.</u></i></small></strong>
   
</body>
</html>
