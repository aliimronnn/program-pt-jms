<?php
 $bn = mysql_query("SELECT * FROM  suratkeluardisposisi WHERE kode_unik='$s[kode_unik]'");
 $bnrow = mysql_num_rows($bn);
 if(empty($bnrow)){
 mysql_query("INSERT into suratkeluardisposisi(kode_unik,status,petugas,tanggal) values('$s[kode_unik]','BELUM DIPROSES','$_SESSION[namauser]',NOW())");
 } 
?>