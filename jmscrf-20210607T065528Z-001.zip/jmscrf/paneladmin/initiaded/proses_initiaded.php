<?php
include"../config/koneksi.php";
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT * from employee where empname LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$kode2_barang = $r['empname'];
	
	echo "$kode2_barang\n";
}
?>
