<?php
$path = "";
$msgREG = "Terimakasih Anda sdh melakukan REG";
$msgErrorREG = "Format REG salah. Format yang benar REG#GROUP#NAMA";
$msgGroupErrorREG = "Maaf, nama group tidak ditemukan";
$msgFWD = "Terima kasih telah mengirim polling";
$msgErrorFWD = "Maaf kode poling tidak ada atau sudah tidak berlaku";
$msgUNREG = "Anda sudah melakukan UNREG, untuk mendaftar kembali ketik : REG#NAMA GROUP#NAMA ANDA";
$msgErrorUNREG = "Format UNREG salah. Format yang benar UNREG";
$msgGroupErrorUNREG = "";
$msgINBOX = "Terimakasih sudah mengirim SMS ke kami";
$msgErrorData = "";
$msgErrorKeyword = "";
$msgErrorInfo = "";
$commandREG = "";
$commandINFO = "";
$commandFWD = "";
$commandUNREG = "";
$autoReplyInbox = "0";
$msgErrorBerita = "Anda tidak terdaftar atau Anda tidak diperbolehkan memforward berita ya";
$msgErrorBeritaGroup = "Maaf nama group tidak ada ya";
$SuksesBerita = "BERITA yang Anda forwad telah terkirim ya";
$header = "";
$footer = "";
$defaultSender = "phone1";
$serial = "";
?>