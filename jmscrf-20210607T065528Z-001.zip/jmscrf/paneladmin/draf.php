<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_no").autocomplete("draf/proses_draf.php", {
		width: 300
	});
	
	$("#draft_no").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "draf/cari_draf.php",
			dataType: "json",
			success: function(data){
				$("#kode").val(data.kode);
				$("#id").val(data.id);
				$("#title").val(data.title);
				//$("#issue_date").html(data.issue_date);
				$("#section").val(data.section);
				$("#hobi").val(data.hobi);
				$("#hobi2").val(data.hobi2);
				
				
			
			}
		});
	});
	$("#draft_no").keyup(function() {
		var kode	= $('#draft_no').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "draf/cari_draf.php",
			dataType: "json",
			success: function(data){
				
					$("#kode").val(data.kode);
					$("#title").val(data.title);
					$("#id").val(data.id);
					
					$("#hobi").val(data.hobi);
					$("#hobi2").val(data.hobi2);
					
					$("#section").val(data.section);
									
			}
		});
	});
	
});
</script>
</head>
<body>
  <input type="hidden" id="hobi" name="hobi">
  <input type="hidden" id="hobi2" name="hobi2">
  <input type="hidden" id="section" name="section">
  <input type="hidden" id="id" name="id_draf">
  <input type="hidden" id="draf_kd" name="draf_kd">
  
 <tr><td>DRAF No.</td><td>: <input type="text" id="draft_no" name="draft_no" size="50"></td></tr>
 <tr><td valign="top">Title</td><td valign="top">: <textarea id="title" name="title" readonly cols="100" rows="3"></textarea></td></tr>
 
   
</body>
</html>
