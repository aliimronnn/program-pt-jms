<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_no").autocomplete("deviation/proses_deviation2.php", {
		width: 300
	});
	
	$("#draft_no").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "deviation/cari_deviation.php",
			dataType: "json",
			success: function(data){
				$("#kode").val(data.kode);
				$("#id").val(data.id);
				$("#title").val(data.title);
			
				
			
			}
		});
	});
	$("#draft_no").keyup(function() {
		var kode	= $('#draft_no').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "deviation/cari_deviation.php",
			dataType: "json",
			success: function(data){
				
					$("#kode").val(data.kode);
					$("#title").val(data.title);
					$("#id").val(data.id);
			}
		});
	});
	
});
//<tr><td>Title</td><td valign="center">: <input type="text" id="title" name="title" size="150" readonly></td></tr>
</script>
</head>
<body>
  <input type="hidden" id="id" name="id">
  
 <input type="text" id="draft_no" name="draft_no" size="50">  *) <strong><small><i><u>Fill DRAF No.</u></i></small></strong>
 
 
   
</body>
</html>
