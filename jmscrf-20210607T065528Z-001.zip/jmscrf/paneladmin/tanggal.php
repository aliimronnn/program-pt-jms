<script type="text/javascript" src="js1/jquery-1.4.js"></script>
<script src="lib/jquery.min.js"></script>
<script src="lib/zebra_datepicker.js"></script>
<link rel="stylesheet" href="lib/css/default.css" />



 <input type="text" name="tanggal" id="tanggal" />
