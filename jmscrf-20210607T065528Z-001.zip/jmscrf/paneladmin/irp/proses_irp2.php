<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT * from irp where crf_no LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$draft_no = $r['crf_no'];
	
	echo "$draft_no\n";
}
?>
