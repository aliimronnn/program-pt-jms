<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT ir.* from irp ir, crf cr where ir.id_crf=cr.id and cr.crf_kd='$_SESSION[crf_kd]' and cr.crf_no LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$draft_no = $r['crf_no'];
	
	echo "$draft_no\n";
}
?>
