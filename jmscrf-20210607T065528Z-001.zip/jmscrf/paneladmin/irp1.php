<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#crf_no").autocomplete("irp/proses_irp.php", {
		width: 300
	});
	
	$("#crf_no").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "irp/cari_irp.php",
			dataType: "json",
			success: function(data){
				$("#kode").val(data.kode);
				$("#id_crf").val(data.id_crf);
				$("#title").val(data.title);
			
				
			
			}
		});
	});
	$("#crf_no").keyup(function() {
		var kode	= $('#crf_no').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "irp/cari_irp.php",
			dataType: "json",
			success: function(data){
				
					$("#kode").val(data.kode);
					$("#title").val(data.title);
					$("#id_crf").val(data.id_crf);
			}
		});
	});
	
});
//<tr><td>Title</td><td valign="center">: <input type="text" id="title" name="title" size="150" readonly></td></tr>
</script>
</head>
<body>
  <input type="hidden" id="id_crf" name="id_crf">
  
<input type="text" id="crf_no" name="crf_no" size="50"> <strong> <small><i><u>*) Fill CRF No.</u></i></small></strong>
 
   
</body>
</html>
