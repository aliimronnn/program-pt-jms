<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#crf_nounclose").autocomplete("crf/proses_crfunclose.php", {
		width: 300
	});
	
	$("#crf_nounclose").result(function(event, data, formatted) {
		var kode_unclose	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_unclose="+kode_unclose,
			url 	: "crf/cari_crfunclose.php",
			dataType: "json",
			success: function(data){
				$("#kode_unclose").val(data.kode_unclose);
				$("#id3").val(data.id3);
				$("#title3").val(data.title3);
				$("#section3").val(data.section3);
			
				
			
			}
		});
	});
	$("#crf_nounclose").keyup(function() {
		var kode_unclose	= $('#crf_nounclose').val();
		$.ajax({
			type	: "POST",
			data	: "kode_unclose="+kode_unclose,
			url 	: "crf/cari_crfunclose.php",
			dataType: "json",
			success: function(data){
				
					$("#kode_unclose").val(data.kode_unclose);
					$("#title3").val(data.title3);
					$("#id3").val(data.id3);
					$("#section3").val(data.section3);
									
			}
		});
	});
	
});
</script>
</head>
<body>
   
  
  <input type="hidden" id="id3" name="id_crf3">
 	  
 <tr><td>CRF No.</td><td>: <input type="text" id="crf_nounclose" name="crf_nounclose" size="50"><small>*) Fill CRF No</small></small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title3" name="title3" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">:  <input type="text" id="section3" name="section3" size="50"></td></tr>
   
</body>
</html>
