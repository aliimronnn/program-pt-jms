<?php
require 'config/koneksi.php';


$sql = mysqli_query($conn, "SELECT cr.draft_no, cr.title, sc.mailto, sc.mailto_1, sc.mailcc, cr.issue_date,
sc.section as section2, cr.section,
cr.initiaded, cr.status FROM draf cr, sectioncode sc WHERE cr.section=sc.id 
AND cr.status!= '3' AND cr.status !='0' AND datediff((cr.issue_date + interval '6' month),current_date()) < 0
AND (cr.issue_date + interval '2' month) >= NOW() - INTERVAL 3 YEAR
GROUP BY cr.section");
	
	while ($data=mysqli_fetch_assoc($sql)){

   	echo "<span>$data[section2]</span><span>$data[mailto]</span>";
 	echo "
<table table border= 1px>
<thead>
<tr>
<th width=120>CRF Ref No</th>
<th>CRF Title</th>
<th width=80>Issue Date</th>
<th width=80>Deadline Report</th>
<th width=80>Late<br>(Days)</th>
<th width=30>Initiated By</th>
</tr>

</thead><tbody>";
$sql2 = mysqli_query($conn, "SELECT cr.draft_no, cr.title, sc.mailto, sc.mailto_1, sc.mailcc, cr.issue_date,
date_format(cr.issue_date,'%d %b %y') AS issue_date, 
date_format((cr.issue_date + interval '6' month),'%d %b %y') AS deadline,
abs(datediff((cr.issue_date + interval '6' month),current_date())) AS selisih,
cr.section, cr.status,
cr.initiaded, cr.status FROM draf cr, sectioncode sc WHERE cr.section=sc.id 
AND cr.status!= '3' AND cr.status !='0' AND datediff((cr.issue_date + interval '6' month),current_date()) < 0
AND (cr.issue_date + interval '6' month) >= NOW() - INTERVAL 3 YEAR AND cr.section = $data[section]
ORDER BY cr.draf_kd");
	
	while ($data2=mysqli_fetch_assoc($sql2)){

   echo "
	   	<td>$data2[draft_no]</td> 
	   	<td>$data2[title]</td>
      	<td>$data2[issue_date]</td>
      	<td>$data2[deadline]</td>
      	<td>$data2[selisih]</td>
      	<td>$data2[initiaded]</td>
       </tr>";
 
}
echo "</tbody></table>";
}
?>