<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_no").autocomplete("draf/proses_draf.php", {
		width: 300
	});
	
	$("#draft_no").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "draf/cari_draf.php",
			dataType: "json",
			success: function(data){
				$("#kode").val(data.kode);
				$("#id").val(data.id);
				$("#title").val(data.title);
				//$("#issue_date").html(data.issue_date);
				$("#section").val(data.section);
				$("#hobi").val(data.hobi);
				
			
			}
		});
	});
	$("#draft_no").keyup(function() {
		var kode	= $('#draft_no').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "draf/cari_draf.php",
			dataType: "json",
			success: function(data){
				
					$("#kode").val(data.kode);
					$("#title").val(data.title);
					$("#id").val(data.id);
					
					$("#hobi").val(data.hobi);
					$("#section").val(data.section);
									
			}
		});
	});
	
});
</script>
</head>
<body>
  <?php
  $sql=mysql_query("SELECT *from draf where id='$r[id_draf]'");
  $k=mysql_fetch_array($sql);
  echo "
  <input type='hidden' id='hobi' name='hobi' value='$k[hobi]'>
  <input type='hidden' id='section' name='section' value='$k[section]'>
  <input type='hidden' id='id' name='id_draf' value='$r[id_draf]'>
  
 <tr><td>DRAF No.</td><td>: <input type='text' id='draft_no' name='draft_no' size='50' value='$k[draft_no]' readonly ></td></tr>
 <tr><td valign='top'>Title</td><td valign='top'>: <textarea id='title' name='title' readonly cols='90' rows='3'>$k[title]</textarea></td></tr>";?>
 
   
</body>
</html>
