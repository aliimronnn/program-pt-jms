<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT * from dcm where doc_code LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$draft_no = $r['doc_code'];	
	echo "$draft_no\n";
}
?>
