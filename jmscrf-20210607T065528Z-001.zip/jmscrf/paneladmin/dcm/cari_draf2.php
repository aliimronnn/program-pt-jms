<?php
include"../config/koneksi.php";

$kode	= $_POST['kode'];

$sql 	= mysqli_query($conn, "SELECT *from draf where status ='0' and draft_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title'] = $r['title'];
	$data['id'] = $r['id'];
	//$data['issue_date'] = $r['issue_date'];
	$data['hobi'] = $r['hobi'];
	$data['hobi2'] = $r['hobi2'];
	$data['section'] = $r['section'];
	$data['draf_kd'] = $r['draf_kd'];
		
		
	echo json_encode($data);
}else{
	$data['title'] = '';
	$data['id'] = '';
	//$data['issue_date'] = '';
	$data['section'] = '';
	$data['hobi'] = '';
	$data['hobi2'] = '';
	$data['draf_kd'] = '';
	
	echo json_encode($data);
}
?>
