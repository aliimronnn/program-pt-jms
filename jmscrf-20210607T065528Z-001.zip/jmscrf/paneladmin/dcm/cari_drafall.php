<?php
include"../config/koneksi.php";

$kode	= $_POST['kode4'];

$sql 	= mysqli_query($conn, "SELECT *from draf where draft_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title4'] = $r['title'];
	$data['id4'] = $r['id'];
	$data['section4'] = $r['section'];
		
		
	echo json_encode($data);
}else{
	$data['title4'] = '';
	$data['id4'] = '';
	$data['section4'] = '';
	
	
	echo json_encode($data);
}
?>
