<?php
include"../config/koneksi.php";

$kode	= $_POST['kodeunclose'];

$sql 	= mysqli_query($conn, "SELECT *from draf where status ='3' and draft_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title3'] = $r['title'];
	$data['id3'] = $r['id'];
	$data['section3'] = $r['section'];
		
		
	echo json_encode($data);
}else{
	$data['title3'] = '';
	$data['id3'] = '';
	$data['section3'] = '';
	
	
	echo json_encode($data);
}
?>
