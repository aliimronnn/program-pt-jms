<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#barang").autocomplete("kapal/proses_barang.php", {
		width: 300
	});
	
	$("#barang").result(function(event, data, formatted) {
		var kode	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "kapal/cari_barang.php",
			dataType: "json",
			success: function(data){
				$("#namabarang").val(data.nama_kapal);
				$("#bendera").html(data.bendera);
				$("#pemilik").html(data.pemilik);
				$("#dwt").html(data.dwt);
				$("#kode").val(data.kode);
			}
		});
	});
	$("#barang").keyup(function() {
		var kode	= $('#barang').val();
		$.ajax({
			type	: "POST",
			data	: "kode="+kode,
			url 	: "kapal/cari_barang.php",
			dataType: "json",
			success: function(data){
				$("#namabarang").val(data.nama_kapal);
					$("#kode").val(data.kode);
						$("#bendera").html(data.bendera);
			}
		});
	});
	
});
</script>
</head>
<body>
  
  <?php
  $sql=mysql_query("select bendera.bendera,datakapal.* from datakapal,bendera where datakapal.id_bendera=bendera.id and datakapal.id='$r[nama_kapal]'");
  $k=mysql_fetch_array($sql);
  echo"
  <tr><td>Nama Kapal </td><td><input type='text' id='barang' value='$k[nama_kapal]' size='50'></td></tr>
  <input type='hidden' id='kode' value='.' name='nama_kapal' value='$k[id]'>
  <tr><td>Bendera </td><td>:   <span id='bendera' >$k[bendera]</span></td></tr>
  <tr><td>Isi Kotor</td> <td>:   <span id='dwt' >$k[dwt]</span></td></tr>
<tr><td>Pemilik Kapal</td><td>: <span id='pemilik' >$k[pemilik_kapal]</span></td></tr>
  ";
  ?>
  
 
</body>
</html>
