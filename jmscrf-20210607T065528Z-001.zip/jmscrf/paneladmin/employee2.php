<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#empno").autocomplete("employee/proses_employee1.php", {
		width: 300
	});
	
	$("#empno").result(function(event, data, formatted) {
		var kode2	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode2="+kode2,
			url 	: "employee/cari_employee2.php",
			dataType: "json",
			success: function(data){
				$("#empname").val(data.empname);
			
			
			}
		});
	});
	$("#empno").keyup(function() {
		var kode2	= $('#empno').val();
		$.ajax({
			type	: "POST",
			data	: "kode2="+kode2,
			url 	: "employee/cari_employee2.php",
			dataType: "json",
			success: function(data){
				
					$("#kode2").val(data.kode2);
					
					$("#empname").val(data.empname);
					
					
			}
		});
	});
	
});
</script>
</head>
<body>
  
  <tr><td colspan="3">     </td></tr>
 <tr><td colspan="2"><strong> Supervisor</strong></td><td><strong>: <input type="text" id="empno"></strong></td></tr>
 <tr><td colspan="2"><strong> Name</strong></td><td><strong>: <input type="text" id="empname"></strong></td></tr>

   
</body>
</html>
