<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_no33").autocomplete("draf/proses_drafunapp.php", {
		width: 300
	});
	
	$("#draft_no33").result(function(event, data, formatted) {
		var kodeunapp	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kodeunapp="+kodeunapp,
			url 	: "draf/cari_drafunapp.php",
			dataType: "json",
			success: function(data){
				$("#kodeunapp").val(data.kodeunapp);
				$("#id33").val(data.id33);
				$("#title33").val(data.title33);
				$("#section33").val(data.section33);
				
				
			
			}
		});
	});
	$("#draft_no33").keyup(function() {
		var kodeunapp	= $('#draft_no33').val();
		$.ajax({
			type	: "POST",
			data	: "kodeunapp="+kodeunapp,
			url 	: "draf/cari_drafunapp.php",
			dataType: "json",
			success: function(data){
				
					$("#kodeunapp").val(data.kodeunapp);
					$("#title33").val(data.title33);
					$("#id33").val(data.id33);
					$("#section33").val(data.section33);
									
			}
		});
	});
	
});
</script>
</head>
<body>
 <input type="hidden" id="id33" name="id_draf33">
  
 <tr><td>DRAF No.</td><td>: <input type="text" id="draft_no33" name="draft_no33" size="40"> *) <small>Fill DRAF No. </small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title33" name="title33" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">: <input type="text" id="section33" name="section33" readonly size="30"></td></tr>
 
   
</body>
</html>
