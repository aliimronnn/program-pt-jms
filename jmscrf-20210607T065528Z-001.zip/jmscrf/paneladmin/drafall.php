<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_all").autocomplete("draf/proses_drafall.php", {
		width: 300
	});
	
	$("#draft_all").result(function(event, data, formatted) {
		var kode4	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "draf/cari_drafall.php",
			dataType: "json",
			success: function(data){
				$("#kode4").val(data.kode4);
				$("#id4").val(data.id4);
				$("#title4").val(data.title4);
				$("#section4").val(data.section4);
				
				
			
			}
		});
	});
	$("#draft_all").keyup(function() {
		var kode4	= $('#draft_all').val();
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "draf/cari_drafall.php",
			dataType: "json",
			success: function(data){
				
					$("#kode4").val(data.kode4);
					$("#title4").val(data.title4);
					$("#id4").val(data.id4);
					$("#section4").val(data.section4);
									
			}
		});
	});
	
});
</script>
</head>
<body>
 <input type="hidden" id="id4" name="id_draf4">
  
 <tr><td>DRAF No.</td><td>: <input type="text" id="draft_all" name="draft_all" size="40"> *) <small>Fill DRAF No. </small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title4" name="title4" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">: <input type="text" id="section4" name="section4" readonly size="30"></td></tr>
 
   
</body>
</html>
