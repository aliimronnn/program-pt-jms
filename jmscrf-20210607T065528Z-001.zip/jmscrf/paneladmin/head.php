<? 
include "config/koneksi.php";

?> 

<div class="date-time">
	<div style="float:center;">
	<script type='text/javascript'>
	<!--
		var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
		var myDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
		var date = new Date();
		var day = date.getDate();
		var month = date.getMonth();
		var thisDay = date.getDay(),
			thisDay = myDays[thisDay];
		var yy = date.getYear();
		var year = (yy < 1000) ? yy + 1900 : yy;
		document.write(thisDay + ', ' + day + ' ' + months[month] + ' ' + year);
	//-->
	</script>
    </div>
    <div style="float:center">
    <script language="javascript">
var XMLHttpRequestObject = false;
if (window.XMLHttpRequest) {
    XMLHttpRequestObject = new XMLHttpRequest();
} else if (window.ActiveXObject) {
    XMLHttpRequestObject = new ActiveXObject("Microsoft.XMLHTTP");
}
function getJam(sumberdata, divID) {
  if(XMLHttpRequestObject) {
    var obj = document.getElementById(divID);
    XMLHttpRequestObject.open("GET",sumberdata);
    XMLHttpRequestObject.onreadystatechange = function() {
      if (XMLHttpRequestObject.readyState == 4 && XMLHttpRequestObject.status == 200) {
        obj.innerHTML = XMLHttpRequestObject.responseText;
        setTimeout("getJam('jam.php','divjam')",1000);
      }
    }
  XMLHttpRequestObject.send(null);
  }
}
window.onload=function(){
setTimeout("getJam('jam.php','divjam')",1000);
}
</script><div id="divjam"></div>
    </div>
	
</div>