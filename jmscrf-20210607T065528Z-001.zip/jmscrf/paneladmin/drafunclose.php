<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_no3").autocomplete("draf/proses_drafunclose.php", {
		width: 300
	});
	
	$("#draft_no3").result(function(event, data, formatted) {
		var kodeunclose	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kodeunclose="+kodeunclose,
			url 	: "draf/cari_drafunclose.php",
			dataType: "json",
			success: function(data){
				$("#kodeunclose").val(data.kodeunclose);
				$("#id3").val(data.id3);
				$("#title3").val(data.title3);
				$("#section3").val(data.section3);
				
				
			
			}
		});
	});
	$("#draft_no3").keyup(function() {
		var kodeunclose	= $('#draft_no3').val();
		$.ajax({
			type	: "POST",
			data	: "kodeunclose="+kodeunclose,
			url 	: "draf/cari_drafunclose.php",
			dataType: "json",
			success: function(data){
				
					$("#kodeunclose").val(data.kodeunclose);
					$("#title3").val(data.title3);
					$("#id3").val(data.id3);
					$("#section3").val(data.section3);
									
			}
		});
	});
	
});
</script>
</head>
<body>
 <input type="hidden" id="id3" name="id_draf3">
  
 <tr><td>DRAF No.</td><td>: <input type="text" id="draft_no3" name="draft_no3" size="40"> *) <small>Fill DRAF No. </small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title3" name="title3" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">: <input type="text" id="section3" name="section3" readonly size="30"></td></tr>
 
   
</body>
</html>
