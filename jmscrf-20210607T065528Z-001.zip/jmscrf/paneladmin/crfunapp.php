<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#crf_nounapp").autocomplete("crf/proses_crfunapp.php", {
		width: 300
	});
	
	$("#crf_nounapp").result(function(event, data, formatted) {
		var kode_unapp	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_unapp="+kode_unapp,
			url 	: "crf/cari_crfunapp.php",
			dataType: "json",
			success: function(data){
				$("#kode_unapp").val(data.kode_unapp);
				$("#id33").val(data.id33);
				$("#title33").val(data.title33);
				$("#section33").val(data.section33);
			
				
			
			}
		});
	});
	$("#crf_nounapp").keyup(function() {
		var kode_unapp	= $('#crf_nounapp').val();
		$.ajax({
			type	: "POST",
			data	: "kode_unapp="+kode_unapp,
			url 	: "crf/cari_crfunapp.php",
			dataType: "json",
			success: function(data){
				
					$("#kode_unapp").val(data.kode_unapp);
					$("#title33").val(data.title33);
					$("#id33").val(data.id33);
					$("#section33").val(data.section33);
									
			}
		});
	});
	
});
</script>
</head>
<body>
   
  
  <input type="hidden" id="id33" name="id_crf33">
 	  
 <tr><td>CRF No.</td><td>: <input type="text" id="crf_nounapp" name="crf_nounapp" size="50"><small>*) Fill CRF No</small></small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title33" name="title33" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">:  <input type="text" id="section33" name="section33" size="50"></td></tr>
   
</body>
</html>
