<?php 

$namasoftware = "SMS Pilkada";
$creator = "";
$url = "";
$email = "";
$nohp = "";

?>