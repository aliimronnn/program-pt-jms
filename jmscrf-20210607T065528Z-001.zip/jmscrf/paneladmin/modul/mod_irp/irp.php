<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
    if (form.crf_no.value.length < mincar){
       alert("CRF No is still empty!");
       form.crf_no.focus();
       return (false);
   }   
   if (form.title.value.length < mincar){
       alert("Title is still empty!");
       form.title.focus();
       return (false);
   }         
    
   
   return (true);
}

function validasidetail(form){
   var mincar = 1;
   if (form.doc_code.value.length < mincar){
       alert("Doc Code is still empty!");
       form.doc_code.focus();
       return (false);
   }   
   	  
   if (form.new.value.length < mincar){
       alert("New Code is still empty!");
       form.new.focus();
       return (false);
   }     
   if (form.issue_date.value==""){
       alert("Issue Date is still empty!");
       form.issue_date.focus();
       return (false);
   }    
   if (form.justification.value==""){
       alert("Justification is still empty!");
       form.justification.focus();
       return (false);
   }
  
   return (true);
}

function validasidetail2(form){
   var mincar = 1;
   if (form.doc_code.value.length < mincar){
       alert("Doc Code is still empty!");
       form.doc_code.focus();
       return (false);
   }   
   	  
   if (form.new.value.length < mincar){
       alert("New Code is still empty!");
       form.new.focus();
       return (false);
   }     
   if (form.issue_date.value==""){
       alert("Issue Date is still empty!");
       form.issue_date.focus();
       return (false);
   }    
  
  
   return (true);
}

function validasi2(form){
   var mincar = 1;
   if (form.crf_no.value.length < mincar){
       alert("CRF Number is still empty!");
       form.crf_no.focus();
       return (false);
   }  
   if (form.title.value.length < mincar){
       alert("Title is still empty!");
       form.title.focus();
       return (false);
   }  
    if (form.content.value.length < mincar){
       alert("Report Content is still empty!");
       form.content.focus();
       return (false);
   }   
   if (form.part.value.length < mincar){
       alert("Part/WIP/FG is still empty!");
       form.part.focus();
       return (false);
   }         
   if (form.test.value.length < mincar){
       alert("Test/Verification is still empty!");
       form.test.focus();
       return (false);
   }
   if (form.need.value.length < mincar){
       alert("Indication is still empty!");
       form.need.focus();
       return (false);
   }
    if (form.completion_date.value.length < mincar){
       alert("Completion Date is still empty!");
       form.completion_date.focus();
       return (false);
   }if (form.verification_date.value.length < mincar){
       alert("Verification Date is still empty!");
       form.verification_date.focus();
       return (false);
   }
   if (form.training_date.value.length < mincar){
       alert("Training Date is still empty!");
       form.training_date.focus();
       return (false);
   }
    if (form.reason.value.length < mincar){
       alert("Reason is still empty!");
       form.reason.focus();
       return (false);
   }
     var radio_val15 = check_radio(form.problem);
   if (radio_val15 === false){
       alert("Problem Encounter is not choosen yet!");
       return false;
   }
   if (form.counter.value.length < mincar){
       alert("Counter Measure is still empty!");
       form.counter.focus();
       return (false);
   }
   if (form.approve_date2.value.length < mincar){
       alert("Approve Date is still empty!");
       form.approve_date2.focus();
       return (false);
   }
   if (form.reject_date2.value.length < mincar){
       alert("Reject Date is still empty!");
       form.reject_date2.focus();
       return (false);
   }
   if (form.reference_no.value.length < mincar){
       alert("Reference No is still empty!");
       form.reference_no.focus();
       return (false);
   }
   
   if (form.verified.value.length < mincar){
       alert("Reported By is still empty!");
       form.verified.focus();
       return (false);
   }if (form.approved.value.length < mincar){
       alert("Approved By is still empty!");
       form.approved.focus();
       return (false);
   }
   
   return (true);
}
</script>

<?php
/** session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Login is required to acces the system!<br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{ **/
function explode_trim($str, $delimiter = ',') {
   if ( is_string($delimiter) ) {
      $str = trim(preg_replace('|\\s*(?:' . preg_quote($delimiter) . ')\\s*|', $delimiter, $str));
      return explode($delimiter, $str);
   }
   return $str;
}
    
$aksi="modul/mod_irp/aksi_irp.php";
switch(@$_GET['act']){

default:
echo "
<form method=POST action='?module=irp&act=viewirp' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find IRP</strong></i></td><td>: ";
include "irp1.php";
echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
<h2>List IRP Report</h2>
<p>&nbsp;</p>
<input type=button  class='large orange super button' value='Add New IRP' 
onclick=\"window.location.href='?module=irp&act=tambahirp';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width='20'>No</th><th width='20'>Section</th>
<th width='150'>CRF No</th><th width='100'>Check Points</th><th >Title</th><th width='80'>Issue Date</th><th width='80'>Deadline</th><th width='80'>Report Date</th><th width='100'>Status</th><th width='100'>Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT irp.id_crf, crf.section, crf.crf_no, crf.title, case crf.jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis, date_format(crf.issue_date,'%d %b %y') as issue_date, 
date_format((crf.issue_date + interval '2' month),'%d %b %y')as deadline, 
date_format(crf.report_date,'%d %b %y') as report_date, 
datediff((crf.issue_date + interval '2' month),current_date()) as selisih,crf.status
from irp , crf where irp.id_crf=crf.id and crf.crf_kd='$_SESSION[crf_kd]'
order by crf.crf_no desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}	
  echo "<tr><td>$no.</td><td>$r[section]</td>
	<td>$r[crf_no]</td><td>$r[jenis]</td>
      <td>$r[title]</td> <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td> <td>$label</td>
    <td><a href='?module=irp&act=editirp&id_crf=$r[id_crf]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=irp&act=delete&id_crf=$r[id_crf]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=irp&act=cetak&id_crf=$r[id_crf] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;

case "irp_qms":
echo "
<form method=POST action='?module=irp&act=view_irpqms' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find IRP</strong></i></td><td>: ";
include "irp2.php";
echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
<h2>List IRP Report</h2>

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width='20'>No</th>
<th width='170'>CRF No</th><th >Section</th><th width='100'>Check Points</th><th >Title</th><th width='80'>Issue Date</th><th width='80'>Deadline</th><th width='80'>Report Date</th><th width='100'>Status</th><th width='100'>Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT irp.id_crf, crf.crf_no, crf.title, sc.section, case crf.jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis, date_format(crf.issue_date,'%d %b %y') as issue_date, 
date_format((crf.issue_date + interval '2' month),'%d %b %y')as deadline, 
date_format(crf.report_date,'%d %b %y') as report_date, 
datediff((crf.issue_date + interval '2' month),current_date()) as selisih,crf.status
from irp , crf, sectioncode sc where irp.id_crf=crf.id and crf.section=sc.id order by irp.create_date desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}	
  echo "<tr><td>$no.</td>
	<td>$r[crf_no]</td><td>$r[section]</td><td>$r[jenis]</td>
      <td>$r[title]</td> <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td> <td>$label</td>
    <td><a href=javascript:confirmdelete('$aksi?module=irp&act=delete2&id_crf=$r[id_crf]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=irp&act=cetak&id_crf=$r[id_crf] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;
case "view_irpqms":
echo "
<h2>Result Finding IRP Report</h2>
<p>&nbsp;</p>

<table id=example class='pretty dataTable'>
<thead><tr><th width='20'>No</th>
<th width='150'>CRF No</th><th >Section</th><th width='100'>Check Points</th><th >Title</th><th width='80'>Issue Date</th><th width='80'>Deadline</th><th width='80'>Report Date</th><th width='100'>Status</th><th width='100'>Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT irp.id_crf, crf.crf_no, crf.title, sc.section, case crf.jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis, date_format(crf.issue_date,'%d %b %y') as issue_date, 
date_format((crf.issue_date + interval '2' month),'%d %b %y')as deadline, 
date_format(crf.report_date,'%d %b %y') as report_date, 
datediff((crf.issue_date + interval '2' month),current_date()) as selisih,crf.status
from irp , crf, sectioncode sc where irp.id_crf=crf.id and crf.section=sc.id and irp.id_crf='$_POST[id_crf]'");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}	
  echo "<tr><td>$no.</td>
	<td>$r[crf_no]</td><td>$r[section]</td><td>$r[jenis]</td>
      <td>$r[title]</td> <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td> <td>$label</td>
    <td><a href=javascript:confirmdelete('$aksi?module=irp&act=delete2&id_crf=$r[id_crf]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=irp&act=cetak&id_crf=$r[id_crf] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;

case "viewirp":
echo "<table class='pretty dataTable'>
<thead><tr><th width='20'>No</th>
<th width='150'>CRF No</th><th width='100'>Check Points</th><th >Title</th><th width='80'>Issue Date</th><th width='80'>Deadline</th><th width='80'>Report Date</th><th width='100'>Status</th><th width='100'>Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT irp.id_crf, crf.crf_no, crf.title, case crf.jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis, date_format(crf.issue_date,'%d %b %y') as issue_date, 
date_format((crf.issue_date + interval '2' month),'%d %b %y')as deadline, 
date_format(crf.report_date,'%d %b %y') as report_date, 
datediff((crf.issue_date + interval '2' month),current_date()) as selisih,crf.status
from irp , crf where irp.id_crf=crf.id and irp.id_crf='$_POST[id_crf]'");
$no=1;
$r=mysqli_fetch_array($tampil);
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}	
  echo "<tr><td>$no.</td>
	<td>$r[crf_no]</td><td>$r[jenis]</td>
      <td>$r[title]</td> <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td> <td>$label</td>	
  <td><a href='?module=irp&act=editirp&id_crf=$r[id_crf]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=irp&act=delete&id_crf=$r[id_crf]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=irp&act=cetak&id_crf=$r[id_crf] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr> 
        </table>";

break;
// Form Edit irp 
case "tambahirp":
echo "<h2>IRP Report</h2>

<form method=POST action='$aksi?module=irp&act=input1' onsubmit='return validasi2(this)'>
<table cellspacing=10 cellpadding=6>
"; 
include "crf.php";
echo "

<table cellspacing=8 cellpadding=6 cellspacing=0  border=0 >
<tr><td colspan=5></td></tr>     
<tr><td  rowspan=2 valign=top width=25px>A. </td><td width=210px valign=top rowspan=2><input type=checkbox value='y' name=completed> CRF <br>Completed and<br>Implemented<br>Succesfully </td><td colspan=3>Report Content</td></tr>
<tr><td colspan=3><textarea name='content' cols='100' rows='2' ></textarea></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td colspan=5><h2>Implementation check list</h2></td></tr>     
<tr><td colspan=2>Part/WIP/FG</td><td>:  <input type='text' name='part' size='50' value='' ></td>
<td >Completion Date</td><td>: <input type='text' name='completion_date' size='20' value='' ><small>*)dd/mm/yy</small></td></tr> 

<tr><td colspan=2>Test/Verification</td><td>:  <input type='text' name='test' size='50' value='' ></td>
<td>Verification Date</td><td>: <input type='text' name='verification_date' size='20' value='' ><small>*)dd/mm/yy</small></td></tr> 

<tr><td colspan=2>Indication Training Needs</td><td>:  <input type='text' name='need' size='50' value='' ></td>
<td>Training Date</td><td>: <input type='text' name='training_date' size='20' value='' ><small>*)dd/mm/yy</small></td></tr> 
<tr><td>&nbsp;</td></tr>
<tr><td>B.</td><td><input type=checkbox value='y' name=terminated > Terminated </td><td colspan=3>Reason: <input type='text' name='reason' size='90' value='' ></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td valign=top rowspan=2>C.</td><td rowspan=2 valign=top> Problem Encounter </td><td colspan=3>

<input type=radio name='problem' value='n'> No &nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name='problem' value='y' > Yes (Please indicate; attach if required) </td></tr>
<tr><td colspan=3>
Counter Measure(s) : <input type='text' name='counter' size='76' value='' >
</td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td rowspan=3 valign=top>D.</td><td valign=top rowspan=2> Change Control <br>Notification (if applicable)</td>
<td colspan=3> <input type=checkbox value='y' name=approve_date1 > Approved Date&nbsp;&nbsp;&nbsp;&nbsp;: <input type='text' name='approve_date2' size='28' value='' ><small>*)dd/mm/yy</small></td></tr>

<tr><td colspan=3> <input type=checkbox value='y' name=reject_date1 > Rejected Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type='text' name='reject_date2' size='28' value='' ><small>*)dd/mm/yy</small>
</td></tr>
<tr><td >Change Notification <br>Form Reference No</td><td colspan=3> <input type='text' name='reference_no' size='50' value='' ></td></tr>

<tr><td colspan=5>&nbsp;</td>
<tr><td colspan=2 align=center> Reported by: (S/D)</td>";
include "verified.php";
echo"</tr>

<tr><td colspan=2 align=center> Approved by: (S/D)<br>(Reporter dept. / Sect.Head)</td>";
include "approved.php";
echo"</tr>

<tr><td colspan=5>&nbsp;</td>
<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Save IRP'>
<input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
</table>

</form>";
break;




case "nextirp":
if ($_POST['id_crf']==NULL) {
	$id_crf2=$_GET['id_crf'];
} else if ($_GET['id_crf']==NULL) {
	$id_crf2=$_POST['id_crf'];
} 

$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$id_crf2'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Implementation Report</h2>
<form method=POST action='$aksi?module=irp&act=input'  onsubmit='return validasi(this)'>
<input type=hidden name=id_crf value='$r[id]'>

<p>&nbsp;</p>
<div style='font-size:16px'><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  CRF No : <input type=text value='$r[crf_no]' name='crf_no' readonly></strong></div> <p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=1 >
<tr><td colspan=5>Title: <input type=text value='$r[title]' name='title' readonly size=150></td></tr>     
<tr><td rowspan=2>A</td><td rowspan=2><input type=checkbox value='y' name=completed checked> CRF <br>Completed and<br>Implemented<br>Succesfully </td><td colspan=3>Report Content</td></tr>
<tr><td colspan=3><textarea name='content' cols='120' rows='3' ></textarea></td></tr>
<tr><td colspan=5>Implementation check list</td></tr>     
<tr><td colspan=2>Part/WIP/FG</td><td>:  <input type='text' name='part' size='60' value='' ></td>
<td >Completion Date</td><td>: <input type='text' name='completion_date' size='30' value='' ><small>*)dd/mm/yy</small></td></tr> 

<tr><td colspan=2>Test/Verification</td><td>:  <input type='text' name='test' size='60' value='' ></td>
<td>Verification Date</td><td>: <input type='text' name='verification_date' size='30' value='' ><small>*)dd/mm/yy</small></td></tr> 

<tr><td colspan=2>Indication Training Needs</td><td>:  <input type='text' name='need' size='60' value='' ></td>
<td>Training Date</td><td>: <input type='text' name='training_date' size='30' value='' ><small>*)dd/mm/yy</small></td></tr> 
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=1 width=800>
<tr style='align=center'><th rowspan=2 align=center>S/N</th><th rowspan=2 align=center>Document Code</th><th align=center rowspan=2>New RN</th><th rowspan=2 align=center>Issue date</th>
<th colspan=2 align='center'>Document Revised<br> as per CRF</th><th rowspan=2>#Justification / Remark</th><th rowspan=2>Action</th></tr>
<tr><th >Yes</th><th >No#</th></tr>
<tr>
</thead><tbody>";
$tampil2=mysqli_query($conn, "SELECT * from affect_doc where id_crf='$r[id]'");
$no2=1;
while ($r2=mysqli_fetch_array($tampil2)){
  echo "<tr style='align=center'><td>$no2.</td>
	<td>$r2[doc_code]</td>
      <td>$r2[new]</td>
      <td>$r2[issue_date]</td>";
      if ($r2['revised']=='y') {
	  echo "<td><input type=checkbox value='' name='' checked disabled readonly></td><td><input type=checkbox value='' name='' disabled readonly></td>";
	  	} else if ($r2['revised']=='n')  {
			 echo "<td><input type=checkbox value='' name='' disabled readonly></td><td><input type=checkbox value='' name='' checked disabled readonly></td>";
		} else  {
			 echo "<td><input type=checkbox value='' name='' disabled readonly></td><td><input type=checkbox value='' name='' disabled readonly></td>";
		}
      
      echo "
       	<td>$r2[justification]</td>
      
      <td>
		<a href='?module=irp&act=editaffect&id=$r2[id]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=irp&act=deleteaffect&id=$r2[id]&id_crf=$r[id]&jns=edt')><img src='images/hapus.png' alt='hapus' /></a>
	
        </td></tr>";
  $no2++;
}

echo"
<tr><td colspan=7><a href='?module=irp&act=tambahaffect&id_crf=$r[id]'><strong><u>Add Affected Doc</strong></u></a></td></tr>

</tbody></table >
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=1>
<tr><td>B.</td><td><input type=checkbox value='y' name=terminated> Terminated </td><td>Reason: <input type='text' name='reason' size='100' value='' ></td></tr>
<tr><td>C.</td><td><input type=checkbox value='y' name='' checked disabled > Problem Encounter </td><td><input type=radio name='problem' value='n' checked> No <input type=radio name='problem' value='y'> Yes (Please indicate; attach if required) <br>
	Counter Measure(s): <input type='text' name='counter' size='60' value='' >
</td></tr>
<tr><td rowspan=3>D.</td><td colspan=2> Change Control Notification (if applicable)  &nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox value='y' name=approve_date1> Approved Date&nbsp;&nbsp;&nbsp;&nbsp;: <input type='text' name='approve_date2' size='30' value='' ><small>*)dd/mm/yy</small></td></tr>
<tr><td colspan=2> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox value='y' name=reject_date1> Rejected Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type='text' name='reject_date2' size='30' value='' ><small>*)dd/mm/yy</small>
</td></tr>
<tr><td colspan=2>Change Notification Form reference No : <input type='text' name='reference_no' size='60' value='' ></td></tr>

<tr><td colspan=2 align=center> Reported by: (S/D)</td>";
include "verified.php";
echo"</tr>
<tr><td colspan=2 align=center> Approved by: (S/D)<br>(Reporter dept. / Sect.Head)</td>";
include "approved.php";
echo"</tr>
</table>
<p>&nbsp;</p>
";

$str3 = $r['hobi'];
$data3 = explode_trim($str3); 
echo "
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=6> Circulation To: </td></tr>
<tr><td>
<input type=checkbox value='1' name=hobi[]"; if (in_array('1',$data3)){echo " checked";} echo ">QAC 1 <br> <input type=checkbox value='2' name=hobi[]"; if (in_array('2',$data3)){echo " checked";} echo ">QAC2 <br> <input type=checkbox value='3' name=hobi[]"; if (in_array('3',$data3)){echo " checked";} echo ">QAC3 <br> <input type=checkbox value='4' name=hobi[]"; if (in_array('4',$data3)){echo " checked";} echo ">QAC2-2 <br> <input type=checkbox value='5' name=hobi[]"; if (in_array('5',$data3)){echo " checked";} echo ">QAC5 <br> <input type=checkbox value='6' name=hobi[]"; if (in_array('6',$data3)){echo " checked";} echo ">QAIC <br> <input type=checkbox value='7' name=hobi[]"; if (in_array('7',$data3)){echo " checked";} echo ">LAB </td>

<td>
<input type=checkbox value='8' name=hobi[]"; if (in_array('8',$data3)){echo " checked";} echo ">PCT1 <br> <input type=checkbox value='9' name=hobi[]"; if (in_array('9',$data3)){echo " checked";} echo ">PCT2 <br> <input type=checkbox value='10' name=hobi[]"; if (in_array('10',$data3)){echo " checked";} echo ">PCT3 <br> <input type=checkbox value='11' name=hobi[]"; if (in_array('11',$data3)){echo " checked";} echo ">PCT2-2 <br> <input type=checkbox value='12' name=hobi[]"; if (in_array('12',$data3)){echo " checked";} echo ">PCT5 <br> <input type=checkbox value='13' name=hobi[]"; if (in_array('13',$data3)){echo " checked";} echo ">EXT1-3 <br> <input type=checkbox value='14' name=hobi[]"; if (in_array('14',$data3)){echo " checked";} echo ">EXT2-2 

</td>

<td>
<input type=checkbox value='15' name=hobi[]"; if (in_array('15',$data3)){echo " checked";} echo ">TEC1 <br> <input type=checkbox value='16' name=hobi[]"; if (in_array('16',$data3)){echo " checked";} echo ">TEC2 <br> <input type=checkbox value='17' name=hobi[]"; if (in_array('17',$data3)){echo " checked";} echo ">TEC3 <br> <input type=checkbox value='18' name=hobi[]"; if (in_array('18',$data3)){echo " checked";} echo ">TEC2-2 <br> <input type=checkbox value='19' name=hobi[]"; if (in_array('19',$data3)){echo " checked";} echo ">TEC5 <br> <input type=checkbox value='20' name=hobi[]"; if (in_array('20',$data3)){echo " checked";} echo ">EXT1-1 <br> <input type=checkbox value='21' name=hobi[]"; if (in_array('21',$data3)){echo " checked";} echo ">EXT1-2 
</td>

<td>
<input type=checkbox value='22' name=hobi[]"; if (in_array('22',$data3)){echo " checked";} echo ">PED <br> <input type=checkbox value='23' name=hobi[]"; if (in_array('23',$data3)){echo " checked";} echo ">HR/GA <br> <input type=checkbox value='24' name=hobi[]"; if (in_array('24',$data3)){echo " checked";} echo ">ACC <br> <input type=checkbox value='25' name=hobi[]"; if (in_array('25',$data3)){echo " checked";} echo ">PCH <br> <input type=checkbox value='26' name=hobi[]"; if (in_array('26',$data3)){echo " checked";} echo ">BQMS <br> <input type=checkbox value='27' name=hobi[]"; if (in_array('27',$data3)){echo " checked";} echo ">JMS(S)QMS <br> <input type=checkbox value='28' name=hobi[]"; if (in_array('28',$data3)){echo " checked";} echo ">Steam STZ 
</td>

<td>
<input type=checkbox value='34' name=hobi[]"; if (in_array('34',$data3)){echo " checked";} echo ">ETO STZ <br>
<input type=checkbox value='29' name=hobi[]"; if (in_array('29',$data3)){echo " checked";} echo ">STR <br> <input type=checkbox value='30' name=hobi[]"; if (in_array('30',$data3)){echo " checked";} echo ">PPL <br> <input type=checkbox value='31' name=hobi[]"; if (in_array('31',$data3)){echo " checked";} echo ">FAC  <br> <input type=checkbox value='32' name=hobi[]"; if (in_array('32',$data3)){echo " checked";} echo ">CQS <br> <input type=checkbox value='33' name=hobi[]"; if (in_array('33',$data3)){echo " checked";} echo ">MIS <br> <input type=checkbox value='35' name=hobi[]"; if (in_array('35',$data3)){echo " checked";} echo ">EAP <br> <input type=checkbox value='41' name=hobi[]"; if (in_array('41',$data3)){echo " checked";} echo ">PQS 
</td>

<td>
<input type=checkbox value='36' name=hobi[]"; if (in_array('36',$data3)){echo " checked";} echo ">JMSS VCD <br> <input type=checkbox value='37' name=hobi[]"; if (in_array('37',$data3)){echo " checked";} echo ">JMSS PED <br>
 <input type=checkbox value='38' name=hobi[]"; if (in_array('38',$data3)){echo " checked";} echo ">JMSS PCH <br><br>Other Specify <br><br> 
 <input type=checkbox value='39' name=hobi[]"; if (in_array('39',$data3)){echo " checked";} echo ">LKD
 <br> <input type=checkbox value='40' name=hobi[]"; if (in_array('40',$data3)){echo " checked";} echo "> <input type=text name=hobi2 value='$r[hobi2]' ><br>  
</td> </tr>
             
<tr><td colspan=2><input type=submit value=Save class='large orange super button'> <input type=button class='large blue super button' value=Cancel onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;

case "tambahaffect":

echo "<h2>New Affected Document</h2>
<form method=POST action='$aksi?module=irp&act=inputaffect'  onsubmit='return validasidetail(this)' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>

<input type='hidden' name='id_crf' size='20' value='$_GET[id_crf]' >
<input type='hidden' name='jns' size='20' value='$_GET[jns]' >
<tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='60' value='' ></td></tr> 
<tr><td>New RN No.</td><td>: <input type='text' name='new' size='20' value='' > </td></tr>
<tr><td>Issue Date/Obsolete Date</td><td>: <input type='text' name='issue_date' size='30' value='' > <small>*) dd/mm/yy</td></tr>
<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y' > Yes  <input type=radio name='revised' value='n' > No </td></tr>
<tr><td>#Justification/Remark</td><td>: <input type='text' name='justification' size='100' value='' > </td></tr>
<tr><td colspan=2><input type=submit name=submit value=Simpan class='large blue super button'>
<input type=button value=Batal onclick=self.history.back() class='large orange super button'></td></tr>
</table>
</form>";
break;

case "editaffect":

$edit = mysqli_query($conn, "SELECT * FROM affect_doc WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Modify Affected Document</h2>
<form method=POST action='$aksi?module=irp&act=updateaffect'  onsubmit='return validasidetail(this)' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<input type='hidden' name='id' size='20' value='$_GET[id]' >
<input type='hidden' name='id_crf' size='20' value='$r[id_crf]' >
<input type='hidden' name='jns' size='20' value='$_GET[jns]' >

<tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='60' value='$r[doc_code]' ></td></tr> 
<tr><td>New RN No.</td><td>: <input type='text' name='new' size='20' value='$r[new]' > </td></tr>
<tr><td>Issue Date</td><td>: <input type='text' name='issue_date' size='30' value='$r[issue_date]' > <small>*) dd/mm/yy</td></tr>
"; 
if ($r['revised']=='y'){
  echo "<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y' checked> Yes  <input type=radio name='revised' value='n' > No </td></tr>";  
}                      
 
elseif ($r['revised']=='n'){
  echo "<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y' > Yes <input type=radio name='revised' value='n' checked> No </td></tr>";  
}      
else {
  echo "<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y' > Yes <input type=radio name='revised' value='n' > No </td></tr>";  
}                
echo "
<tr><td>#Justification/Remark</td><td>: <input type='text' name='justification' size='100' value='$r[justification]' > </td></tr>
<tr><td colspan=2><input type=submit name=submit value=Simpan class='large blue super button'>
<input type=button value=Batal onclick=self.history.back() class='large orange super button'></td></tr>
</table>
</form>";
break;

case "editaffecto":

$edit = mysqli_query($conn, "SELECT * FROM affect_doc WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Modify Affected Document</h2>
<form method=POST action='$aksi?module=irp&act=updateaffect'  onsubmit='return validasidetail2(this)' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<input type='hidden' name='id' size='20' value='$_GET[id]' >
<input type='hidden' name='id_crf' size='20' value='$r[id_crf]' >
<input type='hidden' name='jns' size='20' value='$_GET[jns]' >

<tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='60' value='$r[doc_code]' readonly ></td></tr> 
<tr><td>New RN No.</td><td>: <input type='text' name='new' size='20' value='$r[new]' readonly> </td></tr>
<tr><td>Issue Date/Obsolote Date</td><td>: <input type='text' name='issue_date' size='30' value='$r[issue_date]' > <small>*) dd/mm/yy</td></tr>
"; 
if ($r['revised']=='y'){
  echo "<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y' checked> Yes <input type=radio name='revised' value='n'> No </td></tr>";  
}                      
 
elseif ($r['revised']=='n'){
  echo "<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y'> Yes <input type=radio name='revised' value='n' checked> No </td></tr>";  
}      
else {
  echo "<tr><td>Doc Revised as per CRF?</td><td>: <input type=radio name='revised' value='y' checked> Yes <input type=radio name='revised' value='n' > No </td></tr>";  
}                
echo "
<tr><td>#Justification/Remark</td><td>: <input type='text' name='justification' size='100' value='$r[justification]' > </td></tr>
<tr><td colspan=2><input type=submit name=submit value=Simpan class='large blue super button'>
<input type=button value=Batal onclick=self.history.back() class='large orange super button'></td></tr>
</table>
</form>";
break;

case "editirp":
$edit = mysqli_query($conn, "SELECT * FROM irp WHERE id_crf='$_GET[id_crf]'");
$r    = mysqli_fetch_array($edit);
$qc = mysqli_query($conn, "SELECT crf_no, title FROM crf WHERE id='$_GET[id_crf]'");
$rc    = mysqli_fetch_array($qc);
$cont =  str_replace("<BR />",'', $r['content']);
echo "<div style='float:right'>CRF NO: $rc[crf_no]</div>
<h2>Title: $rc[title]</h2>


<form method=POST action='$aksi?module=irp&act=update' onsubmit='return validasi2(this)' enctype='multipart/form-data'>
<input type=hidden name='id_crf' value='$r[id_crf]'>
<table cellspacing=8 cellpadding=4 border=0 >
<tr><td colspan=5></td></tr>  
<tr><td  rowspan=2 valign=top width=25px>A. </td><td width=210px valign=top rowspan=2><input type=checkbox value='y' name=completed "; if ($r['completed']=='y'){echo " checked";} echo "> CRF <br>Completed and<br>Implemented<br>Succesfully </td><td colspan=3>Report Content</td></tr>
<tr><td colspan=3><textarea name='content' cols='100' rows='2' >$cont</textarea></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td colspan=5><h2>Implementation check list</h2></td></tr>     
<tr><td colspan=2>Part/WIP/FG</td><td>:  <input type='text' name='part' size='50' value='";
echo htmlentities(htmlspecialchars_decode($r['part']), ENT_QUOTES);
echo "' ></td>
<td >Completion Date</td><td>: <input type='text' name='completion_date' size='20' value='";
echo htmlentities(htmlspecialchars_decode($r['completion_date']), ENT_QUOTES);
echo "' ><small>*)dd/mm/yy</small></td></tr> 

<tr><td colspan=2>Test/Verification</td><td>:  <input type='text' name='test' size='50' value='";
echo htmlentities(htmlspecialchars_decode($r['test']), ENT_QUOTES);
echo "' ></td>
<td>Verification Date</td><td>: <input type='text' name='verification_date' size='20' value='";
echo htmlentities(htmlspecialchars_decode($r['verification_date']), ENT_QUOTES);
echo "' ><small>*)dd/mm/yy</small></td></tr> 

<tr><td colspan=2>Indication Training Needs</td><td>:  <input type='text' name='need' size='50' value='";
echo htmlentities(htmlspecialchars_decode($r['need']), ENT_QUOTES);
echo "' ></td>
<td>Training Date</td><td>: <input type='text' name='training_date' size='20' value='";
echo htmlentities(htmlspecialchars_decode($r['training_date']), ENT_QUOTES);
echo "' ><small>*)dd/mm/yy</small></td></tr> 
<tr><td>&nbsp;</td></tr>
<tr><td>B.</td><td><input type=checkbox value='y' name=terminated "; if ($r['terminate']=='y'){echo " checked";} echo "> Terminated </td><td colspan=3>Reason: <input type='text' name='reason' size='90'  value='";
echo htmlentities(htmlspecialchars_decode($r['reason']), ENT_QUOTES);
echo "'></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td valign=top rowspan=2>C.</td><td rowspan=2 valign=top> Problem Encounter </td><td colspan=3>
"; 
if ($r['problem']=='n'){
  echo "
<input type=radio name='problem' value='n' checked> No &nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name='problem' value='y'> Yes (Please indicate; attach if required)"; }
else if ($r['problem']=='y'){
  echo "
<input type=radio name='problem' value='n'> No &nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name='problem' value='y' checked> Yes (Please indicate; attach if required)"; 
}
else {
  echo "
<input type=radio name='problem' value='n'> No &nbsp;&nbsp;&nbsp;&nbsp;<input type=radio name='problem' value='y' > Yes (Please indicate; attach if required)"; 
}
echo "

 </td></tr>
<tr><td colspan=3>
Counter Measure(s) : <input type='text' name='counter' size='76' value='";
echo htmlentities(htmlspecialchars_decode($r['counter']), ENT_QUOTES);
echo "' >
</td></tr>

<tr><td>&nbsp;</td></tr>
<tr><td rowspan=3 valign=top>D.</td><td valign=top rowspan=2> Change Control <br>Notification (if applicable)</td>
<td colspan=3> <input type=checkbox value='y' name=approve_date1 "; if ($r['approve_date1']=='y'){echo " checked";} echo "> Approved Date&nbsp;&nbsp;&nbsp;&nbsp;: <input type='text' name='approve_date2' size='28' value='";
echo htmlentities(htmlspecialchars_decode($r['approve_date2']), ENT_QUOTES);
echo "' ><small>*)dd/mm/yy</small></td></tr>

<tr><td colspan=3> <input type=checkbox value='y' name=reject_date1 "; if ($r['reject_date1']=='y'){echo " checked";} echo "> Rejected Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type='text' name='reject_date2' size='28' value='";
echo htmlentities(htmlspecialchars_decode($r['reject_date2']), ENT_QUOTES);
echo "' ><small>*)dd/mm/yy</small>
</td></tr>
<tr><td >Change Notification <br>Form Reference No</td><td colspan=3> <input type='text' name='reference_no' size='50' value='";
echo htmlentities(htmlspecialchars_decode($r['reference_no']), ENT_QUOTES);
echo "' ></td></tr>

<tr><td colspan=5>&nbsp;</td></tr>
<tr><td colspan=2 align=center> Reported by: (S/D)</td>";
include "verifiededit.php";
echo"</tr>

<tr><td colspan=2 align=center> Approved by: (S/D)<br>(Reporter dept. / Sect.Head)</td>";
include "approvededit.php";
echo"</tr>

</table>

<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=1 width=900px id=example >
<tr><td rowspan=2 align=center>S/N</td><td rowspan=2 align=center width='150px'>Document Code</td><td align=center rowspan=2>New RN</td><td rowspan=2 align=center>Issue date/Obsolete Date</td>
<td colspan=2 align='center'>Document Revised<br>as per CRF</td><td rowspan=2 align='center' width='300px'>#Justification/<br>Remark</td><td rowspan=2 align='center' width='50px'>Action</td></tr>
<tr><td align='center'>Yes</td><td align='center'>No#</td></tr>
<tr>
";
$tampil2=mysqli_query($conn, "SELECT * FROM affect_doc where id_crf='$r[id_crf]' and status='o'");
$no2=1;
while ($r2=mysqli_fetch_array($tampil2)){
  echo "<tr ><td>$no2.</td>
	<td>$r2[doc_code]</td>
      <td>$r2[new]</td>
      <td>$r2[issue_date]</td>";
      if ($r2['revised']=='y') {
	  echo "<td><input type=checkbox value='' name='' checked disabled></td><td><input type=checkbox value='' name='' disabled></td>";
	  	} else if ($r2['revised']=='n')  {
			 echo "<td><input type=checkbox value='' name='' disabled></td><td><input type=checkbox value='' name='' disabled checked></td>";
		} else  {
			 echo "<td><input type=checkbox value='' name='' disabled></td><td><input type=checkbox value='' name='' disabled ></td>";
		}
      
      echo "
       	<td>$r2[justification]</td>
      
      <td>
		<a href='?module=irp&act=editaffecto&id=$r2[id]&jns=edt'><img src='images/edit.png' alt='edit' /></a> 
	
        </td></tr>";
  $no2++;
}
  echo "
      <tr> 	<td colspan=8>Unders Document not listed on CRF</td>
      
     </tr>";

$tampil3=mysqli_query($conn, "SELECT * from affect_doc where id_crf='$r[id_crf]' and status='p'");
$no3=$no2;
while ($r3=mysqli_fetch_array($tampil3)){
  echo "<tr ><td>$no3.</td>
	<td>$r3[doc_code]</td>
      <td>$r3[new]</td>
      <td>$r3[issue_date]</td>";
      if ($r3['revised']=='y') {
	  echo "<td><input type=checkbox value='' name='' checked disabled></td><td><input type=checkbox value='' name='' disabled></td>";
	  	} else if ($r3['revised']=='n')  {
			 echo "<td><input type=checkbox value='' name='' disabled></td><td><input type=checkbox value='' name='' disabled checked></td>";
		} else  {
			 echo "<td><input type=checkbox value='' name='' disabled></td><td><input type=checkbox value='' name='' disabled ></td>";
		}
      
      echo "
       	<td>$r3[justification]</td>
      
      <td>
		<a href='?module=irp&act=editaffect&id=$r3[id]&jns=edt'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=irp&act=deleteaffect&id=$r3[id]&id_crf=$r3[id_crf]&jns=edt')><img src='images/hapus.png' alt='hapus' /></a>
	
        </td></tr>";
  $no3++;
}
echo"
<tr><td colspan=7><a href='?module=irp&act=tambahaffect&id_crf=$r[id_crf]&jns=edt'><strong><u>Add Affected Doc</strong></u></a></td></tr>
</table >
<p>&nbsp;</p>

";
$str3 = $r['hobi'];
$data3 = explode_trim($str3); 
echo "
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=7> Circulation To: </td></tr>
<tr><td>
<!-- <input type=checkbox value='1' name=hobi[]"; if (in_array('1',$data3)){echo " checked";} echo ">QAC1<br> -->
<input type=checkbox value='2' name=hobi[]"; if (in_array('2',$data3)){echo " checked";} echo ">QAC2<br> 
<input type=checkbox value='3' name=hobi[]"; if (in_array('3',$data3)){echo " checked";} echo ">QAC3<br> 
<input type=checkbox value='4' name=hobi[]"; if (in_array('4',$data3)){echo " checked";} echo ">QAC4<br> 
<input type=checkbox value='5' name=hobi[]"; if (in_array('5',$data3)){echo " checked";} echo ">QAC5<br> 
<input type=checkbox value='6' name=hobi[]"; if (in_array('6',$data3)){echo " checked";} echo ">QAIC<br>
<input type=checkbox value='7' name=hobi[]"; if (in_array('7',$data3)){echo " checked";} echo ">LAB<br>
</td>

<td>
<!-- <input type=checkbox value='8' name=hobi[]"; if (in_array('8',$data3)){echo " checked";} echo ">PCT1<br> -->
<input type=checkbox value='9' name=hobi[]"; if (in_array('9',$data3)){echo " checked";} echo ">PCT2<br> 
<input type=checkbox value='10' name=hobi[]"; if (in_array('10',$data3)){echo " checked";} echo ">PCT3<br> 
<input type=checkbox value='11' name=hobi[]"; if (in_array('11',$data3)){echo " checked";} echo ">PCT4<br> 
<input type=checkbox value='12' name=hobi[]"; if (in_array('12',$data3)){echo " checked";} echo ">PCT5<br> 
<input type=checkbox value='35' name=hobi[]"; if (in_array('35',$data3)){echo " checked";} echo ">PQS<br> 
</td>

<td>
<!-- <input type=checkbox value='20' name=hobi[]"; if (in_array('20',$data3)){echo " checked";} echo ">EXT1<br> -->
<input type=checkbox value='21' name=hobi[]"; if (in_array('21',$data3)){echo " checked";} echo ">EXT2<br>
<input type=checkbox value='13' name=hobi[]"; if (in_array('13',$data3)){echo " checked";} echo ">EXT3<br> 
<input type=checkbox value='14' name=hobi[]"; if (in_array('14',$data3)){echo " checked";} echo ">EXT4<br>
<input type=checkbox value='43' name=hobi[]"; if (in_array('43',$data3)){echo " checked";} echo ">EXT5<br>
<input type=checkbox value='42' name=hobi[]"; if (in_array('42',$data3)){echo " checked";} echo ">INFLATION<br>
</td>

<td>
<!-- <input type=checkbox value='15' name=hobi[]"; if (in_array('15',$data3)){echo " checked";} echo ">TEC1<br> -->
<input type=checkbox value='16' name=hobi[]"; if (in_array('16',$data3)){echo " checked";} echo ">TEC2<br> 
<input type=checkbox value='17' name=hobi[]"; if (in_array('17',$data3)){echo " checked";} echo ">TEC3<br> 
<input type=checkbox value='18' name=hobi[]"; if (in_array('18',$data3)){echo " checked";} echo ">TEC4<br>
<input type=checkbox value='19' name=hobi[]"; if (in_array('19',$data3)){echo " checked";} echo ">TEC5<br> 
<input type=checkbox value='22' name=hobi[]"; if (in_array('22',$data3)){echo " checked";} echo ">PED/MTU<br> 
<input type=checkbox value='41' name=hobi[]"; if (in_array('41',$data3)){echo " checked";} echo ">EAP<br>
</td>

<td>
<input type=checkbox value='24' name=hobi[]"; if (in_array('24',$data3)){echo " checked";} echo ">ACC<br>
<input type=checkbox value='25' name=hobi[]"; if (in_array('25',$data3)){echo " checked";} echo ">PCH<br> 
<input type=checkbox value='26' name=hobi[]"; if (in_array('26',$data3)){echo " checked";} echo ">BQMS<br> 
<input type=checkbox value='27' name=hobi[]"; if (in_array('27',$data3)){echo " checked";} echo ">JMS(S)QMS<br>
<input type=checkbox value='28' name=hobi[]"; if (in_array('28',$data3)){echo " checked";} echo ">Steam STZ<br>
<input type=checkbox value='29' name=hobi[]"; if (in_array('29',$data3)){echo " checked";} echo ">STR<br> 
</td>

<td>
<input type=checkbox value='30' name=hobi[]"; if (in_array('30',$data3)){echo " checked";} echo ">PPL<br> 
<input type=checkbox value='31' name=hobi[]"; if (in_array('31',$data3)){echo " checked";} echo ">FAC<br> 
<input type=checkbox value='32' name=hobi[]"; if (in_array('32',$data3)){echo " checked";} echo ">CQS<br> 
<input type=checkbox value='33' name=hobi[]"; if (in_array('33',$data3)){echo " checked";} echo ">MIS<br> 
<input type=checkbox value='34' name=hobi[]"; if (in_array('34',$data3)){echo " checked";} echo ">ETO STZ<br> 
<input type=checkbox value='23' name=hobi[]"; if (in_array('23',$data3)){echo " checked";} echo ">HR/GA<br> 
 </td>
 <td>
 <input type=checkbox value='36' name=hobi[]"; if (in_array('36',$data3)){echo " checked";} echo ">JMSS VCD<br> 
 <input type=checkbox value='37' name=hobi[]"; if (in_array('37',$data3)){echo " checked";} echo ">JMSS PED<br> 
 <input type=checkbox value='38' name=hobi[]"; if (in_array('38',$data3)){echo " checked";} echo ">JMSS PCH<br><br> Other Specify <br><br>
<input type=checkbox value='39' name=hobi[]"; if (in_array('39',$data3)){echo " checked";} echo ">LKD<br> 
<input type=checkbox value='40' name=hobi[]"; if (in_array('40',$data3)){echo " checked";} echo "> 
<input type=text name=hobi2 value='$r[hobi2]' >
</td> </tr>
             
<tr><td colspan=2><input type=submit value=Update class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;



case "close":
$edit = mysqli_query($conn, "SELECT * FROM irp WHERE id_crf='$_GET[id_crf]'");
$r    = mysqli_fetch_array($edit);
//$qc = mysql_query("SELECT * FROM crf WHERE id='$_GET[id_crf]'");
//$rc    = mysql_fetch_array($qc);

echo "<h2>Close Implementation Report</h2>
<form method=POST action='$aksi?module=irp&act=close'  onsubmit='return validasi(this)'>
<input type=hidden name=id_crf value='$r[id_crf]'>

<table cellspacing=10 cellpadding=6>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='30' value='$r[crf_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='100' value='$r[title]' readonly></td></tr> 
<tr><td><strong><u>Report Date</strong></u></td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2013,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo" <small><strong><u><i>Report Date Must be filled!</i></u></stong></small></td></tr>          

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Close Report'>
	<input type=button class='large blue super button' value=Batal onclick=self.history.back() >
</td></tr>
</table>

</form>

";
break;



}


?>




