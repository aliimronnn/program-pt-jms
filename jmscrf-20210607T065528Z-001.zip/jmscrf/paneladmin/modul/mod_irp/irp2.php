<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.id_crf.value.length < mincar){
       alert("id_crf Masih Kosong!");
       form.id_crf.focus();
       return (false);
   }
   if (form.crf_no.value.length < mincar){
       alert("crf_no Masih Kosong!");
       form.crf_no.focus();
       return (false);
   }
   if (form.title.value.length < mincar){
       alert("title Masih Kosong!");
       form.title.focus();
       return (false);
   }
   if (form.section.value.length < mincar){
       alert("section Masih Kosong!");
       form.section.focus();
       return (false);
   }
   if (form.part.value.length < mincar){
       alert("Part/WIP/FG Masih Kosong!");
       form.part.focus();
       return (false);
   }
   if (form.test.value.length < mincar){
       alert("Test/Verification Masih Kosong!");
       form.test.focus();
       return (false);
   }
   if (form.need.value.length < mincar){
       alert("Indication Training Needs Masih Kosong!");
       form.need.focus();
       return (false);
   }
   var chks14 = document.getElementsByName('terminated[]');
   var hasChecked14 = false;
   for (var i = 0; i < chks14.length; i++){
	    if (chks14[i].checked){
            hasChecked14 = true;
            break;
        }
   } 
   if (hasChecked14 == false){
      alert("Anda belum memilih Terminated");
      return false;
   }       
   if (form.reason.value.length < mincar){
       alert("Reason Masih Kosong!");
       form.reason.focus();
       return (false);
   }
   var radio_val16 = check_radio(form.problem);
   if (radio_val16 === false){
       alert("Anda belum memilih Problem Encounter");
       return false;
   }        
   var chks18 = document.getElementsByName('approve_date1[]');
   var hasChecked18 = false;
   for (var i = 0; i < chks18.length; i++){
	    if (chks18[i].checked){
            hasChecked18 = true;
            break;
        }
   } 
   if (hasChecked18 == false){
      alert("Anda belum memilih Approved Date");
      return false;
   }       
   var chks20 = document.getElementsByName('reject_date1[]');
   var hasChecked20 = false;
   for (var i = 0; i < chks20.length; i++){
	    if (chks20[i].checked){
            hasChecked20 = true;
            break;
        }
   } 
   if (hasChecked20 == false){
      alert("Anda belum memilih Rejected Date");
      return false;
   }       
   if (form.reference_no.value.length < mincar){
       alert("Reference No Masih Kosong!");
       form.reference_no.focus();
       return (false);
   }
   if (form.verified.value.length < mincar){
       alert("Reported By (S/D) Masih Kosong!");
       form.verified.focus();
       return (false);
   }
   if (form.approved.value.length < mincar){
       alert("Approved By (S/D) Masih Kosong!");
       form.approved.focus();
       return (false);
   }
   
   return (true);
}
</script>

<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
function explode_trim($str, $delimiter = ',') {
   if ( is_string($delimiter) ) {
      $str = trim(preg_replace('|\\s*(?:' . preg_quote($delimiter) . ')\\s*|', $delimiter, $str));
      return explode($delimiter, $str);
   }
   return $str;
}
    
$aksi="modul/mod_irp/aksi_irp.php";
switch($_GET[act]){

default:
echo "<h2>List irp</h2>
<input type=button value='Tambah irp' 
onclick=\"window.location.href='?module=irp&act=tambahirp';\">
<table>
<tr><th>No</th>
<th>id_crf</th><th>crf_no</th><th>title</th><th>section</th><th>Report Content</th><th>Part/WIP/FG</th><th>Test/Verification</th><th>Indication Training Needs</th><th>Completion date</th><th>Verification Date</th><th>Training Date</th><th>Terminated</th><th>Reason</th><th>Problem Encounter</th><th>Counter Measure(s)</th><th>Approved Date</th><th>Approved Date</th><th>Rejected Date</th><th>Rejected Date</th><th>Reference No</th><th>Reported By (S/D)</th><th>Approved By (S/D)</th><th>Aksi</th></tr>";

//paging
$batas   = 10;
$halaman = $_GET['halaman'];
if(empty($halaman)){
    $posisi  = 0;
    $halaman = 1;
}
else{
    $posisi = ($halaman-1) * $batas;
    } 
$tampil=mysql_query("SELECT * FROM irp LIMIT $posisi,$batas");
$no=$posisi+1;
while ($r=mysql_fetch_array($tampil)){
  echo "<tr><td>$no.</td>
	<td>$r[id_crf]</td>
      	<td>$r[crf_no]</td>
      	<td>$r[title]</td>
      	<td>$r[section]</td>
      	<td>$r[content]</td>
      	<td>$r[part]</td>
      	<td>$r[test]</td>
      	<td>$r[need]</td>
      	<td>$r[completion_date]</td>
      	<td>$r[verification_date]</td>
      	<td>$r[training_date]</td>
      	<td>$r[terminated]</td>
      	<td>$r[reason]</td>
      	<td>$r[problem]</td>
      	<td>$r[counter]</td>
      	<td>$r[approve_date1]</td>
      	<td>$r[approve_date2]</td>
      	<td>$r[reject_date1]</td>
      	<td>$r[reject_date2]</td>
      	<td>$r[reference_no]</td>
      	<td>$r[verified]</td>
      	<td>$r[approved]</td>
        <td><a href='?module=irp&act=editirp&id=$r[id]'>Edit</a> | 
        <a href=javascript:confirmdelete('$aksi?module=irp&act=delete&id=$r[id]')>Hapus</a>
        </td></tr>";
  $no++;
}
echo "</table>";
$tampil2 = mysql_query("SELECT * FROM irp");
$jmldata = mysql_num_rows($tampil2);
$jmlhal  = ceil($jmldata/$batas);

echo "<div class=paging>";
// Link ke halaman sebelumnya (previous)
if($halaman > 1){
   $prev=$halaman-1;
   echo "<span class=prevnext><a href=$_SERVER[PHP_SELF]?module=irp&halaman=$prev>Prev</a></span> ";
}
else{
   echo "<span class=disabled>Prev</span> ";
}
// Tampilkan link halaman 1,2,3 ...
for($i=1;$i<=$jmlhal;$i++)
if ($i != $halaman){
   echo " <a href=$_SERVER[PHP_SELF]?module=irp&halaman=$i>$i</a> ";
}
else{
   echo " <span class=current>$i</span> ";
}
// Link kehalaman berikutnya (Next)
if($halaman < $jmlhal){
  $next=$halaman+1;
  echo "<span class=prevnext><a href=$_SERVER[PHP_SELF]?module=irp&halaman=$next>Next</a></span>";
}
else{
  echo "<span class=disabled>Next</span>";
}
echo "</div>";
break;

// Form Tambah irp
case "tambahirp":
echo "<h2>Tambah irp</h2>
<form method=POST action='$aksi?module=irp&act=input'  onsubmit='return validasi(this)'>
<table>
<tr><td>id_crf</td><td>: <input type='text' name='id_crf' size='20' value='' ></td></tr>                
<tr><td>crf_no</td><td>: <input type='text' name='crf_no' size='20' value='' ></td></tr>                
<tr><td>title</td><td>: <input type='text' name='title' size='20' value='' ></td></tr>                
<tr><td>section</td><td>: <input type='text' name='section' size='20' value='' ></td></tr>                
<tr><td>Report Content</td><td>: <textarea name='content' cols='40' rows='5' ></textarea></td></tr>                
<tr><td>Part/WIP/FG</td><td>: <input type='text' name='part' size='60' value='' ></td></tr>                
<tr><td>Test/Verification</td><td>: <input type='text' name='test' size='60' value='' ></td></tr>                
<tr><td>Indication Training Needs</td><td>: <input type='text' name='need' size='60' value='' ></td></tr>                
<tr><td>Completion date</td><td>: ";
combotgl(1,31,'tgl_completion_date',$tgl_skrg);
combonamabln(1,12,'bln_completion_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_completion_date',$thn_sekarang); 
echo"</td></tr>
<tr><td>Verification Date</td><td>: ";
combotgl(1,31,'tgl_verification_date',$tgl_skrg);
combonamabln(1,12,'bln_verification_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_verification_date',$thn_sekarang); 
echo"</td></tr>
<tr><td>Training Date</td><td>: ";
combotgl(1,31,'tgl_training_date',$tgl_skrg);
combonamabln(1,12,'bln_training_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_training_date',$thn_sekarang); 
echo"</td></tr>
<tr><td>Terminated</td><td>:	 <input type=checkbox value='y' name=terminated[]>Terminated  </td></tr>
<tr><td>Reason</td><td>: <input type='text' name='reason' size='100' value='' ></td></tr>                
<tr><td>Problem Encounter</td><td>:  <input type=radio name='problem' value='n'> No <input type=radio name='problem' value='y'> Yes (Please indicate; attach if required) </td></tr> 
<tr><td>Counter Measure(s)</td><td>: <input type='text' name='counter' size='60' value='' ></td></tr>                
<tr><td>Approved Date</td><td>:	 <input type=checkbox value='y' name=approve_date1[]>Approved Date  </td></tr>
<tr><td>Approved Date</td><td>: ";
combotgl(1,31,'tgl_approve_date2',$tgl_skrg);
combonamabln(1,12,'bln_approve_date2',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_approve_date2',$thn_sekarang); 
echo"</td></tr>
<tr><td>Rejected Date</td><td>:	 <input type=checkbox value='y' name=reject_date1[]>Rejected Date  </td></tr>
<tr><td>Rejected Date</td><td>: ";
combotgl(1,31,'tgl_reject_date2',$tgl_skrg);
combonamabln(1,12,'bln_reject_date2',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_reject_date2',$thn_sekarang); 
echo"</td></tr>
<tr><td>Reference No</td><td>: <input type='text' name='reference_no' size='60' value='' ></td></tr>                
<tr><td>Reported By (S/D)</td><td>: <input type='text' name='verified' size='60' value='' ></td></tr>                
<tr><td>Approved By (S/D)</td><td>: <input type='text' name='approved' size='60' value='' ></td></tr>                
<tr><td colspan=2><input type=submit name=submit value=Simpan>
<input type=button value=Batal onclick=self.history.back()></td></tr>
</table>
</form>";
break;

// Form Edit irp 
case "editirp":
$edit = mysql_query("SELECT * FROM irp WHERE id='$_GET[id]'");
$r    = mysql_fetch_array($edit);

echo "<h2>Edit irp</h2>
<form method=POST action='$aksi?module=irp&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table>
<tr><td>id_crf</td><td>: <input type='text' name='id_crf' size='20' value='$r[id_crf]' ></td></tr>                
<tr><td>crf_no</td><td>: <input type='text' name='crf_no' size='20' value='$r[crf_no]' ></td></tr>                
<tr><td>title</td><td>: <input type='text' name='title' size='20' value='$r[title]' ></td></tr>                
<tr><td>section</td><td>: <input type='text' name='section' size='20' value='$r[section]' ></td></tr>                
<tr><td>Report Content</td><td>: <textarea name='content' cols='40' rows='5' >$r[content]</textarea></td></tr>                
<tr><td>Part/WIP/FG</td><td>: <input type='text' name='part' size='60' value='$r[part]' ></td></tr>                
<tr><td>Test/Verification</td><td>: <input type='text' name='test' size='60' value='$r[test]' ></td></tr>                
<tr><td>Indication Training Needs</td><td>: <input type='text' name='need' size='60' value='$r[need]' ></td></tr>                
<tr><td>Completion date</td><td>: ";
$get_tgl2=substr("$r[completion_date]",8,2);
combotgl(1,31,'tgl_completion_date',$get_tgl2);
$get_bln2=substr("$r[completion_date]",5,2);
combonamabln(1,12,'bln_completion_date',$get_bln2);
$get_thn2=substr("$r[completion_date]",0,4);
combothn(2010,$thn_sekarang,'thn_completion_date',$get_thn2);
echo "</td></tr>                                                       
<tr><td>Verification Date</td><td>: ";
$get_tgl2=substr("$r[verification_date]",8,2);
combotgl(1,31,'tgl_verification_date',$get_tgl2);
$get_bln2=substr("$r[verification_date]",5,2);
combonamabln(1,12,'bln_verification_date',$get_bln2);
$get_thn2=substr("$r[verification_date]",0,4);
combothn(2010,$thn_sekarang,'thn_verification_date',$get_thn2);
echo "</td></tr>                                                       
<tr><td>Training Date</td><td>: ";
$get_tgl2=substr("$r[training_date]",8,2);
combotgl(1,31,'tgl_training_date',$get_tgl2);
$get_bln2=substr("$r[training_date]",5,2);
combonamabln(1,12,'bln_training_date',$get_bln2);
$get_thn2=substr("$r[training_date]",0,4);
combothn(2010,$thn_sekarang,'thn_training_date',$get_thn2);
echo "</td></tr>                                                       
            
<tr><td>Terminated</td><td>:	
";
$str14 = $r['terminated'];
$data14 = explode_trim($str14); 
echo " <input type=checkbox value='y' name='terminated[]'"; if (in_array('y',$data14)){echo "checked";} echo ">Terminated 
 </td></tr>
                        <tr><td>Reason</td><td>: <input type='text' name='reason' size='100' value='$r[reason]' ></td></tr>                
"; 
if ($r[problem]=='n'){
  echo "<tr><td>Problem Encounter</td>     <td> : <input type=radio name='problem' value='n' checked> No <input type=radio name='problem' value='y' > Yes (Please indicate; attach if required)   </td></tr>";  
}                      
 
elseif ($r[problem]=='y'){
  echo "<tr><td>Problem Encounter</td>     <td> : <input type=radio name='problem' value='n' > No <input type=radio name='problem' value='y' checked> Yes (Please indicate; attach if required)   </td></tr>";  
}                      
echo "<tr><td>Counter Measure(s)</td><td>: <input type='text' name='counter' size='60' value='$r[counter]' ></td></tr>                
            
<tr><td>Approved Date</td><td>:	
";
$str18 = $r['approve_date1'];
$data18 = explode_trim($str18); 
echo " <input type=checkbox value='y' name='approve_date1[]'"; if (in_array('y',$data18)){echo "checked";} echo ">Approved Date 
 </td></tr>
                        <tr><td>Approved Date</td><td>: ";
$get_tgl2=substr("$r[approve_date2]",8,2);
combotgl(1,31,'tgl_approve_date2',$get_tgl2);
$get_bln2=substr("$r[approve_date2]",5,2);
combonamabln(1,12,'bln_approve_date2',$get_bln2);
$get_thn2=substr("$r[approve_date2]",0,4);
combothn(2010,$thn_sekarang,'thn_approve_date2',$get_thn2);
echo "</td></tr>                                                       
            
<tr><td>Rejected Date</td><td>:	
";
$str20 = $r['reject_date1'];
$data20 = explode_trim($str20); 
echo " <input type=checkbox value='y' name='reject_date1[]'"; if (in_array('y',$data20)){echo "checked";} echo ">Rejected Date 
 </td></tr>
                        <tr><td>Rejected Date</td><td>: ";
$get_tgl2=substr("$r[reject_date2]",8,2);
combotgl(1,31,'tgl_reject_date2',$get_tgl2);
$get_bln2=substr("$r[reject_date2]",5,2);
combonamabln(1,12,'bln_reject_date2',$get_bln2);
$get_thn2=substr("$r[reject_date2]",0,4);
combothn(2010,$thn_sekarang,'thn_reject_date2',$get_thn2);
echo "</td></tr>                                                       
<tr><td>Reference No</td><td>: <input type='text' name='reference_no' size='60' value='$r[reference_no]' ></td></tr>                
<tr><td>Reported By (S/D)</td><td>: <input type='text' name='verified' size='60' value='$r[verified]' ></td></tr>                
<tr><td>Approved By (S/D)</td><td>: <input type='text' name='approved' size='60' value='$r[approved]' ></td></tr>                
<tr><td colspan=2><input type=submit value=Update>
<input type=button value=Batal onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
}
?>
