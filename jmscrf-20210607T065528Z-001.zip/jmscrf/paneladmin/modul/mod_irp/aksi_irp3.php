<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET[module];
  $act=$_GET[act];
  
  $id_crf = htmlentities($_POST['id_crf']);
  $crf_no = htmlentities($_POST['crf_no']);
  $title = htmlentities($_POST['title']);
  //$section = htmlentities($_POST['section']);
  $completed = htmlentities($_POST['completed']);
 $report_date=$_POST['thn_issue_date'].'-'.$_POST['bln_issue_date'].'-'.$_POST['tgl_issue_date'];
  	$terminated = htmlentities($_POST['terminated']);
   $reason = htmlentities($_POST['reason']);
  $content = $_POST['content'];
  $part = htmlentities($_POST['part']);
  $test = htmlentities($_POST['test']);
  $need = htmlentities($_POST['need']);
  $completion_date=htmlentities($_POST['completion_date']);
  $verification_date=htmlentities($_POST['verification_date']);
  $training_date=htmlentities($_POST['training_date']);
  
  $reason = htmlentities($_POST['reason']);
  $problem = htmlentities($_POST['problem']);
  $counter = htmlentities($_POST['counter']);
  
  $approve_date1 = htmlentities($_POST['approve_date1']);
  $approve_date2 = htmlentities($_POST['approve_date2']);
  $reject_date1=htmlentities($_POST['reject_date1']);
  $reject_date2=htmlentities($_POST['reject_date2']);
  $reference_no = htmlentities($_POST['reference_no']);
  $verified = htmlentities($_POST['verified']);
  $approved = htmlentities($_POST['approved']);
  
  $doc_code=htmlentities($_POST['doc_code']);
  $new=htmlentities($_POST['new']);
  $issue_date = htmlentities($_POST['issue_date']);
  $revised = htmlentities($_POST['revised']);
  $justification = htmlentities($_POST['justification']);

	 if (!empty($_POST['hobi'])){
       $p_hobi = $_POST['hobi'];
       $hobi=implode(',',$p_hobi);
  }
  $hobi2 = htmlentities($_POST['hobi2']);
  
  if ($module=='irp' AND $act=='input1'){
  	        mysql_query("INSERT INTO irp (id_crf,crf_no,title,section,create_date,hobi,hobi2) VALUES ('$id_crf', '$crf_no', '$title', '$_SESSION[section]',DATE(now()),'$_POST[hobii]',upper('$_POST[hobii2]'))");
 
     header('location:../../index.php?module=irp&act=editirp&id_crf='.$id_crf);
            
  }
  
  if ($module=='irp' AND $act=='input'){
  	        mysql_query("INSERT INTO irp VALUES ('$id_crf', '$crf_no', '$title', '$_SESSION[section]',DATE(now()),null,'$completed', '$content', '$part', '$test', '$need', '$completion_date', '$verification_date', '$training_date', '$terminated', '$reason', '$problem', '$counter', '$approve_date1', '$approve_date2', '$reject_date1', '$reject_date2', '$reference_no', '$verified', '$approved', '$hobi', upper('$hobi2'))");
 
     header('location:../../index.php?module='.$module);
            
  }
  
   
  elseif ($module=='irp' AND $act=='update'){ 
          
    mysql_query("UPDATE irp SET 
					completed = '$completed',
					content = '$content',
					part = '$part',
					test = '$test',
					need = '$need',
					completion_date = '$completion_date',
					verification_date = '$verification_date',
					training_date = '$training_date',
					terminate= '$terminated',
					reason = '$reason',
					problem = '$problem',
					counter = '$counter',
					approve_date1 = '$approve_date1',
					approve_date2 = '$approve_date2',
					reject_date1 = '$reject_date1',
					reject_date2 = '$reject_date2',
					reference_no = '$reference_no',
					verified = '$verified',
					approved = '$approved',
					hobi = '$hobi',
					hobi2 = upper('$hobi2')                                       
                          WHERE id_crf = '$_POST[id_crf]'");
    
    header('location:../../index.php?module='.$module);
  }
  
  
   elseif ($module=='irp' AND $act=='close'){ 
          
    mysql_query("UPDATE irp SET 
					report_date = '$report_date'                              
                          WHERE id_crf = '$_POST[id_crf]'");
    mysql_query("UPDATE crf SET 
					report_date = '$report_date', status='3'                             
                          WHERE id= '$_POST[id_crf]'");
    
    header('location:../../index.php?module='.$module);
  }
    else if ($module=='irp' AND $act=='inputaffect'){
  	        mysql_query("INSERT INTO affect_doc (id_crf,doc_code,new,issue_date,revised,justification) VALUES('$id_crf','$doc_code',
					'$new','$issue_date','$revised','$justification')");
	if ($_POST['jns']=='edt'){
		header('location:../../index.php?module=irp&act=editirp&id_crf='.$_POST['id_crf']);
	} else {
		 header('location:../../index.php?module=irp&act=nextirp&id_crf='.$_POST['id_crf']);    
	}
					
                 
  }
   else if ($module=='irp' AND $act=='updateaffect'){
  	        mysql_query("update affect_doc set doc_code='$doc_code',new='$new',issue_date='$issue_date',revised='$revised',justification='$justification'    WHERE id = '$_POST[id]'");
  	
  	if ($_POST['jns']=='edt'){
		header('location:../../index.php?module=irp&act=editirp&id_crf='.$_POST['id_crf']);
	} else {
		 header('location:../../index.php?module=irp&act=nextirp&id_crf='.$_POST['id_crf']);    
	}
     
       
  }
  // Delete irp  
  elseif ($module=='irp' AND $act=='delete'){
            
      mysql_query("DELETE FROM irp WHERE id_crf = '$_GET[id_crf]'");
      header('location:../../index.php?module='.$module);
            
  }
  elseif ($module=='irp' AND $act=='delete2'){
            
      mysql_query("DELETE FROM irp WHERE id_crf = '$_GET[id_crf]'");
      header('location:../../index.php?module=irp&act=irp_qms');
            
  }
  
  else if ($module=='irp' AND $act=='deleteaffect'){
  	        mysql_query("DELETE FROM affect_doc  WHERE id = '$_GET[id]'");
  	
  	if ($_POST['jns']=='edt'){
		header('location:../../index.php?module=irp&act=editirp&id_crf='.$_GET['id_crf']);
	} else {
		 header('location:../../index.php?module=irp&act=nextirp&id_crf='.$_GET['id_crf']);    
	}
     
       
  }
  
  else if ($module=='irp' AND $act=='cetak') {
	include"cetak2.php";

}
  
  }
?>
