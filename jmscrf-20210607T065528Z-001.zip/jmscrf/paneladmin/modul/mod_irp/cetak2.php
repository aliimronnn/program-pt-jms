<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");


$sql=mysql_query("select *from irp where id_crf='$_GET[id_crf]'");
$e=mysql_fetch_array($sql);
$qkode= mysql_query("select *from doc_code where dokumen= 'irp'");
$rkode=mysql_fetch_array($qkode);
//$qcrf=mysql_query("select *from crf where id='$e[id_crf]'");
//$rcrf=mysql_fetch_array($qcrf);
$html = 
'
<html>
				<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:11 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20;margin-top: 1 cm; margin-bottom: 0.3 cm;margin-right:-20; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:8 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
				
<body>
 <div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>
<table border=1 width="740px" cellpadding="0" cellspacing="0">
<tr><td height="15" valign="middle" >Title : '.$e[title].'</td></tr>
</table>

<table border=1 width="720px" cellpadding="0" cellspacing="0">
<tr><td style="font-size:12px" height="15" valign="middle" colspan=8><strong>PART I (Must be completed) Choose ( <input type=checkbox style="width:20px;" name="cus_approval" value="y" checked> ) relevant box(es)</strong></td></tr>
<tr><td valign="top" rowspan=2 width="20" align="center" valign=top>A. </td><td valign=top rowspan=2 width="70" ><input type=checkbox style="width:20px;" name="cus_approval" value="y" checked>CRF <br>Completed and<br>Implemented<br>Succesfully </td><td colspan=6 valign="middle" >Report Content</td></tr>

<tr><td colspan=6 valign="top" height="30">'.$e[content].'</td></tr>
<tr><td height="15" valign="center" colspan=8><strong>Implementation Check List</strong></td></tr>
<tr><td height="15" valign="center"  colspan=7>Part/WIP/FG : '.$e[part].'</td><td width="200">Completion Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[completion_date].'</td></tr>
<tr><td  height="15" valign="center"  colspan=7>Test/Verification : '.$e[test].'</td><td width="200">Test Verification Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[verification_date].'</td></tr>
<tr><td height="15" valign="center"  colspan=7>Indication Training needs : '.$e[need].'</td><td width="150">Training Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[training_date].'</td></tr>
<tr><td height="15" valign="center" colspan=8><strong>Affected Document and Data</strong></td></tr>
<tr ><td rowspan=2>S/N</td><td colspan=2 rowspan=2  align="center">Document Code</td><td rowspan=2 align="center" width=30>New<br>RN</td><td rowspan=2  align="center">Issue Date</td><td colspan=2 align="center">Document revised as<br>per CRF?</td><td rowspan=2 align="center">#Justification / Remark</td></tr>
<tr><td width="45"  align="center">Yes</td><td width="45" height="15"  align="center">No#</td></tr>

';
//<tr><td height="15"></td><td colspan=2></td><td></td><td></td><td></td><td></td><td></td></tr>
 	$no=1;
	$detail=mysql_query("select * from affect_doc where id_crf= '$e[id_crf]'");
	while($d=mysql_fetch_array($detail)){
	$html.='   <tr ><td height="15" align=center>'.$no.'.</td>
        <td colspan="2">'.$d[doc_code].'</td>
        <td>'.$d['new'].'</td>
        <td >'.$d[issue_date].'</td>';
        
          if ($d[revised]=='y') {
	 $html.='<td><input type=checkbox value="" name="" checked></td><td><input type=checkbox value="" name=""></td>';
	  	} else if ($d[revised]=='n')  {
		 $html.='<td><input type=checkbox value="" name=""></td><td><input type=checkbox value="" name="" checked ></td>';
		} else  {
		 $html.='<td><input type=checkbox value="" name=""></td><td><input type=checkbox value="" name="" ></td>';
		} 
		 $html.='
        <td >'.$d[justification].'</td>
        </tr>';
        $no++;
	}
	$html.='


<tr><td>B</td><td ><input type=checkbox value="" style="width:20px;"'; if ($e['terminate']=='y'){ $html.=' checked';}  $html.='>Terminated</td><td colspan=6>Reason : '.$e['reason'].'</td></tr>


<tr><td height="20" valign="top"><br>C </td><td valign="middle"><input type=checkbox value="" checked style="width:20px;" > Problems<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Encounter :
</td><td colspan=6>';
if ($e['problem']=='y') {
	$html.='
	<input type=checkbox value="" style="width:20px;" > No <br>
	<input type=checkbox value="" style="width:20px;" checked > Yes (Please indicate; attach if required)<br>
	';
} else  {
	$html.='
	<input type=checkbox value="" style="width:20px;" checked> No <br>
	<input type=checkbox value="" style="width:20px;"> Yes (Please indicate; attach if required)<br>
	';
}
$html.='
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Counter Measure(s): '.$e['counter'].'<br>
</td></tr>

<tr><td valign=top><br>D</td><td valign=middle colspan=7>Change Control Notification (if applicable)&nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox value="" style="width:20px;"'; if ($e['approve_date1']=='y'){ $html.=' checked';}  $html.='> Approved Date : <u>'.$e[approve_date2].'</u> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox value="" style="width:20px;"'; if ($e['reject_date1']=='y'){ $html.=' checked';}  $html.='> Rejected Date : <u>'.$e[reject_date2].'</u> <br>
	Change Notification Form reference No : <u>'.$e[reference_no].'</u><br><br>
</td></tr>
<tr><td valign=top><br>E</td><td colspan=7>Product Risk Assessment (QMS Judgement) <br>
Are there any known risk with respect to Risk Management Plan/FMEA? &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox value="" style="width:20px;" > Yes <input type=checkbox value="" style="width:20px;" > No <input type=checkbox value="" style="width:20px;" > NA <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;If Yes, Please state Ref. No : <u>________________________</u>  
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox value="" style="width:20px;" > Yes <input type=checkbox value="" style="width:20px;" > No <input type=checkbox value="" style="width:20px;" > NA <br>
Is the risk acceptable? (Rationale to be indicated)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Reviewer
<br>
Remarks <br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;_____________________<br>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QMS Controller and above<br><br>
</td></tr>

</table>


<p style="font-size:10px">
> *Delete whichever not applicable<br>
> Blank column shall be strike off or indicate "Nil" or "NA"  
</p>

<div>&nbsp;</div>
<table border=1 width="730px" style="font-size: 8px;padding-left:0px;padding-top:0px;" cellpadding="0" cellspacing="0">
<tr>
<td> 
<table width="730px" style="font-size: 8px;padding-left:0px;padding-top:0px;" cellpadding="0" cellspacing="0">
<tr><td colspan=6>Circulation To: </td></tr>
<tr><td>	
';
$str3 = $e[hobi];
$data3 = explode(",",$str3); 
$html.=' 
 <input type="checkbox" style="width:20px;"'; if (in_array("1",$data3)){$html.='checked';} $html.='> QAC 1 <br>
 <input type="checkbox" style="width:20px;"'; if (in_array("2",$data3)){ $html.='checked';}  $html.='> QAC2 <br>
 <input type="checkbox" style="width:20px;"'; if (in_array("3",$data3)){ $html.='checked';}  $html.='> QAC3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("4",$data3)){ $html.='checked';}  $html.='> QAC2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("5",$data3)){ $html.='checked';}  $html.='> QAC5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("6",$data3)){ $html.='checked';}  $html.='> QAIC <br>
 <input type=checkbox style="width:20px;"'; if (in_array("7",$data3)){ $html.='checked';}  $html.='> LAB <br></td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("8",$data3)){ $html.='checked';}  $html.='> PCT1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("9",$data3)){ $html.='checked';}  $html.='> PCT2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("10",$data3)){ $html.='checked';}  $html.='> PCT3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("11",$data3)){ $html.='checked';}  $html.='> PCT2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("12",$data3)){ $html.='checked';}  $html.='> PCT5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("13",$data3)){ $html.='checked';}  $html.='> EXT1-3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("14",$data3)){ $html.='checked';}  $html.='> EXT2-2 <br></td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("15",$data3)){ $html.='checked';}  $html.='> TEC1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("16",$data3)){ $html.='checked';}  $html.='> TEC2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("17",$data3)){ $html.='checked';}  $html.='> TEC3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("18",$data3)){ $html.='checked';}  $html.='> TEC2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("19",$data3)){ $html.='checked';}  $html.='> TEC5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("20",$data3)){ $html.='checked';}  $html.='> EXT1-1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("21",$data3)){ $html.='checked';}  $html.='> EXT1-2 <br></td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("22",$data3)){ $html.='checked';}  $html.='> PED <br>
 <input type=checkbox style="width:20px;"'; if (in_array("23",$data3)){ $html.='checked';}  $html.='> HR/GA <br>
 <input type=checkbox style="width:20px;"'; if (in_array('24',$data3)){ $html.='checked';}  $html.='> ACC <br>
 <input type=checkbox style="width:20px;"'; if (in_array('25',$data3)){ $html.='checked';}  $html.='> PCH <br>
 <input type=checkbox style="width:20px;"'; if (in_array('26',$data3)){ $html.='checked';}  $html.='> BQMS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('27',$data3)){ $html.='checked';}  $html.='> JMS(S )QMS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('28',$data3)){ $html.='checked';}  $html.='> Steam STZ <br> </td><td><br>
 <input type=checkbox style="width:20px;"'; if (in_array('29',$data3)){ $html.='checked';}  $html.='> STR <br>
 <input type=checkbox style="width:20px;"'; if (in_array('30',$data3)){ $html.='checked';}  $html.='> PPL <br>
 <input type=checkbox style="width:20px;"'; if (in_array('31',$data3)){ $html.='checked';}  $html.='> FAC  <br>
 <input type=checkbox style="width:20px;"'; if (in_array('32',$data3)){ $html.='checked';}  $html.='> CQS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('33',$data3)){ $html.='checked';}  $html.='> MIS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('34',$data3)){ $html.='checked';}  $html.='> ETO STZ <br>
 <input type=checkbox style="width:20px;"'; if (in_array('35',$data3)){ $html.='checked';}  $html.='> PQS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('41',$data3)){ $html.='checked';}  $html.='> EAP </td><td valign=top>
 <br>
 <input type=checkbox style="width:20px;"'; if (in_array('36',$data3)){ $html.='checked';}  $html.='> JMSS VCD <br>
 <input type=checkbox style="width:20px;"'; if (in_array('37',$data3)){ $html.='checked';}  $html.='> JMSS PED <br>
 <input type=checkbox style="width:20px;"'; if (in_array('38',$data3)){ $html.='checked';}  $html.='> JMSS PCH <br>
 <br> Other Specify <br><br>
 <input type=checkbox style="width:20px;"'; if (in_array('39',$data3)){ $html.='checked';}  $html.='> LKD/OM <br>
 <input type=checkbox style="width:20px;"'; if (in_array('40',$data3)){ $html.='checked';}  $html.='> '.$r[hobi2].' <br>
 </td></tr>
           
 </table> </td> </tr>
 </table>
 
</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();

$canvas->page_text(95, 15, "PT. JMS BATAM", "Helvetica-Bold", 10, array(0,0,0));
$canvas->page_text(95, 28, "Blok 210-212, Jalan Beringin, Muka Kuning, Batam 29433, Indonesia", "Helvetica", 8, array (0,0,0));
$canvas->page_text(95, 38, "Cammo Industrial Park, Blok F, No.2, Batam Centre, Batam 29433, Indonesia", "Helvetica", 8, array (0,0,0));
$canvas->page_text(16, 50, "Implementation Report (IRP)", "Helvetica-Bold", 10, array(0,0,0));
$canvas->page_text(425, 50, "  CRF No  : $e[crf_no]", "Helvetica-Bold", 10, array(0,0,0));
//$canvas->page_text(394, 75, " Reporting Date  : ", $font2, 10, array(0,0,0));
$canvas->page_text(16, 800, "S/D : Signature / Date", "Helvetica", 9, array(0,0,0));
$canvas->page_text(295, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", "Helvetica", 9, array(0,0,0));
$canvas->page_text(16, 810, "Doc. Code : $rkode[code1]", "Helvetica", 9, array(0,0,0));
$canvas->page_text(495, 800, "$rkode[code2]", "Helvetica", 9, array(0,0,0));

$dompdf->stream("form.pdf", array("Attachment" => false));
?>