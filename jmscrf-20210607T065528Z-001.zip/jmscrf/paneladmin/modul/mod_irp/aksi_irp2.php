<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  $draft_no = htmlentities($_POST['draft_no']);
  $id_draf = htmlentities($_POST['id_draf']);
  $section=htmlentities($_POST['section']);
  //$issue_date=htmlentities($_POST['issu_date']);
  $title = htmlentities($_POST['title']);
  $product = htmlentities($_POST['product']);
  $prod_desc = htmlentities($_POST['prod_desc']);
  $prod_code = htmlentities($_POST['prod_code']);
  $prod_lot = htmlentities($_POST['prod_lot']);
  $prod_qty = htmlentities($_POST['prod_qty']);
  $dev_periode = htmlentities($_POST['dev_periode']);
  $problem_encounter = htmlentities($_POST['problem_encounter']);
  $counter_measure = htmlentities($_POST['counter_measure']);
  $plan = htmlentities($_POST['plan']);
  $hobi = htmlentities($_POST['hobi']);
  
 /* $risk = htmlentities($_POST['risk']);
  $risk_refno = htmlentities($_POST['risk_refno']);
  $risk_remark = htmlentities($_POST['risk_remark']);
  $patient_rmp = htmlentities($_POST['patient_rmp']);
  $health_rmp = htmlentities($_POST['health_rmp']);
  $justifi_rep = htmlentities($_POST['justifi_rep']);
  $verified2 = htmlentities($_POST['verified2']);
  $required = htmlentities($_POST['required']);
  $required_remark = htmlentities($_POST['required_remark']);
  $fillby1 = htmlentities($_POST['fillby1']);
  $fillby2 = htmlentities($_POST['fillby2']);
  $fill_others = htmlentities($_POST['fill_others']);
  $fill_remark = htmlentities($_POST['fill_remark']);
  $approved3 = htmlentities($_POST['approved3']);
  $remark3 = htmlentities($_POST['remark3']);*/

  // Input draf
  if ($module=='deviation' AND $act=='input'){
  	        mysql_query("INSERT INTO deviation(id_draf,
  	        		draf_no,
  	        		title,
  	        		section,
  	        		product,
					prod_desc,
					prod_code,
					prod_lot,
					prod_qty,
					dev_periode,
					problem_encounter,
					counter_measure,
					plan,					
					hobi)
                                VALUES('$id_draf',
                    '$draft_no',
                    '$title',
                    '$section',
					'$product',
					'$prod_desc',
					'$prod_code',
					'$prod_lot',
					'$prod_qty',
					'$dev_periode',
					'$problem_encounter',
					'$counter_measure',
					'$plan',
					'$hobi')");
     header('location:../../index.php?module='.$module);
            
  }
  
  // Update draf  
  elseif ($module=='deviation' AND $act=='update'){ 
          
    mysql_query("UPDATE deviation SET  id_draf= '$id_draf',
  	        		draf_no='$draft_no',
  	        		title= '$title',
  	        		section= '$section',
  	        		product='$product',
					prod_desc='$prod_desc',
					prod_code='$prod_code',
					prod_lot='$prod_lot',
					prod_qty='$prod_qty',
					dev_periode='$dev_periode',
					problem_encounter='$problem_encounter',
					counter_measure='$counter_measure',
					plan='$plan',					
					hobi='$hobi'				                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);
  }
    
    
  // Delete draf  
  elseif ($module=='deviation' AND $act=='delete'){
            
      mysql_query("DELETE FROM deviation WHERE id = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  }
  else if ($module=='deviation' AND $act=='cetak') {
	include"cetak.php";
	
}
  }
?>
