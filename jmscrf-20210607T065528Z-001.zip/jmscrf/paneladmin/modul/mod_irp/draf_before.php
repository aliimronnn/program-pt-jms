<script>
function confirmdelete(delUrl) {
   if (confirm("Anda yakin ingin menghapus?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.title.value.length < mincar){
       alert("Title Masih Kosong!");
       form.title.focus();
       return (false);
   }         
  /**
   if (form.current_dev.value.length < mincar){
       alert("Current Masih Kosong!");
       form.current_dev.focus();
       return (false);
   }
 
   if (form.reason.value.length < mincar){
       alert("Reason Masih Kosong!");
       form.reason.focus();
       return (false);
   }         
   if (form.prod_desc.value.length < mincar){
       alert("prod_desc Masih Kosong!");
       form.prod_desc.focus();
       return (false);
   }
 
   if (form.dev_periode.value.length < mincar){
       alert("dev_periode Masih Kosong!");
       form.dev_periode.focus();
       return (false);
   }
   if (form.remark_inst.value.length < mincar){
       alert("remark_inst Masih Kosong!");
       form.remark_inst.focus();
       return (false);
   }         
   var radio_val15 = check_radio(form.cus_approval);
   if (radio_val15 === false){
       alert("Anda belum memilih cus_approval");
       return false;
   }        
   if (form.cus_app_ket.value.length < mincar){
       alert("cus_app_ket Masih Kosong!");
       form.cus_app_ket.focus();
       return (false);
   }
   var chks17 = document.getElementsByName('idr_num[]');
   var hasChecked17 = false;
   for (var i = 0; i < chks17.length; i++){
	    if (chks17[i].checked){
            hasChecked17 = true;
            break;
        }
   } 
   if (hasChecked17 == false){
      alert("Anda belum memilih idr_num");
      return false;
   }       
   if (form.idr_num_ket.value.length < mincar){
       alert("idr_num_ket Masih Kosong!");
       form.idr_num_ket.focus();
       return (false);
   }
   var chks19 = document.getElementsByName('pdr_num[]');
   var hasChecked19 = false;
   for (var i = 0; i < chks19.length; i++){
	    if (chks19[i].checked){
            hasChecked19 = true;
            break;
        }
   } 
   if (hasChecked19 == false){
      alert("Anda belum memilih pdr_num");
      return false;
   }       
   if (form.pdr_num_ket.value.length < mincar){
       alert("pdr_num_ket Masih Kosong!");
       form.pdr_num_ket.focus();
       return (false);
   }
   var chks21 = document.getElementsByName('sdr_num[]');
   var hasChecked21 = false;
   for (var i = 0; i < chks21.length; i++){
	    if (chks21[i].checked){
            hasChecked21 = true;
            break;
        }
   } 
   if (hasChecked21 == false){
      alert("Anda belum memilih sdr_num");
      return false;
   }       
   if (form.sdr_num_ket.value.length < mincar){
       alert("sdr_num_ket Masih Kosong!");
       form.sdr_num_ket.focus();
       return (false);
   }
   var chks23 = document.getElementsByName('process_dr[]');
   var hasChecked23 = false;
   for (var i = 0; i < chks23.length; i++){
	    if (chks23[i].checked){
            hasChecked23 = true;
            break;
        }
   } 
   if (hasChecked23 == false){
      alert("Anda belum memilih process_dr");
      return false;
   }       
   if (form.process_dr_ket.value.length < mincar){
       alert("process_dr_ket Masih Kosong!");
       form.process_dr_ket.focus();
       return (false);
   }
   var chks25 = document.getElementsByName('other_dr[]');
   var hasChecked25 = false;
   for (var i = 0; i < chks25.length; i++){
	    if (chks25[i].checked){
            hasChecked25 = true;
            break;
        }
   } 
   if (hasChecked25 == false){
      alert("Anda belum memilih other_dr");
      return false;
   }       
   if (form.other_dr_ket.value.length < mincar){
       alert("other_dr_ket Masih Kosong!");
       form.other_dr_ket.focus();
       return (false);
   }
   var radio_val27 = check_radio(form.qa_judge);
   if (radio_val27 === false){
       alert("Anda belum memilih qa_judge");
       return false;
   }        
   var radio_val28 = check_radio(form.pct_judge);
   if (radio_val28 === false){
       alert("Anda belum memilih pct_judge");
       return false;
   }        
   if (form.other_judge.value.length < mincar){
       alert("other_judge Masih Kosong!");
       form.other_judge.focus();
       return (false);
   }
   if (form.initiaded.value =="pilih"){
       alert("Anda belum memilih initiaded");            
       return (false);
   }
   if (form.verified.value =="pilih"){
       alert("Anda belum memilih verified");            
       return (false);
   }
   if (form.approved.value =="pilih"){
       alert("Anda belum memilih approved");            
       return (false);
   }
   var radio_val33 = check_radio(form.risk);
   if (radio_val33 === false){
       alert("Anda belum memilih risk");
       return false;
   }        
   if (form.risk_refno.value.length < mincar){
       alert("risk_refno Masih Kosong!");
       form.risk_refno.focus();
       return (false);
   }
   if (form.risk_remark.value.length < mincar){
       alert("risk_remark Masih Kosong!");
       form.risk_remark.focus();
       return (false);
   }
   var radio_val36 = check_radio(form.patient_rmp);
   if (radio_val36 === false){
       alert("Anda belum memilih patient_rmp");
       return false;
   }        
   var radio_val37 = check_radio(form.health_rmp);
   if (radio_val37 === false){
       alert("Anda belum memilih health_rmp");
       return false;
   }        
   var radio_val38 = check_radio(form.justifi_rep);
   if (radio_val38 === false){
       alert("Anda belum memilih justifi_rep");
       return false;
   }        
   if (form.verified2.value.length < mincar){
       alert("verified2 Masih Kosong!");
       form.verified2.focus();
       return (false);
   }
   var radio_val40 = check_radio(form.required);
   if (radio_val40 === false){
       alert("Anda belum memilih required");
       return false;
   }        
   if (form.required_remark.value.length < mincar){
       alert("required_remark Masih Kosong!");
       form.required_remark.focus();
       return (false);
   }         
   var radio_val42 = check_radio(form.fillby1);
   if (radio_val42 === false){
       alert("Anda belum memilih fillby1");
       return false;
   }        
   var radio_val43 = check_radio(form.fillby2);
   if (radio_val43 === false){
       alert("Anda belum memilih fillby2");
       return false;
   }        
   if (form.fill_others.value.length < mincar){
       alert("fill_others Masih Kosong!");
       form.fill_others.focus();
       return (false);
   }
   if (form.fill_remark.value.length < mincar){
       alert("fill_remark Masih Kosong!");
       form.fill_remark.focus();
       return (false);
   }         
   if (form.approved3.value.length < mincar){
       alert("approved3 Masih Kosong!");
       form.approved3.focus();
       return (false);
   }
   if (form.remark3.value.length < mincar){
       alert("remark3 Masih Kosong!");
       form.remark3.focus();
       return (false);
   }  **/     
   
   return (true);
}
</script>

<?php
//session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
function explode_trim($str, $delimiter = ',') {
   if ( is_string($delimiter) ) {
      $str = trim(preg_replace('|\\s*(?:' . preg_quote($delimiter) . ')\\s*|', $delimiter, $str));
      return explode($delimiter, $str);
   }
   return $str;
}
    
$aksi="modul/mod_draf/aksi_draf.php";
switch($_GET[act]){

default:
echo "<h2>List Draf</h2>
<p>&nbsp;</p>
<input type=button  class='large orange super button' value='Tambah Draf' 
onclick=\"window.location.href='?module=draf&act=tambahdraf';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>Draf No</th><th>Issue Date</th><th>Title</th><th>Aksi</th></tr></thead><tbody>";


$tampil=mysql_query("SELECT * FROM draf");
$no=1;
while ($r=mysql_fetch_array($tampil)){
	$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>$no.</td>
	<td>$r[draft_no]</td>
      	<td>$tggl</td>
      	<td>$r[title]</td>
    <td><a href='?module=draf&act=editdraf&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=draf&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=draf&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;


//ini adalah inputan sebelumnya
//<tr><td>6.</td><td>Customer Approval</td><td><input type=radio name='cus_approval' value='y'> Yes (Sales co-ordinates with customer and feedback) SLS Acknowledge (S/D)</br> <input type=radio name='cus_approval' value='n'> No </br><input type='text' name='cus_app_ket' size='50' value='' ></td><td><textarea name='cus_approval_at' cols='20' rows='3' ></textarea></td></tr>

// Form Tambah draf
case "tambahdraf":
echo "<h2>Add New Draff</h2>
<form method=POST action='$aksi?module=draf&act=input'  onsubmit='return validasi(this)'>

<table cellspacing=8 cellpadding=4>
<tr><td>Draf No</td><td>: <input type='text' name='draft_no' size='100' value='' ></td></tr>                
<tr><td>Create Date</td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2013,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo"</td></tr>
<tr><td>Title</td><td>: <input type='text' name='title' size='100' value='' ></td></tr>                
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=1>
<tr>
<th width=40>No</th><th width=200>Check Points</th><th colspan=2>Content</th>
</tr>
<tr><td>1.</td><td valign=top>Deviation Details </br>(Attach if required)</br></br>
(a) Current </br></br>(b) Proposed Deviation)
 </td><td colspan=2><br></br><br>: <input type='text' style='boder:none;' name='current_dev' size='100' value='' >
 		 <br><br>: <input type='text' style='boder:none;' name='proposed_dev' size='100' value='' ></br></br>
 </td></tr>               
<tr><td>2.</td><td>Reason(s): </br>(Attach if required)</td><td colspan=2 valign=top>: <textarea name='reason' cols='102' rows='3' ></textarea></td></tr>                
<tr><td>3.</td><td valign=top>Parts/WIP/FG affected: </br>
(Attach if required) </br></br>
(a) Product Description </br><br>(b) Product Code </br><br>(c) Product Lot </br><br>(d) Product Quantity </td><td colspan=2>	: <input type='text'  name='product' size='100' value='' ><br><br>
	: <input type='text' style='boder:none;' name='prod_desc' size='100' value='' > <br><br>
	: <input type='text' style='boder:none;' name='prod_code' size='100' value='' > <br><br>
	: <input type='text' style='boder:none;' name='prod_lot' size='100' value='' > <br><br>
	: <input type='text' style='boder:none;' name='prod_qty' size='100' value='' > <br><br>
</td></tr> 
              
<tr><td>4.</td><td valign=top>Deviation Period</td><td colspan=2 valign=top>: <input type='text' name='dev_periode' size='100' value='' ></td></tr>             
<tr><td>5.</td><td valign=top>Remarks/Instructions </br>(Attach if required)</td><td colspan=2 valign=top>: <textarea name='remark_inst' cols='102' rows='3' ></textarea></td></tr>                

<tr><td rowspan=5>7.</td><td rowspan=5>Supporting doc./data </td>
<td >
<input type=checkbox value='y' name=idr_num[]> IDR Reference Number</td>
	<td>: <input type='text' name='idr_num_ket' size='63' value='' ></td></tr>
<tr><td> 
<input type=checkbox value='y' name=pdr_num[]> PDR Reference Number </td>
	<td>: <input type='text' name='pdr_num_ket' size='63' value='' ></td> </tr>
<tr><td>
<input type=checkbox value='y' name=sdr_num[]> SDR Reference Number </td>
	<td>: <input type='text' name='sdr_num_ket' size='63' value='' ></td></tr>
<tr><td>
<input type=checkbox value='y' name=process_dr[]> Process DR Reference Number </td>
	<td>: <input type='text' name='process_dr_ket' size='63' value='' ></td></tr>
<tr><td>
<input type=checkbox value='y' name=other_dr[]> Others </td>
	<td>: <input type='text' name='other_dr_ket' size='63' value='' ></td></tr>
</table>

<table cellspacing=8 cellpadding=4>
<tr><td colspan=3>__________________________________________________________________________________________________________________________</td></tr>
<tr><td>A. QA Judgement (QAC/LAB)</td><td>:  <input type=radio name='qa_judge' value='y'> Yes <input type=radio name='qa_judge' value='n'> No </td></tr> 
<tr><td>B. PCT Judgement</td><td>:  <input type=radio name='pct_judge' value='y'> Yes <input type=radio name='pct_judge' value='n'> No </td></tr> 
<tr><td>C. Others</td><td>: <input type='text' name='other_judge' size='50' value='' ></td></tr>                

<tr><td>Initiaded By </br>(S/D)</td><td>: ";
$sql_combobox30 = mysql_query("SELECT * FROM employee");
echo "<select name='initiaded'>
      <option value='' selected>--Pilih--</option>";
while ($r_combobox30=mysql_fetch_array($sql_combobox30)){
 echo "<option value='$r_combobox30[empno]'>$r_combobox30[empno] $r_combobox30[empname]</option>";
}
echo "</select></td></tr>

<td>Verified By </br>(Initiator Dept. Head)</td><td>: ";
$sql_combobox31 = mysql_query("SELECT * FROM employee");
echo "<select name='verified'>
      <option value='' selected>--Pilih--</option>";
while ($r_combobox31=mysql_fetch_array($sql_combobox31)){
 echo "<option value='$r_combobox31[empno]'>$r_combobox31[empno] $r_combobox31[empname]</option>";
}
echo "</select></td></tr>

<td>Approved By </br>(Div Head)</td><td>: ";
$sql_combobox32 = mysql_query("SELECT * FROM employee");
echo "<select name='verified'>
      <option value='' selected>--Pilih--</option>";
while ($r_combobox32=mysql_fetch_array($sql_combobox32)){
 echo "<option value='$r_combobox32[empno]'>$r_combobox32[empno] $r_combobox32[empname]</option>";
}
echo "</select></td></tr>

<tr><td colspan=3>__________________________________________________________________________________________________________________________</td></tr>
<tr><td colspan=2><strong>Risk Assesment (QMS Judgement)</strong></td></tr>

<tr><td>Are there any known risks?</td><td>:  <input type=radio name='risk' value='y'> Yes <input type=radio name='risk' value='n'> No <input type=radio name='risk' value='x'> NA </td><td>Remark : </td></tr> 
<tr><td>If Yes, Please state Ref. No: </td><td>: <input type='text' name='risk_refno' size='60' value='' ></td><td><input type='text' name='risk_remark' size='50' value='' ></td></tr>                

<tr><td rowspan=3>Is Risk Acceptable?</td><td> <input type=radio name='patient_rmp' value='y'> Yes <input type=radio name='patient_rmp' value='n'> No __ Risk to patient wrt RMP</td></tr> 
<tr><td><input type=radio name='health_rmp' value='y'> Yes <input type=radio name='health_rmp' value='n'> No __ Risk to healthcare worker wrt RMP</td><td>Verified by (S/D) (Controller & Above) : </tr> 
<tr><td><input type=radio name='justifi_rep' value='y'> Yes <input type=radio name='justifi_rep' value='n'> No __ Justification report attachment</td>"; include "verified.php"; echo "</tr> 

<tr><td colspan=3>__________________________________________________________________________________________________________________________</td></tr>
<tr><td colspan=3><strong>Is notification required? if yes, please raise deviation control record</strong></td></tr>
<tr><td>To be fill by JMS(B)?</td><td></td><td>To be fill by JMS(S)?</td></tr>
<tr><td><input type=radio name='required' value='y'> Yes <input type=radio name='required' value='n'> No </td><td></td><td><input type=radio name='fillby1' value='y'> Yes, Please specify <input type=radio name='fillby1' value='n'> No </td></tr>
<tr><td></td><td></td><td><input type=radio name='fillby2' value='y'> CQM <input type=radio name='fillby2' value='n'> Others : <input type='text' name='fill_others' size='30' value='' ></td></tr> </td></tr>            

<tr><td colspan=2>Remark : </br></br><textarea name='required_remark' cols='50' rows='3' ></textarea></td><td>Remark : </br></br><textarea name='fill_remark' cols='50' rows='3' ></textarea></td></tr>     
<tr><td colspan=3>__________________________________________________________________________________________________________________________</td></tr>

           
<tr><td colspan=2>Approved By (PD)-Major Issues</td><td >Remarks</td></tr> 
           
<tr>"; include "approved.php"; echo " <td><textarea name='remark3' cols='50' rows='3' ></textarea></td></tr>    
 
          
<tr><td colspan=2><input type=submit name=submit value=Simpan class='large orange super button'>
<input type=button class='large blue super button' value=Batal onclick=self.history.back() ></td></tr>

</table>
</form>";
break;

// Form Edit draf 
case "editdraf":
$edit = mysql_query("SELECT * FROM draf WHERE id='$_GET[id]'");
$r    = mysql_fetch_array($edit);

echo "<h2>Edit draf</h2>
<form method=POST action='$aksi?module=draf&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table>
<tr><td>Draf No</td><td>: <input type='text' name='draft_no' size='20' value='$r[draft_no]' ></td></tr>                
<tr><td>Issue Date</td><td>: ";
$get_tgl2=substr("$r[issue_date]",8,2);
combotgl(1,31,'tgl_issue_date',$get_tgl2);
$get_bln2=substr("$r[issue_date]",5,2);
combobln(1,12,'bln_issue_date',$get_bln2);
$get_thn2=substr("$r[issue_date]",0,4);
combothn(2013,$thn_sekarang,'thn_issue_date',$get_thn2);
echo "</td></tr>                                                       
<tr><td>Title</td><td>: <textarea name='title' cols='40' rows='5' >$r[title]</textarea></td></tr>                
<tr><td>Current</td><td>: <input type='text' name='current_dev' size='20' value='$r[current_dev]' ></td></tr>                
<tr><td>Proposed</td><td>: <input type='text' name='proposed_dev' size='20' value='$r[proposed_dev]' ></td></tr>                
<tr><td>Reason</td><td>: <textarea name='reason' cols='40' rows='5' >$r[reason]</textarea></td></tr>                
<tr><td>prod_desc</td><td>: <input type='text' name='prod_desc' size='20' value='$r[prod_desc]' ></td></tr>                
<tr><td>prod_code</td><td>: <input type='text' name='prod_code' size='20' value='$r[prod_code]' ></td></tr>                
<tr><td>prod_lot</td><td>: <input type='text' name='prod_lot' size='20' value='$r[prod_lot]' ></td></tr>                
<tr><td>prod_qty</td><td>: <input type='text' name='prod_qty' size='20' value='$r[prod_qty]' ></td></tr>                
<tr><td>dev_periode</td><td>: <input type='text' name='dev_periode' size='20' value='$r[dev_periode]' ></td></tr>                
<tr><td>remark_inst</td><td>: <textarea name='remark_inst' cols='40' rows='5' >$r[remark_inst]</textarea></td></tr>                
"; 
if ($r[cus_approval]=='y'){
  echo "<tr><td>cus_approval</td>     <td> : <input type=radio name='cus_approval' value='y' checked> Yes (Sales co-ordinates with customer and feedback) SLS Acknowledge (S/D) <input type=radio name='cus_approval' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[cus_approval]=='n'){
  echo "<tr><td>cus_approval</td>     <td> : <input type=radio name='cus_approval' value='y' > Yes (Sales co-ordinates with customer and feedback) SLS Acknowledge (S/D) <input type=radio name='cus_approval' value='n' checked> No   </td></tr>";  
}                      
echo "<tr><td>cus_app_ket</td><td>: <input type='text' name='cus_app_ket' size='50' value='$r[cus_app_ket]' ></td></tr>                
            
<tr><td>idr_num</td><td>:	
";
$str17 = $r['idr_num'];
$data17 = explode_trim($str17); 
echo " <input type=checkbox value='y' name='idr_num[]'"; if (in_array('y',$data17)){echo "checked";} echo ">IDR Reference Number 
 </td></tr>
                        <tr><td>idr_num_ket</td><td>: <input type='text' name='idr_num_ket' size='50' value='$r[idr_num_ket]' ></td></tr>                
            
<tr><td>pdr_num</td><td>:	
";
$str19 = $r['pdr_num'];
$data19 = explode_trim($str19); 
echo " <input type=checkbox value='y' name='pdr_num[]'"; if (in_array('y',$data19)){echo "checked";} echo ">PDR Reference Number 
 </td></tr>
                        <tr><td>pdr_num_ket</td><td>: <input type='text' name='pdr_num_ket' size='50' value='$r[pdr_num_ket]' ></td></tr>                
            
<tr><td>sdr_num</td><td>:	
";
$str21 = $r['sdr_num'];
$data21 = explode_trim($str21); 
echo " <input type=checkbox value='y' name='sdr_num[]'"; if (in_array('y',$data21)){echo "checked";} echo ">SDR Reference Number 
 </td></tr>
                        <tr><td>sdr_num_ket</td><td>: <input type='text' name='sdr_num_ket' size='50' value='$r[sdr_num_ket]' ></td></tr>                
            
<tr><td>process_dr</td><td>:	
";
$str23 = $r['process_dr'];
$data23 = explode_trim($str23); 
echo " <input type=checkbox value='y' name='process_dr[]'"; if (in_array('y',$data23)){echo "checked";} echo ">Process DR Reference Number 
 </td></tr>
                        <tr><td>process_dr_ket</td><td>: <input type='text' name='process_dr_ket' size='50' value='$r[process_dr_ket]' ></td></tr>                
            
<tr><td>other_dr</td><td>:	
";
$str25 = $r['other_dr'];
$data25 = explode_trim($str25); 
echo " <input type=checkbox value='y' name='other_dr[]'"; if (in_array('y',$data25)){echo "checked";} echo ">Others 
 </td></tr>
                        <tr><td>other_dr_ket</td><td>: <input type='text' name='other_dr_ket' size='50' value='$r[other_dr_ket]' ></td></tr>                
"; 
if ($r[qa_judge]=='y'){
  echo "<tr><td>qa_judge</td>     <td> : <input type=radio name='qa_judge' value='y' checked> Yes <input type=radio name='qa_judge' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[qa_judge]=='n'){
  echo "<tr><td>qa_judge</td>     <td> : <input type=radio name='qa_judge' value='y' > Yes <input type=radio name='qa_judge' value='n' checked> No   </td></tr>";  
}                      
 
if ($r[pct_judge]=='y'){
  echo "<tr><td>pct_judge</td>     <td> : <input type=radio name='pct_judge' value='y' checked> Yes <input type=radio name='pct_judge' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[pct_judge]=='n'){
  echo "<tr><td>pct_judge</td>     <td> : <input type=radio name='pct_judge' value='y' > Yes <input type=radio name='pct_judge' value='n' checked> No   </td></tr>";  
}                      
echo "<tr><td>other_judge</td><td>: <input type='text' name='other_judge' size='50' value='$r[other_judge]' ></td></tr>                
<tr><td>initiaded</td><td>:";
$sql_combobox30 = mysql_query("SELECT * FROM employee");
echo "<select name='initiaded'>
      <option value='pilih'>--Pilih--</option>";
while ($r_combobox30=mysql_fetch_array($sql_combobox30)){
 if ($r['initiaded'] == $r_combobox30['empno']){
     echo "<option value='$r_combobox30[empno]' selected>$r_combobox30[empname]</option>";
 }
 else {
     echo "<option value='$r_combobox30[empno]'>$r_combobox30[empname]</option>";
 }
}
echo "</select></td></tr>
<tr><td>verified</td><td>:";
$sql_combobox31 = mysql_query("SELECT * FROM employee");
echo "<select name='verified'>
      <option value='pilih'>--Pilih--</option>";
while ($r_combobox31=mysql_fetch_array($sql_combobox31)){
 if ($r['verified'] == $r_combobox31['empno']){
     echo "<option value='$r_combobox31[empno]' selected>$r_combobox31[empname]</option>";
 }
 else {
     echo "<option value='$r_combobox31[empno]'>$r_combobox31[empname]</option>";
 }
}
echo "</select></td></tr>
<tr><td>Approved</td><td>:";
$sql_combobox32 = mysql_query("SELECT * FROM employee");
echo "<select name='approved'>
      <option value='pilih'>--Pilih--</option>";
while ($r_combobox32=mysql_fetch_array($sql_combobox32)){
 if ($r['approved'] == $r_combobox32['empno']){
     echo "<option value='$r_combobox32[empno]' selected>$r_combobox32[empname]</option>";
 }
 else {
     echo "<option value='$r_combobox32[empno]'>$r_combobox32[empname]</option>";
 }
}
echo "</select></td></tr>
"; 
if ($r['risk']=='y'){
  echo "<tr><td>risk</td>     <td> : <input type=radio name='risk' value='y' checked> Yes <input type=radio name='risk' value='n' > No <input type=radio name='risk' value='x' > NA   </td></tr>";  
}                      
 
elseif ($r['risk']=='n'){
  echo "<tr><td>risk</td>     <td> : <input type=radio name='risk' value='y' > Yes <input type=radio name='risk' value='n' checked> No <input type=radio name='risk' value='x' > NA   </td></tr>";  
}                      
 
elseif ($r['risk']=='x'){
  echo "<tr><td>risk</td>     <td> : <input type=radio name='risk' value='y' > Yes <input type=radio name='risk' value='n' > No <input type=radio name='risk' value='x' checked> NA   </td></tr>";  
}                      
echo "<tr><td>risk_refno</td><td>: <input type='text' name='risk_refno' size='20' value='$r[risk_refno]' ></td></tr>                
<tr><td>risk_remark</td><td>: <input type='text' name='risk_remark' size='20' value='$r[risk_remark]' ></td></tr>                
"; 
if ($r[patient_rmp]=='y'){
  echo "<tr><td>patient_rmp</td>     <td> : <input type=radio name='patient_rmp' value='y' checked> Yes <input type=radio name='patient_rmp' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[patient_rmp]=='n'){
  echo "<tr><td>patient_rmp</td>     <td> : <input type=radio name='patient_rmp' value='y' > Yes <input type=radio name='patient_rmp' value='n' checked> No   </td></tr>";  
}                      
 
if ($r[health_rmp]=='y'){
  echo "<tr><td>health_rmp</td>     <td> : <input type=radio name='health_rmp' value='y' checked> Yes <input type=radio name='health_rmp' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[health_rmp]=='n'){
  echo "<tr><td>health_rmp</td>     <td> : <input type=radio name='health_rmp' value='y' > Yes <input type=radio name='health_rmp' value='n' checked> No   </td></tr>";  
}                      
 
if ($r[justifi_rep]=='y'){
  echo "<tr><td>justifi_rep</td>     <td> : <input type=radio name='justifi_rep' value='y' checked> Yes <input type=radio name='justifi_rep' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[justifi_rep]=='n'){
  echo "<tr><td>justifi_rep</td>     <td> : <input type=radio name='justifi_rep' value='y' > Yes <input type=radio name='justifi_rep' value='n' checked> No   </td></tr>";  
}                      
echo "<tr><td>verified2</td><td>: <input type='text' name='verified2' size='20' value='$r[verified2]' ></td></tr>                
"; 
if ($r[required]=='y'){
  echo "<tr><td>required</td>     <td> : <input type=radio name='required' value='y' checked> Yes <input type=radio name='required' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[required]=='n'){
  echo "<tr><td>required</td>     <td> : <input type=radio name='required' value='y' > Yes <input type=radio name='required' value='n' checked> No   </td></tr>";  
}                      
echo "<tr><td>required_remark</td><td>: <textarea name='required_remark' cols='40' rows='5' >$r[required_remark]</textarea></td></tr>                
"; 
if ($r[fillby1]=='y'){
  echo "<tr><td>fillby1</td>     <td> : <input type=radio name='fillby1' value='y' checked> Yes, Please specify <input type=radio name='fillby1' value='n' > No   </td></tr>";  
}                      
 
elseif ($r[fillby1]=='n'){
  echo "<tr><td>fillby1</td>     <td> : <input type=radio name='fillby1' value='y' > Yes, Please specify <input type=radio name='fillby1' value='n' checked> No   </td></tr>";  
}                      
 
if ($r[fillby2]=='y'){
  echo "<tr><td>fillby2</td>     <td> : <input type=radio name='fillby2' value='y' checked> CQM <input type=radio name='fillby2' value='n' > Others   </td></tr>";  
}                      
 
elseif ($r[fillby2]=='n'){
  echo "<tr><td>fillby2</td>     <td> : <input type=radio name='fillby2' value='y' > CQM <input type=radio name='fillby2' value='n' checked> Others   </td></tr>";  
}                      
echo "<tr><td>fill_others</td><td>: <input type='text' name='fill_others' size='20' value='$r[fill_others]' ></td></tr>                
<tr><td>fill_remark</td><td>: <textarea name='fill_remark' cols='40' rows='5' >$r[fill_remark]</textarea></td></tr>                
<tr><td>approved3</td><td>: <input type='text' name='approved3' size='20' value='$r[approved3]' ></td></tr>                
<tr><td>remark3</td><td>: <textarea name='remark3' cols='40' rows='5' >$r[remark3]</textarea></td></tr>                
<tr><td colspan=2><input type=submit value=Update>
<input type=button value=Batal onclick=self.history.back()></td></tr>
</table>
</form>";
break;

}
}

?>




