<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];

  $section          = $conn->real_escape_string(htmlentities(@$_POST['section']));
  $doc_code         = $conn->real_escape_string(htmlentities(@$_POST['doc_code']));
  $doc_title        = $conn->real_escape_string(htmlentities(@$_POST['doc_title']));
  $category         = $conn->real_escape_string(htmlentities(@$_POST['category']));
  $issued_hardcopy  = $conn->real_escape_string(htmlentities(@$_POST['issued_hardcopy']));
  $issued_softcopy  = $conn->real_escape_string(htmlentities(@$_POST['issued_softcopy']));
  $obsolete_date    = $conn->real_escape_string(htmlentities(@$_POST['obsolete_date']));
  $refer_to         = $conn->real_escape_string(htmlentities(@$_POST['refer_to']));

  $revisi_no        = $conn->real_escape_string(htmlentities(@$_POST['revisi_no']));
  $issue_date       =@$_POST['thn_issue_date'].'-'.@$_POST['bln_issue_date'].'-'.@$_POST['tgl_issue_date'];


  // Input DCM
  if ($module=='dcm' AND $act=='input'){

  mysqli_query($conn, "INSERT INTO dcm(section,doc_code,doc_title,category,issued_hardcopy,issued_softcopy)
  VALUES('$section','$doc_code','$doc_title','$category','$issued_hardcopy','$issued_softcopy')");
  header('location:../../index.php?module='.$module);           
  } 

  // Update DCM  
  elseif ($module=='dcm' AND $act=='update'){ 
          
    mysqli_query($conn, "UPDATE dcm SET  
    			section		       = '$section',
					doc_code         = '$doc_code',
          doc_title        = '$doc_title',
					category         = '$category',
          issued_hardcopy  = '$issued_hardcopy',
					issued_softcopy  = '$issued_softcopy'               
    WHERE id               = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);
  }

  // Update Obsolete DCM  
  elseif ($module=='dcm' AND $act=='updateobsolete'){ 
          
    mysqli_query($conn, "UPDATE dcm SET  
					obsolete_date = '$obsolete_date',
          refer_to      = '$refer_to'              
    WHERE id            = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);  
  }

  // Input Revisi DCM
  if ($module=='dcm' AND $act=='inputrevisi'){

    mysqli_query($conn, "INSERT INTO dcm_revisi(doc_code,revisi_no,issue_date)
    VALUES('$doc_code','$revisi_no','$issue_date')");
    header('location:../../index.php?module=dcm&act=revisidcm&id='.$_POST['id']);           
    } 
  
  // Update Revisi DCM  
  elseif ($module=='dcm' AND $act=='updaterevisi'){ 
          
    mysqli_query($conn, "UPDATE dcm_revisi SET  
					doc_code         = '$doc_code',
          revisi_no        = '$revisi_no',
					issue_date       = '$issue_date'              
    WHERE id_revisi        = '$_POST[id_revisi]'");
    
    header('location:../../index.php?module=dcm&act=revisidcm&id='.$_POST['id']);  
  }

  // Delete Revisi No. DCM  
  elseif ($module=='dcm' AND $act=='deleterevisi'){
            
    mysqli_query($conn, "DELETE FROM dcm_revisi WHERE id_revisi = '$_GET[id_revisi]'");
    header('location:../../index.php?module=dcm&act=revisidcm&id='.$_GET['id']); 
          
  }

  // Delete DCM  
  elseif ($module=='dcm' AND $act=='delete'){
            
    mysqli_query($conn, "DELETE FROM dcm WHERE id = '$_GET[id]'");
    header('location:../../index.php?module=dcm&act=viewdcm');
          
  }
  else if ($module=='dcm' AND $act=='print_dcmall') {
    include"cetak.php";
    
  }










  elseif ($module=='draf' AND $act=='approve'){ 
          
    mysqli_query($conn, "UPDATE draf SET  issue_date = '$issue_date',
					status = '1'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=draf&act=appdraf');
  }
  
    
  elseif ($module=='draf' AND $act=='return'){ 
          
    mysqli_query($conn, "UPDATE draf SET issue_date=null, 
					status = '0'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=draf&act=appdraf');
  }
  // Delete draf  
  elseif ($module=='draf' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM draf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  }
   elseif ($module=='draf' AND $act=='deleteapp'){
            
      mysqli_query($conn, "DELETE FROM draf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module=draf&act=appdraf');
            
  }
  else if ($module=='draf' AND $act=='cetak') {
	include"cetak.php";
	
}
elseif ($module=='draf' AND $act=='close'){ 
          
    mysqli_query($conn, "UPDATE draf SET  report_date = '$issue_date', status='3'
  	        					                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=draf&act=appdraf');
  }
  elseif ($module=='draf' AND $act=='unclose'){ 
          
    mysqli_query($conn, "UPDATE draf SET  report_date = null, status='2'
  	        					                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=draf&act=appdraf');
  } elseif ($module=='draf' AND $act=='unapprove'){ 
          
    mysqli_query($conn, "UPDATE draf SET  issue_date = null, status='0'
  	        					                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=draf&act=appdraf');
  }
  
    else if ($module=='draf' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE draf";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      $draf_no           = $data->val($i, 3);
     // $affedted           = $data->val($i, 3);
     // $affect_doc = htmlentities($affedted);
      $section           = $data->val($i, 2);
      $tit           = $data->val($i, 9);
      $title = htmlentities($tit);
      $dev           = $data->val($i, 10);
      $dev_periode = htmlentities($dev);
      
      $thnn1		   =$data->val($i, 13);
      $blnn1		   =$data->val($i, 14);
      $tgll1		   =$data->val($i, 15);
      $issue_date	= '20'.$thnn1.'-'.$blnn1.'-'.$tgll1;
      
      $thnn		   =$data->val($i, 20);
      $blnn		   =$data->val($i, 21);
      $tgll		   =$data->val($i, 22);
      $report_date	= '20'.$thnn.'-'.$blnn.'-'.$tgll;
      
   	  $remark	   =$data->val($i, 23);
   	  $remark_inst = htmlentities($remark); 
      $status	   = $data->val($i, 24);
      $initiaded	= $data->val($i, 25);
      $no_surat		= $data->val($i, 7);
      $draf_kd		= $data->val($i, 5);
 //      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into draf (draft_no,section,create_date,issue_date,report_date,status,title,dev_periode,
      remark_inst,initiaded,no_surat,draf_kd) values('$draf_no','$section','2015-01-01','$issue_date','$report_date','$status',
      '$title','$dev_periode','$remark_inst',upper('$initiaded'),'$no_surat','$draf_kd')";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=home');
  }
  }
?>
