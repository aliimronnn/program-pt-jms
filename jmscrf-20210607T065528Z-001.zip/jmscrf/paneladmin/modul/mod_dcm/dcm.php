<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
   if (form.doc_code.value.length < mincar){
       alert("Doc Code is still empty!");
       form.title.focus();
       return (false);
   }
   if (form.doc_title.value.length < mincar){
       alert("Doc Title is still empty!");
       form.title.focus();
       return (false);
   }         
  
   if (form.category.value.length < mincar){
       alert("Category Is still empty!");
       form.current_dev.focus();
       return (false);
   }
   return (true);
}
</script>

<?php
function explode_trim($str, $delimiter = ',') {
   if ( is_string($delimiter) ) {
      $str = trim(preg_replace('|\\s*(?:' . preg_quote($delimiter) . ')\\s*|', $delimiter, $str));
      return explode($delimiter, $str);
   }
   return $str;
}
    
$aksi="modul/mod_dcm/aksi_dcm.php";
switch(@$_GET['act']){

default:
echo "
<!--
<form method=POST action='?module=dcm&act=viewdcm' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find DCM</strong></i></td><td>: ";
include "dcm1.php";
echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
-->

<h2>List Document Control Master (All)&nbsp;&nbsp;&nbsp;&nbsp;
<a href=$aksi?module=dcm&act=print_dcmall target=_blank><img src='images/print.png' alt='cetak' /> Print PDF</a>
<a href=$aksi?module=dcm&act=excel_dcmall target=_blank><img src='images/download.png' alt='cetak' /> Download Excel</a></h2>
<p>&nbsp;</p>
<input type=button  class='large orange super button' value='Add New DCM' 
onclick=\"window.location.href='?module=dcm&act=tambahdcm';\"> 
<input type=button  class='large blue super button' value='Insp.Criteria' 
onclick=\"window.location.href='?module=dcm&act=inspcriteria';\">
<input type=button  class='large gray super button' value='MI' 
onclick=\"window.location.href='?module=dcm&act=mi';\">
<input type=button  class='large red super button' value='SOP & QP' 
onclick=\"window.location.href='?module=dcm&act=sopqp';\">
<input type=button  class='large green super button' value='PMPFC' 
onclick=\"window.location.href='?module=dcm&act=pmpfc';\">

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th><th width=20>Section</th>
<th width=150>Doc Code</th><th width=565>Doc Title</th><th width=150>Category</th><th >Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM dcm order by doc_code desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil, MYSQLI_ASSOC)){
	//$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>$no.</td>
  <td>$r[section]</td>
	<td>$r[doc_code]</td>
  <td>$r[doc_title]</td><td>$r[category]</td>
  <td><a href='?module=dcm&act=editdcm&id=$r[id]'><img src='images/edit2.png' alt='edit' /></a> | <a href='?module=dcm&act=revisidcm&id=$r[id]'><img src='images/rev.png' alt='revisi'/></a> | <a href=javascript:confirmdelete('$aksi?module=dcm&act=delete&id=$r[id]')><img src='images/trash.png' alt='hapus' /></a>
  </td></tr>";
  $no++;
}
echo "</table>";

break;

// Form Add New DCM
case "tambahdcm":
  echo "<h2>Add New DCM</h2>
  <form method=POST action='$aksi?module=dcm&act=input' onsubmit='return validasi(this)'>
  <table cellspacing=8 cellpadding=4>
  <tr><td>Section</td><td>: <input type='text' name='section' size='20' value=''></td></tr>
  <tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='30' value=''></td></tr>                
  <tr><td>Doc Title</td><td>: <input type='text' name='doc_title' size='100' value='' ></td></tr>
      <tr>
				<td>Category</td>
				<td> : <select name='category'>
          <option value=''>- Select -</option>
          <option value='Insp.Criteria'>- Insp.Criteria</option>
          <option value='MI'>- MI</option>
          <option value='SOP & QP'>- SOP & QP</option>
          <option value='PMPFC'>- PMPFC</option>
        </select></td>
      </tr>
  </table>
  <p>&nbsp;</p>
  <table cellspacing=8 cellpadding=4 border=0>
  <tr>
  <th width=180>Issued to Sections :</th><th width=200>Hard Copy :</th><th>Soft Copy :</th>
  </tr>
  <tr><td valign=top></td><td> <input type='text' name='issued_hardcopy' size='40' value='' ></td>
  <td> <input type='text' name='issued_softcopy' size='40' value='' ></td>
  </td>
  </tr><br>
  <tr><td colspan=2><input type=submit name=submit value=Save class='large orange super button'>
  <input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
  </table>
  
  </form>";
  break;

// Form Edit DCM
case "editdcm":
$edit = mysqli_query($conn, "SELECT * FROM dcm WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Modify DCM</h2>
<form method=POST action='$aksi?module=dcm&act=update' onsubmit='return validasi(this)'>
<input type=hidden name='id' value='$r[id]'>
<table cellspacing=8 cellpadding=4>
  <tr><td>Section</td><td>: <input type='text' name='section' size='20' value='";
  echo htmlentities(htmlspecialchars_decode($r['section']), ENT_QUOTES);
  echo "'></td></tr>
  <tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='30' value='";
  echo htmlentities(htmlspecialchars_decode($r['doc_code']), ENT_QUOTES);
  echo "' readonly></td></tr>                
  <tr><td>Doc Title</td><td>: <input type='text' name='doc_title' size='100' value='";
  echo htmlentities(htmlspecialchars_decode($r['doc_title']), ENT_QUOTES);
  echo "' ></td></tr>
      <tr>
				<td>Category</td>
				<td> : <select name='category'>
          <option value='";
          echo htmlentities(htmlspecialchars_decode($r['category']), ENT_QUOTES);
          echo "'>- ";
          echo htmlentities(htmlspecialchars_decode($r['category']), ENT_QUOTES);
          echo "</option>
          <option value='Insp.Criteria'>- Insp.Criteria</option>
          <option value='MI'>- MI</option>
          <option value='SOP & QP'>- SOP & QP</option>
          <option value='PMPFC'>- PMPFC</option>
        </select></td>
      </tr>
  </table>
  <p>&nbsp;</p>
  <table cellspacing=8 cellpadding=4 border=0>
  <tr>
  <th width=180>Issued to Sections :</th><th width=200>Hard Copy :</th><th>Soft Copy :</th>
  </tr>
  <tr><td valign=top></td><td> <input type='text' name='issued_hardcopy' size='40' value='";
  echo htmlentities(htmlspecialchars_decode($r['issued_hardcopy']), ENT_QUOTES);
  echo "' ></td>
  <td> <input type='text' name='issued_softcopy' size='40' value='";
  echo htmlentities(htmlspecialchars_decode($r['issued_softcopy']), ENT_QUOTES);
  echo "' ></td>
  </td>
  </tr><br>
  <tr><td colspan=2><input type=submit name=submit value=Update class='large orange super button'>
  <input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
  </table>
</form>";
break;

case "revisidcm":
  $edit = mysqli_query($conn, "SELECT * FROM dcm WHERE id='$_GET[id]'");
  $r    = mysqli_fetch_array($edit);
  
  echo "<h2>Revise DCM</h2>
  <form method=POST action='$aksi?module=dcm&act=updateobsolete' onsubmit='return validasi2(this)'>
  <input type=hidden name='id' value='$r[id]'>
  <table cellspacing=8 cellpadding=4>
  <tr><td>Section</td><td>: <input type='text' name='section' size='20' value='";
  echo htmlentities(htmlspecialchars_decode($r['section']), ENT_QUOTES);
  echo "' readonly></td></tr>
  <tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='30' value='";
  echo htmlentities(htmlspecialchars_decode($r['doc_code']), ENT_QUOTES);
  echo "' readonly></td></tr>                
  <tr><td>Doc Title</td><td>: <input type='text' name='doc_title' size='100' value='";
  echo htmlentities(htmlspecialchars_decode($r['doc_title']), ENT_QUOTES);
  echo "' readonly></td></tr>
      <tr>
				<td>Category</td>
				<td> : <input type='text' name='category' size='10' value='";
        echo htmlentities(htmlspecialchars_decode($r['category']), ENT_QUOTES);
        echo "' readonly></td>
      </tr>
  </table>
  <p>&nbsp;</p>
  <table cellspacing=8 cellpadding=4 border=0>
  <tr>
  <th width=180>Issued to Sections :</th><th width=200>Hard Copy :</th><th>Soft Copy :</th>
  </tr>
  <tr><td valign=top></td><td> <input type='text' name='issued_hardcopy' size='40' value='";
  echo htmlentities(htmlspecialchars_decode($r['issued_hardcopy']), ENT_QUOTES);
  echo "' readonly></td>
  <td> <input type='text' name='issued_softcopy' size='40' value='";
  echo htmlentities(htmlspecialchars_decode($r['issued_softcopy']), ENT_QUOTES);
  echo "' readonly></td>
  </td>
  </tr>
  <tr>
  <th width=180>Obsolete Date :</th><th width=200>Date :</th><th>Refer To :</th>
  </tr>
  <tr><td valign=top></td><td><input type='text' name='obsolete_date' size='20' value='";
  echo htmlentities(htmlspecialchars_decode($r['obsolete_date']), ENT_QUOTES);
  echo "'><small><strong><i> * dd/mm/yyyy</i></stong></small></td>
  <td> <input type='text' name='refer_to' size='30' value='";
  echo htmlentities(htmlspecialchars_decode($r['refer_to']), ENT_QUOTES);
  echo "' <small><strong><i> * leave the form blank if it's not obsolete!</i></stong></small></td>
  </td>
  </tr>
  </table>
  
  <p>&nbsp;</p>
  <table  cellspacing=8 cellpadding=4 border=1 width=900px id=example class='pretty dataTable'>
  <thead><tr><th align=center width='20px'>S/N</th>
  <th align=center width='300px'>Document Code</th>
  <th align=center>Rev. No</th>
  <th align=center>Issue date</th>
  <th rowspan=2 align='center' width='80px'>Action</th></tr>
  </thead><tbody>
  ";
  $tampil2=mysqli_query($conn, "SELECT * FROM dcm_revisi where doc_code='$r[doc_code]' ORDER BY revisi_no");
  $no2=1;
  while ($r2=mysqli_fetch_array($tampil2)){
    $tggl= tgl_indo($r2['issue_date']);
    echo "<tr ><td>$no2.</td>
    <td align=center>$r2[doc_code]</td>
    <td align=center>$r2[revisi_no]</td>
    <td align=center>$tggl</td>  
    <td><a href='?module=dcm&act=editrevisi&id_revisi=$r2[id_revisi]&id=$r[id]'><img src='images/edit2.png' alt='edit' /></a> | <a href=javascript:confirmdelete('$aksi?module=dcm&act=deleterevisi&id_revisi=$r2[id_revisi]&id=$r[id]')><img src='images/trash.png' alt='hapus' /></a>  
    </td></tr>";
    $no2++;
  }
    echo "
  <tr><td colspan=7><a href='?module=dcm&act=addrevisi&doc_code=$r[doc_code]'><strong><u>Add Revise Doc</strong></u></a></td></tr>
  </table ><br>
  <tr><td colspan=2><input type=submit value=Update class='large orange super button'>
  <input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
  </table>
  </form>";
  break;

  // Form Add New Revisi DCM
  case "addrevisi":
    $view = mysqli_query($conn, "SELECT * FROM dcm WHERE doc_code='$_GET[doc_code]'");
    $rev    = mysqli_fetch_array($view);
  echo "<h2>Add New Revise DCM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Document Code : $rev[doc_code]</h2>
  <form method=POST action='$aksi?module=dcm&act=inputrevisi' onsubmit='return validasi(this)'>
  <table cellspacing=8 cellpadding=4>
  <input type='hidden' name='id' size='20' value='$rev[id]'>
  <input type='hidden' name='doc_code' size='20' value='$rev[doc_code]'>
  <tr><td>Rev No.</td><td>: <input type='text' name='revisi_no' size='20' value=''></td></tr>
  <tr><td>Issue Date</td><td>: ";
  combotgl(1,31,'tgl_issue_date',$tgl_skrg);
  combobln(1,12,'bln_issue_date',$bln_sekarang);
  combothn(2010,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
  echo" <small><strong><u><i>Issue Date Must be filled!</i></u></stong></small></td></tr>                
  <br>
  <tr><td colspan=2><input type=submit name=submit value=Save class='large orange super button'>
  <input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
  </table>
  </form>";
  break;

  // Form Edit Revisi DCM
  case "editrevisi":
  $view   = mysqli_query($conn, "SELECT * FROM dcm WHERE id='$_GET[id]'");
  $rev    = mysqli_fetch_array($view);

  $view2  = mysqli_query($conn, "SELECT * FROM dcm_revisi WHERE id_revisi='$_GET[id_revisi]'");
  $rev2   = mysqli_fetch_array($view2);
  echo "<h2>Edit Revision DCM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Document Code : $rev2[doc_code]</h2>
  <form method=POST action='$aksi?module=dcm&act=updaterevisi' onsubmit='return validasi(this)'>
  <table cellspacing=8 cellpadding=4>
  <input type='hidden' name='id' size='20' value='$rev[id]'>
  <input type='hidden' name='id_revisi' size='20' value='$rev2[id_revisi]'>
  <input type='hidden' name='doc_code' size='20' value='$rev2[doc_code]'>
  <tr><td>Rev No.</td><td>: <input type='text' name='revisi_no' size='20' value='";
  echo htmlentities(htmlspecialchars_decode($rev2['revisi_no']), ENT_QUOTES);
  echo "'></td></tr>
  <tr><td>Issue Date</td><td>: ";
  $get_tgl=substr("$rev2[issue_date]",8,2);
  combotgl(1,31,'tgl_issue_date',$get_tgl);
  $get_bln=substr("$rev2[issue_date]",5,2);
  combobln(1,12,'bln_issue_date',$get_bln);
  $get_thn=substr("$rev2[issue_date]",0,4);
  combothn(2010,$thn_sekarang,'thn_issue_date',$get_thn); 
  echo" <small><strong><u><i>Issue Date Must be filled!</i></u></stong></small></td></tr>                
  <br>
  <tr><td colspan=2><input type=submit name=submit value=Update class='large orange super button'>
  <input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
  </table>
  
  </form>";
  break;

  // Form View Insp.Criteria
case "inspcriteria":
  echo "<h2>List Document Control Master (Insp. Criteria)&nbsp;&nbsp;&nbsp;&nbsp;
  <a href=$aksi?module=dcm&act=print_dcmall target=_blank><img src='images/print.png' alt='cetak' /> Print PDF</a>
  <a href=$aksi?module=dcm&act=excel_dcmall target=_blank><img src='images/download.png' alt='cetak' /> Download Excel</a></h2>
  <p>&nbsp;</p>
<input type=button  class='large orange super button' value='Back' 
onclick=\"window.location.href='?module=dcm&act=viewdcm';\"> 

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th><th width=20>Section</th>
<th width=150>Doc Code</th><th width=570>Doc Title</th><th width=150>Category</th><th >Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM dcm WHERE category='Insp.Criteria' order by doc_code desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	//$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>$no.</td>
  <td>$r[section]</td>
	<td>$r[doc_code]</td>
  <td>$r[doc_title]</td><td>$r[category]</td>
  <td><a href='?module=dcm&act=editdcm&id=$r[id]'><img src='images/edit2.png' alt='edit' /></a> | <a href='?module=dcm&act=revisidcm&id=$r[id]'><img src='images/rev.png' alt='revisi'/></a> | <a href=javascript:confirmdelete('$aksi?module=dcm&act=delete&id=$r[id]')><img src='images/trash.png' alt='hapus' /></a>
  </td></tr>";
  $no++;
}
echo "</table>";

break;

// Form View MI
case "mi":
  echo "<h2>List Document Control Master (MI)&nbsp;&nbsp;&nbsp;&nbsp;
  <a href=$aksi?module=dcm&act=print_dcmall target=_blank><img src='images/print.png' alt='cetak' /> Print PDF</a>
  <a href=$aksi?module=dcm&act=excel_dcmall target=_blank><img src='images/download.png' alt='cetak' /> Download Excel</a></h2>
  <p>&nbsp;</p>
<input type=button  class='large orange super button' value='Back' 
onclick=\"window.location.href='?module=dcm&act=viewdcm';\"> 

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th><th width=20>Section</th>
<th width=150>Doc Code</th><th width=570>Doc Title</th><th width=150>Category</th><th >Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM dcm WHERE category='MI' order by doc_code desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	//$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>$no.</td>
  <td>$r[section]</td>
	<td>$r[doc_code]</td>
  <td>$r[doc_title]</td><td>$r[category]</td>
  <td><a href='?module=dcm&act=editdcm&id=$r[id]'><img src='images/edit2.png' alt='edit' /></a> | <a href='?module=dcm&act=revisidcm&id=$r[id]'><img src='images/rev.png' alt='revisi'/></a> | <a href=javascript:confirmdelete('$aksi?module=dcm&act=delete&id=$r[id]')><img src='images/trash.png' alt='hapus' /></a>
  </td></tr>";
  $no++;
}
echo "</table>";

break;

// Form SOP & QP
case "sopqp":
  echo "<h2>List Document Control Master (SOP & QP)&nbsp;&nbsp;&nbsp;&nbsp;
  <a href=$aksi?module=dcm&act=print_dcmall target=_blank><img src='images/print.png' alt='cetak' /> Print PDF</a>
  <a href=$aksi?module=dcm&act=excel_dcmall target=_blank><img src='images/download.png' alt='cetak' /> Download Excel</a></h2>
  <p>&nbsp;</p>
<input type=button  class='large orange super button' value='Back' 
onclick=\"window.location.href='?module=dcm&act=viewdcm';\"> 

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th><th width=20>Section</th>
<th width=150>Doc Code</th><th width=570>Doc Title</th><th width=145>Category</th><th >Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM dcm WHERE category='SOP &amp; QP' order by doc_code desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	//$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>$no.</td>
  <td>$r[section]</td>
	<td>$r[doc_code]</td>
  <td>$r[doc_title]</td><td>$r[category]</td>
  <td><a href='?module=dcm&act=editdcm&id=$r[id]'><img src='images/edit2.png' alt='edit' /></a> | <a href='?module=dcm&act=revisidcm&id=$r[id]'><img src='images/rev.png' alt='revisi'/></a> | <a href=javascript:confirmdelete('$aksi?module=dcm&act=delete&id=$r[id]')><img src='images/trash.png' alt='hapus' /></a>
  </td></tr>";
  $no++;
}
echo "</table>";

break;

// Form PMPFC
case "pmpfc":
  echo "<h2>List Document Control Master (PMPFC)&nbsp;&nbsp;&nbsp;&nbsp;
  <a href=$aksi?module=dcm&act=print_dcmall target=_blank><img src='images/print.png' alt='cetak' /> Print PDF</a>
  <a href=$aksi?module=dcm&act=excel_dcmall target=_blank><img src='images/download.png' alt='cetak' /> Download Excel</a></h2>
  <p>&nbsp;</p>
<input type=button  class='large orange super button' value='Back' 
onclick=\"window.location.href='?module=dcm&act=viewdcm';\"> 

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th><th width=20>Section</th>
<th width=150>Doc Code</th><th width=570>Doc Title</th><th width=150>Category</th><th>Action</th></tr></thead><tbody>";

$tampil=mysqli_query($conn, "SELECT * FROM dcm WHERE category='PMPFC' order by doc_code desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	//$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>$no.</td>
  <td>$r[section]</td>
	<td>$r[doc_code]</td>
  <td>$r[doc_title]</td><td>$r[category]</td>
  <td><a href='?module=dcm&act=editdcm&id=$r[id]'><img src='images/edit2.png' alt='edit' /></a> | <a href='?module=dcm&act=revisidcm&id=$r[id]'><img src='images/rev.png' alt='revisi'/></a> | <a href=javascript:confirmdelete('$aksi?module=dcm&act=delete&id=$r[id]')><img src='images/trash.png' alt='hapus' /></a>
  </td></tr>";
  $no++;
}
echo "</table>";

break;






















case "view_drafapp":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th>
<th width=150>Draf No</th><th width=150>Create Date</th><th width=150>Section</th><th >Title</th><th width=70>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id= $_POST[id_draf]");
$r=mysqli_fetch_array($tampil);
	
$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>1.</td>
	<td>$r[draft_no]</td>
      	<td>$tggl</td>
      		<td>$r[section2]</td>
      	<td>$r[title]</td>
    <td><a href='?module=draf&act=approvedraf&id=$r[id]'><img src='images/approve.png' alt='edit' /></a>|<a href=$aksi?module=draf&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>
</table>";
break;

case "view_drafclose":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th>
<th width=150>Draf No</th><th width=150>Issue Date</th><th width=150>Section</th><th >Title</th><th width=70>Action</th></tr></thead><tbody>";

//|<a href=?module=draf&act=returndraf&id=$r[id]><img src='images/return.png' alt='cetak' /></a>
$tampil=mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id= $_POST[id_draf2]");
$r=mysqli_fetch_array($tampil);
	
$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>1.</td>
	<td>$r[draft_no]</td>
      	<td>$tggl</td>
      		<td>$r[section2]</td>
      	<td>$r[title]</td>
    <td><a href='?module=draf&act=closedraf&id=$r[id]'><img src='images/checked.png' alt='edit' /></a>|<a href=$aksi?module=draf&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>
</table>";
break;

case "closedraf":
$edit = mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Close Deviation Report</h2><br>
<form method=POST action='$aksi?module=draf&act=close'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Draf No</td><td>: <input type='text' name='draft_no' size='30' value='$r[draft_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='140' value='$r[title]' readonly></td></tr> 
<tr><td>Section</td><td>: <input type='text' name='section' size='70' value='$r[section2]' readonly></td></tr> 
<tr><td>&nbsp;</td></tr>
<tr><td><strong><u>Reporting Date</strong></u></td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo" <small><strong><u><i> Report Date Must be filled!</i></u></stong></small></td></tr>          

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Close Report'>
	<input type=button class='large blue super button' value=Batal onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;

case "unclosedraf":
$edit = mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>UnClose Deviation Report</h2><br>
<form method=POST action='$aksi?module=draf&act=unclose'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Draf No</td><td>: <input type='text' name='draft_no' size='30' value='$r[draft_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='140' value='$r[title]' readonly></td></tr> 
<tr><td>Section</td><td>: <input type='text' name='section' size='70' value='$r[section2]' readonly></td></tr> 
<tr><td>&nbsp;</td></tr>
    

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='UnClose Report'>
	<input type=button class='large blue super button' value=Batal onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;

case "unappdraf":
$edit = mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Disapprove DRAF</h2><br>
<form method=POST action='$aksi?module=draf&act=unapprove' onsubmit=''>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Draf No</td><td>: <input type='text' name='draft_no' size='30' value='$r[draft_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='140' value='$r[title]' readonly></td></tr> 
<tr><td>Section</td><td>: <input type='text' name='section' size='70' value='$r[section2]' readonly></td></tr> 
<tr><td>&nbsp;</td></tr>
    

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Disapprove DRAF'>
	<input type=button class='large blue super button' value=Batal onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;


case "view_drafunclose":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th>
<th width=150>Draf No</th><th width=150>Report Date</th><th width=150>Section</th><th >Title</th><th width=70>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id= $_POST[id_draf3]");
$r=mysqli_fetch_array($tampil);
	
$tggl= tgl_indo($r['report_date']);
  echo "<tr><td>1.</td>
	<td>$r[draft_no]</td>
      	<td>$tggl</td>
      		<td>$r[section2]</td>
      	<td>$r[title]</td>
    <td><a href='?module=draf&act=unclosedraf&id=$r[id]'><img src='images/undo1.png' alt='edit' /></a>|<a href=$aksi?module=draf&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>
</table>";
break;


case "view_drafunapp":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th>
<th width=150>Draf No</th><th width=150>Issue Date</th><th width=150>Section</th><th >Title</th><th width=70>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "select d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and 
d.id='$_POST[id_draf33]'");
$r=mysqli_fetch_array($tampil);
	
$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>1.</td>
	<td>$r[draft_no]</td>
      	<td>$tggl</td>
      		<td>$r[section2]</td>
      	<td>$r[title]</td>
    <td><a href='?module=draf&act=unappdraf&id=$r[id]'><img src='images/undo1.png' alt='edit' /></a>|<a href=$aksi?module=draf&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>
</table>";
break;

case "view_drafall":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th width=20>No</th>
<th width=150>Draf No</th><th width=150>Issue Date</th><th width=150>Section</th><th >Title</th><th width=70>Action</th></tr></thead><tbody>";

//|<a href=?module=draf&act=returndraf&id=$r[id]><img src='images/return.png' alt='cetak' /></a>
$tampil=mysqli_query($conn, "SELECT d.*,sc.section as section2 FROM draf d, sectioncode sc where d.section=sc.id and d.id= $_POST[id_draf4]");
$r=mysqli_fetch_array($tampil);
	
$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>1.</td>
	<td>$r[draft_no]</td>
      	<td>$tggl</td>
      		<td>$r[section2]</td>
      	<td>$r[title]</td>
    <td><a href='?module=draf&act=editdraf3&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=draf&act=deleteapp&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=draf&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>
</table>";
break;

case "importdraf":

echo "<h2>Import Status Log DRAF</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=draf&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old DRAF Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2..
  </small></i></strong></td></tr>
<tr><td colspan=2>No Image</td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;

}


?>




