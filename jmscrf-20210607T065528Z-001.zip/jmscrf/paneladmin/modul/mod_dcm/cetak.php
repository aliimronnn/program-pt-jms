<?php
error_reporting(E_ALL);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);


$html = 
'
<html>
<style type="text/css">
            #header { position: fixed; left:0;margin-left:-20;margin-top: -0.7 cm; right: 0px; height: 150px;  text-align: left; }
            body{font-size:12 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
                 margin-left:-15;margin-top: 1 cm; margin-bottom: 0.2 cm;margin-right:-20; }

            tr td{ padding-left:5px;padding-top:1px; font-size:8 pt;}
            tr th{ padding-left:5px;}	
            }
        </style>
    <body>
        <!--<div id="header">
            <img src="../../images/logo-besar.png" alt="" />
        </div>-->
<table border="1" cellspacing=0; cellpadding=0; width="805">
<thead>
<tr style="font-size:14px; font-weight:bold; text-align:center;">
<th rowspan="2">No.</th>
<th rowspan="2">DOCUMENT CODE</th>
<th rowspan="2">DOCUMENT TITLE</th>
<th rowspan="2">ISSUED TO SECTIONS</th>
<th colspan="10">REVISION NO. (R.N), ISSUE DATE / ENFORCEMENT DATE</th>
<th rowspan="2">Obsolete Date</th>
</tr>
<tr style="font-size:12px; font-weight:bold; text-align:center;">
<th>R.N.</th>
<th>I.D.</th>
<th>R.N.</th>
<th>I.D.</th>
<th>R.N.</th>
<th>I.D.</th>
<th>R.N.</th>
<th>I.D.</th>
<th>R.N.</th>
<th>I.D.</th>
</tr>
</thead><tbody>';
$sql=mysqli_query($conn, "SELECT * FROM dcm d LEFT JOIN dcm_revisi dr ON(d.doc_code=dr.doc_code) ORDER BY d.doc_code");
$e=mysqli_fetch_array($sql);
$no=1;
while ($r=mysqli_fetch_array($sql)){
$html.='<tr><td rowspan="2">'.$no.'.</td>
        <td rowspan="2">'.$r['doc_code'].'</td>
        <td rowspan="2" valign="top">'.$r['doc_title'].'</td>
        <td height="25" valign="top">Hard Copy:<br>'.$r['issued_hardcopy'].'</td>
        </tr>
        <tr>
        <td height="25" valign="top">Soft Copy:<br>'.$r['issued_softcopy'].'</td>
        </tr>';
  $no++;
}
$html.='</table>

</body>
</html>';
$dompdf->load_html($html);
$dompdf->set_paper("A4", "landscape");
$dompdf->render();
$canvas = $dompdf->get_canvas();
//$canvas->page_text(95, 28, "PT. JMS BATAM", "helvetica-bold", 14, array(0,0,0));
$canvas->page_text(315, 20, "DOCUMENT CONTROL MASTER LIST", "Helvetica-bold", 13, array(0,0,0));
$canvas->page_text(16, 780, "S/D : Signature / Date", "Helvetica", 8, array(0,0,0));
$canvas->page_text(280, 805, "Page: {PAGE_NUM} of {PAGE_COUNT}", "Helvetica", 8, array(0,0,0));
$dompdf->stream("form.pdf", array("Attachment" => false));
?>