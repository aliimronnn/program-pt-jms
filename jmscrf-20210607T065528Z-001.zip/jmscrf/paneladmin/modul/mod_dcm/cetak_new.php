<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");


$sql=mysql_query("select draft_no,title, current_dev, proposed_dev,reason, product,prod_code, prod_desc, prod_lot, prod_qty,dev_periode, roles1,pic1,schedule1,roles2,pic2,schedule2,roles3,pic3,schedule3,cus_approval, idr_num,idr_num_ket, pdr_num,pdr_num_ket, sdr_num, sdr_num_ket,process_dr,process_dr_ket, other_dr,other_dr_ket, initiaded, verified, approved, hobi , hobi2  from draf where id='$_GET[id]'
");
$e=mysql_fetch_array($sql);
$qkode= mysql_query("select *from doc_code where dokumen= 'draf'");
$rkode=mysql_fetch_array($qkode);
/*$initiaded= mysql_query("select empname  from employee where empno='$e[initiaded]'");
$i=mysql_fetch_array($initiaded);
$verified= mysql_query("select  empname from employee where empno='$e[verified]'");
$v=mysql_fetch_array($verified);
$approved= mysql_query("select empname from employee where empno='$e[approved]'");
$ap=mysql_fetch_array($approved);
$verified2= mysql_query("select  empname from employee where empno='$e[verified2]'");
$v2=mysql_fetch_array($verified2);
$approved3= mysql_query("select empname from employee where empno='$e[approved3]'");
$ap3=mysql_fetch_array($approved3);*/
//$tanggal=tgl_indo($e['issue_date']);
$html = 
'
<html>
				<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.7 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:12 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20;margin-top: 1 cm; margin-bottom: 0.2 cm;margin-right:-20; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:8 pt;}
				tr th{ padding-left:5px;}	
				
					
}

				</style></head>
				
<body>
 <div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>

<div style="font-size:12px"><strong>PART I (Initiator)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Issue Date &nbsp;&nbsp;&nbsp;&nbsp;: </strong></div>

<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td height="25" valign="top" colspan=7>Title : '.$e[title].'</td></tr>
<tr align=center><td  height="20" width="20" >No</td><td width="110">Check Points</td><td width="370" colspan="4">Contents</td><td width= 30>Attm.</td></tr>
<tr><td height="40" valign="top">1. </td><td valign="top">Deviation Details <br>(Attach if required)<br>(a) Current <br>(b) Proposed Deviation<br></td><td valign="top" colspan=4 >(a) '.$e[current_dev].'<br>(b) '.$e[proposed_dev].'</td><td ></td></tr>

<tr><td valign="top">2. </td><td valign="top" height="40" >Reason(s): <br>(Attach if required)<br></td><td valign="top" colspan=4 >'.$e[reason].'</td><td ></td></tr>

<tr><td height="60" valign="top">3. </td><td valign="top">Parts/WIP/FG affected : <br>(Attach if required)<br>
	(a) Product Description<br>
	(b) Product Code<br>
	(c) Product Lot<br>
	(d) Product Quantity <br>
</td><td valign="top" colspan=4 >'.$e[product].' <br>(a) '.$e[prod_desc].' <br>
	(b) '.$e[prod_code].' <br> (c) '.$e[prod_lot].' <br> (d) '.$e[prod_qty].'</td><td ></td></tr>

<tr><td valign="top">4. </td><td valign="top">Deviation Period <br>(Maximum 6 Month)<br></td><td valign="top" colspan=4 >'.$e[dev_periode].'</td><td ></td></tr>

<tr><td valign="top" rowspan=4 >5. </td><td rowspan=4 valign="top" >Roles and Actions/ Instructions</td><td colspan=2 valign="top" >Roles and Actions/ Instructions</td>
<td width="40px">PIC</td><td width="40px">Schedule</td><td rowspan=4></td></tr>
<tr><td colspan=2 height="15px">'.$e[roles1].'</td><td>'.$e[pic1].'</td><td>'.$e[schedule1].'</td></tr>
<tr><td colspan=2 height="15px">'.$e[roles2].'</td><td>'.$e[pic2].'</td><td>'.$e[schedule2].'</td></tr>
<tr><td colspan=2 height="15px">'.$e[roles3].'</td><td>'.$e[pic3].'</td><td>'.$e[schedule3].'</td></tr>

<tr><td valign="top">6. </td><td valign="top">Supporting doc./data: </td><td colspan="4">';
if ($e[idr_num]=='y'){
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" checked>';}

else {
$html.='<input type=checkbox style="width:20px;" name="cus_approval" value="y" >';} 

$html.=' IDR Reference Number &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[idr_num_ket].' <br>';


if ($e[pdr_num]=='y'){
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" checked>';}

else {
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" >';} 

$html.=' PDR Reference Number &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[pdr_num_ket].' <br>';


if ($e[sdr_num]=='y'){
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" checked>';}

else {
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" >';} 

$html.=' SDR Reference Number &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[sdr_num_ket].' <br>';


if ($e[process_dr]=='y'){
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" checked>';}

else {
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" >';} 

$html.=' Process DR Reference Number &nbsp;&nbsp;: '.$e[process_dr_ket].' <br>';


if ($e[other_dr]=='y'){
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" checked>';}

else {
$html.=' <input type=checkbox style="width:20px;" name="cus_approval" value="y" >';} 

$html.=' Others &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '.$e[other_dr_ket].' <br>';

$html.='</td><td></td> </tr>

<tr><td colspan=3 >Initiated By <br><br>&nbsp;S/D : '.$e[initiaded].' </td>
    <td colspan=2>Verified By (Controller )<br><br>&nbsp;S/D : '.$e[verified].' </td>
     <td colspan=2>Approved By (Dept. Head )<br><br>&nbsp;S/D : '.$e[approved].' </td>
     </tr>


</table>


<div align="left" STYLE="font-size:12px"><strong>PART II (Cross Function Judgement Select A /or B)</strong><br>A. QA Judgement (QAC/LAB)</div>  
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td width="150px">QA Judgement</td><td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" >
 Accept &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
 <input type=checkbox style="width:20px;" name="cus_approval" value="y" > Reject, Reason : </td></tr>
 <tr><td valign="top">QA Inspection Method, <br>
 Criteria & Precaution </td> <td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" > * As per normal operation <br><input type=checkbox style="width:20px;" name="cus_approval" value="y" > Other, Please State : </tr>
 <tr><td colspan=2>Agreed By (S/D): <br>(Controller & Above) </td><td> Verified By (S/D): <br> (Department Head/Division Head)</tr>
 </table>
 
 
<div align="left" STYLE="font-size:12px">B. PCT Judgement</div>  
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td width="150px">PCT Judgement</td><td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" >
 Accept &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
 <input type=checkbox style="width:20px;" name="cus_approval" value="y" > Reject, Reason : </td></tr>
 <tr><td valign="top">Production Action/, <br>
 Remark :  </td> <td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" > * As per normal operation <br><input type=checkbox style="width:20px;" name="cus_approval" value="y" > Other, Please State : </tr>
 <tr><td colspan=2>Agreed By (S/D): <br>(Controller & Above) </td><td> Verified By (S/D): <br> (Department Head/Division Head)</tr>
 </table>
<div style="page-break-after:avoid;"></div> 
<div align="left" STYLE="font-size:12px">C. Others :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Judgement</div>  
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td width="150px">Judgement</td><td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" >
 Accept &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
 <input type=checkbox style="width:20px;" name="cus_approval" value="y" > Reject, Reason : </td></tr>
 <tr><td valign="top">Action <br><br>
 Remark :  </td> <td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" > * As per normal operation <br><input type=checkbox style="width:20px;" name="cus_approval" value="y" > Other, Please State : </tr>
 <tr><td colspan=2>Agreed By (S/D): <br>(Controller & Above) </td><td> Verified By (S/D): <br> (Department Head/Division Head)</tr>
 </table>
 <div style="page-break-before: always;"></div>
 <div align="left" STYLE="font-size:12px">D. JMSS Relevant Section Head /Department Head Approval /Acknowledgement, if applicable</div>  
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td  width="180px">QAC</td><td width="180px">PED</td> <td width="180px">LAB</td> <td >Others</td></tr>
<tr><td valign=bottom height="25px" width="150px" >S/D</td><td valign=bottom>S/D</td> <td valign=bottom>S/D</td><td valign=bottom>S/D</td></tr>
<tr><td width="150px">Coordinator:</td><td >Coordinator:</td> <td >Coordinator:</td><td >Coordinator:</td></tr>
<tr><td colspan=4 height="25px" valign=top>Remark: </td></tr>
</table>

<div align="left" STYLE="font-size:12px"><strong>PART III (Risk Assessment)</strong><br>QMS Judgement </div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign=top width="250px">Are there any known risks? <br>
	With respect to Risk Management plan / FMEA? <br> if Yes, please state Ref. No:_____________<br><br>
</td><td   ><input type=checkbox style="width:20px;" name="cus_approval" value="y" > *Yes <br>&nbsp;</td>
<td > <input type=checkbox style="width:20px;" name="cus_approval" value="y" > No <br> To Update *Risk Management Plan and implement CAPA </td>
<td ><input type=checkbox style="width:20px;" name="cus_approval" value="y" > NA <br>&nbsp;</td></tr>
 
 <tr><td rowspan=3>Is Risk Acceptable? <br>
 (Supporting rationale to be indicated) </td> <td ><input type=checkbox style="width:20px;" name="cus_approval" value="y" > Yes </td><td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" > No &nbsp;&nbsp;&nbsp;Risk to patient wrt RMP </tr>
 
<tr><td><input type=checkbox style="width:20px;" name="cus_approval" value="y" > Yes </td><td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" > No &nbsp;&nbsp;&nbsp;Risk to healthcare worker wrt RMP </tr>
<tr><td><input type=checkbox style="width:20px;" name="cus_approval" value="y" > Yes </td><td colspan=2><input type=checkbox style="width:20px;" name="cus_approval" value="y" > No &nbsp;&nbsp;&nbsp;Justification report attachment</tr>
 
 <tr><td>Is CAPA Required?</td><td   ><input type=checkbox style="width:20px;" name="cus_approval" value="y" >
 *Yes </td><td colspan="2"> <input type=checkbox style="width:20px;" name="cus_approval" value="y" > No </td></tr> 
<tr><td>Remarks : <br></td><td colspan=3></td></tr> 
 <tr><td >Verified By (S/D): <br>(Controller & Above) </td><td colspan=3> </td></tr>
 
 </table>
  
 <div style="font-size:12px"><strong>PART IV (Notification)</strong></div>
 
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign=top width="250px">To be filled up by JMS (B): <br>
	Notification Required to CQM? <br> <input type=checkbox style="width:20px;" >
 Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox style="width:20px;" >
 No </td>
 <td >To be filled up by JMS (S): <br>Notification Required? <br>
 <input type=checkbox style="width:20px;" > Yes, Please specify below: <br> &nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;" > CQM, Please raise <Deviation Control Record><br> &nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;" > Others ________________________ <br>
 <input type=checkbox style="width:20px;" > No </td></tr>
 <tr><td valign=top>Remarks : <br><br></td><td valign=top>Remarks : </td></tr>
 <tr><td >Verified By JMSB QA Head: <br>(S/D)<br> </td><td >Verified By QMS(S) (Officer & Above) <br>(S/D)  </td></tr>
 <tr><td colspan=2 valign=center height=20px>RefNo: ______________________________ (Will be assign by QMS (B) / (S) if notification judgement is required)</td></tr>
 <tr><td valign=top>Regulatory Compliance Assessment (Applicable only when DRAF is accepted with concession)</td><td valign=top>Compliance to regulatory requirement?<br>
 <input type=checkbox style="width:20px;" >
 Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox style="width:20px;" > No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox style="width:20px;" > NA
 </td></tr>
 <tr><td valign=top>Verified by QMSS RA<br><br></td><td valign=bottom>(S/D) </td></tr>
 <tr><td valign=top>Customer Approval required?</td><td valign=top><input type=checkbox style="width:20px;" >
 *Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <input type=checkbox style="width:20px;" > No <br>*(Sales will coordinate with customer and feedback)
 </td></tr>
 <tr><td valign=top>Verified by JMSS Sales : <br><br></td><td valign=bottom>(S/D) </td></tr>
 </table>

<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td width=250 valign=top>Approved by (Plant Director - Critical product quality issue) <br> S/D </td><td> Remarks : <br><br></td></tr>
</table>

<table width=550 border=0>
<tr><td width=30 style="font-size:11px" valign=top>Note : </td><td style="font-size:11px">- Plant Director will approve DRAF when PCT/QA Head cannot reach compromise, or when PCT/QA Head decides that PDs approval necessary.</td></tr>
<tr><td style="font-size:11px"></td><td style="font-size:11px">- Plant Director shall approve DRAF for issues that will affect production Method and Material change and critical product quality issues.</td></tr>
<tr><td colspan=2 style="font-size:11px">> Blank column shall be strike off or indicate "NIL" or "NA". </td></tr></table>




<table border=1 width=565 >
<tr>
<td> 
<table border=0  width="750px" style="font-size: 6px;padding-left:0px;padding-top:0px;" cellpadding="0" cellspacing="0">
<tr><td colspan=7>Circulation To: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: QMS Unit is to be issued the original DRAF for filling</td></tr>
<tr><td >	
';
$str3 = $e[hobi];
$data3 = explode(",",$str3); 
$html.=' 
 <input type="checkbox" style="width:20px;"'; if (in_array("1",$data3)){$html.='checked';} $html.='> QAC 1 <br>
 <input type="checkbox" style="width:20px;"'; if (in_array("2",$data3)){ $html.='checked';}  $html.='> QAC2 <br>
 <input type="checkbox" style="width:20px;"'; if (in_array("3",$data3)){ $html.='checked';}  $html.='> QAC3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("4",$data3)){ $html.='checked';}  $html.='> QAC2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("5",$data3)){ $html.='checked';}  $html.='> QAC5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("6",$data3)){ $html.='checked';}  $html.='> QAIC <br>
 </td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("7",$data3)){ $html.='checked';}  $html.='> LAB <br>
 <input type=checkbox style="width:20px;"'; if (in_array("8",$data3)){ $html.='checked';}  $html.='> PCT1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("9",$data3)){ $html.='checked';}  $html.='> PCT2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("10",$data3)){ $html.='checked';}  $html.='> PCT3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("11",$data3)){ $html.='checked';}  $html.='> PCT2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("12",$data3)){ $html.='checked';}  $html.='> PCT5 <br>
 </td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("13",$data3)){ $html.='checked';}  $html.='> EXT1-3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("14",$data3)){ $html.='checked';}  $html.='> EXT2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("15",$data3)){ $html.='checked';}  $html.='> TEC1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("16",$data3)){ $html.='checked';}  $html.='> TEC2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("17",$data3)){ $html.='checked';}  $html.='> TEC3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("18",$data3)){ $html.='checked';}  $html.='> TEC2-2 <br>
</td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("19",$data3)){ $html.='checked';}  $html.='> TEC5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("20",$data3)){ $html.='checked';}  $html.='> EXT1-1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("21",$data3)){ $html.='checked';}  $html.='> EXT1-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("22",$data3)){ $html.='checked';}  $html.='> PED <br>
 <input type=checkbox style="width:20px;"'; if (in_array("23",$data3)){ $html.='checked';}  $html.='> HR/GA <br>
 <input type=checkbox style="width:20px;"'; if (in_array('24',$data3)){ $html.='checked';}  $html.='> ACC <br>
 </td><td>
 <input type=checkbox style="width:20px;"'; if (in_array('25',$data3)){ $html.='checked';}  $html.='> PCH <br>
 <input type=checkbox style="width:20px;"'; if (in_array('26',$data3)){ $html.='checked';}  $html.='> BQMS <br>
<input type=checkbox style="width:20px;"'; if (in_array('27',$data3)){ $html.='checked';}  $html.='> JMS(S )QMS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('28',$data3)){ $html.='checked';}  $html.='> Steam STZ <br>
 <input type=checkbox style="width:20px;"'; if (in_array('29',$data3)){ $html.='checked';}  $html.='> STR <br>
 <input type=checkbox style="width:20px;"'; if (in_array('30',$data3)){ $html.='checked';}  $html.='> PPL <br>
</td><td >
 <input type=checkbox style="width:20px;"'; if (in_array('31',$data3)){ $html.='checked';}  $html.='> FAC  <br>
 <input type=checkbox style="width:20px;"'; if (in_array('32',$data3)){ $html.='checked';}  $html.='> CQS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('33',$data3)){ $html.='checked';}  $html.='> MIS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('34',$data3)){ $html.='checked';}  $html.='> ETO STZ <br>
 <input type=checkbox style="width:20px;"'; if (in_array('35',$data3)){ $html.='checked';}  $html.='> PQS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('41',$data3)){ $html.='checked';}  $html.='> EAP <br>
 </td><td valign=top>
 <input type=checkbox style="width:20px;"'; if (in_array('36',$data3)){ $html.='checked';}  $html.='> JMSS VCD <br>
 <input type=checkbox style="width:20px;"'; if (in_array('37',$data3)){ $html.='checked';}  $html.='> JMSS PED <br>
 <input type=checkbox style="width:20px;"'; if (in_array('38',$data3)){ $html.='checked';}  $html.='> JMSS PCH <br>
 <br> Other Specify <br><br>
 <input type=checkbox style="width:20px;"'; if (in_array('39',$data3)){ $html.='checked';}  $html.='> LKD/OM <br>
 <input type=checkbox style="width:20px;"'; if (in_array('40',$data3)){ $html.='checked';}  $html.='> '.$e[hobi2].' <br>
 </td></tr>
           
 </table> </td> </tr>
 </table>

</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$font = Font_Metrics::get_font("helvetica");
$font2 = Font_Metrics::get_font("helvetica", "bold");
$canvas->page_text(95, 15, "PT. JMS BATAM", $font2, 10, array(0,0,0));
$canvas->page_text(95, 28, "Blok 210-212, Jalan Beringin, Muka Kuning, Batam 29433, Indonesia", $font, 8, array (0,0,0));
$canvas->page_text(95, 38, "Cammo Industrial Park, Blok F, No.2, Batam Centre, Batam 29433, Indonesia", $font, 8, array (0,0,0));
$canvas->page_text(15, 50, "Deviation Request and Approval Form (DRAF)", $font2, 10, array(0,0,0));
$canvas->page_text(410, 50, "Draf No          : $e[draft_no]", $font2, 9, array(0,0,0));


$canvas->page_text(16, 800, "S/D : Signature/Date", $font, 9, array(0,0,0));
$canvas->page_text(290, 805, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 9, array(0,0,0));
$canvas->page_text(16, 810, "Doc. Code : $rkode[code1]", $font, 9, array(0,0,0));
$canvas->page_text(480, 800, "$rkode[code2]", $font, 9, array(0,0,0));

$dompdf->stream("form.pdf", array("Attachment" => false));
?>