<?php
$aksi="modul/mod_menu/aksi_menu.php";
$act=$_GET[act];
switch($act) {
// Tampil Modul
default:
echo "<h2>Menu</h2>
<input type=button value='Tambah Menu' onclick=\"window.location.href='?module=menu&act=tambahmenu';\" class='large blue super button'>
<table id=rounded-corner>
<thead>
<tr>
	<th width=5px class=rounded-company>No.</th>
	<th class=rounded>Nama Menu</th>
	<th class=rounded>Link</th>
	<th class=rounded>Aktif</th>
	<th class=rounded-q4 align=center>Aksi</th>
</tr>
</thead>
<tfoot>
<tr>
	<td colspan=4 class=rounded-foot-left></td>
	<td class=rounded-foot-right></td>
</tr>
</tfoot><tbody>";
$tampil=mysql_query("SELECT * FROM menu ORDER BY urutan");
while($r=mysql_fetch_array($tampil)) {	
	echo "<tr><td>$r[urutan]</td>
			<td>$r[nama_menu]</td>
			<td><a href=$r[link]>$r[link]</a></td>
			<td align=center>$r[aktif]</td>
			<td><a href=?module=menu&act=editmenu&id=$r[id_menu]><img src='images/edit-icon.gif' alt='edit' /></a> &nbsp; 
			<a href=$aksi?module=menu&act=hapus&id=$r[id_menu]><img src='images/hapus-icon.gif' alt='hapus' /></a></td>
			</tr>";
}

echo "</tbody></table>";
break;
case "tambahmenu":
echo "<h2>Tambah Menu</h2>
<form method=POST action='$aksi?module=menu&act=input'>
<table cellspacing=10>
	<tr><td>Nama Menu</td><td> : <input type=text name='nama_menu'></td></tr>
	<tr><td>Link</td><td> : <input type=text name='link' size=30></td></tr>
	<tr><td>Aktif</td><td> : <input type=radio name='aktif' value='Y' checked>Y
	<input type=radio name='aktif' value='N'>N </td></tr>
	<tr><td colspan=2><input type=submit value=Simpan class='large blue super button'>
	<input type=button value=Batal onclick=self.history.back() class='large orange super button'></td></tr>
	</table></form>";
break;

case "editmenu":
$edit=mysql_query("SELECT * FROM menu WHERE id_menu='$_GET[id]'");
$r=mysql_fetch_array($edit);

echo "<h2>Edit Menu</h2>
	<form method=POST action='$aksi?module=menu&act=update'>
	<input type=hidden name=id value='$r[id_menu]'>
	<table cellspacing=10>
		<tr>
			<td>Nama Menu</td>
			<td> : <input type=text name='nama_menu' value='$r[nama_menu]'></td>
		</tr>
		<tr>
			<td>Link</td>
			<td> : <input type=text name='link' size=30 value='$r[link]'></td>
		</tr>";
		
		if ($r[aktif]=='Y') {
			echo "<tr><td>Aktif</td><td> :
				<input type=radio name='aktif' value='Y' checked>Y
				<input type=radio name='aktif' value='N'>N
				</td></tr>";
		}
		else {
			echo "<tr><td>Aktif</td><td> :
				<input type=radio name='aktif' value='Y'>Y
				<input type=radio name='aktif' value='N' checked>N
				</td></tr>";
		}
		
		echo "<tr><td>Urutan</td><td> : 
			<input type=text name='urutan' size=1 value='$r[urutan]'></td></tr>
			<tr>
				<td colspan=2><input type=submit value=Update class='large blue super button'>
				<input type=button value=Batal onclick=self.history.back() class='large orange super button'></td>
			</tr>
		</table>
	</form>";
break;
}
?>