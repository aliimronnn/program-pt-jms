<?php
session_start();
include "../../../config/koneksi.php";

$module=$_GET[module];
$act=$_GET[act];

// Hapus Modul
if ($module=='menu' AND $act=='hapus') {
	mysql_query("DELETE FROM menu WHERE id_menu='$_GET[id]'");
	header('location:../../../adminweb/index.php?module='.$module);
}

// Input Modul
elseif ($module=='menu' AND $act=='input') {
	$u=mysql_query("SELECT urutan FROM menu ORDER by urutan DESC");
$d=mysql_fetch_array($u);
$urutan=$d[urutan]+1;

mysql_query("INSERT INTO menu (nama_menu,link,aktif,urutan)
	VALUES ('$_POST[nama_menu]',
			'$_POST[link]',
			'$_POST[aktif]',
			'$urutan')");
	header('location:../../../adminweb/index.php?module='.$module);
}

// Update Modul
elseif ($module=='menu' AND $act=='update') {
mysql_query("UPDATE menu SET nama_menu = '$_POST[nama_menu]',
								link     = '$_POST[link]',
								aktif    = '$_POST[aktif]',
								urutan   = '$_POST[urutan]'
			WHERE id_menu  = '$_POST[id]'");
header('location:../../../adminweb/index.php?module='.$module);
}
?>

