<?php
session_start();
include "../../config/koneksi.php";
$module=$_GET['module'];
$act=$_GET['act'];

// Hapus jenisuser
if ($module=='jenisuser' AND $act=='hapus') {
	mysqli_query($conn, "DELETE FROM jenis_user WHERE id='$_GET[id]'");
	header('location:../../index.php?module='.$module);

}

// Input jenisuser
elseif ($module=='jenisuser' AND $act=='input') {
	mysqli_query($conn, "INSERT INTO jenis_user(jenis_user) VALUES ('$_POST[jenisuser]')");
	
	$menu = $_POST['menu'];
	$hitung = count($menu);
	$user = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM jenis_user WHERE jenis_user='$_POST[jenisuser]'"));
	for($i=0; $i<$hitung; $i++){
	$tambah = $_POST['tambah'] ;
	$edit = $_POST['edit'];
	$hapus = $_POST['hapus'];
	
	mysqli_query($conn, "INSERT INTO menu(id_jenisuser,id_modul) VALUES ('$user[id]','$menu[$i]')");
    }	
	header('location:../../index.php?module='.$module);

}

// Update jenisuser
elseif ($module=='jenisuser' AND $act=='update') {
    mysqli_query($conn, "DELETE FROM menu WHERE id_jenisuser='$_POST[id]'");
	
	$menu = $_POST['menu'];
	$hitung = count($menu);
	$user = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM jenis_user WHERE id='$_POST[id]'"));
	for($i=0; $i<$hitung; $i++){
	
	mysqli_query($conn, "INSERT INTO menu(id_jenisuser,id_modul) VALUES ('$user[id]','$menu[$i]')");
	mysqli_query($conn, "UPDATE jenis_user set jenis_user= '$_POST[jenisuser]' where id='$_POST[id]'");
    }	
	header('location:../../index.php?module='.$module);

}
?>