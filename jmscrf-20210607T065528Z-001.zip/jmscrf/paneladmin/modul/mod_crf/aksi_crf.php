<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  $crf_no = htmlspecialchars(@$_POST['crf_no'], ENT_QUOTES);
  $crf_kd = htmlspecialchars(@$_POST['crf_kd'], ENT_QUOTES);
  $id_crf = htmlspecialchars(@$_POST['id_crf'], ENT_QUOTES);
  $no_surat = htmlspecialchars(@$_POST['no_surat'], ENT_QUOTES);
  $no_surat2 = htmlspecialchars(@$_POST['no_surat2'], ENT_QUOTES);
  $section=$_SESSION['section'];
  $issue_date=@$_POST['thn_issue_date'].'-'.@$_POST['bln_issue_date'].'-'.@$_POST['tgl_issue_date'];
  $title = htmlspecialchars(@$_POST['title'], ENT_QUOTES);
  $current_dev = htmlspecialchars(@$_POST['current_dev'], ENT_QUOTES);
  $proposed_dev = htmlspecialchars(@$_POST['proposed_dev'], ENT_QUOTES);
  $jenis = htmlspecialchars(@$_POST['jenis'], ENT_QUOTES);
  $reason1 = htmlspecialchars(@$_POST['reason1'], ENT_QUOTES);
  
  $reason2 = str_replace("\n", '<BR />',htmlspecialchars(@$_POST['reason2'], ENT_QUOTES));
  $support_doc = str_replace("\n", '<BR />', htmlspecialchars(@$_POST['support_doc'], ENT_QUOTES));
  $parts = str_replace("\n", '<BR />', htmlspecialchars(@$_POST['parts'], ENT_QUOTES));
  $content = addslashes(@$_POST['content']);
  
  $implementation = htmlspecialchars(@$_POST['implementation'], ENT_QUOTES);
  $ins_role = htmlspecialchars(@$_POST['ins_role'], ENT_QUOTES);
  $ins_section = htmlspecialchars(@$_POST['ins_section'], ENT_QUOTES);
  $ins_training = htmlspecialchars(@$_POST['ins_training'], ENT_QUOTES);
  $other = htmlspecialchars(@$_POST['other'], ENT_QUOTES);  
  $initiaded = htmlspecialchars(@$_POST['initiaded'], ENT_QUOTES);
  $verified = htmlspecialchars(@$_POST['verified'], ENT_QUOTES);
  $approved = htmlspecialchars(@$_POST['approved'], ENT_QUOTES); 
  $hobi1 = htmlspecialchars(@$_POST['hobi1'], ENT_QUOTES);
  $hobi2 = htmlspecialchars(@$_POST['hobi2'], ENT_QUOTES);

 
 	//detail affect doc
  $doc_code = htmlspecialchars(@$_POST['doc_code'], ENT_QUOTES);
  $old = htmlspecialchars(@$_POST['old'], ENT_QUOTES);
  $new = htmlspecialchars(@$_POST['new'], ENT_QUOTES);
  $remark = htmlspecialchars(@$_POST['remark'], ENT_QUOTES);
 
 
  
   if (!empty($_POST['hobi'])){
       $p_hobi = $_POST['hobi'];
       $hobi=implode(',',$p_hobi);
  }
 
  if ($module=='crf' AND $act=='input'){
 

$qnosurat=mysqli_query($conn, "SELECT RIGHT( CONCAT('000', CONVERT( IFNULL(MAX(d.no_surat)+1,1), CHAR( 4 ) ) ) ,3 ) AS no_surat
, DATE_FORMAT(curdate(),'%y') as th_surat
FROM crf d, sectioncode sc WHERE d.crf_kd= sc.crf and sc.id='$_SESSION[section]' and 
YEAR(d.create_date)=year(NOW())");
$rnosurat=mysqli_fetch_array($qnosurat);

$qkodesurat=mysqli_query($conn, "SELECT CONCAT('CRF/','$rnosurat[no_surat]/','$_SESSION[crf_kd]/','$rnosurat[th_surat]') as kode_surat");
$rkodesurat=mysqli_fetch_array($qkodesurat);

$urutan = $rnosurat['no_surat'];

$crf_kod = $rkodesurat['kode_surat'];
 mysqli_query ($conn, "INSERT into crf (crf_no, section,create_date, status,  
 					jenis, title,reason1, content, 
					reason2,parts,implementation,
					ins_role, ins_section, 
					ins_training, other, support_doc,initiaded,
					verified,approved,hobi,hobi1,hobi2,no_surat,crf_kd) values (
					'$crf_kod','$_SESSION[section]',Date(now()),'0','$jenis',
					'$title','$reason1','$content','$reason2','$parts','$implementation',
					'$ins_role','$ins_section','$ins_training','$other','$support_doc',
					upper('$initiaded'),upper('$verified'), 
					upper('$approved'), '$hobi','$hobi1', upper('$hobi2'),'$urutan','$_SESSION[crf_kd]')");
		
     header('location:../../index.php?module='.$module);
    
            
  }
  
  else if ($module=='crf' AND $act=='inputaffect'){
  	        mysqli_query($conn, "INSERT INTO affect_doc (id_crf,doc_code,old,new,remark,verified,approved,revised,status) VALUES('$id_crf','$doc_code',
					'$old','$new','$remark',
					upper('$verified'),
					upper('$approved'),'y','o')");
     header('location:../../index.php?module=crf&act=affectcrf&id='.$_POST['id_crf']);
            
  }
   else if ($module=='crf' AND $act=='deleteaffect'){
  	        mysqli_query($conn, "DELETE from affect_doc where id= '$_GET[id]'");
     header('location:../../index.php?module=crf&act=affectcrf&id='.$_GET['id_crf']);
            
  }
  else if ($module=='crf' AND $act=='updateaffect'){
  	        mysqli_query($conn, "UPDATE affect_doc set doc_code= '$doc_code',old='$old', 
  	        new='$new', remark='$remark', verified=upper('$verified'),approved=upper('$approved') 
  	        where id= '$_POST[id]'");
     header('location:../../index.php?module=crf&act=affectcrf&id='.$_POST['id_crf']);
            
  }
  // Update crf  
  elseif ($module=='crf' AND $act=='update'){ 
 	//$sect=mysql_query("SELECT * FROM sectioncode where id ='$_SESSION[section]'");
	//$s=mysql_fetch_array($sect);
 	//$qkodesurat=mysql_query("SELECT CONCAT('CRF/',RIGHT(CONCAT('000', CONVERT($_POST[no_surat2], CHAR( 4 ) ) ) ,3 ),'/$s[crf]/',DATE_FORMAT(curdate(),'%y')) as kode_surat");
	//$rkodesurat=mysql_fetch_array($qkodesurat);  
  	//$newcrf_no = $rkodesurat['kode_surat'];
  	
   //crf_no='$newcrf_no' , no_surat=$_POST[no_surat2]
    mysqli_query ($conn, "UPDATE crf set jenis='$jenis',
					title='$title',reason1='$reason1', content='$content', 
					reason2='$reason2',parts='$parts',implementation='$implementation',
					ins_role='$ins_role', ins_section='$ins_section', 
					ins_training='$ins_training', other='$other', support_doc='$support_doc',
					initiaded=upper('$initiaded'), verified=upper('$verified'), 
					approved=upper('$approved'), hobi='$hobi', hobi1='$hobi1', hobi2=upper('$hobi2')			                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);
  }
    
     elseif ($module=='crf' AND $act=='update2'){ 
  
  
 	//$sect=mysql_query("SELECT * FROM sectioncode where id ='$_SESSION[section]'");
	//$s=mysql_fetch_array($sect);
 	//$qkodesurat=mysql_query("SELECT CONCAT('CRF/',RIGHT(CONCAT('000', CONVERT($_POST[no_surat2], CHAR( 4 ) ) ) ,3 ),'/$s[crf]/',DATE_FORMAT(curdate(),'%y')) as kode_surat");
	//$rkodesurat=mysql_fetch_array($qkodesurat);  
  //	$newcrf_no = $rkodesurat['kode_surat'];
  	
    //crf_no='$newcrf_no',     , no_surat=$_POST[no_surat2]	
    mysqli_query ($conn, "UPDATE  crf set  jenis='$jenis',
					title='$title',reason1='$reason1', content='$content', 
					reason2='$reason2',parts='$parts',implementation='$implementation',
					ins_role='$ins_role', ins_section='$ins_section', 
					ins_training='$ins_training', other='$other', support_doc='$support_doc',
					initiaded=upper('$initiaded'), verified=upper('$verified'), 
					approved=upper('$approved'), hobi='$hobi', hobi1='$hobi1', hobi2=upper('$hobi2')		                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=approved');
  }
    elseif ($module=='crf' AND $act=='update3'){ 
  
  
 	//$sect=mysql_query("SELECT * FROM sectioncode where id ='$_SESSION[section]'");
	//$s=mysql_fetch_array($sect);
 	//$qkodesurat=mysql_query("SELECT CONCAT('CRF/',RIGHT(CONCAT('000', CONVERT($_POST[no_surat2], CHAR( 4 ) ) ) ,3 ),'/$s[crf]/',DATE_FORMAT(curdate(),'%y')) as kode_surat");
	//$rkodesurat=mysql_fetch_array($qkodesurat);  
  	//$newcrf_no = $rkodesurat['kode_surat'];
  	
    
    mysqli_query ($conn, "UPDATE crf set 
    				issue_date = '$issue_date',
    				jenis='$jenis',
					title='$title',reason1='$reason1', content='$content', 
					reason2='$reason2',parts='$parts',implementation='$implementation',
					ins_role='$ins_role', ins_section='$ins_section', 
					ins_training='$ins_training', other='$other', support_doc='$support_doc',
					initiaded=upper('$initiaded'), verified=upper('$verified'), 
					approved=upper('$approved'), hobi='$hobi', hobi1='$hobi1', hobi2=upper('$hobi2')
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
   elseif ($module=='crf' AND $act=='approve'){ 
          
    mysqli_query($conn, "UPDATE crf SET  issue_date = '$issue_date',
					status = '1'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  
    
  elseif ($module=='crf' AND $act=='return'){ 
          
    mysqli_query($conn, "UPDATE crf SET  issue_date=null,
					status = '0'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  
   elseif ($module=='crf' AND $act=='close'){ 
          
    mysqli_query($conn, "UPDATE crf SET  report_date = '$issue_date',
					status = '3'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  elseif ($module=='crf' AND $act=='unclose'){ 
          
    mysqli_query($conn, "UPDATE crf SET  report_date=null,
					status = '2'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  elseif ($module=='crf' AND $act=='unapp'){ 
          
    mysqli_query($conn, "UPDATE crf SET  issue_date=null,
					status = '0'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  // Delete crf  
  elseif ($module=='crf' AND $act=='delete'){
            
      mysqli_query($conn, "DELETE FROM crf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  }
  elseif ($module=='crf' AND $act=='delete2'){
            
      mysqli_query($conn, "DELETE FROM crf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module=crf&act=approved');
            
  }
  elseif ($module=='crf' AND $act=='delete3'){
            
      mysqli_query($conn, "DELETE FROM crf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module=crf&act=appcrf');
            
  }
  
  else if ($module=='crf' AND $act=='cetak') {
/*
if ($_GET['jenis']=='minor') {include"cetak_minor.php";}	
else if ($_GET['jenis']=='Minor') {include"cetak_minor.php";}
else if ($_GET['jenis']=='major') {include"cetak_major.php";}
else if ($_GET['jenis']=='Major') {include"cetak_major.php";}
else {include"cetak_corp.php";}
*/
if ($_GET['jenis']=='minor' or $_GET['jenis']=='Minor') {
	include"cetak_minor.php";
}	else if ($_GET['jenis']=='major' or $_GET['jenis']=='Major') {
	include"cetak_major.php";
} else {
	include"cetak_corp.php";
}
	
}
 else if ($module=='crf' AND $act=='cetakaffect') {
include"cetak3.php";
}

    else if ($module=='crf' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE crf";
             mysqli_query($conn, $truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      $crf_no           = $data->val($i, 3);
      $section           = $data->val($i, 2);
      $tit           = $data->val($i, 8);
      $title = mysqli_real_escape_string($conn, $tit);
      $imp           = $data->val($i, 16);
      $implementation = mysqli_real_escape_string($conn, $imp);
      
      $thnn1		   =$data->val($i, 14);
      $blnn1		   =$data->val($i, 13);
      $tgll1		   =$data->val($i, 12);
      $issue_date	= $thnn1.'-'.$blnn1.'-'.$tgll1;
      
      $thnn		   =$data->val($i, 19);
      $blnn		   =$data->val($i, 20);
      $tgll		   =$data->val($i, 21);
      $report_date	= '20'.$thnn.'-'.$blnn.'-'.$tgll;
      
   	  $rem	   =$data->val($i, 24);
   	  $remark = mysqli_real_escape_string($conn, $rem); 
      $status	   = $data->val($i, 25);
      $initiaded	= $data->val($i, 23);
      $no_surat		= $data->val($i, 7);
      $crf_kd		= $data->val($i, 5);
      $jenis		= $data->val($i, 10);
 //      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into crf (crf_no,section,create_date,issue_date,report_date,status,jenis,
      title,implementation,initiaded,no_surat,crf_kd) values('$crf_no','$section','2010-01-01','$issue_date','$report_date','$status','$jenis',
      '$title','$implementation',upper('$initiaded'),'$no_surat','$crf_kd')";
      $hasil = mysqli_query($conn, $query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=home');
  }


  }
