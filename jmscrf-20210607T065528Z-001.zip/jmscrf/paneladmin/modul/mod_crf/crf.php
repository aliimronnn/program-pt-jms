<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete the item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
/* function validasidetail(form){
   var mincar = 1;
   if (form.doc_code.value.length < mincar){
       alert("Doc Code is still empty!");
       form.doc_code.focus();
       return (false);
   }   
   	  
       if (form.old.value.length < mincar){
       alert("Old No Code is still empty!");
       form.old.focus();
       return (false);
   }    
     if (form.new.value.length < mincar){
       alert("New Code is still empty!");
       form.new.focus();
       return (false);
   }     
   if (form.remark.value==""){
       alert("Remark is still empty!");
       form.remark.focus();
       return (false);
   }    
   if (form.verified.value==""){
       alert("Indicated By is still empty!");
       form.verified.focus();
       return (false);
   } 
   if (form.approved.value==""){
       alert("Checked By is still empty!");
       form.approved.focus();
       return (false);
   }      
  	
  
   return (true);
} */
function validasi(form){
   var mincar = 1;
   if (form.title.value.length < mincar){
       alert("Title is still empty!");
       form.title.focus();
       return (false);
   }  
  	
  	if (form.jenis.value==""){
       alert("CRF Type is not Choosen Yet");
       form.jenis.focus();
       return (false);
   }         
     if (form.reason1.value.length < mincar){
       alert("Remarks is still empty!");
       form.reason1.focus();
       return (false);
   } 
    
    if (form.reason2.value.length < mincar){
       alert("Reason is still empty!");
       form.reason2.focus();
       return (false);
   } 
    if (form.parts.value.length < mincar){
       alert("Parts/WIP/FG is still empty!");
       form.parts.focus();
       return (false);
   } 
    if (form.implementation.value.length < mincar){
       alert("Implementation is still empty!");
       form.implementation.focus();
       return (false);
   } 
    if (form.ins_role.value.length < mincar){
       alert("Roles Instructions is still empty!");
       form.ins_role.focus();
       return (false);
   } 
    if (form.ins_section.value.length < mincar){
       alert("Indication of section Instructions is still empty!");
       form.ins_section.focus();
       return (false);
   } 
    if (form.ins_training.value.length < mincar){
       alert("Indication of training Instructions is still empty!");
       form.ins_training.focus();
       return (false);
   } 
    if (form.other.value.length < mincar){
       alert("Other Instructions is still empty!");
       form.other.focus();
       return (false);
   } 
    if (form.support_doc.value.length < mincar){
       alert("Supporting Document is still empty!");
       form.support_doc.focus();
       return (false);
   } 
    if (form.initiaded.value.length < mincar){
       alert("CRF Initiator Is still empty!");
       form.initiaded.focus();
       return (false);
   }
   if (form.verified.value.length < mincar){
       alert("Initiating Dept Is still empty!");
       form.verified.focus();
       return (false);
   } 
   if (form.approved.value.length < mincar){
       alert("CRF Coordination Is still empty!");
       form.approved.focus();
       return (false);
   } 
   return (true);
}
</script>

<?php
//session_start();
/** if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Login is required to acces the system!<br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{ **/
function explode_trim($str, $delimiter = ',') {
   if ( is_string($delimiter) ) {
      $str = trim(preg_replace('|\\s*(?:' . preg_quote($delimiter) . ')\\s*|', $delimiter, $str));
      return explode($delimiter, $str);
   }
   return $str;
}
    
$aksi="modul/mod_crf/aksi_crf.php";
switch(@$_GET['act']){

default:
echo "
<form method=POST action='?module=crf&act=viewcrf' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find CRF</strong></i></td><td>: ";
include "crf1.php";
echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>

</form>

<h2>List CRF Not Approved Yet</h2>
<p>&nbsp;</p>
<input type=button  class='large orange super button' value='Add New CRF' 
onclick=\"window.location.href='?module=crf&act=tambahcrf';\"> <input type=button  class='large blue super button' value='Approved CRF' 
onclick=\"window.location.href='?module=crf&act=approved';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=10>No</th><th width=10>Section</th>
<th width=170>CRF No</th><th>Check Point</th><th width=110>Create Date</th><th width=500>Title</th><th width=100>Remarks</th><th width=250>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT id,section, crf_no,case jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis,date_format(create_date,'%d %b %y') as create_date,title FROM crf where status='0' and crf_kd='$_SESSION[crf_kd]' order by crf_no desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	echo "<tr><td>$no.</td>
	<td>$r[section]</td>
	<td>$r[crf_no]</td>
  <td>$r[jenis]</td>
  <td>$r[create_date]</td>
  <td>$r[title]</td><td>Not Approve Yet</td>
  <td><a href='?module=crf&act=affectcrf&id=$r[id]'>Page 3<img src='images/info.png' alt='edit' /></a>|
  <a href='?module=crf&act=editcrf&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=crf&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
  </td></tr>";
  $no++;
}
echo "</table>";
break;

case "approved":

echo "
<form method=POST action='?module=crf&act=viewapprove' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find CRF</strong></i></td><td>: ";
include "crf2.php";

echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>

</form>
<h2>List Approved CRF</h2>
<p>&nbsp;</p>
<input type=button  class='large orange super button' value='Not Approved CRF' 
onclick=\"window.location.href='?module=crf&act='\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th width=10>No</th><th width=10>Section</th>
<th width=150>CRF No</th><th>Check Points</th><th>Title</th><th width=80>Issue Date</th><th width=80>Deadline</th><th width=80>Report Date</th><th width=100>Remarks</th><th width=50>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT id, crf_no,section, title, case jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis, date_format(issue_date,'%d %b %y') as issue_date, 
date_format((issue_date + interval '2' month),'%d %b %y')as deadline, 
date_format(report_date,'%d %b %y') as report_date, 
datediff((issue_date + interval '2' month),current_date()) as selisih,
initiaded, status
FROM crf where status!='0' and crf_kd='$_SESSION[crf_kd]' order by create_date desc limit 25 ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
} 

// Change History No. 01
  if($_SESSION['jenisuser'] == '1' || $_SESSION['jenisuser'] == '2') {
    echo "<tr><td>$no.</td><td>$r[section]</td>
	  <td>$r[crf_no]</td>
    <td>$r[jenis]</td><td>$r[title]</td><td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td>
    <td>$label</td>    
    <td><a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=?module=crf&act=affectcrf&id=$r[id]><img src='images/info.png' alt='cetak' /></a>";
  $no++;
  } else {
  echo "<tr><td>$no.</td><td>$r[section]</td>
	  <td>$r[crf_no]</td>
    <td>$r[jenis]</td><td>$r[title]</td><td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td>
    <td>$label</td>    
    <td><a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a></td></tr>";
  $no++;
  }
// End History No. 01
}
echo "</table>";
//<a href='?module=crf&act=editcrf2&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>||<a href=javascript:confirmdelete('$aksi?module=crf&act=delete2&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>
break;
case "viewcrf":
echo "
<table id=example class='pretty dataTable'>
<thead><tr><th width=10>No</th>
<th width=150>CRF No</th><th width=100>Check Points</th><th width=100>Create Date</th><th>Title</th><th width=150>Remarks</th><th width=>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT id, crf_no,jenis,date_format(create_date,'%d %b %y') as create_date,title FROM crf where id='$_POST[id_crf]'");

$r=mysqli_fetch_array($tampil);
	echo "<tr><td>1.</td>
	<td>$r[crf_no]</td>
	<td>$r[jenis]</td>
  <td>$r[create_date]</td>
  <td>$r[title]</td><td>Not Approved Yet</td>
  <td><a href='?module=crf&act=affectcrf&id=$r[id]'>Page 3 <img src='images/info.png' alt='edit' /></a>|<a href='?module=crf&act=editcrf&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=crf&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
  </td></tr></table>";
break;

case "viewapprove":
echo "
<table  class='pretty dataTable'>
<thead><tr><th width=10>No</th><th width=10>Section</th>
<th width=150>CRF No</th><th >Check Points</th><th>Title</th><th width=80>Issue Date</th><th width=80>Deadline</th><th width=80>Report Date</th><th width=100>Remarks</th><th width=130>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT id, crf_no,section,title, case jenis when 'minor' then 'Minor'  when 'major'
then 'Major' when 'corporate'
then 'Corporate Tie-Up'  else 'Not Defined' end as jenis, date_format(issue_date,'%d %b %y') as issue_date, 
date_format((issue_date + interval '2' month),'%d %b %y')as deadline, 
date_format(report_date,'%d %b %y') as report_date, 
datediff((issue_date + interval '2' month),current_date()) as selisih,
initiaded, status FROM crf where id ='$_POST[id_crf]' ");
$r=mysqli_fetch_array($tampil);
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}
  echo "<tr><td>1.</td><td>$r[section]</td>
	<td>$r[crf_no]</td>
	<td>$r[jenis]</td>
       	<td>$r[title]</td>	<td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td><td>$label</td>
    <td><a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=?module=crf&act=affectcrf&id=$r[id] ><img src='images/info.png' alt='cetak' /></a>
        </td></tr>
        </table>";

break;
//<a href='?module=crf&act=editcrf2&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|
//ini adalah inputan sebelumnya
//<tr><td>6.</td><td>Customer Approval</td><td><input type=radio name='cus_approval' value='y'> Yes (Sales co-ordinates with customer and feedback) SLS Acknowledge (S/D)</br> <input type=radio name='cus_approval' value='n'> No </br><input type='text' name='cus_app_ket' size='50' value='' ></td><td><textarea name='cus_approval_at' cols='20' rows='3' ></textarea></td></tr>

// Form Add New crf
case "tambahcrf":
//$sect=mysql_query("SELECT crf FROM sectioncode where id ='$_SESSION[section]'");
//$s=mysql_fetch_array($sect);

$qnosurat=mysqli_query($conn, "SELECT RIGHT( CONCAT('000', CONVERT( IFNULL(MAX(d.no_surat)+1,1), CHAR( 4 ) ) ) ,3 ) AS no_surat
, DATE_FORMAT(curdate(),'%y') as th_surat
FROM crf d, sectioncode sc WHERE d.crf_kd= sc.crf and sc.id='$_SESSION[section]' and 
YEAR(d.create_date)=year(NOW())");
$rnosurat=mysqli_fetch_array($qnosurat);

$qkodesurat=mysqli_query($conn, "SELECT CONCAT('CRF/','$rnosurat[no_surat]/','$_SESSION[crf_kd]/','$rnosurat[th_surat]') as kode_surat");
$rkodesurat=mysqli_fetch_array($qkodesurat);
// mysql_query("INSERT INTO crf(crf_no,section,	create_date,status,no_surat) VALUES('$rkodesurat[kode_surat]','$_SESSION[section]',		Date(now()),'0','$rnosurat[no_surat]')");
//
echo "<h2>Add New CRF</h2>
<form method=POST action='$aksi?module=crf&act=input&crfno=$rkodesurat[kode_surat]' onsubmit='return validasi(this)'  >


<table cellspacing=8 cellpadding=4>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='100' value='$rkodesurat[kode_surat]' readonly></td></tr>                

<tr><td>Title</td><td>: <input type='text' name='title' size='100' value='' ></td></tr> 
<tr><td>CRF Issue</td><td>: <select name=jenis><option value=''> -Choose Type CRF- </option>
<option value=minor> Minor </option><option value=major> Major </option><option value=corporate> Corporate Tie-up </option></select></td></tr>  
<tr><td>Remarks</td><td>: <input type='text' name='reason1' size='100' value='' ></td></tr>  
                
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 >

<tr><td valign=top rowspan=2>1.</td><td valign=top>Content Description: <i style='color:maroon;'><strong>*) avoid using of single quote (')!</strong></i></td></tr> 
<tr><td><textarea  name='content' id=loko style='width: 800px; height: 300px;padding: 0;margin: 2px 0;'></textarea></td></tr>              
<tr><td valign=top rowspan=2>2.</td><td>Reason: </td></tr> 
<tr><td><textarea name='reason2' style='width: 800px; height: 70px;' ></textarea></td></tr>               
<tr><td valign=top rowspan=2>3.</td><td >Parts/WIP/FG affected: </td></tr> 
<tr><td ><textarea name='parts' style='width: 800px; height: 70px;' ></textarea></td></tr>
              
<tr><td valign=top rowspan=2>4.</td><td >CRF Implementation: </td></tr> 
<tr><td ><textarea name='implementation' style='width: 800px; height: 30px;' ></textarea></td></tr>

<tr><td valign=top rowspan=9>5.</td><td >Instructions: </td></tr> 
<tr><td valign=top >a. Roles and actions by each participants: </td></tr> 
<tr><td ><textarea name='ins_role' style='width: 800px; height: 30px;' ></textarea></td></tr>

<tr><td valign=top >b. Indication of section / Department to Feedback IRP: </td></tr> 
<tr><td ><textarea name='ins_section' style='width: 800px; height: 30px;' ></textarea></td></tr>

<tr><td valign=top >c. Indication of Training Needs: </td></tr> 
<tr><td ><textarea name='ins_training' style='width: 800px; height: 30px;' ></textarea></td></tr>

<tr><td valign=top >d. Others: </td></tr> 
<tr><td ><textarea name='other' style='width: 800px; height: 30px;' ></textarea></td></tr>
 
<tr><td valign=top rowspan=2>6.</td><td >Supporting Document / Data: </td></tr> 
<tr><td ><textarea name='support_doc' style='width: 800px; height: 70px;' ></textarea></td></tr> 

</table>

<p>&nbsp;</p>
<table cellspacing=4 cellpadding=4 >

<tr><td width=50>CRF Initiator:</td><td>Initiating Dept:</td><td>CRF Coordination:</td></tr>
<tr>";
 include "initiaded.php"; 
 include "verified.php"; 
 include "approved.php"; 
echo "</tr>

<tr><td colspan=3>__________________________________________________________________________________________________________________</td></tr>
 
</table>
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=7> Circulation To: </td></tr>
<tr><td>
<!-- <input type=checkbox value='1' name=hobi[]>QAC 1 <br> -->
<input type=checkbox value='2' name=hobi[]>QAC2 <br> 
<input type=checkbox value='3' name=hobi[]>QAC3 <br> 
<input type=checkbox value='4' name=hobi[]>QAC4 <br> 
<input type=checkbox value='5' name=hobi[]>QAC5 <br> 
<input type=checkbox value='6' name=hobi[]>QAIC <br>
<input type=checkbox value='7' name=hobi[]>LAB <br>
</td>
<td valign='top'>
<!-- <input type=checkbox value='8' name=hobi[]>PCT1 <br> -->
<input type=checkbox value='9' name=hobi[]>PCT2 <br> 
<input type=checkbox value='10' name=hobi[]>PCT3 <br> 
<input type=checkbox value='11' name=hobi[]>PCT2-2 <br> 
<input type=checkbox value='12' name=hobi[]>PCT5 <br>
<input type=checkbox value='35' name=hobi[]>PQS  <br>
</td>

<td valign='top'>
<!-- <input type=checkbox value='21' name=hobi[]>EXT1 <br> -->
<input type=checkbox value='14' name=hobi[]>EXT2 <br>
<input type=checkbox value='13' name=hobi[]>EXT3 <br> 
<input type=checkbox value='44' name=hobi[]>EXT4 <br> 
<input type=checkbox value='42' name=hobi[]>EXT5 <br> 
<input type=checkbox value='20' name=hobi[]>INFLATION <br> 
<!-- <input type=checkbox value='15' name=hobi[]>TEC1 <br> -->
</td>

<td valign='top'>
<input type=checkbox value='16' name=hobi[]>TEC2 <br> 
<input type=checkbox value='17' name=hobi[]>TEC3 <br> 
<input type=checkbox value='18' name=hobi[]>TEC4 <br> 
<input type=checkbox value='19' name=hobi[]>TEC5 <br> 
<input type=checkbox value='22' name=hobi[]>PED/MTU <br> 
<input type=checkbox value='41' name=hobi[]>EAP <br>

</td>

<td>
<input type=checkbox value='24' name=hobi[]>ACC <br>  
<input type=checkbox value='25' name=hobi[]>PCH <br> 
<input type=checkbox value='26' name=hobi[] checked>BQMS <br> 
<input type=checkbox value='27' name=hobi[] checked>JMS(S)QMS <br> 
<input type=checkbox value='28' name=hobi[]>Steam STZ <br>
<input type=checkbox value='29' name=hobi[]>STR <br> 
</td>

<td>
<input type=checkbox value='30' name=hobi[]>PPL <br> 
<input type=checkbox value='31' name=hobi[]>FAC <br> 
<input type=checkbox value='32' name=hobi[]>CQS <br> 
<input type=checkbox value='33' name=hobi[]>MIS <br> 
<input type=checkbox value='34' name=hobi[]>ETO STZ <br> 
<input type=checkbox value='23' name=hobi[]>HR/GA <br> 
</td> 

<td valign='top'>
<input type=checkbox value='36' name=hobi[] checked>JMSS VCD <br> 
<input type=checkbox value='37' name=hobi[] checked>JMSS PED <br> 
<input type=checkbox value='38' name=hobi[] checked>JMSS PCH 
</td>

<td valign='top'>
Other Specify <br>
 <input type=checkbox value='39' name=hobi[]>LKD <br> 
 <input type=checkbox value='40' name=hobi[]> 
 <input type=text name=hobi2 >
 </td>
</tr>

<tr><td colspan=2><input type=submit name=submit value=Save class='large orange super button'>
<input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
</table>

</form>";
break;

case "approvecrf":
$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Approve CRF</h2>
<br>
<table cellspacing=8 cellpadding=4>
<form method=POST action='$aksi?module=crf&act=approve'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='100' value='$r[crf_no]' readonly></td></tr>  
           
<tr><td>Title</td><td>: <input type='text' name='title' size='100' value='$r[title]' readonly></td></tr> 


";
if ($r['jenis']=='minor'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' selected> Minor</option> 
                                
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='major'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 
                                 <option value='major' selected> Major</option> 
                               
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='corporate'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='corporate' selected> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
echo "
<tr><td><strong><u>Issue Date</strong></u></td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo" <small><strong><u><i>Issue Date Must be filled!</i></u></stong></small></td></tr>
<tr><td colspan=2><br><input type=submit value=Approve class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</form>
 

</table>
";
break;

case "return":
$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);

echo "<h2>Return CRF</h2>
<form method=POST action='$aksi?module=crf&act=return' onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=8 cellpadding=4>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='100' value='$r[crf_no]' readonly></td></tr>  
           
<tr><td>Title</td><td>: <input type='text' name='title' size='100' value='$r[title]' readonly></td></tr> 

<tr><td>Issue Date</td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo"</td></tr>";
if ($r['jenis']=='minor'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' selected> Minor</option> 
                                
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='major'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 
                                 <option value='major' selected> Major</option> 
                               
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='corporate'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='corporate' selected> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
echo "
<tr><td>Reason(s)</td><td>: <input type='text' name='reason1' size='100' value='$r[reason1]' readonly></td></tr>  
                

<tr><td colspan=2><input type=submit value=Return class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;
//Affect Document
case "affectcrf":
$qcrf = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$rcrf    = mysqli_fetch_array($qcrf);
echo "<h2>Affected Document  CRF</h2><p>&nbsp;</p>
<form method=POST action='$aksi?module=crf&act=cetakaffect' target=_blank  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$rcrf[id]'>
<input type=hidden name=crf_no value='$rcrf[crf_no]'>

<table cellspacing=8 cellpadding=4>
<tr><td>CRF No</td><td>: <input type=text value='$rcrf[crf_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type=text value='$rcrf[title]' size='100' readonly></td></tr>      
<tr><td>CRF Initiator</td><td>: <input type=text value='$rcrf[initiaded]' readonly size=100></td></tr>                
</table>
<p>&nbsp;</p>

<table class='pretty dataTable' border='1'><thead>
<tr><th>S/N</th><th>Document Code</th><th>Old <br>RN No.</th><th >New <br>RN No. </th><th >*Remarks <br>N,R,O</th><th>Indicated By<br>(CRF Reviewer)</th><th>Checked By <br>DCR </th><th>Action </th></tr>
</thead><tbody>";
$tampil2=mysqli_query($conn, "SELECT *from affect_doc where id_crf=$rcrf[id] and status='o'");
$no2=1;
while ($r2=mysqli_fetch_array($tampil2)){
  echo "<tr style='align=center'><td>$no2.</td>
	<td>$r2[doc_code]</td>
      <td>$r2[old]</td>
      <td>$r2[new]</td>
      	<td>$r2[remark]</td>
      	<td>$r2[verified]</td>
      	<td>$r2[approved]</td>
      <td>
		<a href='?module=crf&act=editaffect&id=$r2[id]&id_crf=$rcrf[id]'><img src='images/edit.png' alt='edit' /></a> | 
        <a href=javascript:confirmdelete('$aksi?module=crf&act=deleteaffect&id=$r2[id]&id_crf=$rcrf[id]')><img src='images/hapus.png' alt='hapus' /></a>
	
        </td></tr>";
  $no2++;
}
echo"
<tr><td colspan=7><a href='?module=crf&act=tambahaffect&id=$rcrf[id]&crf_no=$rcrf[crf_no]'><strong><u>Add Affect Doc</strong></u></a></td></tr>

</table>

<table cellspacing=8 cellpadding=4>
<tr><td colspan=3></br><input type=submit name=submit value=Print class='large orange super button'> <input type=button value=Back onclick=self.history.back() class='large blue super button'>
</td></tr>
</table>
</form>";
break;

case "tambahaffect":

echo "<h2>New Affected Document</h2>
<form method=POST action='$aksi?module=crf&act=inputaffect'  onsubmit='return validasidetail(this)' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>

<input type='hidden' name='crf_no' size='20' value='$_GET[crf_no]'>
<input type='hidden' name='id_crf' size='20' value='$_GET[id]' >
<tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='60' value='' ></td></tr> 
<tr><td>Old RN No.</td><td>: <input type='text' name='old' size='20' value='' > </td></tr>
<tr><td>New RN No.</td><td>: <input type='text' name='new' size='20' value='' > </td></tr>
<tr><td>Remark</td><td>: <select name='remark'>
  <option value=''>--Choose Remark--</option> 
   <option value='NEW' >NEW</option>
   <option value='REVISE'>REVISE</option>
   <option value='OBSOLETE'>OBSOLETE</option>   
   <option value='NA' >NA</option>
   </select>
  </td></tr> 
  <tr><td>Indicated By </td>";
  include "verified.php";
  echo "</tr>
  <tr><td>Checked By </td>";
  include "approved.php";
  echo "</tr>
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel onclick=self.history.back() class='large orange super button'></td></tr>
</table>
</form>";
break;

case "editaffect":
$qaffect = mysqli_query($conn, "SELECT * FROM affect_doc WHERE id='$_GET[id]'");
$r   = mysqli_fetch_array($qaffect);
echo "<h2>Modify Affected Document</h2>
<form method=POST action='$aksi?module=crf&act=updateaffect'  onsubmit='return validasidetail(this)' enctype='multipart/form-data'>
<input type='hidden' name='id_crf' size='20' value='$_GET[id_crf]'>
<input type='hidden' name='id' size='20' value='$r[id]'>
<table cellspacing=10 cellpadding=6>

<tr><td>Doc Code</td><td>: <input type='text' name='doc_code' size='60' value='$r[doc_code]' ></td></tr> 
<tr><td>Old RN No.</td><td>: <input type='text' name='old' size='20' value='$r[old]' > </td></tr>
<tr><td>New RN No.</td><td>: <input type='text' name='new' size='20' value='$r[new]' > </td></tr>
"; 
if ($r['remark']=='NEW'){
  echo "<tr><td>Remark</td><td>: <select name='remark'>
  
   <option value='NEW' selected>NEW</option>
   <option value='REVISE'>REVISE</option>
   <option value='OBSOLETE'>OBSOLETE</option> 
	<option value='NA'>NA</option>    
   </select>
  </td></tr> ";  
}
 
elseif ($r['remark']=='REVISE'){
  echo "<tr><td>Remark</td><td>: <select name='remark'>
  
   <option value='NEW' >NEW</option>
   <option value='REVISE' selected>REVISE</option>
   <option value='OBSOLETE'>OBSOLETE</option>  
<option value='NA'>NA</option>    
   </select>
  </td></tr> ";  
}
 
elseif ($r['remark']=='OBSOLETE'){
  echo "<tr><td>Remark</td><td>: <select name='remark'>
  
   <option value='NEW' >NEW</option>
   <option value='REVISE' >REVISE</option>
   <option value='OBSOLETE' selected>OBSOLETE</option>   
   <option value='NA'>NA</option> 
   </select>
  </td></tr> ";  
}
elseif ($r['remark']=='NA'){
  echo "<tr><td>Remark</td><td>: <select name='remark'>
  
   <option value='NEW' >NEW</option>
   <option value='REVISE' >REVISE</option>
   <option value='OBSOLETE' >OBSOLETE</option>   
   <option value='NA' selected>NA</option> 
   </select>
  </td></tr> ";  
}
else {
  echo "<tr><td>Remark</td><td>: <select name='remark'>
  <option value='' selected>-Choose Remark-</option>
   <option value='NEW' >NEW</option>
   <option value='REVISE' >REVISE</option>
   
   <option value='OBSOLETE' >OBSOLETE</option>   
   <option value='NA' >NA</option> 
   </select>
  </td></tr> ";  
}
echo "

<tr><td>Indicated By </td>";
  include "verifiededit.php";
  echo "</tr>
  <tr><td>Checked By </td>";
  include "approvededit.php";
  echo "</tr>
<tr><td colspan=2><input type=submit name=submit value=Save class='large blue super button'>
<input type=button value=Cancel onclick=self.history.back() class='large orange super button'></td></tr>
</table>
</form>";
break;

case "returncrf":
$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Return crf</h2><p>&nbsp;</p>
<form method=POST action='$aksi?module=crf&act=return'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=8 cellpadding=4>
<tr><td>crf No</td><td>: $r[crf_no]</td></tr>                
<tr><td>Issue Date</td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo"</td></tr>
<tr><td>Title</td><td>: $r[title]</td></tr>                
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=1 width=1000>
<tr>
<th width=40>No</th><th width=200>Check Points</th><th colspan=2>Content</th>
</tr>
<tr><td>1.</td><td valign=top>Deviation Details </br>(Attach if required)</br></br>
(a) Current </br></br>(b) Proposed Deviation)
 </td><td colspan=2 valign=top>(a) $r[current_dev] </br> (b) $r[proposed_dev]
 </td></tr>               
<tr><td>2.</td><td>Reason(s): </br>(Attach if required)</td><td colspan=2 valign=top> $r[reason]</td></tr>                
<tr><td>3.</td><td valign=top>Parts/WIP/FG affected: </br>
(Attach if required) </br></br>
(a) Product Description </br><br>(b) Product Code </br><br>(c) Product Lot </br><br>(d) Product Quantity </td><td colspan=2 valign=top> $r[product]</br>
	(a) $r[prod_desc] <br>
	(b) $r[prod_code] <br>
	(c) $r[prod_lot] <br>
	(d) $r[prod_qty] <br>
</td></tr> 
              
<tr><td>4.</td><td valign=top>Deviation Period</td><td colspan=2 valign=top>$r[dev_periode]</td></tr>             
<tr><td>5.</td><td valign=top>Remarks/Instructions </br>(Attach if required)</td><td colspan=2 valign=top>$r[remark_inst]</td></tr>  
            

<tr><td colspan=3></br><input type=submit name=submit value=Return class='large orange super button'>
<input type=button class='large blue super button' value=Cancel onclick=self.history.back() ></td></tr>
</table>

</form>";
break;
// Form Edit crf 

//<tr><td>No. Max CRF</td><td>: <input type='text' name='no_surat2' size='20' value='$r[no_surat]' ></td></tr>     
case "editcrf":
$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
$reas2 =  str_replace("<BR />",'', $r['reason2']);
$supp_d =  str_replace("<BR />",'', $r['support_doc']);
$part =  str_replace("<BR />",'', $r['parts']);
echo "<h2>Modify CRF</h2>
<form method=POST action='$aksi?module=crf&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=8 cellpadding=4>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='60' value='$r[crf_no]' readonly></td></tr>  
         
<tr><td>Title</td><td>: <input type='text' name='title' size='150' value='";
echo htmlentities(htmlspecialchars_decode($r['title']), ENT_QUOTES);
echo "' ></td></tr> 
"; 
if ($r['jenis']=='minor'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' selected> Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate' > Corporate Tie-up</option> 
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='major'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' selected> Major</option> 
                                 <option value='corporate' > Corporate Tie-up</option> 
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='corporate'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate' selected> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
else {
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
								<option value=''> -Choose Type CRF- </option>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate'> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
echo "
<tr><td>Remarks</td><td>: <input type='text' name='reason1' size='100' value='";
echo htmlentities(htmlspecialchars_decode($r['reason1']), ENT_QUOTES);
echo "' ></td></tr>  
                
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 >

<tr><td valign=top rowspan=2>1.</td><td valign=top>Content Description: <i style='color:maroon;'><strong>*) avoid using of single quote (')!</strong></i></td></tr> 
<tr><td><textarea name='content' id='loko'  style='width: 800px; height: 300px;'>$r[content]</textarea>
</td></tr>              
<tr><td valign=top rowspan=2>2.</td><td>Reason: </td></tr> 
<tr><td><textarea name='reason2' style='width: 800px; height: 70px;' >$reas2</textarea></td></tr>               
<tr><td valign=top rowspan=2>3.</td><td >Parts/WIP/FG affected: </td></tr> 
<tr><td ><textarea name='parts' style='width: 800px; height: 70px;' >$part</textarea></td></tr>
              
<tr><td valign=top rowspan=2>4.</td><td >CRF Implementation: </td></tr> 
<tr><td ><textarea name='implementation' style='width: 800px; height: 30px;' >";
echo htmlentities(htmlspecialchars_decode($r['implementation']), ENT_QUOTES);
echo "</textarea></td></tr>

<tr><td valign=top rowspan=9>5.</td><td >Instructions: </td></tr> 
<tr><td valign=top >a. Roles and actions by each participants: </td></tr> 
<tr><td ><textarea name='ins_role' style='width: 800px; height: 30px;' >";
echo htmlentities(htmlspecialchars_decode($r['ins_role']), ENT_QUOTES);
echo "</textarea></td></tr>

<tr><td valign=top >b. Indication of section / Department to Feedback IRP: </td></tr> 
<tr><td ><textarea name='ins_section' style='width: 800px; height: 30px;' >";
echo htmlentities(htmlspecialchars_decode($r['ins_section']), ENT_QUOTES);
echo "</textarea></td></tr>

<tr><td valign=top >c. Indication of Training Needs: </td></tr> 
<tr><td ><textarea name='ins_training' style='width: 800px; height: 30px;' >";
echo htmlentities(htmlspecialchars_decode($r['ins_training']), ENT_QUOTES);
echo "</textarea></td></tr>

<tr><td valign=top >d. Others: </td></tr> 
<tr><td ><textarea name='other' style='width: 800px; height: 30px;' >";
echo htmlentities(htmlspecialchars_decode($r['other']), ENT_QUOTES);
echo "</textarea></td></tr>
 
<tr><td valign=top rowspan=2>6.</td><td >Supporting Document / Data: </td></tr> 
<tr><td ><textarea name='support_doc' style='width: 800px; height: 70px;' >$supp_d</textarea></td></tr> 

</table>

<p>&nbsp;</p>
<table cellspacing=4 cellpadding=4 >

<tr><td width=50>CRF Initiator:</td><td>Initiating Dept:</td><td>CRF Coordination:</td></tr>
<tr>";
 include "initiadededit.php"; 
 include "verifiededit.php"; 
 include "approvededit.php"; 
echo "</tr>

<tr><td colspan=3>__________________________________________________________________________________________________________________</td></tr>
 
</table>

";
$str3 = $r['hobi'];
$data3 = explode_trim($str3); 
echo "
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=7> Circulation To: </td></tr>
<tr><td>
<!--<input type=checkbox value='1' name=hobi[]"; if (in_array('1',$data3)){echo " checked";} echo ">QAC 1 <br>--> 
<input type=checkbox value='2' name=hobi[]"; if (in_array('2',$data3)){echo " checked";} echo ">QAC2 <br> 
<input type=checkbox value='3' name=hobi[]"; if (in_array('3',$data3)){echo " checked";} echo ">QAC3 <br> 
<input type=checkbox value='4' name=hobi[]"; if (in_array('4',$data3)){echo " checked";} echo ">QAC2-2 <br> 
<input type=checkbox value='5' name=hobi[]"; if (in_array('5',$data3)){echo " checked";} echo ">QAC5 <br> 
<input type=checkbox value='6' name=hobi[]"; if (in_array('6',$data3)){echo " checked";} echo ">QAIC <br>
<input type=checkbox value='7' name=hobi[]"; if (in_array('7',$data3)){echo " checked";} echo ">LAB  <br>
</td>
<td valign='top'>
<!--<input type=checkbox value='8' name=hobi[]"; if (in_array('8',$data3)){echo " checked";} echo ">PCT1 <br> -->
<input type=checkbox value='9' name=hobi[]"; if (in_array('9',$data3)){echo " checked";} echo ">PCT2 <br> 
<input type=checkbox value='10' name=hobi[]"; if (in_array('10',$data3)){echo " checked";} echo ">PCT3 <br> 
<input type=checkbox value='11' name=hobi[]"; if (in_array('11',$data3)){echo " checked";} echo ">PCT2-2 <br> 
<input type=checkbox value='12' name=hobi[]"; if (in_array('12',$data3)){echo " checked";} echo ">PCT5 <br>
<input type=checkbox value='35' name=hobi[]"; if (in_array('35',$data3)){echo " checked";} echo ">PQS <br> 
</td>
<td valign='top'>
<!--<input type=checkbox value='21' name=hobi[]"; if (in_array('21',$data3)){echo " checked";} echo ">EXT1<br>-->
<input type=checkbox value='14' name=hobi[]"; if (in_array('14',$data3)){echo " checked";} echo ">EXT2<br>
<input type=checkbox value='13' name=hobi[]"; if (in_array('13',$data3)){echo " checked";} echo ">EXT3<br>
<input type=checkbox value='44' name=hobi[]"; if (in_array('44',$data3)){echo " checked";} echo ">EXT4<br>  
<input type=checkbox value='42' name=hobi[]"; if (in_array('42',$data3)){echo " checked";} echo ">EXT5<br>
<input type=checkbox value='20' name=hobi[]"; if (in_array('20',$data3)){echo " checked";} echo ">INFL<br> 
<!--<input type=checkbox value='15' name=hobi[]"; if (in_array('15',$data3)){echo " checked";} echo ">TEC1<br>-->

</td><td>
<input type=checkbox value='16' name=hobi[]"; if (in_array('16',$data3)){echo " checked";} echo ">TEC2 <br> 
<input type=checkbox value='17' name=hobi[]"; if (in_array('17',$data3)){echo " checked";} echo ">TEC3 <br> 
<input type=checkbox value='18' name=hobi[]"; if (in_array('18',$data3)){echo " checked";} echo ">TEC4  <br>
<input type=checkbox value='19' name=hobi[]"; if (in_array('19',$data3)){echo " checked";} echo ">TEC5 <br> 
<input type=checkbox value='22' name=hobi[]"; if (in_array('22',$data3)){echo " checked";} echo ">PED/MTU <br>
<input type=checkbox value='41' name=hobi[]"; if (in_array('41',$data3)){echo " checked";} echo ">EAP <br> 

</td><td>
<input type=checkbox value='24' name=hobi[]"; if (in_array('24',$data3)){echo " checked";} echo ">ACC <br>
<input type=checkbox value='25' name=hobi[]"; if (in_array('25',$data3)){echo " checked";} echo ">PCH <br> 
<input type=checkbox value='26' name=hobi[]"; if (in_array('26',$data3)){echo " checked";} echo ">BQMS <br> 
<input type=checkbox value='27' name=hobi[]"; if (in_array('27',$data3)){echo " checked";} echo ">JMS(S)QMS <br> 
<input type=checkbox value='28' name=hobi[]"; if (in_array('28',$data3)){echo " checked";} echo ">Steam STZ <br>
<input type=checkbox value='29' name=hobi[]"; if (in_array('29',$data3)){echo " checked";} echo ">STR <br> 
</td>
<td>
<input type=checkbox value='30' name=hobi[]"; if (in_array('30',$data3)){echo " checked";} echo ">PPL <br>
<input type=checkbox value='31' name=hobi[]"; if (in_array('31',$data3)){echo " checked";} echo ">FAC  <br> 
<input type=checkbox value='32' name=hobi[]"; if (in_array('32',$data3)){echo " checked";} echo ">CQS <br> 
<input type=checkbox value='33' name=hobi[]"; if (in_array('33',$data3)){echo " checked";} echo ">MIS <br> 
<input type=checkbox value='34' name=hobi[]"; if (in_array('34',$data3)){echo " checked";} echo ">ETO STZ <br> 
<input type=checkbox value='23' name=hobi[]"; if (in_array('23',$data3)){echo " checked";} echo ">HR/GA <br> 
 </td> 
 <td valign='top'>
 <input type=checkbox value='36' name=hobi[]"; if (in_array('36',$data3)){echo " checked";} echo ">JMSS VCD <br> 
 <input type=checkbox value='37' name=hobi[]"; if (in_array('37',$data3)){echo " checked";} echo ">JMSS PED <br> 
 <input type=checkbox value='38' name=hobi[]"; if (in_array('38',$data3)){echo " checked";} echo ">JMSS PCH <br>
  </td> 
 <td valign='top'>
 -- Other Specify --<br>
<input type=checkbox value='39' name=hobi[]"; if (in_array('39',$data3)){echo " checked";} echo ">LKD <br> 
<input type=checkbox value='40' name=hobi[]"; if (in_array('40',$data3)){echo " checked";} echo "> <input type=text name=hobi2 value='$r[hobi2]' >
</td> </tr>
             
<tr><td colspan=2><input type=submit value=Update class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;
/**
* 
* @var <tr><td>Issue Date</td><td>: ";
$get_tgl=substr("$r[issue_date]",8,2);
combotgl(1,31,'tgl_issue_date',$get_tgl);
$get_bln=substr("$r[issue_date]",5,2);
combobln(1,12,'bln_issue_date',$get_bln);
$get_thn=substr("$r[issue_date]",0,4);
combothn(2010,$thn_sekarang,'thn_issue_date',$get_thn);
echo "</td></tr>
* 
*/
case "editcrf2":
$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
$reas2 =  str_replace("<BR />",'', $r['reason2']);
$supp_d =  str_replace("<BR />",'', $r['support_doc']);
$part =  str_replace("<BR />",'', $r['parts']);
//$cont =  str_replace("<BR />",'', $r['content']);
echo "<h2>Modify CRF</h2>
<form method=POST action='$aksi?module=crf&act=update2'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=8 cellpadding=4>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='60' value='$r[crf_no]' readonly></td></tr>  
<input type='hidden' name='no_surat2' size='20' value='$r[no_surat]' >         
<tr><td>Title</td><td>: <input type='text' name='title' size='150' value='$r[title]' ></td></tr> 
<tr><td>Issue Date</td><td>: <input type='text' name='' size='100' value='$r[issue_date]' readonly></td></tr> 
"; 
if ($r['jenis']=='minor'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' selected> Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate' > Corporate Tie-up</option> 
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='major'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' selected> Major</option> 
                                 <option value='corporate' > Corporate Tie-up</option> 
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='corporate'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate' selected> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
								else {
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
								<option value=''> -Choose Type CRF- </option>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate'> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
echo "
<tr><td>Remarks</td><td>: <input type='text' name='reason1' size='100' value='$r[reason1]' ></td></tr>  
                
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 >

<tr><td valign=top rowspan=2>1.</td><td valign=top>Content Description: </td></tr> 
<tr><td><textarea   name='content' id=loko style='width: 800px; height: 350px;'>$r[content]</textarea></td></tr>              
<tr><td valign=top rowspan=2>2.</td><td>Reason: </td></tr> 
<tr><td><textarea name='reason2' style='width: 800px; height: 70px;' >$reas2</textarea></td></tr>               
<tr><td valign=top rowspan=2>3.</td><td >Parts/WIP/FG affected: </td></tr> 
<tr><td ><textarea name='parts' style='width: 800px; height: 70px;' >$part</textarea></td></tr>
              
<tr><td valign=top rowspan=2>4.</td><td >CRF Implementation: </td></tr> 
<tr><td ><textarea name='implementation' style='width: 800px; height: 70px;' >$r[implementation]</textarea></td></tr>

<tr><td valign=top rowspan=9>5.</td><td >Instructions: </td></tr> 
<tr><td valign=top >a. Roles and actions by each participants: </td></tr> 
<tr><td ><textarea name='ins_role' style='width: 800px; height: 70px;' >$r[ins_role]</textarea></td></tr>

<tr><td valign=top >b. Indication of section / Department to Feedback IRP: </td></tr> 
<tr><td ><textarea name='ins_section' style='width: 800px; height: 70px;' >$r[ins_section]</textarea></td></tr>

<tr><td valign=top >c. Indication of Training Needs: </td></tr> 
<tr><td ><textarea name='ins_training' style='width: 800px; height: 70px;' >$r[ins_training]</textarea></td></tr>

<tr><td valign=top >d. Others: </td></tr> 
<tr><td ><textarea name='other' style='width: 800px; height: 70px;' >$r[other]</textarea></td></tr>
 
<tr><td valign=top rowspan=2>6.</td><td >Supporting Document / Data: </td></tr> 
<tr><td ><textarea name='support_doc' style='width: 800px; height: 70px;' >$supp_d</textarea></td></tr> 


</table>

<p>&nbsp;</p>
<table cellspacing=4 cellpadding=4 >

<tr><td width=50>CRF Initiator:</td><td>Initiating Dept:</td><td>CRF Coordination:</td></tr>
<tr>";
 include "initiadededit.php"; 
 include "verifiededit.php"; 
 include "approvededit.php"; 
echo "</tr>

<tr><td colspan=3>__________________________________________________________________________________________________________________</td></tr>
 
</table>



";
$str3 = $r['hobi'];
$data3 = explode_trim($str3); 
echo "
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=7> Circulation To: </td></tr>
<tr><td>
<input type=checkbox value='1' name=hobi[]"; if (in_array('1',$data3)){echo " checked";} echo ">QAC 1 <br> <input type=checkbox value='2' name=hobi[]"; if (in_array('2',$data3)){echo " checked";} echo ">QAC2 <br> <input type=checkbox value='3' name=hobi[]"; if (in_array('3',$data3)){echo " checked";} echo ">QAC3 <br> <input type=checkbox value='4' name=hobi[]"; if (in_array('4',$data3)){echo " checked";} echo ">QAC2-2 <br> <input type=checkbox value='5' name=hobi[]"; if (in_array('5',$data3)){echo " checked";} echo ">QAC5 <br> <input type=checkbox value='6' name=hobi[]"; if (in_array('6',$data3)){echo " checked";} echo ">QAIC </td>

<td>
<input type=checkbox value='7' name=hobi[]"; if (in_array('7',$data3)){echo " checked";} echo ">LAB <br>
<input type=checkbox value='8' name=hobi[]"; if (in_array('8',$data3)){echo " checked";} echo ">PCT1 <br> <input type=checkbox value='9' name=hobi[]"; if (in_array('9',$data3)){echo " checked";} echo ">PCT2 <br> <input type=checkbox value='10' name=hobi[]"; if (in_array('10',$data3)){echo " checked";} echo ">PCT3 <br> <input type=checkbox value='11' name=hobi[]"; if (in_array('11',$data3)){echo " checked";} echo ">PCT2-2 <br> <input type=checkbox value='12' name=hobi[]"; if (in_array('12',$data3)){echo " checked";} echo ">PCT5 

</td>

<td>
<input type=checkbox value='13' name=hobi[]"; if (in_array('13',$data3)){echo " checked";} echo ">EXT1-3 <br> <input type=checkbox value='14' name=hobi[]"; if (in_array('14',$data3)){echo " checked";} echo ">EXT2-2 <br>
<input type=checkbox value='15' name=hobi[]"; if (in_array('15',$data3)){echo " checked";} echo ">TEC1 <br> <input type=checkbox value='16' name=hobi[]"; if (in_array('16',$data3)){echo " checked";} echo ">TEC2 <br> <input type=checkbox value='17' name=hobi[]"; if (in_array('17',$data3)){echo " checked";} echo ">TEC3 <br> <input type=checkbox value='18' name=hobi[]"; if (in_array('18',$data3)){echo " checked";} echo ">TEC2-2 
</td>

<td>
<input type=checkbox value='19' name=hobi[]"; if (in_array('19',$data3)){echo " checked";} echo ">TEC5 <br> <input type=checkbox value='20' name=hobi[]"; if (in_array('20',$data3)){echo " checked";} echo ">EXT1-1 <br> <input type=checkbox value='21' name=hobi[]"; if (in_array('21',$data3)){echo " checked";} echo ">EXT1-2 <br>
<input type=checkbox value='22' name=hobi[]"; if (in_array('22',$data3)){echo " checked";} echo ">PED <br> <input type=checkbox value='23' name=hobi[]"; if (in_array('23',$data3)){echo " checked";} echo ">HR/GA <br> <input type=checkbox value='24' name=hobi[]"; if (in_array('24',$data3)){echo " checked";} echo ">ACC 
</td>

<td>
<input type=checkbox value='25' name=hobi[]"; if (in_array('25',$data3)){echo " checked";} echo ">PCH <br> <input type=checkbox value='26' name=hobi[]"; if (in_array('26',$data3)){echo " checked";} echo ">BQMS <br> <input type=checkbox value='27' name=hobi[]"; if (in_array('27',$data3)){echo " checked";} echo ">JMS(S)QMS <br> <input type=checkbox value='28' name=hobi[]"; if (in_array('28',$data3)){echo " checked";} echo ">Steam STZ <br>
<input type=checkbox value='29' name=hobi[]"; if (in_array('29',$data3)){echo " checked";} echo ">STR <br> <input type=checkbox value='30' name=hobi[]"; if (in_array('30',$data3)){echo " checked";} echo ">PPL 
</td>

<td>
<input type=checkbox value='31' name=hobi[]"; if (in_array('31',$data3)){echo " checked";} echo ">FAC  <br> <input type=checkbox value='32' name=hobi[]"; if (in_array('32',$data3)){echo " checked";} echo ">CQS <br> <input type=checkbox value='33' name=hobi[]"; if (in_array('33',$data3)){echo " checked";} echo ">MIS <br> <input type=checkbox value='34' name=hobi[]"; if (in_array('34',$data3)){echo " checked";} echo ">ETO STZ <br> <input type=checkbox value='35' name=hobi[]"; if (in_array('35',$data3)){echo " checked";} echo ">PQS  <br> <input type=checkbox value='41' name=hobi[]"; if (in_array('41',$data3)){echo " checked";} echo ">EAP
 </td>
 <td>
 <input type=checkbox value='36' name=hobi[]"; if (in_array('36',$data3)){echo " checked";} echo ">JMSS VCD <br> <input type=checkbox value='37' name=hobi[]"; if (in_array('37',$data3)){echo " checked";} echo ">JMSS PED <br> <input type=checkbox value='38' name=hobi[]"; if (in_array('38',$data3)){echo " checked";} echo ">JMSS PCH <br><br> Other Specify <br><br>
<input type=checkbox value='39' name=hobi[]"; if (in_array('39',$data3)){echo " checked";} echo ">LKD <br> <input type=checkbox value='40' name=hobi[]"; if (in_array('40',$data3)){echo " checked";} echo "> <input type=text name=hobi2 value='$r[hobi2]' >
</td> </tr>
             
<tr><td colspan=2><input type=submit value=Update class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;

case "editcrf3":
$edit = mysqli_query($conn, "SELECT * FROM crf WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
$reas2 =  str_replace("<BR />",'', $r['reason2']);
$supp_d =  str_replace("<BR />",'', $r['support_doc']);
$part =  str_replace("<BR />",'', $r['parts']);
//$cont =  str_replace("<BR />",'', $r['content']);
//<tr><td>ID CRF</td><td>: <input type='text' name='no_surat2' size='20' value='$r[no_surat]' ></td></tr>  
echo "<h2>Modify CRF</h2>
<form method=POST action='$aksi?module=crf&act=update3'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=8 cellpadding=4>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='60' value='$r[crf_no]' readonly></td></tr>  
            
<tr><td>Title</td><td>: <input type='text' name='title' size='140' value='$r[title]' ></td></tr> 
<tr><td>Issue Date</td><td>: ";
$get_tgl=substr("$r[issue_date]",8,2);
combotgl(1,31,'tgl_issue_date',$get_tgl);
$get_bln=substr("$r[issue_date]",5,2);
combobln(1,12,'bln_issue_date',$get_bln);
$get_thn=substr("$r[issue_date]",0,4);
combothn(2010,$thn_sekarang,'thn_issue_date',$get_thn);
echo "</td></tr>   
"; 
if ($r['jenis']=='minor'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' selected> Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate' > Corporate Tie-up</option> 
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='major'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' selected> Major</option> 
                                 <option value='corporate' > Corporate Tie-up</option> 
                                 </select> </td></tr>";  
}
 
elseif ($r['jenis']=='corporate'){
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate' selected> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
								 else {
  echo "<tr><td>CRF Issue</td><td> : <select name='jenis'>
								<option value=''> -Choose Type CRF- </option>
                                 <option value='minor' > Minor</option> 
                                 <option value='major' > Major</option> 
                                 <option value='corporate'> Corporate Tie-up</option> 
                                 </select> </td></tr> ";
                                 }
echo "
<tr><td>Remarks</td><td>: <input type='text' name='reason1' size='100' value='$r[reason1]' ></td></tr>  
                
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 >

<tr><td valign=top rowspan=2>1.</td><td valign=top>Content Description: </td></tr> 
<tr><td><textarea name='content' id=loko style='width: 800px; height: 350px;'>$r[content]</textarea></td></tr>              
<tr><td valign=top rowspan=2>2.</td><td>Reason: </td></tr> 
<tr><td><textarea name='reason2' style='width: 800px; height: 70px;' >$reas2</textarea></td></tr>               
<tr><td valign=top rowspan=2>3.</td><td >Parts/WIP/FG affected: </td></tr> 
<tr><td ><textarea name='parts' style='width: 800px; height: 70px;' >$part</textarea></td></tr>
              
<tr><td valign=top rowspan=2>4.</td><td >CRF Implementation: </td></tr> 
<tr><td ><textarea name='implementation' style='width: 800px; height: 70px;' >$r[implementation]</textarea></td></tr>

<tr><td valign=top rowspan=9>5.</td><td >Instructions: </td></tr> 
<tr><td valign=top >a. Roles and actions by each participants: </td></tr> 
<tr><td ><textarea name='ins_role' style='width: 800px; height: 70px;' >$r[ins_role]</textarea></td></tr>

<tr><td valign=top >b. Indication of section / Department to Feedback IRP: </td></tr> 
<tr><td ><textarea name='ins_section' style='width: 800px; height: 70px;' >$r[ins_section]</textarea></td></tr>

<tr><td valign=top >c. Indication of Training Needs: </td></tr> 
<tr><td ><textarea name='ins_training' style='width: 800px; height: 70px;' >$r[ins_training]</textarea></td></tr>

<tr><td valign=top >d. Others: </td></tr> 
<tr><td ><textarea name='other' style='width: 800px; height: 70px;' >$r[other]</textarea></td></tr>
 
<tr><td valign=top rowspan=2>6.</td><td >Supporting Document / Data: </td></tr> 
<tr><td ><textarea name='support_doc' style='width: 800px; height: 70px;' >$supp_d</textarea></td></tr> 


</table>

<p>&nbsp;</p>
<table cellspacing=4 cellpadding=4 >

<tr><td width=50>CRF Initiator:</td><td>Initiating Dept:</td><td>CRF Coordination:</td></tr>
<tr>";
 include "initiadededit.php"; 
 include "verifiededit.php"; 
 include "approvededit.php"; 
echo "</tr>

<tr><td colspan=3>__________________________________________________________________________________________________________________</td></tr>
 
</table>

";
$str3 = $r['hobi'];
$data3 = explode_trim($str3); 
echo "
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=7> Circulation To: </td></tr>
<tr><td>
<input type=checkbox value='1' name=hobi[]"; if (in_array('1',$data3)){echo " checked";} echo ">QAC 1 <br> <input type=checkbox value='2' name=hobi[]"; if (in_array('2',$data3)){echo " checked";} echo ">QAC2 <br> <input type=checkbox value='3' name=hobi[]"; if (in_array('3',$data3)){echo " checked";} echo ">QAC3 <br> <input type=checkbox value='4' name=hobi[]"; if (in_array('4',$data3)){echo " checked";} echo ">QAC2-2 <br> <input type=checkbox value='5' name=hobi[]"; if (in_array('5',$data3)){echo " checked";} echo ">QAC5 <br> <input type=checkbox value='6' name=hobi[]"; if (in_array('6',$data3)){echo " checked";} echo ">QAIC </td>

<td>
<input type=checkbox value='7' name=hobi[]"; if (in_array('7',$data3)){echo " checked";} echo ">LAB <br>
<input type=checkbox value='8' name=hobi[]"; if (in_array('8',$data3)){echo " checked";} echo ">PCT1 <br> <input type=checkbox value='9' name=hobi[]"; if (in_array('9',$data3)){echo " checked";} echo ">PCT2 <br> <input type=checkbox value='10' name=hobi[]"; if (in_array('10',$data3)){echo " checked";} echo ">PCT3 <br> <input type=checkbox value='11' name=hobi[]"; if (in_array('11',$data3)){echo " checked";} echo ">PCT2-2 <br> <input type=checkbox value='12' name=hobi[]"; if (in_array('12',$data3)){echo " checked";} echo ">PCT5 

</td>

<td>
<input type=checkbox value='13' name=hobi[]"; if (in_array('13',$data3)){echo " checked";} echo ">EXT1-3 <br> <input type=checkbox value='14' name=hobi[]"; if (in_array('14',$data3)){echo " checked";} echo ">EXT2-2 <br>
<input type=checkbox value='15' name=hobi[]"; if (in_array('15',$data3)){echo " checked";} echo ">TEC1 <br> <input type=checkbox value='16' name=hobi[]"; if (in_array('16',$data3)){echo " checked";} echo ">TEC2 <br> <input type=checkbox value='17' name=hobi[]"; if (in_array('17',$data3)){echo " checked";} echo ">TEC3 <br> <input type=checkbox value='18' name=hobi[]"; if (in_array('18',$data3)){echo " checked";} echo ">TEC2-2 
</td>

<td>
<input type=checkbox value='19' name=hobi[]"; if (in_array('19',$data3)){echo " checked";} echo ">TEC5 <br> <input type=checkbox value='20' name=hobi[]"; if (in_array('20',$data3)){echo " checked";} echo ">EXT1-1 <br> <input type=checkbox value='21' name=hobi[]"; if (in_array('21',$data3)){echo " checked";} echo ">EXT1-2 <br>
<input type=checkbox value='22' name=hobi[]"; if (in_array('22',$data3)){echo " checked";} echo ">PED <br> <input type=checkbox value='23' name=hobi[]"; if (in_array('23',$data3)){echo " checked";} echo ">HR/GA <br> <input type=checkbox value='24' name=hobi[]"; if (in_array('24',$data3)){echo " checked";} echo ">ACC 
</td>

<td>
<input type=checkbox value='25' name=hobi[]"; if (in_array('25',$data3)){echo " checked";} echo ">PCH <br> <input type=checkbox value='26' name=hobi[]"; if (in_array('26',$data3)){echo " checked";} echo ">BQMS <br> <input type=checkbox value='27' name=hobi[]"; if (in_array('27',$data3)){echo " checked";} echo ">JMS(S)QMS <br> <input type=checkbox value='28' name=hobi[]"; if (in_array('28',$data3)){echo " checked";} echo ">Steam STZ <br>
<input type=checkbox value='29' name=hobi[]"; if (in_array('29',$data3)){echo " checked";} echo ">STR <br> <input type=checkbox value='30' name=hobi[]"; if (in_array('30',$data3)){echo " checked";} echo ">PPL 
</td>

<td>
<input type=checkbox value='31' name=hobi[]"; if (in_array('31',$data3)){echo " checked";} echo ">FAC  <br> <input type=checkbox value='32' name=hobi[]"; if (in_array('32',$data3)){echo " checked";} echo ">CQS <br> <input type=checkbox value='33' name=hobi[]"; if (in_array('33',$data3)){echo " checked";} echo ">MIS <br> <input type=checkbox value='34' name=hobi[]"; if (in_array('34',$data3)){echo " checked";} echo ">ETO STZ <br> <input type=checkbox value='35' name=hobi[]"; if (in_array('35',$data3)){echo " checked";} echo ">PQS  <br> <input type=checkbox value='41' name=hobi[]"; if (in_array('41',$data3)){echo " checked";} echo ">EAP
 </td>
 <td>
 <input type=checkbox value='36' name=hobi[]"; if (in_array('36',$data3)){echo " checked";} echo ">JMSS VCD <br> <input type=checkbox value='37' name=hobi[]"; if (in_array('37',$data3)){echo " checked";} echo ">JMSS PED <br> <input type=checkbox value='38' name=hobi[]"; if (in_array('38',$data3)){echo " checked";} echo ">JMSS PCH <br><br> Other Specify <br><br>
<input type=checkbox value='39' name=hobi[]"; if (in_array('39',$data3)){echo " checked";} echo ">LKD <br> <input type=checkbox value='40' name=hobi[]"; if (in_array('40',$data3)){echo " checked";} echo "> <input type=text name=hobi2 value='$r[hobi2]' >
</td> </tr>
             
<tr><td colspan=2><input type=submit value=Update class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;

case "appcrf":
echo "
<table>
<tr><td><h2><u><i>Approve CRF</i></u></h2></td> <td><h2><u><i>Disapprove CRF</i></u></h2></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>

<form method=POST action='?module=crf&act=view_crfapp' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfapp.php";

echo "
<tr><td colspan=2 ><input type=submit name=submit class='large orange super button' value='View Data'></td></tr>
</table>
</form>
</td>



<td>
<form method=POST action='?module=crf&act=view_crfunapp' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfunapp.php";

echo "
<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='View Data'></td></tr>
</table>
</form>
</td>
</tr>


<tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>

<tr><td><h2><u><i>Close CRF</i></u></h2></td> <td><h2><u><i>UnCLosed CRF</i></u></h2></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr><td>
<form method=POST action='?module=crf&act=view_crfclose' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfclose.php";

echo "
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value='View Data'></td></tr>
</table>
</form>
</td>

<td>
<form method=POST action='?module=crf&act=view_crfunclose' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfunclose.php";

echo "
<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='View Data'></td></tr>
</table>
</form>
</td>
</tr>

<tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr>

<tr><td><h2><u><i>View All Approved CRF</i></u></h2></td></tr>
<tr><td>&nbsp;</td><td>&nbsp;</td></tr>
<tr>
<td>
<form method=POST action='?module=crf&act=view_crfall' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfall.php";

echo "
<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='View Data'></td></tr>
</table>
</form>
</td>
</tr>




</table>

";
break;

case "appcrfori":
echo "
<table border=0 width=1000>
<tr><td><h2><u><i>Approve CRF</i></u></h2></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>

<form method=POST action='?module=crf&act=view_crfapp' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfapp.php";

echo "
<tr><td colspan=2 ><input type=submit name=submit class='large orange super button' value='View Data'></td></tr>
</table>
</form>
</td>
</tr>


<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
<tr><td><h2><u><i>Close CRF</i></u></h2></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>
<form method=POST action='?module=crf&act=view_crfclose' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfclose.php";

echo "
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value='View Data'></td></tr>
</table>
</form>
</td>
</tr>

<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr>
<tr><td><h2><u><i>UnClose CRF</i></u></h2></td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td>
<form method=POST action='?module=crf&act=view_crfunclose' enctype='multipart/form-data'>

<table  cellspacing=10 cellpadding=6>
";
include "crfunclose.php";

echo "
<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='View Data'></td></tr>
</table>
</form>
</td>
</tr>
</table>

";
break;

case "view_crfapp":
echo "
<table  class='pretty dataTable'>
<thead><tr><th width=10>No</th>
<th width=150>CRF No</th><th width=100>Section</th><th>Title</th><th width=130>Create Date</th><th width=170>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id ='$_POST[id_crf]' ");
$r=mysqli_fetch_array($tampil);
	$tggl= tgl_indo($r['create_date']);
  echo "<tr><td>1.</td>
	<td>$r[crf_no]</td>
      <td>$r[section2]</td>
      	<td>$r[title]</td><td>$tggl</td>
    <td><a href='?module=crf&act=approvecrf&id=$r[id]'> <img src='images/approve.png' alt='edit' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=$aksi?module=crf&act=cetakaffect&id=$r[id] target=_blank><img src='images/info.png' alt='cetak' /></a>
        </td></tr>
        </table>";

break;

case "view_crfclose":
echo "
<table  class='pretty dataTable'>
<thead><tr><th width=10>No</th>
<th width=150>CRF No</th><th width=130>Issue Date</th><th width=100>Section</th><th>Title</th><th width=130>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_POST[id_crf2]' ");
$r=mysqli_fetch_array($tampil);
	$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>1.</td>
	<td>$r[crf_no]</td>
     <td>$tggl</td>	 <td>$r[section2]</td>	
      	<td>$r[title]</td>	
    <td><a href='?module=crf&act=closecrf&id=$r[id]'><img src='images/checked.png' alt='edit' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=$aksi?module=crf&act=cetakaffect&id=$r[id] target=_blank><img src='images/info.png' alt='cetak' /></a>
        </td></tr>
        </table>";

break;

case "view_crfunclose":
echo "
<table  class='pretty dataTable'>
<thead><tr><th width=10>No</th>
<th width=150>CRF No</th><th width=130>Report Date</th><th width=100>Section</th><th>Title</th><th width=130>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_POST[id_crf3]' ");
$r=mysqli_fetch_array($tampil);
	$tggl= tgl_indo($r['report_date']);
  echo "<tr><td>1.</td>
	<td>$r[crf_no]</td>
     <td>$tggl</td>	 <td>$r[section2]</td>	
      	<td>$r[title]</td>	
    <td><a href='?module=crf&act=unclosecrf&id=$r[id]'><img src='images/undo2.png' alt='edit' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=$aksi?module=crf&act=cetakaffect&id=$r[id] target=_blank><img src='images/info.png' alt='cetak' /></a>
        </td></tr>
        </table>";

break;

case "view_crfunapp":
echo "
<table  class='pretty dataTable'>
<thead><tr><th width=10>No</th>
<th width=150>CRF No</th><th width=130>Issue Date</th><th width=100>Section</th><th>Title</th><th width=130>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_POST[id_crf33]' ");
$r=mysqli_fetch_array($tampil);
	$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>1.</td>
	<td>$r[crf_no]</td>
     <td>$tggl</td>	 <td>$r[section2]</td>	
      	<td>$r[title]</td>	
    <td><a href='?module=crf&act=unappcrf&id=$r[id]'><img src='images/undo2.png' alt='edit' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=$aksi?module=crf&act=cetakaffect&id=$r[id] target=_blank><img src='images/info.png' alt='cetak' /></a>
        </td></tr>
        </table>";

break;

case "view_crfall":
echo "
<table  class='pretty dataTable'>
<thead><tr><th width=10>No</th>
<th width=150>CRF No</th><th width=130>Issue Date</th><th width=100>Section</th><th>Title</th><th width=130>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_POST[id_crf4]' ");
$r=mysqli_fetch_array($tampil);
	$tggl= tgl_indo($r['issue_date']);
  echo "<tr><td>1.</td>
	<td>$r[crf_no]</td>
     <td>$tggl</td>	 <td>$r[section2]</td>	
      	<td>$r[title]</td>	
    <td><a href='?module=crf&act=editcrf3&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=crf&act=delete3&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=crf&act=cetak&id=$r[id]&jenis=$r[jenis] target=_blank><img src='images/cetak.png' alt='cetak' /></a>|<a href=$aksi?module=crf&act=cetakaffect&id=$r[id] target=_blank><img src='images/info.png' alt='cetak' /></a>
        </td></tr>
        </table>";

break;

case "closecrf":
$edit = mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Close IRP Report</h2><br>
<form method=POST action='$aksi?module=crf&act=close'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='30' value='$r[crf_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='130' value='$r[title]' readonly></td></tr> 
<tr><td>Section</td><td>: <input type='text' name='section' size='70' value='$r[section2]' readonly></td></tr> 
<tr><td>&nbsp;</td></tr>
<tr><td><strong><u>Reporting Date</strong></u></td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2010,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo" <small><strong><u><i> Report Date Must be filled!</i></u></stong></small></td></tr>          

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Close Report'>
	<input type=button class='large blue super button' value=Cancel onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;

case "unclosecrf":
$edit = mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>UnClose IRP Report</h2><br>
<form method=POST action='$aksi?module=crf&act=unclose'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='30' value='$r[crf_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='140' value='$r[title]' readonly></td></tr> 
<tr><td>Section</td><td>: <input type='text' name='section' size='70' value='$r[section2]' readonly></td></tr> 
<tr><td>&nbsp;</td></tr>
        

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='UnClose Report'>
	<input type=button class='large blue super button' value=Cancel onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;

case "unappcrf":
$edit = mysqli_query($conn, "SELECT c.*, sc.section as section2 FROM crf c, sectioncode sc where c.section=sc.id and  c.id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Disapprove CRF</h2><br>
<form method=POST action='$aksi?module=crf&act=unapp'  onsubmit=''>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>CRF No</td><td>: <input type='text' name='crf_no' size='30' value='$r[crf_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='140' value='$r[title]' readonly></td></tr> 
<tr><td>Section</td><td>: <input type='text' name='section' size='70' value='$r[section2]' readonly></td></tr> 
<tr><td>&nbsp;</td></tr>
        

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Disapprove CRF'>
	<input type=button class='large blue super button' value=Cancel onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;

case "importcrf":

echo "<h2>Import Status Log CRF</h2>
<p>&nbsp;</p>
<form name='myForm' id='myForm' onSubmit='return validateForm()' action='$aksi?module=crf&act=import' method='post' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td>File </td><td>: <input type='file' id='filepegawaiall' name='filepegawaiall' /></td></tr>
<tr><td colspan=2><strong><small><i>*Format of Excel File Must 97-2003! <i></small></strong></td></tr>
<tr><td colspan=2><label><input type='checkbox' name='drop' value='1' /> <u>Do you want to delete all the Old CRF Data? </u> </label>   </td></tr>
<tr><td colspan=2></br>Sample of Excel Format File: </td></tr>
<tr><td colspan=2></br><strong><i><small>Note: Data will be imported start on Row Two (2) A2,B2,C2..
  </small></i></strong></td></tr>
<tr><td colspan=2>No Image</td></tr>
<tr><td colspan=2><input type=submit name=submit class='large blue super button' value=Import>
<input type=button value=Cancel class='large orange super button' onclick=self.history.back()></td></tr>

    </table>
</form>";

break;


}


?>
