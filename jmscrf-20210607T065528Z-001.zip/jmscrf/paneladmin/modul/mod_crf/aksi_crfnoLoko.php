<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
  <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
  include "../../config/koneksi.php";

  
  $module=$_GET['module'];
  $act=$_GET['act'];
  
  $crf_no = htmlentities($_POST['crf_no']);
  $crf_kd = htmlentities($_POST['crf_kd']);
  $id_crf = htmlentities($_POST['id_crf']);
  $no_surat = htmlentities($_POST['no_surat']);
  $no_surat2 = htmlentities($_POST['no_surat2']);
  $section=$_SESSION['section'];
  $issue_date=$_POST['thn_issue_date'].'-'.$_POST['bln_issue_date'].'-'.$_POST['tgl_issue_date'];
  $title = htmlentities($_POST['title']);
  $current_dev = htmlentities($_POST['current_dev']);
  $proposed_dev = htmlentities($_POST['proposed_dev']);
  $jenis = htmlentities($_POST['jenis']);
  $reason1 = htmlentities($_POST['reason1']);
  $reason2 = htmlentities($_POST['reason2']);
  $content = str_replace("\n", '<BR />', $_POST['content']);
  $parts = htmlentities($_POST['parts']);
  $implementation = htmlentities($_POST['implementation']);
  $ins_role = htmlentities($_POST['ins_role']);
  $ins_section = htmlentities($_POST['ins_section']);
  $ins_training = htmlentities($_POST['ins_training']);
  $other = htmlentities($_POST['other']);
  $support_doc = htmlentities($_POST['support_doc']);
  //$affect_doc = htmlentities($_POST['affect_doc']);
  
  $initiaded = htmlentities($_POST['initiaded']);
  $verified = htmlentities($_POST['verified']);
  $approved = htmlentities($_POST['approved']);
  
  $hobi1 = htmlentities($_POST['hobi1']);
  $hobi2 = htmlentities($_POST['hobi2']);
 
 	//detail affect doc
  $doc_code = htmlentities($_POST['doc_code']);
  $old = htmlentities($_POST['old']);
  $new = htmlentities($_POST['new']);
  $remark = htmlentities($_POST['remark']);
 
 
  
   if (!empty($_POST['hobi'])){
       $p_hobi = $_POST['hobi'];
       $hobi=implode(',',$p_hobi);
  }
 
  if ($module=='crf' AND $act=='input'){
  	
 mysql_query ("insert into crf (crf_no, section,create_date, status,  
 					jenis, title,reason1, content, 
					reason2,parts,implementation,
					ins_role, ins_section, 
					ins_training, other, support_doc,initiaded,
					verified,approved,hobi,hobi1,hobi2,no_surat,crf_kd) values (
					'$crf_no','$_SESSION[section]','$issue_date','0','$jenis',
					'$title','$reason1','$content','$reason2','$parts','$implementation',
					'$ins_role','$ins_section','$ins_training','$other','$support_doc',
					upper('$initiaded'),upper('$verified'), 
					upper('$approved'), '$hobi','$hobi1', upper('$hobi2'),'$no_surat','$crf_kd')			                      
               ");
		
     header('location:../../index.php?module='.$module);
    
            
  }
  
  else if ($module=='crf' AND $act=='inputaffect'){
  	        mysql_query("INSERT INTO affect_doc (id_crf,doc_code,old,new,remark,verified,approved,revised,status) VALUES('$id_crf','$doc_code',
					'$old','$new','$remark',
					upper('$verified'),
					upper('$approved'),'y','o')");
     header('location:../../index.php?module=crf&act=affectcrf&id='.$_POST['id_crf']);
            
  }
   else if ($module=='crf' AND $act=='deleteaffect'){
  	        mysql_query("delete from affect_doc where id= '$_GET[id]'");
     header('location:../../index.php?module=crf&act=affectcrf&id='.$_GET['id_crf']);
            
  }
  else if ($module=='crf' AND $act=='updateaffect'){
  	        mysql_query("update affect_doc set doc_code= '$doc_code',old='$old', 
  	        new='$new', remark='$remark', verified=upper('$verified'),approved=upper('$approved') 
  	        where id= '$_POST[id]'");
     header('location:../../index.php?module=crf&act=affectcrf&id='.$_POST['id_crf']);
            
  }
  // Update crf  
  elseif ($module=='crf' AND $act=='update'){ 
 	//$sect=mysql_query("SELECT * FROM sectioncode where id ='$_SESSION[section]'");
	//$s=mysql_fetch_array($sect);
 	//$qkodesurat=mysql_query("SELECT CONCAT('CRF/',RIGHT(CONCAT('000', CONVERT($_POST[no_surat2], CHAR( 4 ) ) ) ,3 ),'/$s[crf]/',DATE_FORMAT(curdate(),'%y')) as kode_surat");
	//$rkodesurat=mysql_fetch_array($qkodesurat);  
  	//$newcrf_no = $rkodesurat['kode_surat'];
  	
   //crf_no='$newcrf_no' , no_surat=$_POST[no_surat2]
    mysql_query ("update  crf set jenis='$jenis',
					title='$title',reason1='$reason1', content='$content', 
					reason2='$reason2',parts='$parts',implementation='$implementation',
					ins_role='$ins_role', ins_section='$ins_section', 
					ins_training='$ins_training', other='$other', support_doc='$support_doc',
					initiaded=upper('$initiaded'), verified=upper('$verified'), 
					approved=upper('$approved'), hobi='$hobi', hobi1='$hobi1', hobi2=upper('$hobi2')			                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module='.$module);
  }
    
     elseif ($module=='crf' AND $act=='update2'){ 
  
  
 	//$sect=mysql_query("SELECT * FROM sectioncode where id ='$_SESSION[section]'");
	//$s=mysql_fetch_array($sect);
 	//$qkodesurat=mysql_query("SELECT CONCAT('CRF/',RIGHT(CONCAT('000', CONVERT($_POST[no_surat2], CHAR( 4 ) ) ) ,3 ),'/$s[crf]/',DATE_FORMAT(curdate(),'%y')) as kode_surat");
	//$rkodesurat=mysql_fetch_array($qkodesurat);  
  //	$newcrf_no = $rkodesurat['kode_surat'];
  	
    //crf_no='$newcrf_no',     , no_surat=$_POST[no_surat2]	
    mysql_query ("update  crf set  jenis='$jenis',
					title='$title',reason1='$reason1', content='$content', 
					reason2='$reason2',parts='$parts',implementation='$implementation',
					ins_role='$ins_role', ins_section='$ins_section', 
					ins_training='$ins_training', other='$other', support_doc='$support_doc',
					initiaded=upper('$initiaded'), verified=upper('$verified'), 
					approved=upper('$approved'), hobi='$hobi', hobi1='$hobi1', hobi2=upper('$hobi2')		                      
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=approved');
  }
    elseif ($module=='crf' AND $act=='update3'){ 
  
  
 	//$sect=mysql_query("SELECT * FROM sectioncode where id ='$_SESSION[section]'");
	//$s=mysql_fetch_array($sect);
 	//$qkodesurat=mysql_query("SELECT CONCAT('CRF/',RIGHT(CONCAT('000', CONVERT($_POST[no_surat2], CHAR( 4 ) ) ) ,3 ),'/$s[crf]/',DATE_FORMAT(curdate(),'%y')) as kode_surat");
	//$rkodesurat=mysql_fetch_array($qkodesurat);  
  	//$newcrf_no = $rkodesurat['kode_surat'];
  	
    
    mysql_query ("update  crf set 
    				issue_date = '$issue_date',
    				jenis='$jenis',
					title='$title',reason1='$reason1', content='$content', 
					reason2='$reason2',parts='$parts',implementation='$implementation',
					ins_role='$ins_role', ins_section='$ins_section', 
					ins_training='$ins_training', other='$other', support_doc='$support_doc',
					initiaded=upper('$initiaded'), verified=upper('$verified'), 
					approved=upper('$approved'), hobi='$hobi', hobi1='$hobi1', hobi2=upper('$hobi2')
                    WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
   elseif ($module=='crf' AND $act=='approve'){ 
          
    mysql_query("UPDATE crf SET  issue_date = '$issue_date',
					status = '1'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  
    
  elseif ($module=='crf' AND $act=='return'){ 
          
    mysql_query("UPDATE crf SET  issue_date=null,
					status = '0'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  
   elseif ($module=='crf' AND $act=='close'){ 
          
    mysql_query("UPDATE crf SET  report_date = '$issue_date',
					status = '3'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  elseif ($module=='crf' AND $act=='unclose'){ 
          
    mysql_query("UPDATE crf SET  report_date=null,
					status = '2'                                        
                          WHERE id = '$_POST[id]'");
    
    header('location:../../index.php?module=crf&act=appcrf');
  }
  // Delete crf  
  elseif ($module=='crf' AND $act=='delete'){
            
      mysql_query("DELETE FROM crf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module='.$module);
            
  }
  elseif ($module=='crf' AND $act=='delete2'){
            
      mysql_query("DELETE FROM crf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module=crf&act=approved');
            
  }
  elseif ($module=='crf' AND $act=='delete3'){
            
      mysql_query("DELETE FROM crf WHERE id = '$_GET[id]'");
      header('location:../../index.php?module=crf&act=appcrf');
            
  }
  
  else if ($module=='crf' AND $act=='cetak') {

if ($_GET['jenis']=='minor' or $_GET['jenis']=='Minor') {
	include"cetak.php";
}	else {
	include"cetak2.php";
}
	
}

 else if ($module=='crf' AND $act=='cetakaffect') {
include"cetak3.php";

}

    else if ($module=='crf' AND $act=='import'){ 
          
    require "../../excel_reader.php";

//jika tombol import ditekan
    $target = basename($_FILES['filepegawaiall']['name']) ;
    move_uploaded_file($_FILES['filepegawaiall']['tmp_name'], $target);
    
    $data = new Spreadsheet_Excel_Reader($_FILES['filepegawaiall']['name'],false);
    
//    menghitung jumlah baris file xls
    $baris = $data->rowcount($sheet_index=0);
    
//    jika kosongkan data dicentang jalankan kode berikut
    if($_POST['drop']==1){
//             kosongkan tabel pegawai
             $truncate ="TRUNCATE TABLE crf";
             mysql_query($truncate);
    };
    
//    import data excel mulai baris ke-2 (karena tabel xls ada header pada baris 1)
    for ($i=2; $i<=$baris; $i++)
    {
//       membaca data (kolom ke-1 sd terakhir)
      $crf_no           = $data->val($i, 3);
      $section           = $data->val($i, 2);
      $tit           = $data->val($i, 8);
      $title = mysql_real_escape_string($tit);
      $imp           = $data->val($i, 16);
      $implementation = mysql_real_escape_string($imp);
      
      $thnn1		   =$data->val($i, 14);
      $blnn1		   =$data->val($i, 13);
      $tgll1		   =$data->val($i, 12);
      $issue_date	= $thnn1.'-'.$blnn1.'-'.$tgll1;
      
      $thnn		   =$data->val($i, 19);
      $blnn		   =$data->val($i, 20);
      $tgll		   =$data->val($i, 21);
      $report_date	= '20'.$thnn.'-'.$blnn.'-'.$tgll;
      
   	  $rem	   =$data->val($i, 24);
   	  $remark = mysql_real_escape_string($rem); 
      $status	   = $data->val($i, 25);
      $initiaded	= $data->val($i, 23);
      $no_surat		= $data->val($i, 7);
      $crf_kd		= $data->val($i, 5);
      $jenis		= $data->val($i, 10);
 //      setelah data dibaca, masukkan ke tabel pegawai sql
      $query = "INSERT into crf (crf_no,section,create_date,issue_date,report_date,status,jenis,
      title,implementation,initiaded,no_surat,crf_kd) values('$crf_no','$section','2010-01-01','$issue_date','$report_date','$status','$jenis',
      '$title','$implementation',upper('$initiaded'),'$no_surat','$crf_kd')";
      $hasil = mysql_query($query);
    }
    
   //    hapus file xls yang udah dibaca
    unlink($_FILES['filepegawaiall']['name']);
    
    header('location:../../index.php?module=home');
  }


  }
?>
