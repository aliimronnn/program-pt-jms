<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");


$sql=mysql_query("select cr.*, case cr.jenis when 'minor' then 'Minor' 
when 'major' then 'Major' else
'Corporate Tie-up' end as 'jenis2', sc.section as section2
from crf cr, sectioncode sc where cr.section=sc.id and cr.id='$_GET[id]'
");
$e=mysql_fetch_array($sql);
$qkode= mysql_query("select *from doc_code where dokumen= 'crf'");
$rkode=mysql_fetch_array($qkode);
/*$initiaded= mysql_query("select empname  from employee where empno='$e[initiaded]'");
$i=mysql_fetch_array($initiaded);
$verified= mysql_query("select  empname from employee where empno='$e[verified]'");
$v=mysql_fetch_array($verified);
$approved= mysql_query("select empname from employee where empno='$e[approved]'");
$ap=mysql_fetch_array($approved);
$verified2= mysql_query("select  empname from employee where empno='$e[verified2]'");
$v2=mysql_fetch_array($verified2);
$approved3= mysql_query("select empname from employee where empno='$e[approved3]'");
$ap3=mysql_fetch_array($approved3);*/
//$tanggal=tgl_indo($e['issue_date']);
$html = 
'
<html>
				<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:12 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20;margin-top: 1.4 cm; margin-bottom: 0.5 cm;margin-right:-20; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:9 pt;}
				tr th{ padding-left:5px;}	
				
					
}

				</style></head>
				
<body>
 <div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>

<div style="font-size:14px"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Issue Date &nbsp;&nbsp;: </strong></div>

<table border=0 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" ><br>Title : '.$e[title].'</td></tr>
<tr><td >________________________________________________________________________________________________________________</td></tr>
<tr><td ><br>CRF Issue : '.$e[jenis2].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Remarks : '.$e[reason1].'</td></tr>

</table>


<div align="left" STYLE="font-size:12px"><br>1. Content Description :</div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="70" >'.$e[content].'</td></tr>
 </table>
 
 
<div align="left" STYLE="font-size:12px"><br>2. Reason :</div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="60" >'.$e[reason2].'</td></tr>
 </table>
 
 
<div align="left" STYLE="font-size:12px"><br>3. Parts/WIP/FG Affected : </div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="50" >'.$e[parts].'</td></tr>
 </table>
 
 
<div align="left" STYLE="font-size:12px"><br>4. CRF Implementation :</div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="40" >'.$e[implementation].'</td></tr>
 </table>
 
 
<div align="left" STYLE="font-size:12px"><br>5. Instructions : </div> 
<table>
<tr></td><td rowspan=2 valign="top">  a.</td><td>Roles and actions by each participant : </td></tr>
<tr><td>
<table border=1 width=543 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="30" >'.$e[ins_role].'</td></tr>
 </table>
 </td></tr>
</table>  
<table>
<tr></td><td rowspan=2 valign="top">  b.</td><td>Indication of section / Department to Feedback IRP : </td></tr>
<tr><td>
<table border=1 width=543 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="30" >'.$e[ins_section].'</td></tr>
 </table>
 </td></tr>
</table>  
<table>
<tr></td><td rowspan=2 valign="top">  c.</td><td>Indication of Training Needs : </td></tr>
<tr><td>
<table border=1 width=543 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="30" >'.$e[ins_training].'</td></tr>
 </table>
 </td></tr>
</table>  
<table>
<tr></td><td rowspan=2 valign="top">  d.</td><td>Others : </td></tr>
<tr><td>
<table border=1 width=543 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="30" >'.$e[other].'</td></tr>
 </table>
 </td></tr>
</table>  

<div align="left" STYLE="font-size:12px"><br>6. Supporting Document / Data :</div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="40" >'.$e[support_doc].'</td></tr>
 </table> 
 
<div align="left" STYLE="font-size:12px"><br>7. Affected Document / Data :</div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="20">Refer to BQMS/PRO/002-Document/Quality Control Procedure/Record Update Reminder For Change Request</td></tr>
 </table> 
 <div >&nbsp;</div>  
<table  border=0 width=565 cellpadding="0" cellspacing="0">
<tr><td width="165">CRF Initiator : </td><td width="165">Initiating Dept : </td> <td width="200">CRF Coordination : </td></tr>
<tr><td><table width="170" CELLPADDING="0" cellspacing="0" border=1><tr><td valign=bottom  height=40>'.$e[initiaded].'</td></tr></table></td>
	<td><table width="170" CELLPADDING="0" cellspacing="0" border=1><tr><td valign=bottom  height=40>'.$e[verified].'</td></tr></table></td>
	<td><table width="210" CELLPADDING="0" cellspacing="0" border=1><tr><td valign=bottom  height=40>'.$e[approved].'</td></tr></table></td>
</tr>

</table>

<div align="left" STYLE="font-size:12px"><br>Review Board (S/D) <br>JMSB(B)</div>   <br>
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="bottom" width="70" height="70px" >QMS / LAB</td><td valign="bottom" width="70">* QAC / PED</td> <td valign="bottom" width="70">* PPL / STR</td>
<td valign="bottom" width="70">* PUR / ACC</td> <td valign="bottom" width="70">PCT</td>
<td valign="bottom" width="65">TEC</td> <td valign="bottom" width="60">GA / HR</td> <td valign="bottom">Others</td></tr>

</table>

<div align="left" STYLE="font-size:12px"><br>Approver(s)</div>   
<table border=1 width=150 cellpadding="0" cellspacing="0">
<tr><td valign="bottom" width="150" height="90px" >JMS(B)<br>Department Head (S/D)</td>
</tr>
</table>
<br>
<table width=543 border=0 style="font-size:11px">
<tr><td  valign=top colspan=2>Note : </td></tr>
<tr><td width=5>1.</td><td >Please cancel unused boxes before issuing</td></tr>
<tr><td >2.</td><td >The initiators Department / or Division Head is fully responsible to determine whether the nature of change falls under (Minor Issue), (Major Issue), or (Corporate Tie-up Issue) </td></tr>
<tr><td width=5>3.</td><td >Department Head shall approve under Minor Issue</td></tr>
<tr><td width=5>4.</td><td >QMS(S) is to be notified (given a copy) of this approved CRF</td></tr>
<tr><td width=5>5.</td><td >* Delete whichever not applicable</td></tr>
</table>

<br>
<table cellpadding="0" cellspacing="0" border=1 width=565>
<tr><td> 
<table width="565" style="font-size: 8px" >
<tr><td colspan=6>Circulation To: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: QMS Unit is to be issued the original DRAF for filling</td></tr>
<tr><td>	
';
$str3 = $e[hobi];
$data3 = explode(",",$str3); 
$html.=' 
 <input type="checkbox" style="width:20px;"'; if (in_array("1",$data3)){$html.='checked';} $html.='> QAC 1 <br>
 <input type="checkbox" style="width:20px;"'; if (in_array("2",$data3)){ $html.='checked';}  $html.='> QAC2 <br>
 <input type="checkbox" style="width:20px;"'; if (in_array("3",$data3)){ $html.='checked';}  $html.='> QAC3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("4",$data3)){ $html.='checked';}  $html.='> QAC2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("5",$data3)){ $html.='checked';}  $html.='> QAC5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("6",$data3)){ $html.='checked';}  $html.='> QAIC <br>
 <input type=checkbox style="width:20px;"'; if (in_array("7",$data3)){ $html.='checked';}  $html.='> LAB <br></td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("8",$data3)){ $html.='checked';}  $html.='> PCT1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("9",$data3)){ $html.='checked';}  $html.='> PCT2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("10",$data3)){ $html.='checked';}  $html.='> PCT3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("11",$data3)){ $html.='checked';}  $html.='> PCT2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("12",$data3)){ $html.='checked';}  $html.='> PCT5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("13",$data3)){ $html.='checked';}  $html.='> EXT1-3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("14",$data3)){ $html.='checked';}  $html.='> EXT2-2 <br></td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("15",$data3)){ $html.='checked';}  $html.='> TEC1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("16",$data3)){ $html.='checked';}  $html.='> TEC2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("17",$data3)){ $html.='checked';}  $html.='> TEC3 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("18",$data3)){ $html.='checked';}  $html.='> TEC2-2 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("19",$data3)){ $html.='checked';}  $html.='> TEC5 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("20",$data3)){ $html.='checked';}  $html.='> EXT1-1 <br>
 <input type=checkbox style="width:20px;"'; if (in_array("21",$data3)){ $html.='checked';}  $html.='> EXT1-2 <br></td><td>
 <input type=checkbox style="width:20px;"'; if (in_array("22",$data3)){ $html.='checked';}  $html.='> PED <br>
 <input type=checkbox style="width:20px;"'; if (in_array("23",$data3)){ $html.='checked';}  $html.='> HR/GA <br>
 <input type=checkbox style="width:20px;"'; if (in_array('24',$data3)){ $html.='checked';}  $html.='> ACC <br>
 <input type=checkbox style="width:20px;"'; if (in_array('25',$data3)){ $html.='checked';}  $html.='> PCH <br>
 <input type=checkbox style="width:20px;"'; if (in_array('26',$data3)){ $html.='checked';}  $html.='> BQMS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('27',$data3)){ $html.='checked';}  $html.='> JMS(S )QMS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('28',$data3)){ $html.='checked';}  $html.='> Steam STZ <br> </td><td>
 <br><input type=checkbox style="width:20px;"'; if (in_array('34',$data3)){ $html.='checked';}  $html.='> ETO STZ <br>
 <input type=checkbox style="width:20px;"'; if (in_array('29',$data3)){ $html.='checked';}  $html.='> STR <br>
 <input type=checkbox style="width:20px;"'; if (in_array('30',$data3)){ $html.='checked';}  $html.='> PPL <br>
 <input type=checkbox style="width:20px;"'; if (in_array('31',$data3)){ $html.='checked';}  $html.='> FAC  <br>
 <input type=checkbox style="width:20px;"'; if (in_array('32',$data3)){ $html.='checked';}  $html.='> CQS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('33',$data3)){ $html.='checked';}  $html.='> MIS <br>
 <input type=checkbox style="width:20px;"'; if (in_array('35',$data3)){ $html.='checked';}  $html.='> EAP <br>
 <input type=checkbox style="width:20px;"'; if (in_array('41',$data3)){ $html.='checked';}  $html.='> PQS <br>
 </td><td valign=top>
 <br><input type=checkbox style="width:20px;"'; if (in_array('36',$data3)){ $html.='checked';}  $html.='> JMSS VCD <br>
 <input type=checkbox style="width:20px;"'; if (in_array('37',$data3)){ $html.='checked';}  $html.='> JMSS PED <br>
 <input type=checkbox style="width:20px;"'; if (in_array('38',$data3)){ $html.='checked';}  $html.='> JMSS PCH <br>
 <br> Other Specify <br><br>
 <input type=checkbox style="width:20px;"'; if (in_array('39',$data3)){ $html.='checked';}  $html.='> LKD/OM <br>
 <input type=checkbox style="width:20px;"'; if (in_array('40',$data3)){ $html.='checked';}  $html.='> '.$e[hobi2].' <br>
 </td></tr>
           
 </table> </td> </tr>
 </table>

</body></html>';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("a4", "portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$font = Font_Metrics::get_font("helvetica");
$font2 = Font_Metrics::get_font("helvetica", "bold");
$canvas->page_text(95, 15, "PT. JMS BATAM", $font2, 10, array(0,0,0));
$canvas->page_text(95, 28, "Blok 210-212, Jalan Beringin, Muka Kuning, Batam 29433, Indonesia", $font, 8, array (0,0,0));
$canvas->page_text(95, 38, "Cammo Industrial Park, Blok F, No.2, Batam Centre, Batam 29433, Indonesia", $font, 8, array (0,0,0));
$canvas->page_text(13, 60, "CHANGE REQUEST FORM (CRF)", $font2, 10, array(0,0,0));
$canvas->page_text(428, 60, "CRF Code   : $e[crf_no]", $font2, 10, array(0,0,0));


$canvas->page_text(16, 800, "S/D : Signature / Date", $font, 9, array(0,0,0));
$canvas->page_text(300, 805, "Page: {PAGE_NUM} of {PAGE_COUNT}", $font, 9, array(0,0,0));
$canvas->page_text(16, 810, "Doc. Code : $rkode[code1]", $font, 9, array(0,0,0));
$canvas->page_text(500, 800, "$rkode[code2]", $font, 9, array(0,0,0));

$dompdf->stream("form.pdf", array("Attachment" => false));
?>