<?php
error_reporting(E_ALL);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);

$id1=@$_POST['id'];
$id2=@$_GET['id'];
if ($id1== NULL){
	$id3 = $id2;
} else if($id2==NULL) {
	$id3 = $id1;
}
$sql=mysqli_query($conn, "SELECT id, crf_no, title, initiaded FROM crf where id='$id3'");
$e=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * FROM doc_code WHERE dokumen= 'affect'");
$rkode=mysqli_fetch_array($qkode);
$html =
'
<html>
	<style type="text/css">			
	#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
	body{font-size:12 pt;  font-family:verdana,helvetica,arial,tahoma; 
	margin-left:-20;margin-top: 0.8 cm; margin-bottom: 0.5 cm;margin-right:-20; }
			
	tr td{ padding-left:5px;padding-top:1px; font-size:9 pt;}
	tr th{ padding-left:5px;}						
}
</style>				
<body>
<div id="header">
    <img src="../../images/logo-besar.png" alt="" />
</div>
<table border="1" cellspacing=0; cellpadding=0; style="font-size:9pt;" width="540">
<tr><td valign=middle colspan=7 height=20><b>AFFECTED DOCUMENT/QUALITY CONTROL PROCEDURE/RECORD UPDATE REMINDER FOR CHANGE REQUEST</b></td></tr>
<tr><td valign=top colspan=2 height=20>CRF No : '.$e['crf_no'].'</td><td valign=top colspan=5 rowspan=2 > Title : '.$e['title'].'</td></tr>
<tr><td valign=top colspan=2 height=20 >CRF Initiator : '.$e['initiaded'].'</td></tr>
<tr><td width="10">S/N</td><td width=110>DOCUMENT CODE</TD><td align=center width=60>Old<BR>RN No.</TD><td width=60 align=center>New<br>RN No.</TD><td align=center width=50>*Remarks<br>N.R.O</TD><td width=70 align=center>Indicated By<br>(CRF Reviewer)</TD><td width=70 align=center>Checked By<br>(DCR)</TD></tr>
 ';
    $no=1;
    $detail=mysqli_query($conn, "SELECT *, new as new2 from affect_doc where id_crf= '$e[id]' and status='o'");
    while($d=mysqli_fetch_array($detail)){
    $html.=' 	<tr><td height="15">'.$no.'.</td>
        <td>'.$d['doc_code'].'</td>
        <td>'.$d['old'].'</td>
        <td>'.$d['new2'].'</td>
        <td>'.$d['remark'].'</td>
        <td>'.$d['verified'].'</td>
        <td>'.$d['approved'].'</td>
        </tr>';
        $no++;
    }
    $html.='
        </tr>
        <tr>
        <td height="15"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        </tr>
        <tr>
        <td height="15"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        </tr>
        </table>
<table border="0" cellspacing=0; cellpadding=0; style="font-size:9pt;" width="540" >
<tr><td colspan=5>N=New, R=Revise, O=Obsolete<br>
* Completion date shall be 2 Months (By Default) from CRF Implementation Date, unless otherwise stated (under Remarks)<br>
</td></tr>
<tr><td colspan=2>Potensial Documents Affected By Change : -</td><td width=50 rowspan=14 valign=top align=right width=5>8.</td><td colspan=2>Device Master Record (DMR), e.g. : -</td></tr>
<tr><td width="2">1.</td><td width="230">Quality Manual (Please indicate Section(s) affected)</td><td rowspan=3 width="5" valign=top>a.</td><td>Device / Part Specification</td></tr>
<tr><td>2.</td><td>Quality Procedures </td><td>- Standard Charts</td></tr>
<tr><td>3.</td><td>Standard Opearating Procedures </td><td>- Part / Material Specification Drawing</td></tr>
<tr><td>4.</td><td>Quality Records</td><td >b.</td><td>Packaging / Labeling Specification Drawing</td></tr>
<tr><td rowspan=4 valign=top>5.</td><td>Regulatory Documents (e.g)</td><td rowspan=4 valign=top>c.</td><td>Production Process Specification</td></tr>
<tr><td>- Product Registration Document</td><td>- Production Manufacturing Process Flow Chart</td></tr>
<tr><td>- Technical Files</td><td>- Manufacturing Instruction</td></tr>
<tr><td>- 510K Document</td><td>- Machine Manuals</td></tr>
<tr><td rowspan=2 valign=top>6.</td><td>Master Listing (e.g.)</td><td rowspan=5 valign=top>d.</td><td>QA Specification</td></tr>
<tr><td>- Calibration (QAC, LAB, PED, PCT, TEC)</td><td>- QA Acceptance</td></tr>
<tr><td rowspan=3 valign=top>7.</td><td>Others:- </td><td>- QA Inspection Stations</td></tr>
<tr><td>- Electronic Document Management System</td><td>- Process Tolerance Specification</td></tr>
<tr><td>- JMS(B) Documents</td><td>- Limit Samples</td></tr>
</table>
</body></html>';

//<div style="page-break-before: always;"></div>	
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();


$canvas->page_text(95, 15, "PT. JMS BATAM", "Helvetica-Bold", 10, array(0,0,0));
$canvas->page_text(95, 28, "Blok 210-212, Jalan Beringin, Muka Kuning, Batam 29433, Indonesia", "Helvetica", 8, array (0,0,0));
$canvas->page_text(95, 38, "Cammo Industrial Park, Blok F, No.2, Batam Centre, Batam 29433, Indonesia", "Helvetica", 8, array (0,0,0));

$canvas->page_text(16, 790, "(Link to CRF)", "Helvetica", 9, array(0,0,0));
$canvas->page_text(300, 800, "Page: {PAGE_NUM} of {PAGE_COUNT}", "Helvetica", 9, array(0,0,0));
$canvas->page_text(16, 800, "Document Code : $rkode[code1]", "Helvetica", 9, array(0,0,0));
$canvas->page_text(490, 800, "$rkode[code2]", "Helvetica", 9, array(0,0,0));

$dompdf->stream("form.pdf", array("Attachment" => false));
?>