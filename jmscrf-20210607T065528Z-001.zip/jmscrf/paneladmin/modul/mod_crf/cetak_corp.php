<?php
error_reporting(E_ALL);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);


$sql=mysqli_query($conn, "SELECT cr.crf_no,cr.title, cr.reason1, cr.content,cr.reason2, cr.parts, cr.implementation, cr.ins_role, cr.ins_section,
cr.ins_training,cr.other, cr.support_doc,cr.initiaded,cr.verified, cr.approved, cr.hobi, cr.hobi2,  case cr.jenis when 'minor' then 'Minor' 
when 'major' then 'Major' else
'Corporate Tie-up' end as 'jenis2', sc.section as section2
from crf cr, sectioncode sc where cr.section=sc.id and cr.id='$_GET[id]'
");
$e=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * from doc_code where dokumen= 'crf'");
$rkode=mysqli_fetch_array($qkode);

$html = 
'
<html>
    <head><style type="text/css">

            #header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }

            body{font-size:12 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
                 margin-left:-20;margin-top: 1.2 cm; margin-bottom: 0.4 cm;margin-right:-20; }

            tr td{ padding-left:5px;padding-top:1px; font-size:8.3 pt;}
            tr th{ padding-left:5px;}
	
            }

        </style></head>

    <body>
        <div id="header">
            <img src="../../images/logo-besar.png" alt="" />
        </div>

        <div style="font-size:14px"><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  Issue Date &nbsp;: </strong></div>

        <table border=0 width=565 cellpadding="0" cellspacing="0">
            <tr><td colspan="2" valign="top" > <br>Title : '.$e['title'].'</td></tr>
            <tr><td colspan="2" > ___________________________________________ _________________________________________________ _________________________</td></tr 
            <tr><td valign="top" width="150">CRF Issue : '.$e['jenis2'].' </td> <td >Remarks : '.$e['reason1'].'</td></tr>

        </table>


        <div align="left" STYLE="font-size:12px"><br>1. Content Description :</div>   
        <div style="border:1px solid black; font-size:10px; width:740px; padding:5px;">'.$e['content'].'
        </div>


        <div align="left" STYLE="font-size:12px"><br>2. Reason :</div>   
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="top" width="150px" height="20" >'.$e['reason2'].'</td></tr>
        </table>


        <div align="left" STYLE="font-size:12px"><br>3. Parts/WIP/FG Affected : </div>   
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="top" width="150px" height="20" >'.$e['parts'].'</td></tr>
        </table>

        <div align="left" STYLE="font-size:12px"><br>4. Work Environment & Safety Affected :  &nbsp;&nbsp;&nbsp;<input type=checkbox style="width:20px;height:18px;"> Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type=checkbox style="width:20px;height:18px;">No  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox style="width:20px;height:18px;">NA</div>   
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="top" width="400px" ><small>(To be reviewed by QA Lab section head and above)</small><br><br>
                    <small><u>Signature</u></small><br>
                </td><td valign=top><small>Remarks: </small></td></tr>
        </table>


        <div align="left" STYLE="font-size:12px"><br>5. CRF Implementation :</div>   
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="top" width="150px" height="20" >'.$e['implementation'].'</td></tr>
        </table>


        <div align="left" STYLE="font-size:12px"><br>6. Instructions : </div> 
        <table>
            <tr></td><td rowspan=2 valign="top">  a.</td><td>Roles and actions by each participant : </td></tr>
            <tr><td>
                    <table border=1 width=545 cellpadding="0" cellspacing="0">
                        <tr><td valign="top" width="150px" height="20" >'.$e['ins_role'].'</td></tr>
                    </table>
                </td></tr>
        </table>  
        <table>
            <tr></td><td rowspan=2 valign="top">  b.</td><td>Indication of section / Department to Feedback IRP : </td></tr>
            <tr><td>
                    <table border=1 width=545 cellpadding="0" cellspacing="0">
                        <tr><td valign="top" width="150px" height="20" >'.$e['ins_section'].'</td></tr>
                    </table>
                </td></tr>
        </table>  
        <table>
            <tr></td><td rowspan=2 valign="top">  c.</td><td>Indication of Training Needs : </td></tr>
            <tr><td>
                    <table border=1 width=545 cellpadding="0" cellspacing="0">
                        <tr><td valign="top" width="150px" height="20" >'.$e['ins_training'].'</td></tr>
                    </table>
                </td></tr>
        </table>  
        <table>
            <tr></td><td rowspan=2 valign="top">  d.</td><td>Others : </td></tr>
            <tr><td>
                    <table border=1 width=545 cellpadding="0" cellspacing="0">
                        <tr><td valign="top" width="150px" height="20" >'.$e['other'].'</td></tr>
                    </table>
                </td></tr>
        </table>  

        <div align="left" STYLE="font-size:12px"><br>7. Supporting Document / Data :</div>   
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="top" width="150px" height="20" >'.$e['support_doc'].'</td></tr>
        </table> 

        <div align="left" STYLE="font-size:12px"><br>8. Affected Document / Data : <br>
            Refer to BQMS/PRO/002-Document/Quality Control Procedure/Record Update Reminder For Change Request</div>   


        <table  border=0 width=565 cellpadding="0" cellspacing="0">
            <tr><td width="165">CRF Initiator : </td><td width="165">Initiating Dept : </td> <td width="200">CRF Coordination : </td></tr>
            <tr><td><table width="170" CELLPADDING="0" cellspacing="0" border=1><tr><td valign=bottom  height=40>'.$e['initiaded'].'</td></tr></table></td>
                <td><table width="170" CELLPADDING="0" cellspacing="0" border=1><tr><td valign=bottom  height=40>'.$e['verified'].'</td></tr></table></td>
                <td><table width="210" CELLPADDING="0" cellspacing="0" border=1><tr><td valign=bottom  height=40>'.$e['approved'].'</td></tr></table></td>
            </tr>

        </table>
        <div style="page-break-before: always;"></div>
        <div align="left" STYLE="font-size:12px"><u>9. Product Risk Assessment (QMS Judgement)</u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Reviewer</div> 
        <table border=0 width=565 cellpadding="0" cellspacing="0">
            <tr><td width="310">Are there any known risk with respect to Risk Management Plan / FMEA? </td>
                <td width=50><input type=checkbox style="width:20px;height:18px;" > Yes </td><td width=50><input type=checkbox style="width:20px;height:18px;" > No </td><td width=50><input type=checkbox style="width:20px;height:18px;" > Na </td><td rowspan="2" align="center"><textarea style="width: 107px; height: 50px; font-style:times new roman "><br><br><br>QMS Unit</textarea></td></tr>

            <tr><td >if Yes, please state Ref.No:  _________________________</td><td><input type=checkbox style="width:20px;height:18px;" > Yes </td><td><input type=checkbox style="width:20px;height:18px;" > No </td><td><input type=checkbox style="width:20px;height:18px;" > Na </td></tr>

            <tr><td colspan=5>Is risk acceptable (supporting rationale to be indicated)<br>
                    Remarks :  <textarea style="width: 560px; height: 15px;"></textarea></td></tr>
        </table>

        <div align="left" STYLE="font-size:12px"><u>10. Notification</u></div>
        <table  width=565 border=1 cellpadding="0" cellspacing="0">
            <tr>
                <td width="180" valign=top>Notification required to CQM?<br>
                    <table width="180" border=0 cellpadding="0" cellspacing="0">
                        <tr>
                            <td>
                                <input type=checkbox style="width:20px;height:18px;" >YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NO  
                            </td>
                        </tr>
                    </table><br>
                    To be filled by JMSB QA Division Head
                </td>
                
                <td valign=top>Notification required? <br>
                    <table width="180" border=0 cellpadding="0" cellspacing="0">
                        <tr>
                            <td>
                                <input type=checkbox style="width:20px;height:18px;" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NO  &nbsp;&nbsp;&nbsp;&nbsp;
                                <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NA 
                            </td>
                        </tr>
                    </table>
                    if yes pls specify: <br>
                    <table width="180" border=0 cellpadding="0" cellspacing="0">
                        <tr>
                            <td>
                                <input type=checkbox style="width:20px;height:18px;" > CQM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NB  &nbsp;&nbsp;&nbsp;&nbsp;
                                <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > Others: ____
                            </td>
                        </tr>
                    </table>
                    To be filled by QMS(S) Officer and above <br>
                </td>

                <td valign=top>Notification required to MOH-RI? <br>
                    <table width="180" border=0 cellpadding="0" cellspacing="0">
                        <tr>
                            <td>
                                <input type=checkbox style="width:20px;height:18px;" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NO  &nbsp;&nbsp;&nbsp;&nbsp;
                            </td>
                        </tr>
                    </table><br><br>
                    To be filled by JMSB QMS-RA Section Head and above if changes related to domestic sales<br>
                </td>
            </tr>

            <tr>
                <td  height="15" valign="middle">Sign/Date : </td>
                <td>Sign/Date : </td> 
                <td>Sign/Date : </td> 
            </tr>
            <tr>
                <td colspan="3" height="15" valign="middle"># Notification Ref No: __________________
                <br>(Will be assign by QMS (B)/(S) if notification judgement is required)</td> 
            </tr>
        </table>

        <div align="left" STYLE="font-size:12px"><strong>Review Board (S/D)</strong> <br>JMS(B)</div>
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="bottom" width="65" height="40px" >QMS / LAB</td><td valign="bottom" width="60">*QAC / PED</td> <td valign="bottom" width="65">*PPL / STR</td>
                <td valign="bottom" width="60">*PUR / ACC</td> <td valign="bottom" width="50">PCT</td>
                <td valign="bottom" width="50">TEC</td> <td valign="bottom" width="60">GA / HR</td><td width="55" valign="bottom">Others</td></tr>

        </table>

        <div align="left" STYLE="font-size:12px"><br>JMS(S)-QMS(S) and Relevant JMS(S) Manager.</div> 
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="bottom" width="80" height="40px" >QMS</td><td valign="bottom" width="90">*QAC/LAB</td> <td valign="bottom" width="90">*PPL/STR </td>
                <td valign="bottom" width="90">*PUR/SLS</td> <td valign="bottom" width="90">PCT</td>
                <td valign="bottom">Others</td></tr>

        </table>


        <div align="left" STYLE="font-size:12px"><strong>APPROVAL BOARD (S/D)</strong></div> 
        <table border=1 width=565 cellpadding="0" cellspacing="0">
            <tr><td valign="bottom" width="80" height="60px" align="center">JMS(B) <br>QA Division Head (S/D)</td><td align="center" valign="bottom" width="80">JMS(B)<br>Plant Director (S/D) /<br>President Director (S/D)</td> <td align="center" valign="bottom" width="80">JMS(S)<br>QA Department<br>Head/Division Head (S/D)</td>
                <td  align="center" valign="bottom" width="80">JMS(S) MD (S/D)</td>

        </table>

        <table width=550 border=0 style="font-size:10px">
            <tr><td  valign=top colspan=2>Note : </td></tr>
            <tr><td width=5>1.</td><td >Please cancel unused boxes before issuing.</td></tr>
            <tr><td valign="top">2.</td><td valign="top">The Initiators Department fully responsible to determine whether the nature of change fall under Minor lssue, Major lssue, or
                    Corporate Tie-up lssue</td></tr>
            <tr><td width=5>3.</td><td >JMSB QA Division Head shall approve under Major and Corporate tie up issue</td></tr>
            <tr><td width=5>4.</td><td >QMS(S) is to be notified (given a copy) of this approved CRF</td></tr>
            <tr><td width=5>5.</td><td >Plant Director / President Director shall approve CRF for below Issue:</td></tr>
            <tr><td width=5></td><td >Change affect of organization structure</td></tr>
            <tr><td width=5></td><td >When PCT/QA/PED/Admin Division Head Decided that Plant Director /President Approval Is necessary.</td></tr>
            <tr><td width=5>6.</td><td >JMSS QA Division Head shall approve under Corporate tie up issue</td></tr>
            <tr><td width=5>7.</td><td >JMSS MD approval required for below issued:</td></tr>
            <tr><td width=5></td><td >When PCT/QA/PED/AdmIn Headdecided MD approval Isrequired.</td></tr>
            <tr><td width=5>8.</td><td >*Delete whichever not applicable.</td></tr>
        </table>

        <table border=1 width=565 style="font-size: 6px;padding-left:0px;padding-top:0px;" cellpadding="0" cellspacing="0">

        <tr>
        <td> 
        <table width="750px" style="font-size: 6px;padding-left:0px;padding-top:0px;" cellpadding="0" cellspacing="0">
        <tr><td colspan=7>Circulation To: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: QMS Unit will maintain the original CRF for filling</td></tr>
        
        <tr><td>
        ';
      $str3 = $e['hobi'];
      $data3 = explode(",",$str3); 
      $html.=' 
       <!--<input type="checkbox" style="width:15px;height:18px;"'; if (in_array("1",$data3)){$html.='checked';} $html.='> QAC 1<br>-->
       <input type="checkbox" style="width:15px;height:18px;"'; if (in_array("2",$data3)){ $html.='checked';}  $html.='> QAC2<br>
       <input type="checkbox" style="width:15px;height:18px;"'; if (in_array("3",$data3)){ $html.='checked';}  $html.='> QAC3<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("4",$data3)){ $html.='checked';}  $html.='> QAC4<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("5",$data3)){ $html.='checked';}  $html.='> QAC5<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("6",$data3)){ $html.='checked';}  $html.='> QAIC<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("7",$data3)){ $html.='checked';}  $html.='> LAB<br>
       </td><td>
       <!--<input type=checkbox style="width:15px;height:18px;"'; if (in_array("8",$data3)){ $html.='checked';}  $html.='> PCT1<br>-->
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("9",$data3)){ $html.='checked';}  $html.='> PCT2<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("10",$data3)){ $html.='checked';}  $html.='> PCT3<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("11",$data3)){ $html.='checked';}  $html.='> PCT4<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("12",$data3)){ $html.='checked';}  $html.='> PCT5<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('35',$data3)){ $html.='checked';}  $html.='> PQS<br>
       </td><td>
       <!--<input type=checkbox style="width:15px;height:18px;"'; if (in_array("21",$data3)){ $html.='checked';}  $html.='> EXT1<br>-->
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("14",$data3)){ $html.='checked';}  $html.='> EXT2<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("13",$data3)){ $html.='checked';}  $html.='>  EXT3<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("44",$data3)){ $html.='checked';}  $html.='> EXT4<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("42",$data3)){ $html.='checked';}  $html.='> EXT5<br>
        <input type=checkbox style="width:15px;height:18px;"'; if (in_array("20",$data3)){ $html.='checked';}  $html.='> INFLATION<br>
      </td><td>
      <!--<input type=checkbox style="width:15px;height:18px;"'; if (in_array("15",$data3)){ $html.='checked';}  $html.='> TEC1<br>-->
      <input type=checkbox style="width:15px;height:18px;"'; if (in_array("16",$data3)){ $html.='checked';}  $html.='> TEC2<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("17",$data3)){ $html.='checked';}  $html.='> TEC3<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("18",$data3)){ $html.='checked';}  $html.='> TEC4<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("19",$data3)){ $html.='checked';}  $html.='> TEC5<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("22",$data3)){ $html.='checked';}  $html.='> PED/MTU<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('41',$data3)){ $html.='checked';}  $html.='> EAP<br>
       </td><td>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('24',$data3)){ $html.='checked';}  $html.='> ACC<br>
        <input type=checkbox style="width:15px;height:18px;"'; if (in_array('25',$data3)){ $html.='checked';}  $html.='> PCH<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('26',$data3)){ $html.='checked';}  $html.='> BQMS<br>
      <input type=checkbox style="width:15px;height:18px;"'; if (in_array('27',$data3)){ $html.='checked';}  $html.='> JMS(S)QMS<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('28',$data3)){ $html.='checked';}  $html.='> Steam STZ<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('29',$data3)){ $html.='checked';}  $html.='> STR
      </td><td>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('30',$data3)){ $html.='checked';}  $html.='> PPL<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('31',$data3)){ $html.='checked';}  $html.='> FAC<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('32',$data3)){ $html.='checked';}  $html.='> CQS<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('33',$data3)){ $html.='checked';}  $html.='> MIS<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array('34',$data3)){ $html.='checked';}  $html.='> ETO STZ<br>
       <input type=checkbox style="width:15px;height:18px;"'; if (in_array("23",$data3)){ $html.='checked';}  $html.='> HR/GA
       </td>
       
      <td valign="baseline">
       <!-- <input type=checkbox style="width:15px;height:15px;"'; if (in_array('36',$data3)){ $html.='checked';}  $html.='> JMSS VCD<br>
       <input type=checkbox style="width:15px;height:15px;"'; if (in_array('37',$data3)){ $html.='checked';}  $html.='> JMSS PED<br>
       <input type=checkbox style="width:15px;height:15px;"'; if (in_array('38',$data3)){ $html.='checked';}  $html.='> JMSS PCH<br> -->
       <input type=checkbox style="width:15px;height:18px;" checked>JMSS VCD<br>
       <input type=checkbox style="width:15px;height:18px;" checked>JMSS PED<br>
       <input type=checkbox style="width:15px;height:18px;" checked>JMSS PCH<br>
       </td>
       
       <td valign="baseline">
       Other Specify <br>
       <input type=checkbox style="width:20px;height:18px;"'; if (in_array('39',$data3)){ $html.='checked';}  $html.='> LKD<br>
       <input type=checkbox style="width:20px;height:18px;"'; if (in_array('40',$data3)){ $html.='checked';}  $html.='>'.$e['hobi2'].'<br>
       </td></tr>
       </table> </td> </tr>
       </table>
    </body></html>';
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$canvas->page_text(95, 28, "PT. JMS BATAM", "Helvetica-Bold", 14, array(0,0,0));
//$canvas->page_text(95, 28, "Jalan Beringin Lot 211-212, Kawasan Industri Batamindo, Muka Kuning-Batam 29433 INDONESIA", $font, 8, array (0,0,0));
//$canvas->page_text(95, 38, "Telepon : (62) 770-611807 Faksimili : (62) 770-611-806", $font, 8, array (0,0,0));
$canvas->page_text(13, 55, "CHANGE REQUEST AND APPROVAL FORM (CRF)", "Helvetica-Bold", 10, array(0,0,0));
$canvas->page_text(405, 55, "CRF Code    : $e[crf_no]", "Helvetica-Bold", 10, array(0,0,0));


$canvas->page_text(16, 790, "S/D : Signature / Date", "Helvetica", 8, array(0,0,0));
$canvas->page_text(16, 800, "Doc. Code : $rkode[code1], $rkode[code3], $rkode[code4]", "Helvetica", 8, array(0,0,0));
$canvas->page_text(280, 805, "Page: {PAGE_NUM} of {PAGE_COUNT}", "Helvetica", 8, array(0,0,0));
$canvas->page_text(505, 790, "$rkode[code2]", "Helvetica", 8, array(0,0,0));

$dompdf->stream("form.pdf", array("Attachment" => false));
?>