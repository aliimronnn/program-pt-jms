<?php
require_once("../../dompdf/dompdf_config.inc.php");
require_once("../../config/fungsi_indotgl.php");
require_once("../../config/koneksi.php");


$kapalku=mysql_query("select * from crf where id=94");
$kapal=mysql_fetch_array($kapalku);
	$html = '
				
		
				
				<html>
				<head><style type="text/css">
				body{  font-size:11pt; margin-top:1cm; font-family:verdana,helvetica,arial,sans-serif,tahoma; }
				td{padding-top:10px;}
				</style></head>
<body>
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td valign="top" width="150px" height="70" >
'.$kapal[content].'</td></tr></table>
</body>

';
	
$dompdf = new DOMPDF();
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$dompdf->stream("form.pdf", array("Attachment" => false));
?>