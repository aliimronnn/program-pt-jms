<?php
error_reporting(E_ALL);

// menyertakan autoloader
require_once("../../dompdf_08_04/autoload.inc.php");
require_once("../../config/fungsi_indotgl.php");

// mengacu ke namespace DOMPDF
use Dompdf\Dompdf;
use Dompdf\Helpers;
use Dompdf\Exception\ImageException;

// menggunakan class dompdf
$dompdf = new Dompdf();
$dompdf->set_option('isRemoteEnabled', true);

$sql=mysqli_query($conn, "SELECT * from deviation where id='$_GET[id]'
");
$e=mysqli_fetch_array($sql);
$qkode= mysqli_query($conn, "SELECT * from doc_code where dokumen= 'deviation'");
$rkode=mysqli_fetch_array($qkode);
$qdraf=mysqli_query($conn, "SELECT draft_no, title from draf where id='$e[id_draf]'");
$rdraf=mysqli_fetch_array($qdraf);
$html = 
'
<html>	<head><style type="text/css">
				
				#header { position: fixed; left:0;margin-left:-20;margin-top: -0.75 cm; right: 0px; height: 150px;  text-align: left; }
				
				body{font-size:11 pt;  font-family:verdana,helvetica,arial,sans-serif,tahoma; 
				margin-left:-20;margin-top: 2 cm; margin-bottom: 1 cm;margin-right:-10; }
			
				tr td{ padding-left:5px;padding-top:1px; font-size:9 pt;}
				tr th{ padding-left:5px;}	
			
					
}

				</style></head>
				
<body>
 <div id="header">
    <img src="../../images/logo-besar.png" alt="" />
  </div>

<div style="font-size:14px"><strong>PART I </strong></div>

<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td height="25" valign="top" colspan=5>Title : '.$rdraf['title'].'</td></tr>
<tr align=center><td  height="20" colspan="1" >No</td><td width="110">Check Points</td><td width="370" colspan="3">Contents</td></tr>
<tr><td valign="top">1. </td><td valign="top">Parts/WIP/FG affected : <br>(Attach if required)<br>
	(a) Product Description<br>
	(b) Product Code<br>
	(c) Product Lot<br>
	(d) Product Quantity <br><br>
</td><td valign="top" colspan=3 height=120>'.$e['product'].' <br>(a) '.$e['prod_desc'].' <br>
	(b) '.$e['prod_code'].' <br> (c) '.$e['prod_lot'].' <br> (d) '.$e['prod_qty'].'</td></tr>

<tr><td valign="top">2. </td><td valign="top">Deviation Period <br>(Maximum 6 Month)<br><br></td><td valign="top" colspan=3 >'.$e['dev_periode'].'</td></tr>

<tr><td valign="top">3. </td><td valign="top">Problem Encounter / <br>Special Remarks: <br>
(Attach if required)</td><td valign="top" colspan=3 >'.$e['problem_encounter'].'<br><br><u>Counter Measure(s): </u><br><br>'.$e['counter_measure'].'<br><br></td></tr>

<tr><td valign="top">4. </td><td valign="top">Improvement Plan<br> (Attach if required)<br><br></td><td valign="top" colspan=3 >'.$e['plan'].'<br><br></td></tr>
</table>


 <div align="left" STYLE="font-size:14px"><strong><strong>PART II (Deviation Conclusion)</strong></div>  
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td colspan=3>Deviation Succesfully Implemented &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > NO <br>
 Deviation Control Record (if applicable) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > APPROVED DATE: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > REJECTED DATE: <br>Deviation Control Record Reference No. &nbsp;&nbsp;&nbsp;: <br>Note (if Any): </td></tr>
 
 <tr><td width="170">Reported By <br><br><br>(S/D):SPV</td><td>Verified By: <br><br><br>(S/D): Controller & above </td><td>Approved By: <br><br><br>(S/D) Department Head/Division Head </td></tr>
 
 </table>
 
<div align="left" STYLE="font-size:14px"><strong>PART III (Cross Function Judgement, Select A &/or B)</strong><br>A. QA Judgement (QAC/LAB)</div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td colspan=2>Deviation Succesfully Implemented &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > NO <br>
<br>Note (if Any): </td></tr>
 
 <tr><td width="250">Agreed By (S/D)<br><br><br>(S/D) (Controller & above)</td><td>Verified By (S/D) <br><br><br>(S/D) Department Head/Division Head)</td></tr>
 
 </table>
 
  <div align="left" STYLE="font-size:14px">B. PCT Judgement </div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td colspan=2>Deviation Succesfully Implemented &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;height:18px;" name="cus_approval" value="y" > NO <br>
<br>Note (if Any): </td></tr>
 
 <tr><td width="250">Agreed By (S/D)<br><br><br>(S/D) (Controller & above)</td><td>Verified By (S/D) <br><br><br>(S/D) Department Head/Division Head)</td></tr>
 
 </table>
 
<p>
 <div align="left" STYLE="font-size:14px"><strong>PART IV (Risk Assesment)</strong><br>QMS Judgement </div>   
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td width="200">Are there any known risk <br>With respect to risk Management Plan / FMEA? <br>
if Yes, please state Ref.No: </td><td> <input type=checkbox style="width:20px;height:18px;" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NO  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NA
 <br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Reason: </td></tr>
 <tr><td>Is Risk Acceptable? <br>
 Supporting rationale to be indicated</td> <td><input type=checkbox style="width:20px;height:18px;" > YES &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input type=checkbox style="width:20px;height:18px;" name="cus_approval" > NO </td></tr>

<tr>
<td>Remarks: <br> <br>  <br> <br> </td><td></td>
</tr>
 <tr><td colspan=2 >Verified by (S/D): <br><br><br>(Controller & above)</td></tr>
 
 </table>
  <div align="left" STYLE="font-size:12px"><br></div>
<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td width="290">Approved by (PD)<br> <br> S/D</td><td valign="top">Remarks <br> <br> </td></tr>
 </table>
 
 
 

<p>&nbsp;</p>
<p style="font-size:11px">
Note : <br>
> Plant Director/President Director (PD) will approve DRAF when PCT/QA Head cannot reach compromise, or when the PCT/QA Head decides that PD`s approval necessary.<br>
> Plant/President Director (PD) shall approve DRAF for issues that will affect production Method and Material change and critical product Quality issues.<br>
> Blank Column shall be strike off or indicate "NIL" or "NA".</p>

<table border=1 width=565 cellpadding="0" cellspacing="0">
<tr><td> 
 
<table border=0  width="750px" style="font-size: 6px;padding-left:0px;padding-top:0px;" cellpadding="0" cellspacing="0">
<tr><td colspan=7>Circulation To: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Note: QMS Unit is to be issued the original DRAF for filling</td></tr>
<tr><td>&nbsp;</td></tr>
<tr><td >	
';
$str3 = $e['hobi'];
$data3 = explode(",",$str3); 
$html.=' 
 <!-- <input type="checkbox" style="width:20px;height:18px;"'; if (in_array("1",$data3)){$html.='checked';} $html.='> QAC1<br> -->
 <input type="checkbox" style="width:20px;height:18px;"'; if (in_array("2",$data3)){ $html.='checked';}  $html.='>QAC2<br>
 <input type="checkbox" style="width:20px;height:18px;"'; if (in_array("3",$data3)){ $html.='checked';}  $html.='>QAC3<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("4",$data3)){ $html.='checked';}  $html.='>QAC4<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("5",$data3)){ $html.='checked';}  $html.='>QAC5<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("6",$data3)){ $html.='checked';}  $html.='>QAIC<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("7",$data3)){ $html.='checked';}  $html.='>LAB<br>
 </td><td>
 <!-- <input type=checkbox style="width:20px;"'; if (in_array("8",$data3)){ $html.='checked';}  $html.='>PCT1<br> -->
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("9",$data3)){ $html.='checked';}  $html.='>PCT2<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("10",$data3)){ $html.='checked';}  $html.='>PCT3<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("11",$data3)){ $html.='checked';}  $html.='>PCT4<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("12",$data3)){ $html.='checked';}  $html.='>PCT5<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('35',$data3)){ $html.='checked';}  $html.='>PQS<br>
 </td><td>
<!-- <input type=checkbox style="width:20px;"'; if (in_array("20",$data3)){ $html.='checked';}  $html.='>EXT1<br> -->
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("21",$data3)){ $html.='checked';}  $html.='>EXT2<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("13",$data3)){ $html.='checked';}  $html.='>EXT3<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("14",$data3)){ $html.='checked';}  $html.='>EXT4<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("43",$data3)){ $html.='checked';}  $html.='>EXT5<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("42",$data3)){ $html.='checked';}  $html.='>INFLATION<br>
</td><td>
<!-- <input type=checkbox style="width:20px;"'; if (in_array("15",$data3)){ $html.='checked';}  $html.='>TEC1<br> -->
<input type=checkbox style="width:20px;height:18px;"'; if (in_array("16",$data3)){ $html.='checked';}  $html.='>TEC2<br>
<input type=checkbox style="width:20px;height:18px;"'; if (in_array("17",$data3)){ $html.='checked';}  $html.='>TEC3<br>
<input type=checkbox style="width:20px;height:18px;"'; if (in_array("18",$data3)){ $html.='checked';}  $html.='>TEC4<br>
<input type=checkbox style="width:20px;height:18px;"'; if (in_array("19",$data3)){ $html.='checked';}  $html.='>TEC5<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("22",$data3)){ $html.='checked';}  $html.='>PED/MTU<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('41',$data3)){ $html.='checked';}  $html.='>EAP<br>
 </td><td>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('24',$data3)){ $html.='checked';}  $html.='>ACC<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('25',$data3)){ $html.='checked';}  $html.='>PCH<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('26',$data3)){ $html.='checked';}  $html.='>BQMS<br>
<input type=checkbox style="width:20px;height:18px;"'; if (in_array('27',$data3)){ $html.='checked';}  $html.='>JMS(S)QMS<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('28',$data3)){ $html.='checked';}  $html.='>Steam STZ<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('29',$data3)){ $html.='checked';}  $html.='>STR<br>
</td><td >
<input type=checkbox style="width:20px;height:18px;"'; if (in_array('30',$data3)){ $html.='checked';}  $html.='>PPL<br>
<input type=checkbox style="width:20px;height:18px;"'; if (in_array('31',$data3)){ $html.='checked';}  $html.='>FAC <br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('32',$data3)){ $html.='checked';}  $html.='>CQS<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('33',$data3)){ $html.='checked';}  $html.='>MIS<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('34',$data3)){ $html.='checked';}  $html.='>ETO STZ<br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array("23",$data3)){ $html.='checked';}  $html.='>HR/GA<br>
 </td><td valign=top>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('36',$data3)){ $html.='checked';}  $html.='> JMSS VCD <br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('37',$data3)){ $html.='checked';}  $html.='> JMSS PED <br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('38',$data3)){ $html.='checked';}  $html.='> JMSS PCH <br>
 <br> Other Specify <br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('39',$data3)){ $html.='checked';}  $html.='> LKD <br>
 <input type=checkbox style="width:20px;height:18px;"'; if (in_array('40',$data3)){ $html.='checked';}  $html.='> '.$e['hobi2'].' <br><br>
 </td></tr>
           
 </table> </td> </tr>
 </table>

</body></html>';
	
$dompdf->load_html($html);
$dompdf->set_paper("A4", "portrait");
$dompdf->render();
$canvas = $dompdf->get_canvas();
$canvas->page_text(95, 28, "PT. JMS BATAM", "Helvetica-Bold", 14, array(0,0,0));
//$canvas->page_text(95, 28, "Blok 210-212, Jalan Beringin, Muka Kuning, Batam 29433, Indonesia", $font, 8, array (0,0,0));
//$canvas->page_text(95, 38, "Cammo Industrial Park, Blok F, No.2, Batam Centre, Batam 29433, Indonesia", $font, 8, array (0,0,0));
$canvas->page_text(15, 50, "Deviation Report", "Helvetica-Bold", 12, array(0,0,0));
$canvas->page_text(380, 58, "       Draf No  : $rdraf[draft_no]", "Helvetica-Bold", 10, array(0,0,0));
$canvas->page_text(365, 75, "Reporting Date  : ", "Helvetica-Bold", 10, array(0,0,0));




$canvas->page_text(16, 780, "S/D : Signature / Date", "Helvetica", 8, array(0,0,0));
$canvas->page_text(16, 790, "Doc. Code : $rkode[code1], $rkode[code3], $rkode[code4]", "Helvetica", 8, array(0,0,0));
$canvas->page_text(280, 805, "Page: {PAGE_NUM} of {PAGE_COUNT}", "Helvetica", 8, array(0,0,0));
$canvas->page_text(505, 790, "$rkode[code2]", "Helvetica", 8, array(0,0,0));

$dompdf->stream("form.pdf", array("Attachment" => false));
?>