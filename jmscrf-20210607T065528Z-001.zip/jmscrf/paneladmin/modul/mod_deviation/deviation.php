<script>
function confirmdelete(delUrl) {
   if (confirm("Are you sure to delete this item?")) {
      document.location = delUrl;
   }
}
</script>
<script type="text/javascript">
function check_radio(radio){
    for (i = 0; i < radio.length; i++){
      if (radio[i].checked === true){
          return radio[i].value;
      }
    }
    return false;
}
function validasi(form){
   var mincar = 1;
  if (form.draft_no.value.length < mincar){
       alert("DRAF NO is still empty!");
       form.draft_no.focus();
       return (false);
   } 
   if (form.title.value.length < mincar){
       alert("Title is still empty!");
       form.title.focus();
       return (false);
   }  
    if (form.product.value.length < mincar){
       alert("Parts/WIP/FG afffected is still empty!");
       form.product.focus();
       return (false);
   }  
    if (form.prod_desc.value.length < mincar){
       alert("Product Description is still empty!");
       form.prod_desc.focus();
       return (false);
   }   
    if (form.prod_code.value.length < mincar){
       alert("Product Code is still empty!");
       form.prod_code.focus();
       return (false);
   }      
   if (form.prod_lot.value.length < mincar){
       alert("Product Lot is still empty!");
       form.prod_lot.focus();
       return (false);
   } 
   if (form.prod_qty.value.length < mincar){
       alert("Product Quantity is still empty!");
       form.prod_qty.focus();
       return (false);
   }   
    if (form.dev_periode.value.length < mincar){
       alert("Deviation Period is still empty!");
       form.dev_periode.focus();
       return (false);
   }  
   if (form.problem_encounter.value.length < mincar){
       alert("Problem Encounter is still empty!");
       form.problem_encounter.focus();
       return (false);
   }   
   if (form.counter_measure.value.length < mincar){
       alert("Counter Measure is still empty!");
       form.counter_measure.focus();
       return (false);
   } 
    if (form.plan.value.length < mincar){
       alert("Improvement Plan is still empty!");
       form.plan.focus();
       return (false);
   }      
   
  /**
   if (form.current_dev.value.length < mincar){
       alert("Current Masih Kosong!");
       form.current_dev.focus();
       return (false);
   }
 
   if (form.reason.value.length < mincar){
       alert("Reason Masih Kosong!");
       form.reason.focus();
       return (false);
   }         
   if (form.prod_desc.value.length < mincar){
       alert("prod_desc Masih Kosong!");
       form.prod_desc.focus();
       return (false);
   }
 
   if (form.dev_periode.value.length < mincar){
       alert("dev_periode Masih Kosong!");
       form.dev_periode.focus();
       return (false);
   }
   if (form.remark_inst.value.length < mincar){
       alert("remark_inst Masih Kosong!");
       form.remark_inst.focus();
       return (false);
   }         
   var radio_val15 = check_radio(form.cus_approval);
   if (radio_val15 === false){
       alert("Anda belum memilih cus_approval");
       return false;
   }        
   if (form.cus_app_ket.value.length < mincar){
       alert("cus_app_ket Masih Kosong!");
       form.cus_app_ket.focus();
       return (false);
   }
   var chks17 = document.getElementsByName('idr_num[]');
   var hasChecked17 = false;
   for (var i = 0; i < chks17.length; i++){
	    if (chks17[i].checked){
            hasChecked17 = true;
            break;
        }
   } 
   if (hasChecked17 == false){
      alert("Anda belum memilih idr_num");
      return false;
   }       
   if (form.idr_num_ket.value.length < mincar){
       alert("idr_num_ket Masih Kosong!");
       form.idr_num_ket.focus();
       return (false);
   }
   var chks19 = document.getElementsByName('pdr_num[]');
   var hasChecked19 = false;
   for (var i = 0; i < chks19.length; i++){
	    if (chks19[i].checked){
            hasChecked19 = true;
            break;
        }
   } 
   if (hasChecked19 == false){
      alert("Anda belum memilih pdr_num");
      return false;
   }       
   if (form.pdr_num_ket.value.length < mincar){
       alert("pdr_num_ket Masih Kosong!");
       form.pdr_num_ket.focus();
       return (false);
   }
   var chks21 = document.getElementsByName('sdr_num[]');
   var hasChecked21 = false;
   for (var i = 0; i < chks21.length; i++){
	    if (chks21[i].checked){
            hasChecked21 = true;
            break;
        }
   } 
   if (hasChecked21 == false){
      alert("Anda belum memilih sdr_num");
      return false;
   }       
   if (form.sdr_num_ket.value.length < mincar){
       alert("sdr_num_ket Masih Kosong!");
       form.sdr_num_ket.focus();
       return (false);
   }
   var chks23 = document.getElementsByName('process_dr[]');
   var hasChecked23 = false;
   for (var i = 0; i < chks23.length; i++){
	    if (chks23[i].checked){
            hasChecked23 = true;
            break;
        }
   } 
   if (hasChecked23 == false){
      alert("Anda belum memilih process_dr");
      return false;
   }       
   if (form.process_dr_ket.value.length < mincar){
       alert("process_dr_ket Masih Kosong!");
       form.process_dr_ket.focus();
       return (false);
   }
   var chks25 = document.getElementsByName('other_dr[]');
   var hasChecked25 = false;
   for (var i = 0; i < chks25.length; i++){
	    if (chks25[i].checked){
            hasChecked25 = true;
            break;
        }
   } 
   if (hasChecked25 == false){
      alert("Anda belum memilih other_dr");
      return false;
   }       
   if (form.other_dr_ket.value.length < mincar){
       alert("other_dr_ket Masih Kosong!");
       form.other_dr_ket.focus();
       return (false);
   }
   var radio_val27 = check_radio(form.qa_judge);
   if (radio_val27 === false){
       alert("Anda belum memilih qa_judge");
       return false;
   }        
   var radio_val28 = check_radio(form.pct_judge);
   if (radio_val28 === false){
       alert("Anda belum memilih pct_judge");
       return false;
   }        
   if (form.other_judge.value.length < mincar){
       alert("other_judge Masih Kosong!");
       form.other_judge.focus();
       return (false);
   }
   if (form.initiaded.value =="pilih"){
       alert("Anda belum memilih initiaded");            
       return (false);
   }
   if (form.verified.value =="pilih"){
       alert("Anda belum memilih verified");            
       return (false);
   }
   if (form.approved.value =="pilih"){
       alert("Anda belum memilih approved");            
       return (false);
   }
   var radio_val33 = check_radio(form.risk);
   if (radio_val33 === false){
       alert("Anda belum memilih risk");
       return false;
   }        
   if (form.risk_refno.value.length < mincar){
       alert("risk_refno Masih Kosong!");
       form.risk_refno.focus();
       return (false);
   }
   if (form.risk_remark.value.length < mincar){
       alert("risk_remark Masih Kosong!");
       form.risk_remark.focus();
       return (false);
   }
   var radio_val36 = check_radio(form.patient_rmp);
   if (radio_val36 === false){
       alert("Anda belum memilih patient_rmp");
       return false;
   }        
   var radio_val37 = check_radio(form.health_rmp);
   if (radio_val37 === false){
       alert("Anda belum memilih health_rmp");
       return false;
   }        
   var radio_val38 = check_radio(form.justifi_rep);
   if (radio_val38 === false){
       alert("Anda belum memilih justifi_rep");
       return false;
   }        
   if (form.verified2.value.length < mincar){
       alert("verified2 Masih Kosong!");
       form.verified2.focus();
       return (false);
   }
   var radio_val40 = check_radio(form.required);
   if (radio_val40 === false){
       alert("Anda belum memilih required");
       return false;
   }        
   if (form.required_remark.value.length < mincar){
       alert("required_remark Masih Kosong!");
       form.required_remark.focus();
       return (false);
   }         
   var radio_val42 = check_radio(form.fillby1);
   if (radio_val42 === false){
       alert("Anda belum memilih fillby1");
       return false;
   }        
   var radio_val43 = check_radio(form.fillby2);
   if (radio_val43 === false){
       alert("Anda belum memilih fillby2");
       return false;
   }        
   if (form.fill_others.value.length < mincar){
       alert("fill_others Masih Kosong!");
       form.fill_others.focus();
       return (false);
   }
   if (form.fill_remark.value.length < mincar){
       alert("fill_remark Masih Kosong!");
       form.fill_remark.focus();
       return (false);
   }         
   if (form.approved3.value.length < mincar){
       alert("approved3 Masih Kosong!");
       form.approved3.focus();
       return (false);
   }
   if (form.remark3.value.length < mincar){
       alert("remark3 Masih Kosong!");
       form.remark3.focus();
       return (false);
   }  **/     
   
   return (true);
}
</script>

<?php
/** session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
    echo "<link href='style.css' rel='stylesheet' type='text/css'>
    <center>Untuk mengakses modul, Anda harus login <br>";
    echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{ **/
function explode_trim($str, $delimiter = ',') {
   if ( is_string($delimiter) ) {
      $str = trim(preg_replace('|\\s*(?:' . preg_quote($delimiter) . ')\\s*|', $delimiter, $str));
      return explode($delimiter, $str);
   }
   return $str;
}
    
$aksi="modul/mod_deviation/aksi_deviation.php";
switch(@$_GET['act']){

default:
echo "
<form method=POST action='?module=deviation&act=viewdeviation' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find Deviation</strong></i></td><td>: ";
include "deviation1.php";
echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
<h2>List Deviation Report</h2>
<p>&nbsp;</p>
<input type=button  class='large orange super button' value='CREATE NEW DEVIATION' 
onclick=\"window.location.href='?module=deviation&act=tambahdeviation';\">
<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th>No</th><th>Section</th>
<th>DRAF No</th><th>Title</th><th>Issue Date</th><th>Deadline</th><th>Report Date</th><th>Status</th><th>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT dev.id, dr.draft_no,dr.section, dr.title, dr.issue_date, 
dr.status, date_format(dr.issue_date,'%d %b %y') as issue_date, 
date_format((dr.issue_date + interval '6' month),'%d %b %y')as deadline, 
date_format(dr.report_date,'%d %b %y') as report_date, datediff((dr.issue_date + interval '6' month),current_date()) as selisih
from deviation dev, draf dr where dev.id_draf=dr.id and dr.draf_kd='$_SESSION[draf_kd]' order by dr.draft_no desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}		
  echo "<tr><td>$no.</td><td>$r[section]</td>
	<td>$r[draft_no]</td> <td>$r[title]</td>
   <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td><td>$label</td>
    <td><a href='?module=deviation&act=editdeviation&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=deviation&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=deviation&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;

case "dev_qms":
echo "
<form method=POST action='?module=deviation&act=viewqmsdev' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
<tr><td><strong><i>Find Deviation</strong></i></td><td>: ";
include "deviation2.php";
echo "</td><td><input type=submit name=submit class='large blue super button' value='Find'></td></tr>
</table>
</form>
<h2>List Deviation Report</h2>
<p>&nbsp;</p>

<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th width=170>DRAF No</th><th>Section</th><th>Title</th><th width=100>Issue Date</th><th>Deadline</th><th>Report Date</th><th>Status</th><th>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT dev.id, dr.draft_no, dr.title, dr.issue_date, 
dr.status, sc.section as section2, date_format(dr.issue_date,'%d %b %y') as issue_date, 
date_format((dr.issue_date + interval '6' month),'%d %b %y')as deadline, 
date_format(dr.report_date,'%d %b %y') as report_date, datediff((dr.issue_date + interval '6' month),current_date()) as selisih
from deviation dev, draf dr, sectioncode sc where dev.id_draf=dr.id and dr.section=sc.id order by dev.create_date desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}		
  echo "<tr><td>$no.</td>
	<td>$r[draft_no]</td><td>$r[section2]</td> <td>$r[title]</td>
   <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td><td>$label</td>
    <td><a href=javascript:confirmdelete('$aksi?module=deviation&act=delete2&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=deviation&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;


case "viewqmsdev":
echo "

<h2>Result Finding Deviation Report</h2>
<p>&nbsp;</p>

<table id=example class='pretty dataTable'>
<thead><tr><th>No</th>
<th>DRAF No</th><th>Section</th><th>Title</th><th>Issue Date</th><th>Deadline</th><th>Report Date</th><th>Status</th><th>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT dev.id, dr.draft_no, dr.title, dr.issue_date, 
dr.status, sc.section as section2, date_format(dr.issue_date,'%d %b %y') as issue_date, 
date_format((dr.issue_date + interval '6' month),'%d %b %y')as deadline, 
date_format(dr.report_date,'%d %b %y') as report_date, datediff((dr.issue_date + interval '6' month),current_date()) as selisih
from deviation dev, draf dr, sectioncode sc where dev.id_draf=dr.id and dr.section=sc.id and dev.id='$_POST[id]'");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}		
  echo "<tr><td>$no.</td>
	<td>$r[draft_no]</td><td>$r[section2]</td> <td>$r[title]</td>
   <td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td><td>$label</td>
    <td><a href=javascript:confirmdelete('$aksi?module=deviation&act=delete2&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=deviation&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;
case "closed":
echo "
<form method=POST action='?module=deviation&act=viewdeviation2' enctype='multipart/form-data'>
<table cellspacing=10 cellpadding=6>
";
include "deviation2.php";
echo "
<tr><td></td><td><input type=submit name=submit class='large blue super button' value='View Deviation'></td></tr>
</table>
</form>
<p>&nbsp;</p>
<h2>Closed Deviation Report</h2>

<p>&nbsp;</p>
<table id=example class='pretty dataTable'>
<thead><tr><th></th><th>No</th>
<th>DRAF No</th><th>Title</th><th>Report Date</th><th>Aksi</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT * FROM draf where status='3' and section='$_SESSION[section]' order by report_date desc limit 25");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
	$tggl= tgl_indo($r['report_date']);
  echo "<tr><td></td><td>$no.</td>
	<td>$r[draf_no]</td>
      	
      	<td>$r[title]</td>
    <td><a href='?module=deviation&act=editdeviation&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=deviation&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=deviation&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";

break;
// Form Edit deviation 
case "tambahdeviation":
echo "<h2>Deviation Report</h2>

<form method=POST action='$aksi?module=deviation&act=input'  onsubmit='return validasi(this)'>
<table cellspacing=10 cellpadding=6>
"; 
include "draf.php";
echo "
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=0 >
<tr>
<th width=40>No</th><th width=200>Check Points</th><th colspan=2>Content</th>
</tr>
              
<tr><td valign=top>1.</td><td valign=top>Parts/WIP/FG affected: </br></br><br>
(a) Product Description </br><br><br><br><br>(b) Product Code </br><br>(c) Product Lot </br><br>(d) Product Quantity </td><td colspan=2> <input type='text'  name='product' size='100' value='' ><br><br>
	 <textarea name='prod_desc' cols='102' rows='3' ></textarea> <br><br>
	 <input type='text' style='boder:none;' name='prod_code' size='100' value='' > <br><br>
	 <input type='text' style='boder:none;' name='prod_lot' size='100' value='' > <br><br>
	 <input type='text' style='boder:none;' name='prod_qty' size='100' value='' > <br><br>
</td></tr> 
              
<tr><td>2.</td><td valign=top>Deviation Period</td><td colspan=2 valign=top> <input type='text' name='dev_periode' size='100' value='' ></td></tr>             
<tr><td valign=top>3.</td><td valign=top>Problem Encounter / </br> Special Remarks: </br>(Attach if required)</td><td colspan=2 valign=top>  <textarea name='problem_encounter' cols='102' rows='4' ></textarea></br></br>
<u>Counter Measure(s): </u> </br> </br>
  <textarea name='counter_measure' cols='102' rows='3' ></textarea>
</td></tr>                

<tr><td valign=top>4.</td><td valign=top>Improvement Plan </br>(Attach if required)</td><td colspan=2 valign=top>  <textarea name='plan' cols='102' rows='4' ></textarea></td></tr> 

<tr><br><td colspan=3><input type=submit name=submit class='large orange super button' value='Save Deviation'>
	<input type=button value=Cancel onclick=self.history.back() class='large blue super button'>
</td></tr>
</table>
</form>

";
break;


case "editdeviation":
$edit = mysqli_query($conn, "SELECT * FROM deviation WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
$prod_des =  str_replace("<BR />",'', $r['prod_desc']);
$prob =  str_replace("<BR />",'', $r['problem_encounter']);
$counter =  str_replace("<BR />",'', $r['counter_measure']);
$pla =  str_replace("<BR />",'', $r['plan']);
echo "<h2>Edit Deviation Report</h2>
<form method=POST action='$aksi?module=deviation&act=update'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
"; 
include "drafedit.php";
echo "
</table>
<p>&nbsp;</p>
<table cellspacing=8 cellpadding=4 border=0 >
<tr>
<th width=40>No</th><th width=200>Check Points</th><th colspan=2>Content</th>
</tr>
              
<tr><td valign=top>1.</td><td valign=top>Parts/WIP/FG affected: </br></br>
(a) Product Description </br><br><br><br><br><br>(b) Product Code </br><br>(c) Product Lot </br><br>(d) Product Quantity </td><td colspan=2>	<input type='text'  name='product' size='100' value='";
echo htmlentities(htmlspecialchars_decode($r['product']), ENT_QUOTES);
echo "' ><br><br>
	 <textarea name='prod_desc' cols='102' rows='3' >$prod_des</textarea> <br><br>
	 <input type='text' style='boder:none;' name='prod_code' size='100' value='";
echo htmlentities(htmlspecialchars_decode($r['prod_code']), ENT_QUOTES);
echo "' > <br><br>
	 <input type='text' style='boder:none;' name='prod_lot' size='100' value='";
echo htmlentities(htmlspecialchars_decode($r['prod_lot']), ENT_QUOTES);
echo "' > <br><br>
	 <input type='text' style='boder:none;' name='prod_qty' size='100' value='";
echo htmlentities(htmlspecialchars_decode($r['prod_qty']), ENT_QUOTES);
echo "' > <br><br>
</td></tr> 
              
<tr><td>2.</td><td valign=top>Deviation Period</td><td colspan=2 valign=top> <input type='text' name='dev_periode' size='100' value='";
echo htmlentities(htmlspecialchars_decode($r['dev_periode']), ENT_QUOTES);
echo "' ></td></tr>             
<tr><td valign=top>3.</td><td valign=top>Problem Encounter / </br> Special Remarks: </br>(Attach if required)</td><td colspan=2 valign=top>    <textarea name='problem_encounter' cols='102' rows='5' >$prob</textarea></br></br>
<u>Counter Measure(s)</u> :</br> </br>
    <textarea name='counter_measure' cols='102' rows='5' >$counter</textarea>
</td></tr>                

<tr><td valign=top>4.</td><td valign=top>Improvement Plan </br>(Attach if required)</td><td colspan=2 valign=top>   <textarea name='plan' cols='102' rows='5' >$pla</textarea></td></tr> 
<tr><td colspan=3>__________________________________________________________________________________________________________________</td></tr>
 
</table>

";
$str3 = $r['hobi'];
$data3 = explode_trim($str3); 
echo "
<table width=1000 border=0 cellspacing=8 cellpadding=4>
<tr><td colspan=7> Circulation To: </td></tr>
<tr><td>
<!-- <input type=checkbox value='1' name=hobii[]"; if (in_array('1',$data3)){echo " checked";} echo ">QAC1<br> -->
<input type=checkbox value='2' name=hobii[]"; if (in_array('2',$data3)){echo " checked";} echo ">QAC2<br> 
<input type=checkbox value='3' name=hobii[]"; if (in_array('3',$data3)){echo " checked";} echo ">QAC3<br> 
<input type=checkbox value='4' name=hobii[]"; if (in_array('4',$data3)){echo " checked";} echo ">QAC4<br> 
<input type=checkbox value='5' name=hobii[]"; if (in_array('5',$data3)){echo " checked";} echo ">QAC5<br> 
<input type=checkbox value='6' name=hobii[]"; if (in_array('6',$data3)){echo " checked";} echo ">QAIC<br>
<input type=checkbox value='7' name=hobii[]"; if (in_array('7',$data3)){echo " checked";} echo ">LAB<br>
</td>

<td>
<!-- <input type=checkbox value='8' name=hobii[]"; if (in_array('8',$data3)){echo " checked";} echo ">PCT1<br> -->
<input type=checkbox value='9' name=hobii[]"; if (in_array('9',$data3)){echo " checked";} echo ">PCT2<br> 
<input type=checkbox value='10' name=hobii[]"; if (in_array('10',$data3)){echo " checked";} echo ">PCT3<br> 
<input type=checkbox value='11' name=hobii[]"; if (in_array('11',$data3)){echo " checked";} echo ">PCT4<br> 
<input type=checkbox value='12' name=hobii[]"; if (in_array('12',$data3)){echo " checked";} echo ">PCT5<br> 
<input type=checkbox value='35' name=hobii[]"; if (in_array('35',$data3)){echo " checked";} echo ">PQS<br> 
</td>

<td>
<!-- <input type=checkbox value='20' name=hobii[]"; if (in_array('20',$data3)){echo " checked";} echo ">EXT1<br> -->
<input type=checkbox value='21' name=hobii[]"; if (in_array('21',$data3)){echo " checked";} echo ">EXT2<br>
<input type=checkbox value='13' name=hobii[]"; if (in_array('13',$data3)){echo " checked";} echo ">EXT3<br>
<input type=checkbox value='14' name=hobii[]"; if (in_array('14',$data3)){echo " checked";} echo ">EXT4<br>
<input type=checkbox value='43' name=hobii[]"; if (in_array('43',$data3)){echo " checked";} echo ">EXT5<br>
<input type=checkbox value='42' name=hobii[]"; if (in_array('42',$data3)){echo " checked";} echo ">INFLATION<br>
</td>

<td>
<!-- <input type=checkbox value='15' name=hobii[]"; if (in_array('15',$data3)){echo " checked";} echo ">TEC1<br> -->
<input type=checkbox value='16' name=hobii[]"; if (in_array('16',$data3)){echo " checked";} echo ">TEC2<br> 
<input type=checkbox value='17' name=hobii[]"; if (in_array('17',$data3)){echo " checked";} echo ">TEC3<br> 
<input type=checkbox value='18' name=hobii[]"; if (in_array('18',$data3)){echo " checked";} echo ">TEC4<br>
<input type=checkbox value='19' name=hobii[]"; if (in_array('19',$data3)){echo " checked";} echo ">TEC5<br> 
<input type=checkbox value='22' name=hobii[]"; if (in_array('22',$data3)){echo " checked";} echo ">PED/MTU<br>
<input type=checkbox value='41' name=hobii[]"; if (in_array('41',$data3)){echo " checked";} echo ">EAP
</td>

<td>
<input type=checkbox value='24' name=hobii[]"; if (in_array('24',$data3)){echo " checked";} echo ">ACC<br>
<input type=checkbox value='25' name=hobii[]"; if (in_array('25',$data3)){echo " checked";} echo ">PCH<br> 
<input type=checkbox value='26' name=hobii[]"; if (in_array('26',$data3)){echo " checked";} echo ">BQMS<br> 
<input type=checkbox value='27' name=hobii[]"; if (in_array('27',$data3)){echo " checked";} echo ">JMS(S)QMS<br> 
<input type=checkbox value='28' name=hobii[]"; if (in_array('28',$data3)){echo " checked";} echo ">Steam STZ<br>
<input type=checkbox value='29' name=hobii[]"; if (in_array('29',$data3)){echo " checked";} echo ">STR<br> 
</td>

<td>
<input type=checkbox value='30' name=hobii[]"; if (in_array('30',$data3)){echo " checked";} echo ">PPL<br>
<input type=checkbox value='31' name=hobii[]"; if (in_array('31',$data3)){echo " checked";} echo ">FAC<br> 
<input type=checkbox value='32' name=hobii[]"; if (in_array('32',$data3)){echo " checked";} echo ">CQS<br> 
<input type=checkbox value='33' name=hobii[]"; if (in_array('33',$data3)){echo " checked";} echo ">MIS<br> 
<input type=checkbox value='34' name=hobii[]"; if (in_array('34',$data3)){echo " checked";} echo ">ETO STZ<br> 
<input type=checkbox value='23' name=hobii[]"; if (in_array('23',$data3)){echo " checked";} echo ">HR/GA<br> 
</td>

<td>
<input type=checkbox value='36' name=hobii[]"; if (in_array('36',$data3)){echo " checked";} echo ">JMSS VCD <br> 
<input type=checkbox value='37' name=hobii[]"; if (in_array('37',$data3)){echo " checked";} echo ">JMSS PED <br> 
<input type=checkbox value='38' name=hobii[]"; if (in_array('38',$data3)){echo " checked";} echo ">JMSS PCH <br><br> Other Specify <br><br>
<input type=checkbox value='39' name=hobii[]"; if (in_array('39',$data3)){echo " checked";} echo ">LKD <br> 
<input type=checkbox value='40' name=hobii[]"; if (in_array('40',$data3)){echo " checked";} echo "> 
<input type=text name=hobii2 value='$r[hobi2]' >
</td> </tr>
             
<tr><td colspan=2><input type=submit value=Update class='large orange super button'>
<input type=button value=Cancel onclick=self.history.back() class='large blue super button'></td></tr>
</table>
</form>";
break;



case "close":
$edit = mysqli_query($conn, "SELECT * FROM deviation WHERE id='$_GET[id]'");
$r    = mysqli_fetch_array($edit);
echo "<h2>Close Deviation Report</h2><br>
<form method=POST action='$aksi?module=deviation&act=close'  onsubmit='return validasi(this)'>
<input type=hidden name=id value='$r[id]'>
<table cellspacing=10 cellpadding=6>
<tr><td>Draf No</td><td>: <input type='text' name='draft_no' size='30' value='$r[draf_no]' readonly></td></tr>                
<tr><td>Title</td><td>: <input type='text' name='title' size='100' value='$r[title]' readonly></td></tr> 
<tr><td><strong><u>Report Date</strong></u></td><td>: ";
combotgl(1,31,'tgl_issue_date',$tgl_skrg);
combobln(1,12,'bln_issue_date',$bln_sekarang);
combothn(2013,$thn_sekarang,'thn_issue_date',$thn_sekarang); 
echo" <small><strong><u><i>Report Date Must be filled!</i></u></stong></small></td></tr>          

<tr><td colspan=2><input type=submit name=submit class='large orange super button' value='Close Report'>
	<input type=button class='large blue super button' value=Batal onclick=self.history.back() >
</td></tr>
</table>
</form>

";
break;
case "viewdeviation":
echo "
<table class='pretty dataTable'>
<thead><tr><th>No</th>
<th>DRAF No</th><th>Title</th><th>Issue Date</th><th>Deadline</th><th>Report Date</th><th>Status</th><th>Action</th></tr></thead><tbody>";


$tampil=mysqli_query($conn, "SELECT dev.id, dr.draft_no, dr.title, dr.issue_date, 
dr.status, date_format(dr.issue_date,'%d %b %y') as issue_date, 
date_format((dr.issue_date + interval '6' month),'%d %b %y')as deadline, 
date_format(dr.report_date,'%d %b %y') as report_date, datediff((dr.issue_date + interval '6' month),current_date()) as selisih
from deviation dev, draf dr where dev.id_draf=dr.id and dev.id='$_POST[id]' ");
$no=1;
while ($r=mysqli_fetch_array($tampil)){
if ($r['status'] =='3'){
	$label='Closed';
} else if  (($r['status'] !='3')&& ($r['selisih']<0))  {
	$label='Out Standing';
} else {
	$label='On Progress';
}	
  echo "<tr><td>$no.</td>
	<td>$r[draft_no]</td>
    
      	<td>$r[title]</td><td>$r[issue_date]</td><td>$r[deadline]</td><td>$r[report_date]</td><td>$label</td>
    <td><a href='?module=deviation&act=editdeviation&id=$r[id]'><img src='images/edit.png' alt='edit' /></a>|<a href=javascript:confirmdelete('$aksi?module=deviation&act=delete&id=$r[id]')><img src='images/hapus.png' alt='hapus' /></a>|<a href=$aksi?module=deviation&act=cetak&id=$r[id] target=_blank><img src='images/cetak.png' alt='cetak' /></a>
        </td></tr>";
  $no++;
}
echo "</table>";
break;
}
?>




