<h2>Data Kelurahan</h2><br/>
<a href="?module=tambah_kel"> <input type=submit value="Tambah Kelurahan" class='large blue super button'> </a>
<a href="eksport_kelurahan.php" target="_blank"> <input type=submit value="Export Kelurahan" class='large blue super button'> </a><br />
<br /> 
<?

$offset = $_GET['offset'];
$totalquery = mysql_query("select * from kelurahan");
$numrows = mysql_num_rows($totalquery);

//jumlah data yang ditampilkan perpage
$limit = 10;
if (empty ($offset)) {
	$offset = 0;
}
if ($numrows == 0) {
	echo "<br><center> Tidak Ada Data</center>";	
}
else {

$hasil = mysql_query("select kelurahan.*,kecamatan.kecamatan,wilayah.wilayah,provinsi.provinsi from kelurahan, kecamatan, wilayah,provinsi WHERE kelurahan.kode_kec=kecamatan.id AND kelurahan.kode_wil=wilayah.id AND kelurahan.kode_prov=provinsi.id ");
$k = 1;
$k = 1 + $offset;

echo"<table id=example class='pretty dataTable'>
<thead>
<tr>
				<th class=rounded-company> No. </th>
				<th> Kode </th>
				<th> Kelurahan </th>
				<th> Kecamatan</th>
				<th> Wilayah</th>
				<th> Provinsi</th>
				<th width=100 class=rounded-q4> Aksi </th>
			</tr>
		</thead><tbody>		
";

while ($data = mysql_fetch_array($hasil)) {

echo"
		<tr>
			<td width=10 align=center> $k </td>
			<td> $data[kode] </td>
			<td> $data[kelurahan] </td>
			<td> $data[kecamatan] </td>
			<td> $data[wilayah] </td>
			<td> $data[provinsi] </td>
			<td align=center><a href=index.php?module=edit_kel&id=$data[id] title='Edit Kelurahan'> <img src='images/edit.png' width='25' hight='20'> </a>  <a href=index.php?module=hapus_kel&id=$data[id] title='Hapus Kelurahan'> <img src='images/hapus.png' width='18' hight='18'> </a> </td>
		</tr> 
";
$k++;
}
//untuk tutup tabel
echo "</tbody></table>";
}
?>