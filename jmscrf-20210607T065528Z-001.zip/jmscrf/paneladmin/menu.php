<?php
include "config/koneksi.php";

      function get_menu($data, $parent = 0) {
	      static $i = 1;
	      $tab = str_repeat(" ", $i);
	      if ($data[$parent]) {
		      $html = "$tab<ul>";
		      $i++;
		      foreach ($data[$parent] as $v) {
			       $child = get_menu($data, $v->id_modul);
			       $html .= "$tab<li>";
			       $html .= '<a href="'.$v->link.'">'.$v->nama_modul.'</a>';
			       if ($child) {
				       $i--;
				       $html .= $child;
				       $html .= "$tab";
			       }
			       $html .= '</li>';
		      }
		      $html .= "$tab</ul>";
		      return $html;
	      } 
        else {
		      return false;
	      }
      }
      	if ($_SESSION['leveluser']=='admin') {
			$result = mysqli_query($conn, "SELECT * FROM modul WHERE aktif='Y'  group by id_modul order BY nama_modul asc");
		} 
		   else if ($_SESSION['leveluser']=='user')  {
			$result = mysqli_query($conn, "SELECT modul.* FROM modul,menu,jenis_user, users WHERE modul.status='user' and modul.aktif='Y' and 
jenis_user.id=menu.id_jenisuser and modul.id_modul=menu.id_modul and users.`level`='user' 
and menu.id_jenisuser='$_SESSION[jenisuser]' group by modul.id_modul order by modul.nama_modul asc");
		}
	/*	else {
			$result = mysql_query("SELECT modul.* FROM modul,menu,jenis_user WHERE  modul.aktif='Y' and 
jenis_user.id=menu.id_jenisuser and modul.id_modul=menu.id_modul and jenis_user.id='$_SESSION[jenisuser]' order by modul.nama_modul asc");
		} */
      while ($row = mysqli_fetch_object($result)) {
	       $data[$row->parent_id][] = $row;
      }
      $menu = get_menu($data);
      echo "$menu"; 
?>
	