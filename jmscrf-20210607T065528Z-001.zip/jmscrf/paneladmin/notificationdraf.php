<?php
require 'config/koneksi.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$sql = mysqli_query($conn, "SELECT cr.draft_no, cr.title, sc.mailto, sc.mailto_1, sc.mailcc, cr.issue_date,
sc.section as sectionName, cr.section,
cr.initiaded, cr.status FROM draf cr, sectioncode sc WHERE cr.section=sc.id 
AND cr.status!= '3' AND cr.status !='0' AND datediff((cr.issue_date + interval '6' month),current_date()) < 0
AND (cr.issue_date + interval '6' month) >= NOW() - INTERVAL 3 YEAR
GROUP BY cr.section");
    
	require 'vendor/autoload.php';
	require 'vendor/phpmailer/phpmailer/src/Exception.php';
	require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
	require 'vendor/phpmailer/phpmailer/src/SMTP.php';

	$mail = new PHPMailer;
	$mail->isSMTP();
													
	$mail->Host = 'mail.jmsb.co.id';
	$mail->Port = 465;
	$mail->SMTPSecure = 'ssl';
	$mail->SMTPAuth = true;
	$mail->Username = 'noreply@jmsb.co.id';
	$mail->Password = 'misbbo11';
	$mail->setFrom('noreply@jmsb.co.id', 'E-CRF & DRAF System');

while ($data=mysqli_fetch_assoc($sql)) {

    $section 	= $data['sectionName'];
    $mailto		= $data['mailto'];
    $mailto_1	= $data['mailto_1'];
    $mailcc		= $data['mailcc'];

	$mail->addAddress($mailto);
	$mail->addCC($mailto_1);
	$mail->addBCC($mailcc);
	

	$sql2 = mysqli_query($conn, "SELECT cr.draft_no, cr.title, sc.mailto, sc.mailto_1, sc.mailcc, cr.issue_date,
	date_format(cr.issue_date,'%d %b %y') AS issue_date, 
	date_format((cr.issue_date + interval '6' month),'%d %b %y') AS deadline,
	abs(datediff((cr.issue_date + interval '6' month),current_date())) AS selisih,
	cr.section,
	cr.initiaded, cr.status FROM draf cr, sectioncode sc WHERE cr.section=sc.id 
	AND cr.status!= '3' AND cr.status !='0' AND datediff((cr.issue_date + interval '6' month),current_date()) < 0
	AND (cr.issue_date + interval '6' month) >= NOW() - INTERVAL 3 YEAR AND cr.section = $data[section]
	ORDER BY cr.draf_kd");

	//$mail->AddEmbeddedImage('img/2u_cs_mini.jpg', 'logo_2u');
	$mail->Subject = 'Notification from E-CRF & DRAF System';
	$body = "<html>
    <head>
    <title>Student Data</title>
     <style>
     table {
     border-collapse: collapse;
     width: 100%;
     }

    th {
    border: 1px solid #ddd;
    text-align: left;
    padding: 8px;
    color:black
     }

    td {
    border: 1px solid #4CAF50;
    text-align: left;
    padding: 8px;
    color:black
     }

    tr:nth-child(even){background-color: #f2f2f2}

    th {
	background-color: #4CAF50;
	color: white;
    }
  </style>
  </head>
  <body>
  Dear <b>".$section."</b>, <br><br>
			As per our QP BQMS/PRO/AK , Production, Process & Design Change deviation & Failure Control 
			Lead-time of closing DRAF shall not exceed more than 6months; otherwise a new DRAF shall be initiated for extension of deviation period.
			Lead Time of closing CRF shall not  exceed more than 2 months, unless otherwise stated in CRF.
			<br>
			Please be reminded to feedback IRP and deviation report  for the below outstanding CRF/DRAF.
			<br><br>
   <table>
  	<thead>
    <tr>
      <th>DRAF Ref No</th>
      <th>DRAF Title</th>
      <th>Issue Date</th>
      <th>Deadline Report</th>
      <th>Late<br>(Days)</th>
      <th>Initiated By</th>
    </tr>
  </thead>
  <tbody>";

while( $row = mysqli_fetch_assoc( $sql2 ) ){ 

      $body.= "<tr> 
      <td>".$row['draft_no']."</td>
      <td>".$row['title']."</td>
      <td>".$row['issue_date']."</td>
      <td>".$row['deadline']."</td>
      <td>".$row['selisih']."</td>
      <td>".$row['initiaded']."</td>
      </tr>";  
   }

   $body.="</tbody></table>
   <br><br>
  Thanks & Best Regards, <br>
	 E-CRF & DRAF System
   </body></html>";
   
    $mail->Body = $body;
    $mail->Priority = 1;
		$mail->AltBody = 'Welcome at E-CRF & DRAF System';

        if (!$mail->send()) {

          echo "Mailer Error: " . $mail->ErrorInfo;

        }

  $mail->clearAddresses();
	$mail->ClearCCs();
	$mail->ClearBCCs();
	}
  
?>