<script>
function confirmlogout(delUrl) {
   if (confirm("Are you sure to Logout from system?")) {
      document.location = delUrl;
   }
}
</script>
<?php
include "config/koneksi.php";
include "config/library.php";
include "config/fungsi_indotgl.php";
include "config/fungsi_tanggal.php";
include "config/fungsi_combobox.php";
include "config/class_paging.php";
include "config/fungsi_thumb.php";

// Bagian Home
if ($_SESSION['leveluser']=='admin' OR $_SESSION['leveluser']=='user'  ) {
if ($_GET['module']=='home') {
	echo "<div align=center><h2>Login as : $_SESSION[nama_section] </h2>
			<p>Welcome at CRF System PT. JMS Batam.<br>
			 </p>
			 <p><small>Login : $hari_ini, ";
  echo tgl_indo(date("Y m d")); 
  echo " | "; 
   date_default_timezone_set("Asia/Jakarta");
  echo date("H:i:s");
  echo " WIB</small></p>";
 //echo $_SESSION[jenisuser] ;
  if ($_SESSION['leveluser']=='admin'){
  
 echo"	<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=draf&act=>
		  <div class=menu_thumb><img src=images/new-icon/draf.png border=none>
		  <br/><b>DRAF</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index.php?module=deviation&act=>
		  <div class=menu_thumb><img src=images/new-icon/deviation.png border=none>
		  <br/><b>Deviation</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index.php?module=report&act=>
		  <div class=menu_thumb><img src=images/new-icon/log-draf.png border=none>
		  <br/><b>View Status Log DRAF</b></div></a></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=draf&act=appdraf>
		  <div class=menu_thumb><img src=images/new-icon/change-draf.png border=none>
		  <br/><b>Change Status Log DRAF</b></div></a></a></td>
		  
		  
    	</tr>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=crf&act=>
		  <div class=menu_thumb><img src=images/new-icon/crf.png border=none>
		  <br/><b>CRF</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index.php?module=irp&act=>
		  <div class=menu_thumb><img src=images/new-icon/irp.png border=none>
		  <br/><b>IRP</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index.php?module=report&act=report_crf>
		  <div class=menu_thumb><img src=images/new-icon/log-crf.png border=none>
		  <br/><b>View Status Log CRF</b></div></a></a></td> 
		  
		  <td width=120 align=center><a href=index.php?module=crf&act=appcrf>
		  <div class=menu_thumb><img src=images/new-icon/change-crf.png border=none>
		  <br/><b>Change Status Log CRF</b></div></a></a></td> 
    	</tr>
    	
		<tr>
		  <td width=120 align=center><a href=index.php?module=dcm&act=>
		  <div class=menu_thumb><img src=images/dcmmaster.png border=none>
		  <br/><b>Document Control Master</b></div></a></a></td>

		  <td width=120 align=center><a href=index.php?module=sectiondcm&act=>
		  <div class=menu_thumb><img src=images/sectiondcm.png border=none>
		  <br/><b>Data Section - DCM</b></div></a></a></td>
		
		  <td width=120 align=center><a href=index.php?module=section&act=>
		  <div class=menu_thumb><img src=images/new-icon/section.png border=none>
		  <br/><b>Data Section</b></div></a></a></td>

		  <td width=120 align=center><a href=index.php?module=doc_code&act=>
		  <div class=menu_thumb><img src=images/new-icon/doc-code.png border=none>
		  <br/><b>Document Code</b></div></a></a></td>
		
		</tr>

		<tr>  
		<td width=120 align=center><a href=index.php?module=user&act=>
		  <div class=menu_thumb><img src=images/new-icon/management-user.png border=none>
		  <br/><b>Management User</b></div></a></a></td>	
		  
		  <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/new-icon/account-info.png border=none>
		  <br/><b>Account Info</b></div></a></td> 

		  <td width=120 align=center><a href=index.php?module=draf&act=importdraf>
		  <div class=menu_thumb><img src=images/new-icon/excel.png border=none>
		  <br/><b>Import DRAF</b></div></a></a></td>

		  <td width=120 align=center><a href=index.php?module=crf&act=importcrf>
		  <div class=menu_thumb><img src=images/new-icon/excel.png border=none>
		  <br/><b>Import CRF</b></div></a></a></td>
		</tr>	
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=employee>
		  <div class=menu_thumb><img src=images/new-icon/emp-data.png border=none>
		  <br/><b>Employee Data</b></div></a></a></td>
		  
		 <td width=120 align=center><a href='http://svr05:8080/jmscrf/manual/CRF_DRAF_Manual_Book.pdf' target=_blank>
		  <div class=menu_thumb><img src=images/new-icon/user-guide.png border=none>
		  <br/><b>User Guide</b></div></a></td>
		</tr>	
		
    </table>
		
	
	
	";

  } else 
   if ($_SESSION['leveluser']=='user'){
   	
   	if ($_SESSION['jenisuser']==2){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=draf&act=>
		  <div class=menu_thumb><img src=images/new-icon/draf.png border=none>
		  <br/><b>DRAF</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index.php?module=deviation&act=>
		  <div class=menu_thumb><img src=images/new-icon/deviation.png border=none>
		  <br/><b>Deviation</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index.php?module=report&act=>
		  <div class=menu_thumb><img src=images/new-icon/log-draf.png border=none>
		  <br/><b>View Status Log DRAF</b></div></a></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=draf&act=appdraf>
		  <div class=menu_thumb><img src=images/new-icon/change-draf.png border=none>
		  <br/><b>Change Status Log DRAF</b></div></a></a></td>
    	</tr>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=crf&act=>
		  <div class=menu_thumb><img src=images/new-icon/crf.png border=none>
		  <br/><b>CRF</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index.php?module=irp&act=>
		  <div class=menu_thumb><img src=images/new-icon/irp.png border=none>
		  <br/><b>IRP</b></div></a></a></td>
		  	
		  <td width=120 align=center><a href=index.php?module=report&act=report_crf>
		  <div class=menu_thumb><img src=images/new-icon/log-crf.png border=none>
		  <br/><b>View Status Log CRF</b></div></a></a></td> 
		  
		  <td width=120 align=center><a href=index.php?module=crf&act=appcrf>
		  <div class=menu_thumb><img src=images/new-icon/change-crf.png border=none>
		  <br/><b>Change Status Log CRF</b></div></a></a></td>
    	</tr>
    	
		<tr>
		
		
		  <td width=120 align=center><a href=index.php?module=section&act=>
		  <div class=menu_thumb><img src=images/new-icon/section.png border=none>
		  <br/><b>Section Data</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=doc_code&act=>
		  <div class=menu_thumb><img src=images/new-icon/doc-code.png border=none>
		  <br/><b>Document Code</b></div></a></a></td>
		  
		   <td width=120 align=center><a href=index.php?module=deviation&act=dev_qms>
		  <div class=menu_thumb><img src=images/new-icon/view-deviation.png border=none>
		  <br/><b>View All Deviation</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=irp&act=irp_qms>
		  <div class=menu_thumb><img src=images/new-icon/view-irp.png border=none>
		  <br/><b>View All IRP</b></div></a></a></td>
		  
		</tr>	
		<tr>
		
		  
		  <td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/new-icon/account-info.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
		  <td width=120 align=center><a href='http://svr05:8080/jmscrf/manual/CRF_DRAF_Manual_Book.pdf' target=_blank>
		  <div class=menu_thumb><img src=images/new-icon/user-guide.png border=none>
		  <br/><b>User Guide</b></div></a></td>
		</tr>
    </table>
	
	";
/*
		   <td width=120 align=center><a href=index.php?module=deviation&act=valldraf_qms>
		  <div class=menu_thumb><img src=images/v_deviation.png border=none>
		  <br/><b>View All DRAF</b></div></a></a></td>
		  
		  <td width=120 align=center><a href=index.php?module=irp&act=vallcrf_qms>
		  <div class=menu_thumb><img src=images/v_irp.png border=none>
		  <br/><b>View All CRF</b></div></a></a></td>*/
  } else 
  	if ($_SESSION['jenisuser']==3){
  
 echo"		<table cellspacing=15 cellpadding=6 width='100%'>
		<th colspan=8 class=title_cpanel>Control Panel</th>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=draf&act=>
		  <div class=menu_thumb><img src=images/new-icon/draf.png border=none>
		  <br/><b>DRAF</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index.php?module=deviation&act=>
		  <div class=menu_thumb><img src=images/new-icon/deviation.png border=none>
		  <br/><b>Deviation</b></div></a></a></td>
		 
		   <td width=120 align=center><a href=index.php?module=report&act=report_draf2>
		  <div class=menu_thumb><img src=images/new-icon/log-draf.png border=none>
		  <br/><b>Status Log DRAF</b></div></a></a></td>
    	</tr>
		
		<tr>
		 <td width=120 align=center><a href=index.php?module=crf&act=>
		  <div class=menu_thumb><img src=images/new-icon/crf.png border=none>
		  <br/><b>CRF</b></div></a></a></td>
		  		 
		   <td width=120 align=center><a href=index.php?module=irp&act=>
		  <div class=menu_thumb><img src=images/new-icon/irp.png border=none>
		  <br/><b>IRP</b></div></a></a></td>
		  	
		  	 <td width=120 align=center><a href=index.php?module=report&act=report_crf2>
		  <div class=menu_thumb><img src=images/new-icon/log-crf.png border=none>
		  <br/><b>Status Log CRF</b></div></a></a></td> 	  
		  
    	</tr>
    	<tr>
		
		<td width=120 align=center><a href=index.php?module=user&act=akunuser>
		  <div class=menu_thumb><img src=images/new-icon/account-info.png border=none>
		  <br/><b>Account Info</b></div></a></td>
		  
		  <td width=120 align=center><a href='http://svr05:8080/jmscrf/manual/CRF_DRAF_Manual_Book.pdf' target=_blank>
		  <div class=menu_thumb><img src=images/new-icon/user-guide.png border=none>
		  <br/><b>User Guide</b></div></a></td>
		
		</tr>	
				
    </table>
	
	";

  }
 }
}

// Bagian User
 /*elseif ($_GET[module]=='user') {
	include "modul/mod_user/user.php";
	
	 <td width=120 align=center>
		   <a href=javascript:confirmdelete('logout.php')><div class=menu_thumb>
		   <img src=images/big_logout.png border=none>
		  <br/><b>Logout</b></div></a>
		 </td>
}
}*/
// Bagian Modul

elseif ($_GET['module']=='crf') {
	include "modul/mod_crf/crf.php";
}
elseif ($_GET['module']=='deviation') {
	include "modul/mod_deviation/deviation.php";
}
elseif ($_GET['module']=='irp') {
	include "modul/mod_irp/irp.php";
}
elseif ($_GET['module']=='employee') {
	include "modul/mod_employee/employee.php";
} 
elseif ($_GET['module']=='section') {
	include "modul/mod_section/section.php";
} 
elseif ($_GET['module']=='draf') {
	include "modul/mod_draf/draf.php";
}
elseif ($_GET['module']=='doc_code') {
	include "modul/mod_doc_code/doc_code.php";
}
elseif ($_GET['module']=='report') {
	include "modul/mod_report/report.php";
}

elseif ($_GET['module']=='jenisuser') {
	include "modul/mod_jenisuser/jenisuser.php";
}
elseif ($_GET['module']=='identitas') {
	include "modul/mod_identitas/identitas.php";
}
elseif ($_GET['module']=='dcm') {
	include "modul/mod_dcm/dcm.php";
}
elseif ($_GET['module']=='sectiondcm') {
	include "modul/mod_sectiondcm/sectiondcm.php";
}

// Bagian Modul
elseif ($_GET['module']=='phpmyadmin') {
	include "modul/mod_phpmyadmin/phpmyadmin.php";
}

elseif ($_GET['module']=='autocomplete') {
	include "modul/mod_autocomplete/barang.php";
}



else if ($_GET['module'] == 'logout') {
	include "logout.php";
}

else if ($_GET['module'] == 'identitas') {
	include "identitas.php";
}
else if ($_GET['module'] == 'rdatabase') {
	include "rdatabase.php";
}
else if ($_GET['module'] == 'konfigurasi') {
	include "setting.php";
}
// Bagian provinsi

// Bagian User
else	if ($_GET['module']=='user') {
		include "modul/mod_user/user.php";
}
// Bagian Modul
	elseif ($_GET['module']=='modul') {
		include "modul/mod_modul/modul.php";
}
// Bagian Modul
	elseif ($_GET['module']=='backup') {
		include "modul/mod_backup/backup.php";
}


}

?>