<?php
include"../config/koneksi.php";

$kode3	= $_POST['kode3'];

$sql 	= mysqli_query($conn, "SELECT *from employee where empname='$kode3'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
		$data['kode3'] = $r['empno'];
		$data['nama'] = $r['empname'];
			
	echo json_encode($data);
}else{
		$data['kode3'] = '';
		$data['nama'] = '';
				
	echo json_encode($data);
}
?>
