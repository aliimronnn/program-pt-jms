<?php
include"../config/koneksi.php";

$kode	= $_POST['kode'];

$sql 	= mysqli_query($conn, "SELECT * from crf where status ='0' and crf_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title'] = $r['title'];
	$data['id'] = $r['id'];
	//$data['issue_date'] = $r['issue_date'];
	$data['hobi'] = $r['hobi'];
	$data['hobi2'] = $r['hobi2'];
	$data['section'] = $r['section'];
		
		
	echo json_encode($data);
}else{
	$data['title'] = '';
	$data['id'] = '';
	//$data['issue_date'] = '';
	$data['section'] = '';
	$data['hobi'] = '';
	$data['hobi2'] = '';
	
	echo json_encode($data);
}
?>
