<?php
include"../config/koneksi.php";

$kode	= $_POST['kode_unapp'];

$sql 	= mysqli_query($conn, "SELECT *from crf where status ='1' and crf_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title33'] = $r['title'];
	$data['id33'] = $r['id'];
	$data['section33'] = $r['section'];
		
		
	echo json_encode($data);
}else{
	$data['title33'] = '';
	$data['id33'] = '';
	$data['section33'] = '';

	echo json_encode($data);
}
?>
