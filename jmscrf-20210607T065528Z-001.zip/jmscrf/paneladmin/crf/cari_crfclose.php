<?php
include"../config/koneksi.php";

$kode	= $_POST['kode_close'];

$sql 	= mysqli_query($conn, "SELECT * from crf where status in ('1','2') and crf_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title2'] = $r['title'];
	$data['id2'] = $r['id'];
	$data['section2'] = $r['section'];
		
		
	echo json_encode($data);
}else{
	$data['title2'] = '';
	$data['id2'] = '';
	$data['section2'] = '';

	echo json_encode($data);
}
?>
