<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT * from crf where status !='0' and crf_no LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$crf_no = $r['crf_no'];
	
	echo "$crf_no\n";
}
?>
