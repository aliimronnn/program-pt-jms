<?php
include "config/koneksi.php";

function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['id_user']);
$pass     = anti_injection($_POST['password']);

// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  //echo "Sekarang loginnya tidak bisa di injeksi lho.";
  header('location:index_pegawai.php');
}
else {

	//if (trim($_POST[jenis_user])=='pegawai') {

		//$pass=md5($_POST[password]);
		$login = mysql_query("SELECT * FROM pegawai WHERE username='$username' AND password='$pass' ");
		$ketemu=mysql_num_rows($login);
		$r=mysql_fetch_array($login);
		
       $s=mysql_fetch_array(mysql_query("SELECT * FROM jenis_user WHERE id='$r[id_jenisuser]'"));
	// Apabila username dan password ditemukan
		if ($ketemu > 0) {
			session_start();
			//session_register("namauser");
			//session_register("namalengkap");
			//session_register("passuser");
			//session_register("leveluser");
		       $_SESSION[nip]    = $r[nip];
			 $_SESSION[pegawai] = $r[id];
                  $_SESSION[user]    = $s[jenis_user];
			$_SESSION[namauser]    = $r[id_user];
			$_SESSION[namalengkap] = $r[nama];
			$_SESSION[jenisuser] = $r[id_jenisuser];
			$_SESSION[passuser]    = $r[password];
			$_SESSION[leveluser]   = 'pegawai';
		
			header('location:index.php?module=logpegawai');
		}
		else
		{
			echo "<link href=config/adminstyle.css rel=stylesheet type=text/css>";
			echo "<center>LOGIN GAGAL! <br>
				Username atau Password Anda tidak benar.<br>
				Atau Account Anda sedang diblokir.<br>";
			echo "<a href=index_pegawai.php><b>ULANGI LAGI</b></a></center>";
		}
	//}

	
}
?>