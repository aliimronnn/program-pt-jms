<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#crf_noclose").autocomplete("crf/proses_crfclose.php", {
		width: 300
	});
	
	$("#crf_noclose").result(function(event, data, formatted) {
		var kode_close	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode_close="+kode_close,
			url 	: "crf/cari_crfclose.php",
			dataType: "json",
			success: function(data){
				$("#kode_close").val(data.kode_close);
				$("#id2").val(data.id2);
				$("#title2").val(data.title2);
				$("#section2").val(data.section2);
			
				
			
			}
		});
	});
	$("#crf_noclose").keyup(function() {
		var kode_close	= $('#crf_noclose').val();
		$.ajax({
			type	: "POST",
			data	: "kode_close="+kode_close,
			url 	: "crf/cari_crfclose.php",
			dataType: "json",
			success: function(data){
				
					$("#kode_close").val(data.kode_close);
					$("#title2").val(data.title2);
					$("#id2").val(data.id2);
					$("#section2").val(data.section2);
									
			}
		});
	});
	
});
</script>
</head>
<body>
   
  
  <input type="hidden" id="id2" name="id_crf2">
 	  
 <tr><td>CRF No.</td><td>: <input type="text" id="crf_noclose" name="crf_noclose" size="40"><small>*) Fill CRF No</small></small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title2" name="title2" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">:  <input type="text" id="section2" name="section2" size="50"></td></tr>
   
</body>
</html>
