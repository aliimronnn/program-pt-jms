<?php
include "config/koneksi.php";
include "config/fungsi_indotgl.php";
$login = mysql_fetch_array(mysql_query("SELECT * FROM identitas WHERE judul='loginpegawai'"));
?>
<html>
<head>
<title>LOGIN FORM PEGAWAI</title>
<link href="css/adminstyle.css" rel="stylesheet" type="text/css" />
<script language="javascript">
function validasi(form){
  if (form.username.value == ""){
    alert("Anda belum mengisikan Username.");
    form.username.focus();
    return (false);
  }
     
  if (form.password.value == ""){
    alert("Anda belum mengisikan Password.");
    form.password.focus();
    return (false);
  }
  return (true);
}
</script>

<script type="text/javascript">	
	//fungsi displayTime yang dipanggil di bodyOnLoad dieksekusi tiap 1000ms = 1detik
	function displayTime(){
		//buat object date berdasarkan waktu saat ini
		var time = new Date();
		//ambil nilai jam, 
		//tambahan script + "" supaya variable sh bertipe string sehingga bisa dihitung panjangnya : sh.length
		var sh = time.getHours() + ""; 
		//ambil nilai menit
		var sm = time.getMinutes() + "";
		//ambil nilai detik
		var ss = time.getSeconds() + "";
		//tampilkan jam:menit:detik dengan menambahkan angka 0 jika angkanya cuma satu digit (0-9)
		document.getElementById("clock").innerHTML = (sh.length==1?"0"+sh:sh) + ":" + (sm.length==1?"0"+sm:sm) + ":" + (ss.length==1?"0"+ss:ss);
	}
</script>


</head>
<body OnLoad="document.login.username.focus();" >
	<div id="logincontent">
        <div id="loginForm">
            <form name="login" action="cek_pegawai.php" method="POST" onSubmit="return validasi(this)">
                 <table border="0"><tr ><td valign='top' colspan=3 align=center>			   
			 
				 <?php
				 echo $login[identitas];
				 ?><br> 
                  <span style='font-size: medium; color: #5F9EAD;'>
				 <?php 
				  //echo "<span style='font-size: medium; color: #5F9EAD;'>". tgl_indo(date("Y m d"))."</span>"; 
				include "head.php";
				                  
               
				 ?> </span><br>
				</td></tr>
				 <tr ><td>&nbsp;&nbsp;
              </td><td> <span style='font-size: medium; color: #008B8B;'><strong>Username</strong></span></td><td>
                <input type="text" name="id_user" /><td>
                </tr>
				 <tr ><td>&nbsp;&nbsp; </td><td><span style='font-size: medium; color:#008B8B;'><strong>Password</strong></span></td><td>
                <input type="password" name="password" />
                </td></tr><tr><td colspan=3 align=center><br>
                <input type="submit" value="Login" class="large blue super button"/>&nbsp;&nbsp;&nbsp;
                <input type="button" value="SI KSOP" onClick="javascript: location.href = 'index_login.php';" class="large orange super button"/></td></tr></table>
                
            </form>
        </div>
	</div>
	<div id="footer">Copyright &copy; 2014 by <a href="http://ksoptanjungemas.diphub.go.id">KSOP Tanjung Emas Semarang </a>. All rights reserved.</div>
</body>
</html>
