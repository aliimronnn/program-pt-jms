<?php
include"../config/koneksi.php";
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT * from employee where empno LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$empno = $r['empno'];
	
	echo "$empno\n";
}
?>
