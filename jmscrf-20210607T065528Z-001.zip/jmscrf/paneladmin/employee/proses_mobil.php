<?php
include"../config/koneksi.php";
$q = strtolower($_GET["q"]);
if (!$q) return;

$sql = mysql_query("select dk.*, sp.nama as sumber from datakendaraan dk, supplier sp where dk.sumber=sp.id and dk.nama LIKE '%$q%'");
while($r = mysql_fetch_array($sql)) {
	$kode_barang = $r['nama'];
	$sumber = $r['sumber'];
	echo "$kode_barang\n";
}
?>
