<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#draft_no2").autocomplete("draf/proses_drafclose.php", {
		width: 300
	});
	
	$("#draft_no2").result(function(event, data, formatted) {
		var kodeclose	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kodeclose="+kodeclose,
			url 	: "draf/cari_drafclose.php",
			dataType: "json",
			success: function(data){
				$("#kodeclose").val(data.kodeclose);
				$("#id2").val(data.id2);
				$("#title2").val(data.title2);
				$("#section2").val(data.section2);
				
				
			
			}
		});
	});
	$("#draft_no2").keyup(function() {
		var kodeclose	= $('#draft_no2').val();
		$.ajax({
			type	: "POST",
			data	: "kodeclose="+kodeclose,
			url 	: "draf/cari_drafclose.php",
			dataType: "json",
			success: function(data){
				
					$("#kodeclose").val(data.kodeclose);
					$("#title2").val(data.title2);
					$("#id2").val(data.id2);
					$("#section2").val(data.section2);
									
			}
		});
	});
	
});
</script>
</head>
<body>
 <input type="hidden" id="id2" name="id_draf2">
  
 <tr><td>DRAF No.</td><td>: <input type="text" id="draft_no2" name="draft_no2" size="40"> *) <small>Fill DRAF No. </small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title2" name="title2" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">: <input type="text" id="section2" name="section2" readonly size="30"></td></tr>
 
   
</body>
</html>
