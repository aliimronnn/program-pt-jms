<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysql_query("select *from deviation where draf_no LIKE '%$q%'");
while($r = mysql_fetch_array($sql)) {
	$draft_no = $r['draf_no'];
	
	echo "$draft_no\n";
}
?>
