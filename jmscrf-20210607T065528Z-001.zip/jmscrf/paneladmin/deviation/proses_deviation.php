<?php
include"../config/koneksi.php";
session_start();
$q = strtolower($_GET['q']);
if (!$q) return;

$sql = mysqli_query($conn, "SELECT dev.* from deviation dev, draf dr where dev.id_draf=dr.id and dr.draf_kd='$_SESSION[draf_kd]' and 
dr.draft_no LIKE '%$q%'");
while($r = mysqli_fetch_array($sql)) {
	$draft_no = $r['draf_no'];
	
	echo "$draft_no\n";
}
?>
