<?php
include"../config/koneksi.php";

$kode	= $_POST['kode'];

$sql 	= mysqli_query($conn, "SELECT *from deviation where draf_no = '$kode'");
$row	= mysqli_num_rows($sql);
if($row>0){
	$r = mysqli_fetch_array($sql);
	$data['title'] = $r['title'];
	$data['id'] = $r['id'];
			
	echo json_encode($data);
}else{
	$data['title'] = '';
	$data['id'] = '';

	
	echo json_encode($data);
}
?>
