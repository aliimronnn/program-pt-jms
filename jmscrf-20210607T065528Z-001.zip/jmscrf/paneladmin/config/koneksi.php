<?php
// Koneksi dan memilih database di server
/*
$server = "localhost";
$username = "root";
$password = "";
$database = "db_crf";
*/
$server = "svr04";
$username = "jmsbadmin";
$password = "MISbbo11";
$database = "db_crf";

$conn = mysqli_connect($server,$username,$password,$database) or die("Connection Failed!");
?>