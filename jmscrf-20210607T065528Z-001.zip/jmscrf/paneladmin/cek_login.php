<?php
include "config/koneksi.php";

function anti_injection($data){
  $filter = (stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['id_user']);
$pass     = anti_injection(md5($_POST['password']));

// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  //echo "Sekarang loginnya tidak bisa di injeksi lho.";
  header('location:index_login.php');
}
else {

	//if (trim($_POST[jenis_user])=='pegawai') {

		//$pass=md5($_POST[password]);
		$login = mysqli_query($conn, "SELECT *FROM users WHERE id_user='$username' AND password='$pass' AND blokir='N'");
		$ketemu=mysqli_num_rows($login);
		$r=mysqli_fetch_array($login);
       $s=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM jenis_user WHERE id='$r[id_jenisuser]'"));
       $nama=mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM sectioncode WHERE id='$r[section]'"));
       
	// Apabila username dan password ditemukan
		if ($ketemu > 0) {
			session_start();
			//session_register("namauser");
			//session_register("namalengkap");
			//session_register("passuser");
			//session_register("leveluser");
		   // $_SESSION[nip]    = $r[nip];
            $_SESSION[user]    = $s[jenis_user];
			$_SESSION[namauser]    = $r[id_user];
			//$_SESSION[namalengkap] = $nama[empname];
			$_SESSION[jenisuser] = $r[id_jenisuser];
			$_SESSION[passuser]    = $r[password];
			$_SESSION[leveluser]   = $r[level];
			$_SESSION[section]   = $nama[id];
			$_SESSION[draf_kd]   = $nama[draf];
			$_SESSION[crf_kd]   = $nama[crf];
			$_SESSION[nama_section]   = $nama[section];
			//$_SESSION[empno]   = $r[nip];
		
			header('location:index.php?module=home');
		}
		else
		{
			echo "<link href=config/adminstyle.css rel=stylesheet type=text/css>";
			echo "<center>LOGIN FAILED! <br>
				The combination of Username & Password is not correct!<br>
				Or Your account has been blocked!<br>";
			echo "<a href=index_login.php><b>Try Again</b></a></center>";
		}
	//}

	
}
?>