<html>
<head>
<script type="text/javascript" src="jquery-1.4.js"></script>
<script type='text/javascript' src='jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="jquery.autocomplete.css" />
<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript">
$(document).ready(function() {	
	$("#crf_all").autocomplete("crf/proses_crfall.php", {
		width: 300
	});
	
	$("#crf_all").result(function(event, data, formatted) {
		var kode4	= formatted;
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "crf/cari_crfall.php",
			dataType: "json",
			success: function(data){
				$("#kode4").val(data.kode4);
				$("#id4").val(data.id4);
				$("#title4").val(data.title4);
				$("#section4").val(data.section4);
				
				
			
			}
		});
	});
	$("#crf_all").keyup(function() {
		var kode4	= $('#crf_all').val();
		$.ajax({
			type	: "POST",
			data	: "kode4="+kode4,
			url 	: "crf/cari_crfall.php",
			dataType: "json",
			success: function(data){
				
					$("#kode4").val(data.kode4);
					$("#title4").val(data.title4);
					$("#id4").val(data.id4);
					$("#section4").val(data.section4);
									
			}
		});
	});
	
});
</script>
</head>
<body>
 <input type="hidden" id="id4" name="id_crf4">
  
 <tr><td>CRF No.</td><td>: <input type="text" id="crf_all" name="crf_all" size="40"> *) <small>Fill CRF No. </small></td></tr>
 <tr><td>Title</td><td valign="center">: <textarea id="title4" name="title4" readonly cols="60" rows="3"></textarea></td></tr>
 <tr><td>Section</td><td valign="center">: <input type="text" id="section4" name="section4" readonly size="30"></td></tr>
 
   
</body>
</html>
